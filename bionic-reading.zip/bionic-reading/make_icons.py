from PIL import Image, ImageDraw

INK = (20, 22, 28, 255)
FULL = (255, 255, 255, 255)
FADE = (round(20 + 235 * 0.36), round(22 + 233 * 0.36), round(28 + 227 * 0.36), 255)
SS = 8


def draw_icon(size):
    s = size * SS
    img = Image.new("RGBA", (s, s), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    d.rounded_rectangle([0, 0, s - 1, s - 1], radius=s * 0.22, fill=INK)

    bars = 2 if size <= 32 else 3
    inset = s * 0.17
    left = inset
    right = s - inset
    width = right - left

    if bars == 2:
        bar_h = s * 0.17
        gap = s * 0.15
        widths = [1.0, 0.68]
    else:
        bar_h = s * 0.115
        gap = s * 0.105
        widths = [1.0, 0.92, 0.6]

    total = bars * bar_h + (bars - 1) * gap
    y = (s - total) / 2

    for i in range(bars):
        w = width * widths[i]
        split = w * 0.4
        r = bar_h * 0.35
        d.rounded_rectangle([left, y, left + split, y + bar_h], radius=r, fill=FULL)
        d.rounded_rectangle([left + split + s * 0.02, y, left + w, y + bar_h], radius=r, fill=FADE)
        y += bar_h + gap

    return img.resize((size, size), Image.LANCZOS)


for size in (16, 32, 48, 128):
    draw_icon(size).save("icons/%d.png" % size)
print("ok")
