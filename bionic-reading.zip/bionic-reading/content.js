const SKIP_TAGS = new Set([
  "SCRIPT", "STYLE", "NOSCRIPT", "TEXTAREA", "INPUT", "SELECT", "OPTION",
  "CODE", "PRE", "KBD", "SAMP", "VAR", "IFRAME", "CANVAS", "SVG", "MATH",
  "TITLE", "BIONIC-W", "BIONIC-F", "BIONIC-T"
]);

const WORD_RE = /[\p{L}\p{N}]+(?:['\u2019][\p{L}\p{N}]+)*/gu;
const HAS_WORD_RE = /[\p{L}\p{N}]/u;
const LETTER_RE = /\p{L}/u;
const CHUNK = 150;

const settings = { ratio: 40, tail: 65, sites: [] };
let active = false;
let observer = null;
let queue = [];
let scheduled = false;

function boldLength(word) {
  const n = word.length;
  if (n <= 1) return n;
  const k = Math.round((n * settings.ratio) / 100);
  return Math.max(1, Math.min(n - 1, k));
}

function eligible(node) {
  if (!node.nodeValue || !HAS_WORD_RE.test(node.nodeValue)) return false;
  const parent = node.parentElement;
  if (!parent) return false;
  if (SKIP_TAGS.has(parent.tagName)) return false;
  if (parent.isContentEditable) return false;
  if (parent.closest("bionic-w, code, pre, textarea, [translate=no], [contenteditable]:not([contenteditable=false])")) return false;
  return true;
}

function collect(root) {
  const found = [];
  if (!root) return found;
  if (root.nodeType === Node.TEXT_NODE) {
    if (eligible(root)) found.push(root);
    return found;
  }
  if (root.nodeType !== Node.ELEMENT_NODE && root.nodeType !== Node.DOCUMENT_NODE) return found;
  const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, {
    acceptNode(node) {
      return eligible(node) ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_REJECT;
    }
  });
  let node;
  while ((node = walker.nextNode())) found.push(node);
  return found;
}

function transform(node) {
  if (!node.parentNode) return;
  const text = node.nodeValue;
  const wrap = document.createElement("bionic-w");
  let last = 0;
  let match;
  WORD_RE.lastIndex = 0;
  while ((match = WORD_RE.exec(text))) {
    const word = match[0];
    if (match.index > last) {
      wrap.appendChild(document.createTextNode(text.slice(last, match.index)));
    }
    last = match.index + word.length;
    if (!LETTER_RE.test(word)) {
      wrap.appendChild(document.createTextNode(word));
      continue;
    }
    const cut = boldLength(word);
    const head = document.createElement("bionic-f");
    head.textContent = word.slice(0, cut);
    wrap.appendChild(head);
    if (cut < word.length) {
      const tail = document.createElement("bionic-t");
      tail.textContent = word.slice(cut);
      wrap.appendChild(tail);
    }
  }
  if (last < text.length) wrap.appendChild(document.createTextNode(text.slice(last)));
  node.parentNode.replaceChild(wrap, node);
}

function flush() {
  scheduled = false;
  if (!active) {
    queue = [];
    return;
  }
  const batch = queue.splice(0, CHUNK);
  for (const node of batch) transform(node);
  if (queue.length) schedule();
}

function schedule() {
  if (scheduled) return;
  scheduled = true;
  if (typeof requestIdleCallback === "function") {
    requestIdleCallback(flush, { timeout: 200 });
  } else {
    setTimeout(flush, 0);
  }
}

function enqueue(nodes) {
  if (!nodes.length) return;
  queue = queue.concat(nodes);
  schedule();
}

function applyVars() {
  document.documentElement.style.setProperty("--bx-tail", settings.tail);
}

function watch() {
  if (observer) return;
  observer = new MutationObserver((records) => {
    if (!active) return;
    const pending = [];
    for (const record of records) {
      for (const added of record.addedNodes) {
        if (added.nodeType === Node.ELEMENT_NODE && added.tagName.startsWith("BIONIC-")) continue;
        pending.push(...collect(added));
      }
      if (record.type === "characterData" && eligible(record.target)) {
        pending.push(record.target);
      }
    }
    enqueue(pending);
  });
  observer.observe(document.documentElement, {
    childList: true,
    subtree: true,
    characterData: true
  });
}

function unwatch() {
  if (!observer) return;
  observer.disconnect();
  observer = null;
}

function enable() {
  if (active) return;
  active = true;
  applyVars();
  enqueue(collect(document.body));
  watch();
  report();
}

function disable() {
  if (!active) return;
  active = false;
  unwatch();
  queue = [];
  const parents = new Set();
  for (const wrap of document.querySelectorAll("bionic-w")) {
    const parent = wrap.parentNode;
    if (!parent) continue;
    parent.replaceChild(document.createTextNode(wrap.textContent), wrap);
    parents.add(parent);
  }
  for (const parent of parents) parent.normalize();
  report();
}

function restyle() {
  if (!active) {
    applyVars();
    return;
  }
  disable();
  enable();
}

function report() {
  chrome.runtime.sendMessage({ type: "state", on: active }).catch(() => {});
}

function hostname() {
  try {
    return new URL(location.href).hostname;
  } catch (err) {
    return "";
  }
}

chrome.runtime.onMessage.addListener((message, sender, respond) => {
  if (message.type === "query") {
    respond({ on: active, host: hostname() });
    return true;
  }
  if (message.type === "set") {
    if (message.on) enable();
    else disable();
    respond({ on: active });
    return true;
  }
  if (message.type === "toggle") {
    if (active) disable();
    else enable();
    respond({ on: active });
    return true;
  }
  return false;
});

chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== "sync") return;
  let restyleNeeded = false;
  if (changes.ratio) {
    settings.ratio = changes.ratio.newValue;
    restyleNeeded = true;
  }
  if (changes.tail) {
    settings.tail = changes.tail.newValue;
    applyVars();
  }
  if (changes.sites) settings.sites = changes.sites.newValue || [];
  if (restyleNeeded) restyle();
});

chrome.storage.sync.get({ ratio: 40, tail: 65, sites: [] }).then((stored) => {
  settings.ratio = stored.ratio;
  settings.tail = stored.tail;
  settings.sites = stored.sites || [];
  applyVars();
  if (settings.sites.includes(hostname())) enable();
  else report();
});
