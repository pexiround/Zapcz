const BADGE_ON = "ON";

function badge(tabId, on) {
  if (tabId == null) return;
  chrome.action.setBadgeText({ tabId, text: on ? BADGE_ON : "" }).catch(() => {});
  chrome.action.setBadgeBackgroundColor({ tabId, color: "#2C2CE6" }).catch(() => {});
}

chrome.commands.onCommand.addListener(async (command) => {
  if (command !== "toggle-bionic") return;
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab || tab.id == null) return;
  try {
    await chrome.tabs.sendMessage(tab.id, { type: "toggle" });
  } catch (err) {
    badge(tab.id, false);
  }
});

chrome.runtime.onMessage.addListener((message, sender) => {
  if (message.type !== "state") return;
  if (sender.frameId !== 0) return;
  badge(sender.tab && sender.tab.id, message.on);
});
