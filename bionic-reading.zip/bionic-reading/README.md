# Bionic Reading

Bolds the leading letters of every word on a page so the eye has a fixation target, and fades the rest so the contrast actually reads.

## Install

1. Unzip the folder somewhere permanent (Chrome loads it from disk every launch).
2. Open `chrome://extensions`.
3. Turn on **Developer mode** (top right).
4. Click **Load unpacked** and pick this folder.
5. Pin the extension so the toolbar button is reachable.

## Use

- Click the toolbar button to open the panel, then flip the switch to convert the current tab.
- `Alt+B` toggles the active tab without opening the panel. Remap it at `chrome://extensions/shortcuts`.
- **Fixation** sets how much of each word is bolded (20–70% of its length).
- **Tail contrast** sets how visible the unbolded remainder is. Lower values push harder toward skimming.
- **Turn on automatically here** stores the hostname, so every page on that site converts on load.

Settings live in `chrome.storage.sync`, so they follow the Chrome profile across machines. The toolbar badge shows `ON` for tabs that are currently converted.

## How it works

`content.js` walks text nodes with a `TreeWalker`, skipping `script`, `style`, `pre`, `code`, form fields, `contenteditable` regions, and anything marked `translate=no`. Each eligible text node is replaced by a single `<bionic-w>` wrapper holding `<bionic-f>` (fixation) and `<bionic-t>` (tail) elements per word.

Custom element names are used instead of `<b>`/`<span>` so page stylesheets targeting real tags can't repaint them, and so screen readers get no extra semantics. `content.css` resets them with `all: unset` and applies `font-weight: bolder`, which steps relative to the inherited weight — headings that are already bold get 900, so the effect stays visible instead of flattening.

Reverting replaces each wrapper with a text node built from `wrapper.textContent`, then normalizes the parent. Since the transform only inserts elements and never alters characters, the DOM comes back byte-identical. Nodes added after the fact are picked up by a `MutationObserver` and processed in idle-time batches of 150.

Numbers with no letters are left alone, so prices and dates don't get half-bolded.

## Known limits

- Text inside a shadow root (some web components) isn't touched — the walker doesn't cross shadow boundaries.
- Sites that re-render aggressively from a virtual DOM may fight the wrappers; toggling off and on resettles the page.
- `chrome://` pages, the Web Store, and other restricted origins don't allow content scripts at all. The panel says so instead of failing silently.

## Regenerating icons

`python3 make_icons.py` rewrites `icons/*.png` from the geometry in that script. Pillow required.
