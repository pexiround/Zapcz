const SAMPLE = "Your eyes land on only a few points per line. Bolding the stem of each word gives them a target, and the rest of the word arrives from memory.";
const WORD_RE = /[\p{L}\p{N}]+(?:['\u2019][\p{L}\p{N}]+)*/gu;

const app = document.getElementById("app");
const blocked = document.getElementById("blocked");
const scope = document.getElementById("scope");
const toggle = document.getElementById("toggle");
const preview = document.getElementById("preview");
const ratio = document.getElementById("ratio");
const tail = document.getElementById("tail");
const ratioOut = document.getElementById("ratio-out");
const tailOut = document.getElementById("tail-out");
const always = document.getElementById("always");
const alwaysLabel = document.getElementById("always-label");

const state = { tabId: null, host: "", on: false, sites: [] };
let saveTimer = null;

function boldLength(word, percent) {
  const n = word.length;
  if (n <= 1) return n;
  return Math.max(1, Math.min(n - 1, Math.round((n * percent) / 100)));
}

function renderPreview() {
  const percent = Number(ratio.value);
  document.documentElement.style.setProperty("--tail", tail.value);
  preview.replaceChildren();
  if (!state.on) {
    preview.append(document.createTextNode(SAMPLE));
    return;
  }
  let last = 0;
  let match;
  WORD_RE.lastIndex = 0;
  while ((match = WORD_RE.exec(SAMPLE))) {
    const word = match[0];
    if (match.index > last) preview.append(SAMPLE.slice(last, match.index));
    const cut = boldLength(word, percent);
    const head = document.createElement("b");
    head.textContent = word.slice(0, cut);
    preview.append(head);
    if (cut < word.length) {
      const rest = document.createElement("span");
      rest.className = "tail";
      rest.textContent = word.slice(cut);
      preview.append(rest);
    }
    last = match.index + word.length;
  }
  if (last < SAMPLE.length) preview.append(SAMPLE.slice(last));
}

function renderControls() {
  toggle.setAttribute("aria-checked", String(state.on));
  ratioOut.textContent = ratio.value + "%";
  tailOut.textContent = tail.value + "%";
  always.checked = state.sites.includes(state.host);
  scope.textContent = state.host || "this page";
  alwaysLabel.textContent = state.host
    ? "Turn on automatically on " + state.host
    : "Turn on automatically here";
  renderPreview();
}

function saveSoon() {
  clearTimeout(saveTimer);
  saveTimer = setTimeout(() => {
    chrome.storage.sync.set({ ratio: Number(ratio.value), tail: Number(tail.value) });
  }, 120);
}

async function send(message, options) {
  if (state.tabId == null) throw new Error("no tab");
  return chrome.tabs.sendMessage(state.tabId, message, options || {});
}

toggle.addEventListener("click", async () => {
  const next = !state.on;
  try {
    const reply = await send({ type: "set", on: next });
    state.on = reply ? reply.on : next;
  } catch (err) {
    state.on = false;
  }
  renderControls();
});

always.addEventListener("change", async () => {
  if (!state.host) return;
  const sites = new Set(state.sites);
  if (always.checked) sites.add(state.host);
  else sites.delete(state.host);
  state.sites = [...sites];
  await chrome.storage.sync.set({ sites: state.sites });
  if (always.checked && !state.on) {
    try {
      await send({ type: "set", on: true });
      state.on = true;
    } catch (err) {
      state.on = false;
    }
  }
  renderControls();
});

for (const slider of [ratio, tail]) {
  slider.addEventListener("input", () => {
    ratioOut.textContent = ratio.value + "%";
    tailOut.textContent = tail.value + "%";
    renderPreview();
    saveSoon();
  });
}

async function init() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  const stored = await chrome.storage.sync.get({ ratio: 40, tail: 65, sites: [] });
  ratio.value = stored.ratio;
  tail.value = stored.tail;
  state.sites = stored.sites || [];

  if (!tab || tab.id == null) {
    blocked.hidden = false;
    return;
  }
  state.tabId = tab.id;
  try {
    state.host = new URL(tab.url).hostname;
  } catch (err) {
    state.host = "";
  }

  try {
    const reply = await send({ type: "query" }, { frameId: 0 });
    state.on = Boolean(reply && reply.on);
    if (reply && reply.host) state.host = reply.host;
  } catch (err) {
    blocked.hidden = false;
    return;
  }

  app.hidden = false;
  renderControls();
}

init().catch(() => {
  app.hidden = true;
  blocked.hidden = false;
});
