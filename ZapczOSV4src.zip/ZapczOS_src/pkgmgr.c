#include "pkgmgr.h"
#include "util.h"
#include "apps.h"
#include "fat32.h"
#include "desktop.h"
#include "config.h"

typedef struct {
    const char* name;
    const char* version;
    const char* desc;
    const char* filename;
    const char* content;
} pkg_t;

static const pkg_t CATALOG[] = {
    { "welcome", "1.0", "A friendly welcome note",
      "welcome.txt",
      "Welcome to ZapczOS!\n\nThis note was installed by the built-in package\n"
      "manager (zap). Everything here -- kernel, drivers, GUI,\n"
      "network stack and browser -- is written from scratch.\n\nEnjoy exploring.\n" },
    { "cheatsheet", "1.1", "Terminal command cheat sheet",
      "cheatsheet.txt",
      "ZapczOS Terminal cheat sheet\n============================\n"
      "help           list commands\n"
      "ver            OS version\n"
      "uptime         time since boot\n"
      "mem            memory usage\n"
      "sysfetch       system summary\n"
      "open <app>     launch an app\n"
      "curl <url>     fetch a web page\n"
      "zap list       list packages\n"
      "zap install X  install a package\n"
      "zap remove X   uninstall a package\n"
      "zap info X     package details\n" },
    { "readme", "1.0", "About this operating system",
      "zapcz-readme.md",
      "# ZapczOS\n\nA hobby x86 operating system written from scratch in C\n"
      "and NASM. Features a real FAT32 filesystem, a windowed\n"
      "desktop, a from-scratch TCP/IP stack with TLS, and a\n"
      "hand-rolled web browser.\n\n## Packages\n\nUse `zap list` in the Terminal to see what's available.\n" },
    { "notes", "1.0", "A blank notes template",
      "my-notes.md",
      "# My Notes\n\n- \n- \n- \n\n## Ideas\n\n\n## To do\n\n- [ ] \n- [ ] \n" },
    { "ascii", "1.0", "ASCII art banner",
      "banner.txt",
      " ______                               ____   ____  \n"
      "|___  /    __ _   _ __    ___  ____  / __ \\ / ___| \n"
      "   / /    / _` | | '_ \\  / __||_  / | |  | |\\___ \\ \n"
      "  / /    | (_| | | |_) || (__  / /  | |  | | ___) |\n"
      " / /___   \\__,_| | .__/  \\___|/___|  \\____/ |____/ \n"
      "/_____|          |_|                               \n"
      "\n                    from scratch.\n" },
};
#define CATALOG_N (int)(sizeof(CATALOG) / sizeof(CATALOG[0]))

typedef struct { const char* name; const char* label; int app_id; u8 cfg_bit; } zapp_t;
static const zapp_t ZAPPS[] = {
    { "2048",        "2048",         APP_2048,   CFG_INSTALLED_2048   },
    { "snake",       "Snake",        APP_SNAKE,  CFG_INSTALLED_SNAKE  },
    { "minesweeper", "Minesweeper",  APP_MINES,  CFG_INSTALLED_MINES  },
    { "life",        "Game of Life", APP_LIFE,   CFG_INSTALLED_LIFE   },
    { "calculator",  "Calculator",   APP_CALC,   CFG_INSTALLED_CALC   },
    { "paint",       "Paint",        APP_PAINT,  CFG_INSTALLED_PAINT  },
    { "tictactoe",   "Tic-Tac-Toe",  APP_TTT,    CFG_INSTALLED_TTT    },
    { "grapher",     "3D Grapher",   APP_CUBE3D, CFG_INSTALLED_CUBE3D },
};
#define ZAPPS_N (int)(sizeof(ZAPPS) / sizeof(ZAPPS[0]))

static const zapp_t* find_zapp(const char* name) {
    for (int i = 0; i < ZAPPS_N; i++)
        if (str_eq_ci(ZAPPS[i].name, name)) return &ZAPPS[i];
    return 0;
}

void pkgmgr_cmd_apps(void) {
    term_print("Installable apps (zap install <name>):");
    if (!config_disk_available())
        term_print("  (no config disk -- installs won't persist)");
    u8 m = config_get_installed_mask();
    for (int i = 0; i < ZAPPS_N; i++) {
        char line[96];
        str_copy(line, "  ", sizeof(line));
        str_cat(line, ZAPPS[i].name, sizeof(line));
        int pad = 14 - (int)str_len(ZAPPS[i].name);
        for (int q = 0; q < pad; q++) str_cat(line, " ", sizeof(line));
        str_cat(line, (m & ZAPPS[i].cfg_bit) ? "[installed]  " : "[available]  ", sizeof(line));
        str_cat(line, ZAPPS[i].label, sizeof(line));
        term_print(line);
    }
}

static int pkg_is_installed(const char* filename) {
    static fat_dirent_t ents[64];
    int n = fat32_list_root(ents, 64);
    for (int i = 0; i < n; i++)
        if (str_eq_ci(ents[i].display_name, filename)) return 1;
    return 0;
}

static const pkg_t* find_pkg(const char* name) {
    for (int i = 0; i < CATALOG_N; i++)
        if (str_eq_ci(CATALOG[i].name, name)) return &CATALOG[i];
    return 0;
}

void pkgmgr_cmd_list(void) {
    term_print("Available packages (zap install <name>):");
    if (!fat32_available()) {
        term_print("  (no writable disk -- install unavailable)");
    }
    for (int i = 0; i < CATALOG_N; i++) {
        char line[96];
        str_copy(line, "  ", sizeof(line));
        str_cat(line, CATALOG[i].name, sizeof(line));
        int pad = 14 - (int)str_len(CATALOG[i].name);
        for (int p = 0; p < pad; p++) str_cat(line, " ", sizeof(line));
        str_cat(line, CATALOG[i].version, sizeof(line));
        str_cat(line, "  ", sizeof(line));
        str_cat(line, pkg_is_installed(CATALOG[i].filename) ? "[installed]  " : "             ", sizeof(line));
        str_cat(line, CATALOG[i].desc, sizeof(line));
        term_print(line);
    }
}

void pkgmgr_cmd_install(const char* name) {
    const zapp_t* z = find_zapp(name);
    if (z) {
        if (config_get_installed_mask() & z->cfg_bit) {
            char l[96]; str_copy(l, "Already installed: ", sizeof(l)); str_cat(l, z->label, sizeof(l));
            term_print(l); return;
        }
        config_set_installed(z->cfg_bit, 1);
        char l[96]; str_copy(l, "Installed app: ", sizeof(l)); str_cat(l, z->label, sizeof(l));
        term_print(l);
        term_print("Open it from the Start menu.");
        return;
    }
    const pkg_t* p = find_pkg(name);
    if (!p) { term_print("No such package. Try 'zap list'."); return; }
    if (!fat32_available()) { term_print("No writable disk available."); return; }
    if (pkg_is_installed(p->filename)) {
        char l[96]; str_copy(l, "Already installed: ", sizeof(l)); str_cat(l, p->filename, sizeof(l));
        term_print(l); return;
    }
    int ok = fat32_write_file(p->filename, (const u8*)p->content, str_len(p->content));
    if (ok) {
        char l[96]; str_copy(l, "Installed ", sizeof(l)); str_cat(l, p->name, sizeof(l));
        str_cat(l, " -> ", sizeof(l)); str_cat(l, p->filename, sizeof(l));
        term_print(l);
        term_print("Open it in Files or the Notes editor.");
    } else {
        term_print("Install failed (disk write error).");
    }
}

void pkgmgr_cmd_remove(const char* name) {
    const zapp_t* z = find_zapp(name);
    if (z) {
        if (!(config_get_installed_mask() & z->cfg_bit)) { term_print("That app is not installed."); return; }
        config_set_installed(z->cfg_bit, 0);
        char l[96]; str_copy(l, "Removed app: ", sizeof(l)); str_cat(l, z->label, sizeof(l));
        term_print(l); return;
    }
    const pkg_t* p = find_pkg(name);
    if (!p) { term_print("No such package. Try 'zap list'."); return; }
    if (!pkg_is_installed(p->filename)) { term_print("That package is not installed."); return; }
    int ok = fat32_delete_file(p->filename);
    if (ok) {
        char l[96]; str_copy(l, "Removed ", sizeof(l)); str_cat(l, p->name, sizeof(l));
        term_print(l);
    } else {
        term_print("Remove failed.");
    }
}

void pkgmgr_cmd_info(const char* name) {
    const zapp_t* z = find_zapp(name);
    if (z) {
        char l[96];
        str_copy(l, "App: ", sizeof(l)); str_cat(l, z->label, sizeof(l));
        str_cat(l, (config_get_installed_mask() & z->cfg_bit) ? "  [installed]" : "  [available]", sizeof(l));
        term_print(l);
        term_print("  Install with: zap install ");
        return;
    }
    const pkg_t* p = find_pkg(name);
    if (!p) { term_print("No such package. Try 'zap list'."); return; }
    char l[96];
    str_copy(l, "Package: ", sizeof(l)); str_cat(l, p->name, sizeof(l));
    str_cat(l, " ", sizeof(l)); str_cat(l, p->version, sizeof(l)); term_print(l);
    str_copy(l, "  ", sizeof(l)); str_cat(l, p->desc, sizeof(l)); term_print(l);
    str_copy(l, "  File: ", sizeof(l)); str_cat(l, p->filename, sizeof(l));
    str_cat(l, pkg_is_installed(p->filename) ? "  [installed]" : "  [not installed]", sizeof(l));
    term_print(l);
}
