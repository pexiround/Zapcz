#ifndef ACCOUNTS_H
#define ACCOUNTS_H
#include "io.h"

#define ACCOUNTS_MAX     8
#define ACCOUNT_NAME_LEN 16

void accounts_init(void);

int  accounts_logged_in(void);
void accounts_logout(void);

int  accounts_count(void);
const char* accounts_name_at(int idx);
int  accounts_has_password_at(int idx);
int  accounts_current_index(void);

int  accounts_get_keyboard_layout(void);
void accounts_set_keyboard_layout(int layout);

void accounts_login_draw(void);
void accounts_login_click(i32 mx, i32 my);
void accounts_login_key(int key);

void app_accounts_draw(i32 x, i32 y, i32 w, i32 h);
void app_accounts_click(i32 rx, i32 ry);
void app_accounts_key(int key);

#endif
