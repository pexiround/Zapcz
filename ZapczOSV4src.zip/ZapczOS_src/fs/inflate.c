#include "inflate.h"
#include "libc_shim.h"

typedef struct {
    const u8* src;
    u32 src_len;
    u32 byte_pos;
    u32 bit_pos;
} bitreader_t;

static u32 br_getbit(bitreader_t* br) {
    if (br->byte_pos >= br->src_len) return 0;
    u32 bit = (br->src[br->byte_pos] >> br->bit_pos) & 1;
    br->bit_pos++;
    if (br->bit_pos == 8) { br->bit_pos = 0; br->byte_pos++; }
    return bit;
}
static u32 br_getbits(bitreader_t* br, int n) {
    u32 v = 0;
    for (int i = 0; i < n; i++) v |= br_getbit(br) << i;
    return v;
}
static void br_align(bitreader_t* br) {
    if (br->bit_pos != 0) { br->bit_pos = 0; br->byte_pos++; }
}

#define MAX_CODES 288
#define MAX_BITS 15

typedef struct {
    u16 count[MAX_BITS + 1];
    u16 symbol[MAX_CODES];
} huff_t;

static void huff_build(huff_t* h, const u8* lengths, int n) {
    memset(h->count, 0, sizeof(h->count));
    for (int i = 0; i < n; i++) h->count[lengths[i]]++;
    h->count[0] = 0;

    u16 offs[MAX_BITS + 2];
    offs[1] = 0;
    for (int len = 1; len < MAX_BITS + 1; len++) {
        offs[len + 1] = (u16)(offs[len] + h->count[len]);
    }
    for (int sym = 0; sym < n; sym++) {
        if (lengths[sym] != 0) {
            h->symbol[offs[lengths[sym]]++] = (u16)sym;
        }
    }
}

static i32 huff_decode(bitreader_t* br, const huff_t* h) {
    int code = 0, first = 0, index = 0;
    for (int len = 1; len <= MAX_BITS; len++) {
        code |= (int)br_getbit(br);
        int count = h->count[len];
        if (code - first < count) {
            return h->symbol[index + (code - first)];
        }
        index += count;
        first += count;
        first <<= 1;
        code <<= 1;
    }
    return -1;
}

static const u16 LEN_BASE[29] = {3,4,5,6,7,8,9,10,11,13,15,17,19,23,27,31,35,43,51,59,67,83,99,115,131,163,195,227,258};
static const u8 LEN_EXTRA[29] = {0,0,0,0,0,0,0,0,1,1,1,1,2,2,2,2,3,3,3,3,4,4,4,4,5,5,5,5,0};
static const u16 DIST_BASE[30] = {1,2,3,4,5,7,9,13,17,25,33,49,65,97,129,193,257,385,513,769,1025,1537,2049,3073,4097,6145,8193,12289,16385,24577};
static const u8 DIST_EXTRA[30] = {0,0,0,0,1,1,2,2,3,3,4,4,5,5,6,6,7,7,8,8,9,9,10,10,11,11,12,12,13,13};
static const u8 CLEN_ORDER[19] = {16,17,18,0,8,7,9,6,10,5,11,4,12,3,13,2,14,1,15};

static i32 inflate_block_data(bitreader_t* br, const huff_t* lit_h, const huff_t* dist_h,
                               u8* out, u32 out_cap, u32* out_pos) {
    for (;;) {
        i32 sym = huff_decode(br, lit_h);
        if (sym < 0) return 0;
        if (sym < 256) {
            if (*out_pos >= out_cap) return 0;
            out[(*out_pos)++] = (u8)sym;
        } else if (sym == 256) {
            return 1;
        } else {
            sym -= 257;
            if (sym >= 29) return 0;
            u32 length = LEN_BASE[sym] + br_getbits(br, LEN_EXTRA[sym]);
            i32 dsym = huff_decode(br, dist_h);
            if (dsym < 0 || dsym >= 30) return 0;
            u32 dist = DIST_BASE[dsym] + br_getbits(br, DIST_EXTRA[dsym]);
            if (dist > *out_pos) return 0;
            for (u32 i = 0; i < length; i++) {
                if (*out_pos >= out_cap) return 0;
                out[*out_pos] = out[*out_pos - dist];
                (*out_pos)++;
            }
        }
    }
}

static void build_fixed_huffman(huff_t* lit_h, huff_t* dist_h) {
    u8 lit_lengths[288];
    for (int i = 0; i < 144; i++) lit_lengths[i] = 8;
    for (int i = 144; i < 256; i++) lit_lengths[i] = 9;
    for (int i = 256; i < 280; i++) lit_lengths[i] = 7;
    for (int i = 280; i < 288; i++) lit_lengths[i] = 8;
    huff_build(lit_h, lit_lengths, 288);

    u8 dist_lengths[30];
    for (int i = 0; i < 30; i++) dist_lengths[i] = 5;
    huff_build(dist_h, dist_lengths, 30);
}

static i32 inflate_dynamic_block(bitreader_t* br, u8* out, u32 out_cap, u32* out_pos) {
    u32 hlit = br_getbits(br, 5) + 257;
    u32 hdist = br_getbits(br, 5) + 1;
    u32 hclen = br_getbits(br, 4) + 4;

    u8 clen_lengths[19];
    memset(clen_lengths, 0, sizeof(clen_lengths));
    for (u32 i = 0; i < hclen; i++) {
        clen_lengths[CLEN_ORDER[i]] = (u8)br_getbits(br, 3);
    }
    huff_t clen_h;
    huff_build(&clen_h, clen_lengths, 19);

    u8 lengths[288 + 32];
    u32 n = 0;
    while (n < hlit + hdist) {
        i32 sym = huff_decode(br, &clen_h);
        if (sym < 0) return 0;
        if (sym < 16) {
            lengths[n++] = (u8)sym;
        } else if (sym == 16) {
            if (n == 0) return 0;
            u32 rep = br_getbits(br, 2) + 3;
            u8 prev = lengths[n - 1];
            for (u32 i = 0; i < rep && n < hlit + hdist; i++) lengths[n++] = prev;
        } else if (sym == 17) {
            u32 rep = br_getbits(br, 3) + 3;
            for (u32 i = 0; i < rep && n < hlit + hdist; i++) lengths[n++] = 0;
        } else {
            u32 rep = br_getbits(br, 7) + 11;
            for (u32 i = 0; i < rep && n < hlit + hdist; i++) lengths[n++] = 0;
        }
    }

    huff_t lit_h, dist_h;
    huff_build(&lit_h, lengths, (int)hlit);
    huff_build(&dist_h, lengths + hlit, (int)hdist);

    return inflate_block_data(br, &lit_h, &dist_h, out, out_cap, out_pos);
}

int inflate_raw(const u8* src, u32 src_len, u8* out, u32 out_cap, u32* out_len) {
    bitreader_t br;
    br.src = src; br.src_len = src_len; br.byte_pos = 0; br.bit_pos = 0;
    u32 out_pos = 0;

    for (;;) {
        u32 bfinal = br_getbit(&br);
        u32 btype = br_getbits(&br, 2);

        if (btype == 0) {
            br_align(&br);
            if (br.byte_pos + 4 > src_len) return 0;
            u32 len = src[br.byte_pos] | (src[br.byte_pos + 1] << 8);
            br.byte_pos += 4;
            if (br.byte_pos + len > src_len) return 0;
            if (out_pos + len > out_cap) return 0;
            memcpy(out + out_pos, src + br.byte_pos, len);
            out_pos += len;
            br.byte_pos += len;
        } else if (btype == 1) {
            huff_t lit_h, dist_h;
            build_fixed_huffman(&lit_h, &dist_h);
            if (!inflate_block_data(&br, &lit_h, &dist_h, out, out_cap, &out_pos)) return 0;
        } else if (btype == 2) {
            if (!inflate_dynamic_block(&br, out, out_cap, &out_pos)) return 0;
        } else {
            return 0;
        }

        if (bfinal) break;
    }

    *out_len = out_pos;
    return 1;
}
