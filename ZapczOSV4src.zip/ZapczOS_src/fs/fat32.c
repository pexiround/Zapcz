#include "libc_shim.h"
#include "fat32.h"
#include "ata.h"
#include "rtc.h"
#include "mm.h"
#include "util.h"

typedef struct __attribute__((packed)) {
    u8  jmp[3];
    u8  oem[8];
    u16 bytes_per_sector;
    u8  sectors_per_cluster;
    u16 reserved_sectors;
    u8  num_fats;
    u16 root_entry_count;
    u16 total_sectors_16;
    u8  media;
    u16 fat_size_16;
    u16 sectors_per_track;
    u16 num_heads;
    u32 hidden_sectors;
    u32 total_sectors_32;
    u32 fat_size_32;
    u16 ext_flags;
    u16 fs_version;
    u32 root_cluster;
    u16 fsinfo_sector;
    u16 backup_boot_sector;
    u8  reserved[12];
    u8  drive_number;
    u8  reserved1;
    u8  boot_signature;
    u32 volume_id;
    u8  volume_label[11];
    u8  fs_type[8];
} bpb_t;

typedef struct __attribute__((packed)) {
    u8  name[11];
    u8  attr;
    u8  ntres;
    u8  ctime_tenth;
    u16 ctime;
    u16 cdate;
    u16 adate;
    u16 cluster_hi;
    u16 wtime;
    u16 wdate;
    u16 cluster_lo;
    u32 size;
} fat_entry_t;

#define ATTR_DIR     0x10
#define ATTR_LFN     0x0F
#define ATTR_VOLLBL  0x08

static u32 bytes_per_sector = 512;
static u32 sectors_per_cluster = 1;
static u32 reserved_sectors = 0;
static u32 num_fats = 2;
static u32 fat_size = 0;
static u32 root_cluster = 2;
static u32 fat_start_lba = 0;
static u32 data_start_lba = 0;
static u32 total_clusters = 0;
static int fs_ok = 0;
static int disk_ok = 0;

static u32 cluster_to_lba(u32 cluster) {
    return data_start_lba + (cluster - 2) * sectors_per_cluster;
}

static u32 fat_get_entry(u32 cluster) {
    u32 fat_offset = cluster * 4;
    u32 sec = fat_start_lba + fat_offset / bytes_per_sector;
    u32 off = fat_offset % bytes_per_sector;
    u8 buf[512];
    if (!ata_read_sector(sec, buf)) return 0x0FFFFFFF;
    u32 v;
    memcpy(&v, buf + off, 4);
    return v & 0x0FFFFFFF;
}

static void fat_set_entry(u32 cluster, u32 value) {
    u32 fat_offset = cluster * 4;
    u32 off = fat_offset % bytes_per_sector;
    for (u32 f = 0; f < num_fats; f++) {
        u32 sec = fat_start_lba + f * fat_size + fat_offset / bytes_per_sector;
        u8 buf[512];
        if (!ata_read_sector(sec, buf)) continue;
        u32 v = value & 0x0FFFFFFF;
        memcpy(buf + off, &v, 4);
        ata_write_sector(sec, buf);
    }
}

static int is_eoc(u32 v) { return v >= 0x0FFFFFF8; }

static u32 fat_alloc_cluster(void) {
    for (u32 c = 2; c < total_clusters + 2; c++) {
        if (fat_get_entry(c) == 0) {
            fat_set_entry(c, 0x0FFFFFFF);
            return c;
        }
    }
    return 0;
}

static void fat_free_chain(u32 start) {
    u32 c = start;
    int guard = 0;
    while (c >= 2 && !is_eoc(c) && guard++ < 1000000) {
        u32 next = fat_get_entry(c);
        fat_set_entry(c, 0);
        c = next;
    }
}

static void zero_cluster(u32 cluster) {
    u8 zero[512];
    for (u32 i = 0; i < bytes_per_sector; i++) zero[i] = 0;
    u32 lba = cluster_to_lba(cluster);
    for (u32 s = 0; s < sectors_per_cluster; s++) ata_write_sector(lba + s, zero);
}

#define RAMFS_MAX_FILES 48
#define RAMFS_ROOT_ID 0xFFFFFFFFu
typedef struct {
    int used;
    char display_name[13];
    u8* data;
    u32 size;
    u32 capacity;
    u8  is_dir;
    u8  read_only;
    u32 parent;
} ramfs_entry_t;
static ramfs_entry_t ramfs[RAMFS_MAX_FILES];

static int ramfs_free_slot(void);
static void fatname_to_display(const u8* raw, char* out);
static void display_to_fatname(const char* in, char out[11]);

static int ramfs_find_slot(const char* disp) {
    for (int i = 0; i < RAMFS_MAX_FILES; i++) {
        if (ramfs[i].used && ramfs[i].parent == RAMFS_ROOT_ID && str_eq_ci(ramfs[i].display_name, disp)) return i;
    }
    return -1;
}

static int ramfs_find_in(u32 parent, const char* disp) {
    for (int i = 0; i < RAMFS_MAX_FILES; i++) {
        if (ramfs[i].used && ramfs[i].parent == parent && str_eq_ci(ramfs[i].display_name, disp)) return i;
    }
    return -1;
}

static void ramfs_free_index(int idx) {
    if (ramfs[idx].data) { kfree(ramfs[idx].data); ramfs[idx].data = 0; }
    ramfs[idx].used = 0;
    ramfs[idx].size = 0;
    ramfs[idx].capacity = 0;
    ramfs[idx].is_dir = 0;
    ramfs[idx].read_only = 0;
}

static void ramfs_delete_subtree(u32 dir_id) {
    for (int i = 0; i < RAMFS_MAX_FILES; i++) {
        if (ramfs[i].used && ramfs[i].parent == dir_id) {
            if (ramfs[i].is_dir) ramfs_delete_subtree((u32)i);
            ramfs_free_index(i);
        }
    }
}

static int ramfs_dir_is_ro(u32 dir_id) {
    return dir_id != RAMFS_ROOT_ID && dir_id < RAMFS_MAX_FILES && ramfs[dir_id].used && ramfs[dir_id].read_only;
}

static int ramfs_write_raw(u32 dir_id, const char* name, const u8* data, u32 size, int ro) {
    char name11[11];
    display_to_fatname(name, name11);
    char disp[13];
    fatname_to_display((const u8*)name11, disp);
    int idx = ramfs_find_in(dir_id, disp);
    if (idx < 0) idx = ramfs_free_slot();
    if (idx < 0) return 0;
    u32 want = size > 0 ? size : 1;
    if (ramfs[idx].capacity < want) {
        u8* nd = (u8*)kmalloc(want);
        if (!nd) return 0;
        if (ramfs[idx].data) kfree(ramfs[idx].data);
        ramfs[idx].data = nd;
        ramfs[idx].capacity = want;
    }
    if (size > 0) memcpy(ramfs[idx].data, data, size);
    ramfs[idx].size = size;
    ramfs[idx].used = 1;
    ramfs[idx].is_dir = 0;
    ramfs[idx].read_only = ro ? 1 : 0;
    ramfs[idx].parent = dir_id;
    str_copy(ramfs[idx].display_name, disp, 13);
    return 1;
}

static int ramfs_write(u32 dir_id, const char* name, const u8* data, u32 size) {
    if (ramfs_dir_is_ro(dir_id)) return 0;
    return ramfs_write_raw(dir_id, name, data, size, 0);
}

static int ramfs_delete(u32 dir_id, const char* name) {
    char name11[11];
    display_to_fatname(name, name11);
    char disp[13];
    fatname_to_display((const u8*)name11, disp);
    int idx = ramfs_find_in(dir_id, disp);
    if (idx < 0) idx = ramfs_find_in(dir_id, name);
    if (idx < 0) return 0;
    if (ramfs[idx].read_only) return 0;
    if (ramfs[idx].is_dir) ramfs_delete_subtree((u32)idx);
    ramfs_free_index(idx);
    return 1;
}

static int ramfs_rename(u32 dir_id, const char* old_name, const char* new_name) {
    char old11[11], new11[11];
    display_to_fatname(old_name, old11);
    display_to_fatname(new_name, new11);
    char olddisp[13], newdisp[13];
    fatname_to_display((const u8*)old11, olddisp);
    fatname_to_display((const u8*)new11, newdisp);
    int oidx = ramfs_find_in(dir_id, olddisp);
    if (oidx < 0) oidx = ramfs_find_in(dir_id, old_name);
    if (oidx < 0) return 0;
    if (ramfs[oidx].read_only) return 0;
    if (ramfs[oidx].is_dir) str_copy(newdisp, new_name, 13);
    if (str_eq_ci(newdisp, ramfs[oidx].display_name)) return 1;
    if (ramfs_find_in(dir_id, newdisp) >= 0) return 0;
    str_copy(ramfs[oidx].display_name, newdisp, 13);
    return 1;
}

static int ramfs_free_slot(void) {
    for (int i = 0; i < RAMFS_MAX_FILES; i++) if (!ramfs[i].used) return i;
    return -1;
}

int fat32_persistent(void) { return fs_ok; }

int fat32_init(void) {
    disk_ok = ata_detect();
    if (!disk_ok) { fs_ok = 0; return 0; }

    u8 sec0[512];
    if (!ata_read_sector(0, sec0)) { fs_ok = 0; return 0; }

    bpb_t bpb;
    memcpy(&bpb, sec0, sizeof(bpb_t));

    if (bpb.bytes_per_sector != 512 || bpb.num_fats == 0 ||
        bpb.fat_size_32 == 0 || bpb.boot_signature != 0x29) {
        fs_ok = 0;
        return 0;
    }

    bytes_per_sector = bpb.bytes_per_sector;
    sectors_per_cluster = bpb.sectors_per_cluster;
    reserved_sectors = bpb.reserved_sectors;
    num_fats = bpb.num_fats;
    fat_size = bpb.fat_size_32;
    root_cluster = bpb.root_cluster;
    fat_start_lba = reserved_sectors;
    data_start_lba = reserved_sectors + num_fats * fat_size;

    u32 total_sectors = bpb.total_sectors_32;
    u32 data_sectors = total_sectors - data_start_lba;
    total_clusters = data_sectors / sectors_per_cluster;

    fs_ok = 1;
    return 1;
}

int fat32_available(void) { return 1; }

static void fatname_to_display(const u8* raw, char* out) {
    int p = 0;
    for (int i = 0; i < 8 && raw[i] != ' '; i++) out[p++] = (char)raw[i];
    if (raw[8] != ' ') {
        out[p++] = '.';
        for (int i = 8; i < 11 && raw[i] != ' '; i++) out[p++] = (char)raw[i];
    }
    out[p] = 0;
}

static void display_to_fatname(const char* in, char out[11]) {
    for (int i = 0; i < 11; i++) out[i] = ' ';
    int p = 0;
    for (int i = 0; in[i] && in[i] != '.' && p < 8; i++) {
        char c = in[i];
        if (c >= 'a' && c <= 'z') c = (char)(c - 'a' + 'A');
        out[p++] = c;
    }
    const char* dot = 0;
    for (const char* s = in; *s; s++) if (*s == '.') dot = s;
    if (dot) {
        int q = 8;
        for (const char* s = dot + 1; *s && q < 11; s++) {
            char c = *s;
            if (c >= 'a' && c <= 'z') c = (char)(c - 'a' + 'A');
            out[q++] = c;
        }
    }
}

typedef int (*dirent_visitor)(fat_entry_t* fe, u32 dir_cluster, u32 sector_lba,
                               u32 offset_in_sector, void* ctx);

static void walk_dir(u32 start_cluster, dirent_visitor visit, void* ctx) {
    u32 cluster = start_cluster;
    int guard = 0;
    u8 buf[512];
    while (cluster >= 2 && !is_eoc(cluster) && guard++ < 100000) {
        u32 lba = cluster_to_lba(cluster);
        for (u32 s = 0; s < sectors_per_cluster; s++) {
            if (!ata_read_sector(lba + s, buf)) return;
            for (u32 off = 0; off < bytes_per_sector; off += 32) {
                fat_entry_t* fe = (fat_entry_t*)(buf + off);
                if (visit(fe, cluster, lba + s, off, ctx)) return;
            }
        }
        cluster = fat_get_entry(cluster);
    }
}

typedef struct { fat_dirent_t* out; int max; int count; } list_ctx_t;
static int list_visitor(fat_entry_t* fe, u32 dc, u32 lba, u32 off, void* ctx) {
    (void)dc; (void)lba; (void)off;
    list_ctx_t* lc = (list_ctx_t*)ctx;
    if (fe->name[0] == 0x00) return 1;
    if (fe->name[0] == 0xE5) return 0;
    if (fe->attr == ATTR_LFN) return 0;
    if (fe->attr & ATTR_VOLLBL) return 0;
    if (lc->count >= lc->max) return 1;
    fat_dirent_t* d = &lc->out[lc->count];
    fatname_to_display(fe->name, d->display_name);
    memcpy(d->short_name, fe->name, 11);
    d->size = fe->size;
    d->first_cluster = ((u32)fe->cluster_hi << 16) | fe->cluster_lo;
    d->is_dir = (fe->attr & ATTR_DIR) ? 1 : 0;
    d->read_only = 0;
    lc->count++;
    return 0;
}

int fat32_list_dir(u32 dir_id, fat_dirent_t* out, int max_entries) {
    if (!fs_ok) {
        int count = 0;
        for (int i = 0; i < RAMFS_MAX_FILES && count < max_entries; i++) {
            if (!ramfs[i].used || ramfs[i].parent != dir_id) continue;
            fat_dirent_t* d = &out[count];
            str_copy(d->display_name, ramfs[i].display_name, 13);
            d->short_name[0] = 0;
            d->size = ramfs[i].size;
            d->first_cluster = (u32)i;
            d->is_dir = ramfs[i].is_dir;
            d->read_only = ramfs[i].read_only;
            count++;
        }
        return count;
    }
    if (dir_id != RAMFS_ROOT_ID) return 0;
    list_ctx_t lc = { out, max_entries, 0 };
    walk_dir(root_cluster, list_visitor, &lc);
    return lc.count;
}

int fat32_list_root(fat_dirent_t* out, int max_entries) {
    return fat32_list_dir(RAMFS_ROOT_ID, out, max_entries);
}

int fat32_read_file(const fat_dirent_t* ent, u8* buf, u32 bufsize) {
    if (!fs_ok) {
        u32 idx = ent->first_cluster;
        if (idx >= RAMFS_MAX_FILES || !ramfs[idx].used) return 0;
        u32 n = ramfs[idx].size < bufsize ? ramfs[idx].size : bufsize;
        memcpy(buf, ramfs[idx].data, n);
        return (int)n;
    }
    u32 remaining = ent->size < bufsize ? ent->size : bufsize;
    u32 cluster = ent->first_cluster;
    u32 written = 0;
    int guard = 0;
    u8 sec[512];
    while (cluster >= 2 && !is_eoc(cluster) && remaining > 0 && guard++ < 100000) {
        u32 lba = cluster_to_lba(cluster);
        for (u32 s = 0; s < sectors_per_cluster && remaining > 0; s++) {
            if (!ata_read_sector(lba + s, sec)) return (int)written;
            u32 chunk = remaining < bytes_per_sector ? remaining : bytes_per_sector;
            memcpy(buf + written, sec, chunk);
            written += chunk;
            remaining -= chunk;
        }
        cluster = fat_get_entry(cluster);
    }
    return (int)written;
}

typedef struct { const char* name11; fat_entry_t* found; u32 dir_cluster;
                 u32 sector_lba; u32 offset; int free_found;
                 fat_entry_t* free_slot; u32 free_lba; u32 free_off; } find_ctx_t;

static int find_visitor(fat_entry_t* fe, u32 dc, u32 lba, u32 off, void* ctx) {
    find_ctx_t* fc = (find_ctx_t*)ctx;
    if (fe->name[0] == 0x00) {
        if (!fc->free_found) {
            fc->free_found = 1;
            fc->free_slot = fe; fc->free_lba = lba; fc->free_off = off;
        }
        return 1;
    }
    if (fe->name[0] == 0xE5) {
        if (!fc->free_found) {
            fc->free_found = 1;
            fc->free_slot = fe; fc->free_lba = lba; fc->free_off = off;
        }
        return 0;
    }
    if (fe->attr == ATTR_LFN) return 0;
    if (memcmp(fe->name, fc->name11, 11) == 0) {
        fc->found = fe; fc->dir_cluster = dc;
        fc->sector_lba = lba; fc->offset = off;
        return 1;
    }
    return 0;
}

static void fat_datetime(u16* fdate, u16* ftime) {
    rtc_time_t t;
    rtc_read(&t);
    u16 year = t.year >= 1980 ? (u16)(t.year - 1980) : 0;
    *fdate = (u16)((year << 9) | ((u32)t.month << 5) | t.day);
    *ftime = (u16)(((u32)t.hour << 11) | ((u32)t.minute << 5) | (t.second / 2));
}

int fat32_write_file(const char* name, const u8* data, u32 size) {
    if (!fs_ok) return ramfs_write(RAMFS_ROOT_ID, name, data, size);
    char name11[11];
    display_to_fatname(name, name11);

    find_ctx_t fc = {0};
    fc.name11 = name11;
    walk_dir(root_cluster, find_visitor, &fc);

    u8 sec[512];
    if (fc.found) {
        u32 old_cluster = ((u32)fc.found->cluster_hi << 16) | fc.found->cluster_lo;
        if (old_cluster >= 2) fat_free_chain(old_cluster);
    } else if (!fc.free_found) {

        u32 last = root_cluster;
        while (!is_eoc(fat_get_entry(last))) last = fat_get_entry(last);
        u32 newc = fat_alloc_cluster();
        if (!newc) return 0;
        fat_set_entry(last, newc);
        zero_cluster(newc);
        fc.free_found = 1;
        fc.free_lba = cluster_to_lba(newc);
        fc.free_off = 0;
    }

    u32 first_cluster = 0, prev = 0;
    u32 remaining = size;
    const u8* src = data;
    while (remaining > 0 || first_cluster == 0) {
        u32 c = fat_alloc_cluster();
        if (!c) return 0;
        if (prev) fat_set_entry(prev, c);
        else first_cluster = c;
        u32 lba = cluster_to_lba(c);
        for (u32 s = 0; s < sectors_per_cluster; s++) {
            u32 chunk = remaining < bytes_per_sector ? remaining : bytes_per_sector;
            if (chunk > 0) {
                for (u32 i = 0; i < bytes_per_sector; i++)
                    sec[i] = (i < chunk) ? src[i] : 0;
                ata_write_sector(lba + s, sec);
                src += chunk;
                remaining -= chunk;
            }
        }
        prev = c;
        if (size == 0) break;
    }
    fat_set_entry(prev, 0x0FFFFFFF);

    u32 target_lba = fc.found ? fc.sector_lba : fc.free_lba;
    u32 target_off = fc.found ? fc.offset : fc.free_off;
    if (!ata_read_sector(target_lba, sec)) return 0;
    fat_entry_t* fe = (fat_entry_t*)(sec + target_off);
    memcpy(fe->name, name11, 11);
    fe->attr = 0x20;
    fe->ntres = 0;
    fe->ctime_tenth = 0;
    u16 fdate, ftime;
    fat_datetime(&fdate, &ftime);
    fe->ctime = ftime; fe->cdate = fdate;
    fe->adate = fdate;
    fe->wtime = ftime; fe->wdate = fdate;
    fe->cluster_hi = (u16)(first_cluster >> 16);
    fe->cluster_lo = (u16)(first_cluster & 0xFFFF);
    fe->size = size;
    ata_write_sector(target_lba, sec);
    return 1;
}

int fat32_delete_file(const char* name) {
    if (!fs_ok) return ramfs_delete(RAMFS_ROOT_ID, name);
    char name11[11];
    display_to_fatname(name, name11);
    find_ctx_t fc = {0};
    fc.name11 = name11;
    walk_dir(root_cluster, find_visitor, &fc);
    if (!fc.found) return 0;

    u32 cluster = ((u32)fc.found->cluster_hi << 16) | fc.found->cluster_lo;
    if (cluster >= 2) fat_free_chain(cluster);

    u8 sec[512];
    if (!ata_read_sector(fc.sector_lba, sec)) return 0;
    sec[fc.offset] = 0xE5;
    ata_write_sector(fc.sector_lba, sec);
    return 1;
}

int fat32_rename_file(const char* old_name, const char* new_name) {
    if (!fs_ok) return ramfs_rename(RAMFS_ROOT_ID, old_name, new_name);
    char old11[11], new11[11];
    display_to_fatname(old_name, old11);
    display_to_fatname(new_name, new11);

    if (memcmp(old11, new11, 11) == 0) return 1;

    find_ctx_t collide = {0};
    collide.name11 = new11;
    walk_dir(root_cluster, find_visitor, &collide);
    if (collide.found) return 0;

    find_ctx_t fc = {0};
    fc.name11 = old11;
    walk_dir(root_cluster, find_visitor, &fc);
    if (!fc.found) return 0;

    u8 sec[512];
    if (!ata_read_sector(fc.sector_lba, sec)) return 0;
    fat_entry_t* fe = (fat_entry_t*)(sec + fc.offset);
    memcpy(fe->name, new11, 11);
    u16 fdate, ftime;
    fat_datetime(&fdate, &ftime);
    fe->wtime = ftime; fe->wdate = fdate;
    ata_write_sector(fc.sector_lba, sec);
    return 1;
}

int fat32_mkdir_id(u32 dir_id, const char* name, int read_only) {
    if (!fs_ok) {
        if (ramfs_dir_is_ro(dir_id)) return -1;
        char disp[13];
        str_copy(disp, name, 13);
        if (disp[0] == 0) return -1;
        if (ramfs_find_in(dir_id, disp) >= 0) return -1;
        int idx = ramfs_free_slot();
        if (idx < 0) return -1;
        ramfs[idx].used = 1;
        ramfs[idx].is_dir = 1;
        ramfs[idx].read_only = read_only ? 1 : 0;
        ramfs[idx].parent = dir_id;
        ramfs[idx].size = 0;
        ramfs[idx].data = 0;
        ramfs[idx].capacity = 0;
        str_copy(ramfs[idx].display_name, disp, 13);
        return idx;
    }
    (void)dir_id; (void)name; (void)read_only;
    return -1;
}

int fat32_mkdir(u32 dir_id, const char* name) {
    return fat32_mkdir_id(dir_id, name, 0) >= 0 ? 1 : 0;
}

int fat32_write_protected(u32 dir_id, const char* name, const u8* data, u32 size) {
    if (!fs_ok) return ramfs_write_raw(dir_id, name, data, size, 1);
    return 0;
}

int fat32_dir_readonly(u32 dir_id) {
    if (!fs_ok) return ramfs_dir_is_ro(dir_id) ? 1 : 0;
    return 0;
}

int fat32_write_file_in(u32 dir_id, const char* name, const u8* data, u32 size) {
    if (!fs_ok) return ramfs_write(dir_id, name, data, size);
    if (dir_id != RAMFS_ROOT_ID) return 0;
    return fat32_write_file(name, data, size);
}

int fat32_delete_in(u32 dir_id, const char* name) {
    if (!fs_ok) return ramfs_delete(dir_id, name);
    if (dir_id != RAMFS_ROOT_ID) return 0;
    return fat32_delete_file(name);
}

int fat32_rename_in(u32 dir_id, const char* old_name, const char* new_name) {
    if (!fs_ok) return ramfs_rename(dir_id, old_name, new_name);
    if (dir_id != RAMFS_ROOT_ID) return 0;
    return fat32_rename_file(old_name, new_name);
}

u32 fat32_free_bytes(void) {
    if (!fs_ok) {
        u32 used_b = 0, free_b = 0;
        heap_stats(&used_b, &free_b);
        return free_b;
    }
    u32 free_clusters = 0;
    u32 entries_per_sector = bytes_per_sector / 4;
    u32 clusters_seen = 0;
    u8* buf = (u8*)kmalloc(64 * 512);
    if (!buf) return 0;
    for (u32 s = 0; s < fat_size && clusters_seen < total_clusters + 2; s += 64) {
        u32 batch = fat_size - s;
        if (batch > 64) batch = 64;
        int got = ata_read_sectors(fat_start_lba + s, batch, buf);
        if (got <= 0) break;
        for (u32 b = 0; b < (u32)got; b++) {
            for (u32 i = 0; i < entries_per_sector; i++) {
                u32 cluster_num = (s + b) * entries_per_sector + i;
                if (cluster_num < 2) continue;
                if (cluster_num >= total_clusters + 2) break;
                u32 v;
                memcpy(&v, buf + b * 512 + i * 4, 4);
                if ((v & 0x0FFFFFFF) == 0) free_clusters++;
                clusters_seen++;
            }
        }
    }
    kfree(buf);
    return free_clusters * sectors_per_cluster * bytes_per_sector;
}
