#include "zip.h"
#include "inflate.h"
#include "libc_shim.h"
#include "util.h"

static u32 rd32(const u8* p) { return (u32)p[0] | ((u32)p[1] << 8) | ((u32)p[2] << 16) | ((u32)p[3] << 24); }
static u16 rd16(const u8* p) { return (u16)((u32)p[0] | ((u32)p[1] << 8)); }

int zip_extract_entry(const u8* zip_data, u32 zip_len, const char* entry_name,
                       u8* out, u32 out_cap, u32* out_len) {
    if (zip_len < 22) return 0;

    u32 eocd = 0;
    int found_eocd = 0;
    i32 scan_limit = (i32)zip_len - 22 - 65557;
    if (scan_limit < 0) scan_limit = 0;
    for (i32 i = (i32)zip_len - 22; i >= scan_limit; i--) {
        if (rd32(zip_data + (u32)i) == 0x06054b50) { eocd = (u32)i; found_eocd = 1; break; }
    }
    if (!found_eocd) return 0;

    u32 cd_offset = rd32(zip_data + eocd + 16);
    u16 entry_count = rd16(zip_data + eocd + 10);
    u32 name_len = str_len(entry_name);

    u32 p = cd_offset;
    for (u16 i = 0; i < entry_count; i++) {
        if (p + 46 > zip_len) return 0;
        if (rd32(zip_data + p) != 0x02014b50) return 0;

        u16 method = rd16(zip_data + p + 10);
        u32 csize = rd32(zip_data + p + 20);
        u32 usize = rd32(zip_data + p + 24);
        u16 namelen = rd16(zip_data + p + 28);
        u16 extralen = rd16(zip_data + p + 30);
        u16 commentlen = rd16(zip_data + p + 32);
        u32 lho = rd32(zip_data + p + 42);

        if (namelen == name_len && memcmp(zip_data + p + 46, entry_name, namelen) == 0) {
            if (lho + 30 > zip_len) return 0;
            u16 lh_namelen = rd16(zip_data + lho + 26);
            u16 lh_extralen = rd16(zip_data + lho + 28);
            u32 data_offset = lho + 30 + lh_namelen + lh_extralen;
            if (data_offset + csize > zip_len) return 0;

            if (method == 0) {
                if (usize > out_cap) return 0;
                memcpy(out, zip_data + data_offset, usize);
                *out_len = usize;
                return 1;
            } else if (method == 8) {
                u32 got_len = 0;
                if (!inflate_raw(zip_data + data_offset, csize, out, out_cap, &got_len)) return 0;
                if (got_len != usize) return 0;
                *out_len = got_len;
                return 1;
            }
            return 0;
        }
        p += 46 + namelen + extralen + commentlen;
    }
    return 0;
}

int zip_list(const u8* zip_data, u32 zip_len, zip_entry_t* out, int max_entries) {
    if (zip_len < 22 || max_entries <= 0) return 0;

    u32 eocd = 0;
    int found_eocd = 0;
    i32 scan_limit = (i32)zip_len - 22 - 65557;
    if (scan_limit < 0) scan_limit = 0;
    for (i32 i = (i32)zip_len - 22; i >= scan_limit; i--) {
        if (rd32(zip_data + (u32)i) == 0x06054b50) { eocd = (u32)i; found_eocd = 1; break; }
    }
    if (!found_eocd) return 0;

    u32 cd_offset = rd32(zip_data + eocd + 16);
    u16 entry_count = rd16(zip_data + eocd + 10);

    int n = 0;
    u32 p = cd_offset;
    for (u16 i = 0; i < entry_count && n < max_entries; i++) {
        if (p + 46 > zip_len) break;
        if (rd32(zip_data + p) != 0x02014b50) break;
        u32 usize = rd32(zip_data + p + 24);
        u16 namelen = rd16(zip_data + p + 28);
        u16 extralen = rd16(zip_data + p + 30);
        u16 commentlen = rd16(zip_data + p + 32);

        u32 copy = namelen;
        if (copy > ZIP_NAME_MAX - 1) copy = ZIP_NAME_MAX - 1;
        for (u32 k = 0; k < copy; k++) out[n].name[k] = (char)zip_data[p + 46 + k];
        out[n].name[copy] = 0;
        out[n].size = usize;
        out[n].is_dir = (namelen > 0 && zip_data[p + 46 + namelen - 1] == '/') ? 1 : 0;
        n++;

        p += 46 + namelen + extralen + commentlen;
    }
    return n;
}
