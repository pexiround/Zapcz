#ifndef ZIP_H
#define ZIP_H
#include "io.h"

#define ZIP_NAME_MAX 64
typedef struct { char name[ZIP_NAME_MAX]; u32 size; int is_dir; } zip_entry_t;

int zip_list(const u8* zip_data, u32 zip_len, zip_entry_t* out, int max_entries);

int zip_extract_entry(const u8* zip_data, u32 zip_len, const char* entry_name,
                       u8* out, u32 out_cap, u32* out_len);

#endif
