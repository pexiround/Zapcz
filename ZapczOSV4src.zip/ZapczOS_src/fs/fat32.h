#ifndef FAT32_H
#define FAT32_H
#include "io.h"

#define FAT32_ROOT_ID 0xFFFFFFFFu

typedef struct {
    char display_name[13];
    char short_name[11];
    u32  size;
    u32  first_cluster;
    u8   is_dir;
    u8   read_only;
} fat_dirent_t;

int fat32_init(void);
int fat32_available(void);
int fat32_persistent(void);
int fat32_list_root(fat_dirent_t* out, int max_entries);
int fat32_read_file(const fat_dirent_t* ent, u8* buf, u32 bufsize);
int fat32_write_file(const char* name, const u8* data, u32 size);
int fat32_list_dir(u32 dir_id, fat_dirent_t* out, int max_entries);
int fat32_mkdir(u32 dir_id, const char* name);
int fat32_mkdir_id(u32 dir_id, const char* name, int read_only);
int fat32_write_protected(u32 dir_id, const char* name, const u8* data, u32 size);
int fat32_dir_readonly(u32 dir_id);
int fat32_write_file_in(u32 dir_id, const char* name, const u8* data, u32 size);
int fat32_delete_in(u32 dir_id, const char* name);
int fat32_rename_in(u32 dir_id, const char* old_name, const char* new_name);

int fat32_delete_file(const char* name);
int fat32_rename_file(const char* old_name, const char* new_name);
u32  fat32_free_bytes(void);

#endif
