#ifndef INFLATE_H
#define INFLATE_H
#include "io.h"

int inflate_raw(const u8* src, u32 src_len, u8* out, u32 out_cap, u32* out_len);

#endif
