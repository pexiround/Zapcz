
BITS 32
SECTION .text

extern _kernel_main
extern _bss_start
extern _bss_end

global _start
_start:
    mov esp, 0x3FF000
    mov ebp, esp

    mov edi, _bss_start
    mov ecx, _bss_end
    sub ecx, edi
    cmp ecx, 0
    je bss_zeroed
zero_bss_loop:
    mov byte [edi], 0
    inc edi
    dec ecx
    jnz zero_bss_loop
bss_zeroed:

    push ebx
    call _kernel_main

    cli
hang_forever:
    hlt
    jmp hang_forever
