#include "rtl8169.h"
#include "pci.h"
#include "io.h"
#include "libc_shim.h"

#define RTL_VENDOR 0x10EC

/* Register offsets (MMIO via BAR2, or I/O via BAR0 on older parts) */
#define R_IDR0      0x00
#define R_MAR0      0x08
#define R_TNPDS     0x20    /* transmit normal priority descriptor start (64-bit) */
#define R_CR        0x37    /* command */
#define R_TPPoll    0x38
#define R_IMR       0x3C
#define R_ISR       0x3E
#define R_TCR       0x40
#define R_RCR       0x44
#define R_9346CR    0x50    /* EEPROM command / config lock */
#define R_CONFIG1   0x52
#define R_PHYSTATUS 0x6C
#define R_RDSAR     0xE4    /* receive descriptor start (64-bit) */
#define R_MTPS      0xEC

#define CR_RST      0x10
#define CR_RE       0x08
#define CR_TE       0x04

#define DESC_OWN    0x80000000u
#define DESC_EOR    0x40000000u
#define DESC_FS     0x20000000u
#define DESC_LS     0x10000000u

#define NUM_TX 8
#define NUM_RX 16
#define BUF_SZ 2048

/* Descriptors must be 256-byte aligned and physically contiguous. */
typedef struct { u32 cmd; u32 vlan; u32 buf_lo; u32 buf_hi; } desc_t;

static desc_t tx_ring[NUM_TX] __attribute__((aligned(256)));
static desc_t rx_ring[NUM_RX] __attribute__((aligned(256)));
static u8 tx_buf[NUM_TX][BUF_SZ] __attribute__((aligned(16)));
static u8 rx_buf[NUM_RX][BUF_SZ] __attribute__((aligned(16)));

static volatile u8* mmio = 0;
static int rtl_ok = 0;
static u8  rtl_mac[6];
static u32 tx_cur = 0, rx_cur = 0;
static const char* rtl_name = "RTL8168/8169";

static u8  r8(u32 o)  { return mmio[o]; }
static u16 r16(u32 o) { return *(volatile u16*)(mmio + o); }
static u32 r32(u32 o) { return *(volatile u32*)(mmio + o); }
static void w8(u32 o, u8 v)   { mmio[o] = v; }
static void w16(u32 o, u16 v) { *(volatile u16*)(mmio + o) = v; }
static void w32(u32 o, u32 v) { *(volatile u32*)(mmio + o) = v; }

/* Device IDs across the 8168/8169/8111 family. */
static const u16 RTL_IDS[] = {
    0x8129, 0x8136, 0x8161, 0x8167, 0x8168, 0x8169, 0x8125, 0x2502, 0x2600, 0
};

int rtl8169_init(void) {
    pci_dev_t dev;
    int found = 0;
    for (int i = 0; RTL_IDS[i]; i++) {
        if (pci_find_device(RTL_VENDOR, RTL_IDS[i], &dev)) { found = 1; break; }
    }
    if (!found) return 0;

    pci_enable_bus_master(&dev);

    /* Prefer a memory BAR; these parts expose registers at BAR2 (and BAR1 on
       some steppings). Fall back to any memory BAR we can find. */
    u32 base = 0;
    for (int b = 0; b < 6; b++) {
        u32 bar = dev.bar[b];
        if (!bar || (bar & 0x1)) continue;      /* skip empty and I/O BARs */
        base = bar & ~0xFu;
        break;
    }
    if (!base) return 0;
    mmio = (volatile u8*)base;

    /* soft reset */
    w8(R_CR, CR_RST);
    for (int i = 0; i < 1000000; i++) { if (!(r8(R_CR) & CR_RST)) break; }

    for (int i = 0; i < 6; i++) rtl_mac[i] = r8(R_IDR0 + i);

    /* unlock config registers */
    w8(R_9346CR, 0xC0);

    /* build RX ring: every descriptor owned by the NIC, last one marks EOR */
    memset(rx_ring, 0, sizeof(rx_ring));
    for (int i = 0; i < NUM_RX; i++) {
        rx_ring[i].buf_lo = (u32)rx_buf[i];
        rx_ring[i].buf_hi = 0;
        rx_ring[i].cmd = DESC_OWN | (u32)BUF_SZ | (i == NUM_RX - 1 ? DESC_EOR : 0);
    }
    memset(tx_ring, 0, sizeof(tx_ring));
    for (int i = 0; i < NUM_TX; i++) {
        tx_ring[i].buf_lo = (u32)tx_buf[i];
        tx_ring[i].buf_hi = 0;
        tx_ring[i].cmd = (i == NUM_TX - 1) ? DESC_EOR : 0;
    }

    w32(R_RDSAR, (u32)rx_ring);      w32(R_RDSAR + 4, 0);
    w32(R_TNPDS, (u32)tx_ring);      w32(R_TNPDS + 4, 0);

    w16(R_MTPS, 0x3B);               /* max transmit packet size */
    w32(R_TCR, 0x03000700);          /* standard IFG, max DMA burst */
    w32(R_RCR, 0x0000E70F);          /* accept broadcast/multicast/physical/all */

    w8(R_CR, CR_RE | CR_TE);         /* enable rx + tx */
    w16(R_IMR, 0);                   /* poll instead of interrupting, for now */
    w16(R_ISR, 0xFFFF);

    w8(R_9346CR, 0x00);              /* relock config */

    tx_cur = rx_cur = 0;
    rtl_ok = 1;
    return 1;
}

int rtl8169_available(void) { return rtl_ok; }
void rtl8169_get_mac(u8 out[6]) { for (int i = 0; i < 6; i++) out[i] = rtl_mac[i]; }
const char* rtl8169_card_name(void) { return rtl_name; }

int rtl8169_send(const u8* data, u32 len) {
    if (!rtl_ok) return 0;
    if (len > BUF_SZ) len = BUF_SZ;
    desc_t* d = &tx_ring[tx_cur];
    if (d->cmd & DESC_OWN) return 0;             /* ring full */

    for (u32 i = 0; i < len; i++) tx_buf[tx_cur][i] = data[i];
    if (len < 60) { for (u32 i = len; i < 60; i++) tx_buf[tx_cur][i] = 0; len = 60; }

    u32 eor = (tx_cur == NUM_TX - 1) ? DESC_EOR : 0;
    d->cmd = DESC_OWN | DESC_FS | DESC_LS | eor | len;

    w8(R_TPPoll, 0x40);                          /* kick normal-priority queue */
    tx_cur = (tx_cur + 1) % NUM_TX;
    return 1;
}

int rtl8169_poll_recv(u8* buf, u32 bufsize) {
    if (!rtl_ok) return 0;
    desc_t* d = &rx_ring[rx_cur];
    if (d->cmd & DESC_OWN) return 0;             /* still owned by NIC: nothing yet */

    u32 len = d->cmd & 0x1FFF;
    if (len > 4) len -= 4;                       /* strip CRC */
    if (len > bufsize) len = bufsize;
    for (u32 i = 0; i < len; i++) buf[i] = rx_buf[rx_cur][i];

    u32 eor = (rx_cur == NUM_RX - 1) ? DESC_EOR : 0;
    d->cmd = DESC_OWN | eor | (u32)BUF_SZ;       /* hand back to the NIC */
    rx_cur = (rx_cur + 1) % NUM_RX;
    return (int)len;
}
