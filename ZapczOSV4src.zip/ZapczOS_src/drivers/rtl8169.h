#ifndef RTL8169_H
#define RTL8169_H
#include "io.h"

/* Realtek RTL8168/8111/8169 gigabit family -- the NIC in most Lenovo E-series,
   ThinkPads and a large share of desktop boards. */

int  rtl8169_init(void);
int  rtl8169_available(void);
void rtl8169_get_mac(u8 mac[6]);
int  rtl8169_send(const u8* data, u32 len);
int  rtl8169_poll_recv(u8* buf, u32 bufsize);
const char* rtl8169_card_name(void);

#endif
