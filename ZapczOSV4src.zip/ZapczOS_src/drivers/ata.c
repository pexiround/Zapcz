#include "ata.h"

#define ATA_DATA    0x1F0
#define ATA_ERR     0x1F1
#define ATA_SECCNT  0x1F2
#define ATA_LBA_LO  0x1F3
#define ATA_LBA_MID 0x1F4
#define ATA_LBA_HI  0x1F5
#define ATA_DRIVE   0x1F6
#define ATA_STATUS  0x1F7
#define ATA_CMD     0x1F7
#define ATA_CTRL    0x3F6

#define STATUS_BSY  0x80
#define STATUS_DRQ  0x08
#define STATUS_ERR  0x01

static int wait_not_busy(void) {
    for (int i = 0; i < 1000000; i++) {
        if (!(inb(ATA_STATUS) & STATUS_BSY)) return 1;
    }
    return 0;
}
static int wait_drq(void) {
    for (int i = 0; i < 1000000; i++) {
        u8 s = inb(ATA_STATUS);
        if (s & STATUS_ERR) return 0;
        if (s & STATUS_DRQ) return 1;
    }
    return 0;
}

static void select_lba(u32 lba) {
    outb(ATA_DRIVE, (u8)(0xE0 | ((lba >> 24) & 0x0F)));
    outb(ATA_SECCNT, 1);
    outb(ATA_LBA_LO,  (u8)(lba & 0xFF));
    outb(ATA_LBA_MID, (u8)((lba >> 8) & 0xFF));
    outb(ATA_LBA_HI,  (u8)((lba >> 16) & 0xFF));
}

int ata_detect(void) {
    u8 status = inb(ATA_STATUS);
    if (status == 0xFF) return 0;

    outb(ATA_DRIVE, 0xE0);
    io_wait();
    if (!wait_not_busy()) return 0;

    outb(ATA_CMD, 0xEC);
    if (!wait_not_busy()) return 0;

    status = inb(ATA_STATUS);
    if (status == 0 || (status & STATUS_ERR)) return 0;
    if (!wait_drq()) return 0;

    u16 buf[256];
    for (int i = 0; i < 256; i++) buf[i] = inw(ATA_DATA);
    (void)buf;
    return 1;
}

int ata_identify(char* model_out, u32 model_buf_size, u32* sectors_out) {
    u8 status = inb(ATA_STATUS);
    if (status == 0xFF) return 0;

    outb(ATA_DRIVE, 0xE0);
    io_wait();
    if (!wait_not_busy()) return 0;

    outb(ATA_CMD, 0xEC);
    if (!wait_not_busy()) return 0;

    status = inb(ATA_STATUS);
    if (status == 0 || (status & STATUS_ERR)) return 0;
    if (!wait_drq()) return 0;

    u16 buf[256];
    for (int i = 0; i < 256; i++) buf[i] = inw(ATA_DATA);

    u32 sectors = ((u32)buf[61] << 16) | buf[60];
    if (sectors_out) *sectors_out = sectors;

    if (model_out && model_buf_size > 0) {
        u32 p = 0;
        for (int w = 27; w <= 46 && p + 1 < model_buf_size; w++) {
            u16 v = buf[w];
            model_out[p++] = (char)(v >> 8);
            if (p + 1 < model_buf_size) model_out[p++] = (char)(v & 0xFF);
        }
        model_out[p] = 0;
        while (p > 0 && model_out[p - 1] == ' ') model_out[--p] = 0;
    }
    return 1;
}

int ata_read_sector(u32 lba, u8* buf512) {
    if (!wait_not_busy()) return 0;
    select_lba(lba);
    outb(ATA_CMD, 0x20);
    if (!wait_drq()) return 0;
    u16* p = (u16*)buf512;
    for (int i = 0; i < 256; i++) p[i] = inw(ATA_DATA);
    return 1;
}

int ata_write_sector(u32 lba, const u8* buf512) {
    if (!wait_not_busy()) return 0;
    select_lba(lba);
    outb(ATA_CMD, 0x30);
    if (!wait_drq()) return 0;
    const u16* p = (const u16*)buf512;
    for (int i = 0; i < 256; i++) outw(ATA_DATA, p[i]);
    outb(ATA_CMD, 0xE7);
    wait_not_busy();
    return 1;
}

int ata_read_sectors(u32 lba, u32 count, u8* buf) {
    if (count == 0 || count > 128) return 0;
    if (!wait_not_busy()) return 0;
    outb(ATA_DRIVE, (u8)(0xE0 | ((lba >> 24) & 0x0F)));
    outb(ATA_SECCNT, (u8)count);
    outb(ATA_LBA_LO,  (u8)(lba & 0xFF));
    outb(ATA_LBA_MID, (u8)((lba >> 8) & 0xFF));
    outb(ATA_LBA_HI,  (u8)((lba >> 16) & 0xFF));
    outb(ATA_CMD, 0x20);
    for (u32 s = 0; s < count; s++) {
        if (!wait_drq()) return (int)s;
        u16* p = (u16*)(buf + (u32)s * 512);
        for (int i = 0; i < 256; i++) p[i] = inw(ATA_DATA);
    }
    return (int)count;
}

int ata_write_sectors(u32 lba, u32 count, const u8* buf) {
    if (count == 0 || count > 128) return 0;
    if (!wait_not_busy()) return 0;
    outb(ATA_DRIVE, (u8)(0xE0 | ((lba >> 24) & 0x0F)));
    outb(ATA_SECCNT, (u8)count);
    outb(ATA_LBA_LO,  (u8)(lba & 0xFF));
    outb(ATA_LBA_MID, (u8)((lba >> 8) & 0xFF));
    outb(ATA_LBA_HI,  (u8)((lba >> 16) & 0xFF));
    outb(ATA_CMD, 0x30);
    for (u32 s = 0; s < count; s++) {
        if (!wait_drq()) return (int)s;
        const u16* p = (const u16*)(buf + (u32)s * 512);
        for (int i = 0; i < 256; i++) outw(ATA_DATA, p[i]);
    }
    outb(ATA_CMD, 0xE7);
    wait_not_busy();
    return (int)count;
}

static const u16 CH_IO[2]   = { 0x1F0, 0x170 };

typedef struct {
    int present;
    int is_atapi;
    char model[41];
    u32 sectors;
} ata_drive_rec_t;

static ata_drive_rec_t drives[ATA_MAX_DRIVES];

static int ch_wait_not_busy(u16 io) {
    for (int i = 0; i < 1000000; i++) {
        if (!(inb((u16)(io + 7)) & STATUS_BSY)) return 1;
    }
    return 0;
}
static int ch_wait_drq(u16 io) {
    for (int i = 0; i < 1000000; i++) {
        u8 s = inb((u16)(io + 7));
        if (s & STATUS_ERR) return 0;
        if (s & STATUS_DRQ) return 1;
    }
    return 0;
}

int ata_scan_all(void) {
    int count = 0;
    for (int idx = 0; idx < ATA_MAX_DRIVES; idx++) {
        int ch = idx / 2, slave = idx % 2;
        u16 io = CH_IO[ch];

        drives[idx].present = 0;
        drives[idx].is_atapi = 0;
        drives[idx].model[0] = 0;
        drives[idx].sectors = 0;

        u8 status = inb((u16)(io + 7));
        if (status == 0xFF) continue;

        outb((u16)(io + 6), (u8)(0xE0 | (slave << 4)));
        io_wait();
        if (!ch_wait_not_busy(io)) continue;

        outb((u16)(io + 7), 0xEC);
        if (!ch_wait_not_busy(io)) continue;

        status = inb((u16)(io + 7));
        if (status == 0) continue;

        int is_atapi = 0;
        if (status & STATUS_ERR) {
            u8 mid = inb((u16)(io + 4));
            u8 hi  = inb((u16)(io + 5));
            if (mid != 0x14 || hi != 0xEB) continue;
            is_atapi = 1;
            outb((u16)(io + 7), 0xA1);
            if (!ch_wait_not_busy(io)) continue;
            status = inb((u16)(io + 7));
            if (status & STATUS_ERR) continue;
        }
        if (!ch_wait_drq(io)) continue;

        u16 buf[256];
        for (int i = 0; i < 256; i++) buf[i] = inw(io);

        drives[idx].present = 1;
        drives[idx].is_atapi = is_atapi;
        drives[idx].sectors = is_atapi ? 0 : (((u32)buf[61] << 16) | buf[60]);

        u32 p = 0;
        for (int w = 27; w <= 46 && p + 1 < 41; w++) {
            u16 v = buf[w];
            drives[idx].model[p++] = (char)(v >> 8);
            if (p + 1 < 41) drives[idx].model[p++] = (char)(v & 0xFF);
        }
        drives[idx].model[p] = 0;
        while (p > 0 && drives[idx].model[p - 1] == ' ') drives[idx].model[--p] = 0;

        count++;
    }
    return count;
}

int ata_drive_present(int idx) {
    return (idx >= 0 && idx < ATA_MAX_DRIVES) ? drives[idx].present : 0;
}
int ata_drive_is_atapi(int idx) {
    return (idx >= 0 && idx < ATA_MAX_DRIVES) ? drives[idx].is_atapi : 0;
}
const char* ata_drive_model(int idx) {
    return (idx >= 0 && idx < ATA_MAX_DRIVES) ? drives[idx].model : "";
}
u32 ata_drive_sectors(int idx) {
    return (idx >= 0 && idx < ATA_MAX_DRIVES) ? drives[idx].sectors : 0;
}

int ata_drive_read_sectors(int idx, u32 lba, u32 count, u8* buf) {
    if (idx < 0 || idx >= ATA_MAX_DRIVES) return 0;
    if (!drives[idx].present || drives[idx].is_atapi) return 0;
    if (count == 0 || count > 128) return 0;
    int ch = idx / 2, slave = idx % 2;
    u16 io = CH_IO[ch];
    if (!ch_wait_not_busy(io)) return 0;
    outb((u16)(io + 6), (u8)(0xE0 | (slave << 4) | ((lba >> 24) & 0x0F)));
    io_wait(); io_wait(); io_wait(); io_wait();
    if (!ch_wait_not_busy(io)) return 0;
    outb((u16)(io + 2), (u8)count);
    outb((u16)(io + 3), (u8)(lba & 0xFF));
    outb((u16)(io + 4), (u8)((lba >> 8) & 0xFF));
    outb((u16)(io + 5), (u8)((lba >> 16) & 0xFF));
    outb((u16)(io + 7), 0x20);
    for (u32 s = 0; s < count; s++) {
        if (!ch_wait_drq(io)) return (int)s;
        u16* p = (u16*)(buf + (u32)s * 512);
        for (int i = 0; i < 256; i++) p[i] = inw(io);
    }
    return (int)count;
}

int ata_drive_write_sectors(int idx, u32 lba, u32 count, const u8* buf) {
    if (idx < 0 || idx >= ATA_MAX_DRIVES) return 0;
    if (!drives[idx].present || drives[idx].is_atapi) return 0;
    if (count == 0 || count > 128) return 0;
    int ch = idx / 2, slave = idx % 2;
    u16 io = CH_IO[ch];
    if (!ch_wait_not_busy(io)) return 0;
    outb((u16)(io + 6), (u8)(0xE0 | (slave << 4) | ((lba >> 24) & 0x0F)));
    io_wait(); io_wait(); io_wait(); io_wait();
    if (!ch_wait_not_busy(io)) return 0;
    outb((u16)(io + 2), (u8)count);
    outb((u16)(io + 3), (u8)(lba & 0xFF));
    outb((u16)(io + 4), (u8)((lba >> 8) & 0xFF));
    outb((u16)(io + 5), (u8)((lba >> 16) & 0xFF));
    outb((u16)(io + 7), 0x30);
    for (u32 s = 0; s < count; s++) {
        if (!ch_wait_drq(io)) return (int)s;
        const u16* p = (const u16*)(buf + (u32)s * 512);
        for (int i = 0; i < 256; i++) outw(io, p[i]);
    }
    return (int)count;
}

int ata_drive_flush(int idx) {
    if (idx < 0 || idx >= ATA_MAX_DRIVES) return 0;
    if (!drives[idx].present || drives[idx].is_atapi) return 0;
    int ch = idx / 2;
    u16 io = CH_IO[ch];
    if (!ch_wait_not_busy(io)) return 0;
    outb((u16)(io + 7), 0xE7);
    ch_wait_not_busy(io);
    return 1;
}
