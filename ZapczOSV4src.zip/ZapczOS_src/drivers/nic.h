#ifndef NIC_H
#define NIC_H
#include "io.h"

int  nic_init(void);
int  nic_available(void);
void nic_get_mac(u8 mac[6]);
int  nic_send(const u8* data, u32 len);
int  nic_poll_recv(u8* buf, u32 bufsize);
const char* nic_card_name(void);

#endif
