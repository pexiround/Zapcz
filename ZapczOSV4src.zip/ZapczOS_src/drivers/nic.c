#include "nic.h"
#include "e1000.h"
#include "rtl8139.h"
#include "rtl8169.h"

/* 0 = none, 1 = e1000, 2 = rtl8139, 3 = rtl8168/8169 */
static int active = 0;

int nic_init(void) {
    if (e1000_init()) { active = 1; return 1; }
    if (rtl8169_init()) { active = 3; return 1; }   /* gigabit Realtek, common in Lenovo E-series */
    if (rtl8139_init()) { active = 2; return 1; }
    active = 0;
    return 0;
}

int nic_available(void) {
    if (active == 1) return e1000_available();
    if (active == 2) return rtl8139_available();
    if (active == 3) return rtl8169_available();
    return 0;
}

void nic_get_mac(u8 mac[6]) {
    if (active == 1) e1000_get_mac(mac);
    else if (active == 2) rtl8139_get_mac(mac);
    else if (active == 3) rtl8169_get_mac(mac);
    else for (int i = 0; i < 6; i++) mac[i] = 0;
}

int nic_send(const u8* data, u32 len) {
    if (active == 1) return e1000_send(data, len);
    if (active == 2) return rtl8139_send(data, len);
    if (active == 3) return rtl8169_send(data, len);
    return 0;
}

int nic_poll_recv(u8* buf, u32 bufsize) {
    if (active == 1) return e1000_poll_recv(buf, bufsize);
    if (active == 2) return rtl8139_poll_recv(buf, bufsize);
    if (active == 3) return rtl8169_poll_recv(buf, bufsize);
    return 0;
}

const char* nic_card_name(void) {
    if (active == 1) return e1000_card_name();
    if (active == 2) return rtl8139_card_name();
    if (active == 3) return rtl8169_card_name();
    return "none";
}
