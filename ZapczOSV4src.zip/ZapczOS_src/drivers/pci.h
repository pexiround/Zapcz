#ifndef PCI_H
#define PCI_H
#include "io.h"

typedef struct {
    u8  bus, dev, func;
    u16 vendor_id, device_id;
    u8  class_code, subclass, prog_if;
    u32 bar[6];
} pci_dev_t;

u32  pci_read32(u8 bus, u8 dev, u8 func, u8 offset);
u16  pci_read16(u8 bus, u8 dev, u8 func, u8 offset);
u8   pci_read8(u8 bus, u8 dev, u8 func, u8 offset);
void pci_write32(u8 bus, u8 dev, u8 func, u8 offset, u32 val);
void pci_write16(u8 bus, u8 dev, u8 func, u8 offset, u16 val);

int  pci_find_class(u8 class_code, u8 subclass, pci_dev_t* out);
int  pci_find_device(u16 vendor_id, u16 device_id, pci_dev_t* out);
void pci_enable_bus_master(const pci_dev_t* d);

#endif
