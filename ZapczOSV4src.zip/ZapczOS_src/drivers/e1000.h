#ifndef E1000_H
#define E1000_H
#include "io.h"

int  e1000_init(void);
int  e1000_available(void);
void e1000_get_mac(u8 mac[6]);
int  e1000_send(const u8* data, u32 len);
int  e1000_poll_recv(u8* buf, u32 bufsize);
const char* e1000_card_name(void);

#endif
