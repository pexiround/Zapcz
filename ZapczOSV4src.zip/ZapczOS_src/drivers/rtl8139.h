#ifndef RTL8139_H
#define RTL8139_H
#include "io.h"

int  rtl8139_init(void);
int  rtl8139_available(void);
void rtl8139_get_mac(u8 mac[6]);
int  rtl8139_send(const u8* data, u32 len);
int  rtl8139_poll_recv(u8* buf, u32 bufsize);
const char* rtl8139_card_name(void);

#endif
