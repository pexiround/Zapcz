#include "battery.h"
#include "io.h"

static int g_ec_ok = 0;

void battery_init(void) {
    u8 status = inb(0x66);
    g_ec_ok = (status != 0xFF);
}

void battery_read(battery_status_t* out) {
    out->present   = 0;
    out->ac_online = 1;
    out->charging  = 0;
    out->percent   = 100;

    if (!g_ec_ok) return;

    u8 ec_flags = inb(0x62);
    if (ec_flags == 0xFF || ec_flags == 0x00) return;

    out->present   = 1;
    out->charging  = (ec_flags & 0x02) ? 1 : 0;
    out->ac_online = (ec_flags & 0x04) ? 1 : 0;
    if (out->charging) out->ac_online = 1;

    u8 pct = inb(0x63);
    if (pct > 100) pct = 100;
    out->percent = (int)pct;
}
