#ifndef IWLWIFI_H
#define IWLWIFI_H
#include "io.h"
#include "wifi.h"

int  iwl_init(u32 fw_addr, u32 fw_size, int fw_type);
int  iwl_fw_validate(u32 fw_addr, u32 fw_size);
int  iwl_detect_family(void);
void iwl_dump_diag(void (*emit)(const char*));
int  iwl_scan(wifi_bss_t* out, u32 max, u32* found);
int  iwl_connect(const char* ssid, const char* pass);
void iwl_poll(void);
int  iwl_is_up(void);
const char* iwl_status(void);

#endif
