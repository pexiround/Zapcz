#ifndef ATH9K_H
#define ATH9K_H
#include "io.h"
#include "wifi80211.h"

#define ATH9K_VENDOR_ID 0x168C
#define ATH9K_MAX_TX_BUFS 64
#define ATH9K_MAX_RX_BUFS 128
#define ATH9K_RX_BUF_SIZE 2048
#define ATH9K_TX_BUF_SIZE 2048

typedef struct {
    u32 ctl;
    u32 data_ptr;
    u32 ctl2;
    u32 status;
} ath9k_desc_t;

typedef struct {
    u32 pci_mmio;
    u16 device_id;
    u8  mac_addr[6];
    u8  current_channel;
    u8  initialized;
    u8  opmode;

    ath9k_desc_t* rx_descs;
    u8**          rx_bufs;
    u32           rx_head;

    ath9k_desc_t* tx_descs;
    u8**          tx_bufs;
    u32           tx_tail;
    u32           tx_head;

    wifi_ctx_t*   wifi;
} ath9k_ctx_t;

int  ath9k_detect(void);
int  ath9k_init(ath9k_ctx_t* ctx);
const char* wifi_detect_unsupported(void);
int  ath9k_set_channel(ath9k_ctx_t* ctx, u8 channel);
int  ath9k_tx(ath9k_ctx_t* ctx, const u8* data, u32 len);
int  ath9k_rx_poll(ath9k_ctx_t* ctx, u8* buf, u32 bufsize, u32* rx_len, i32* rssi);
void ath9k_irq_handler(ath9k_ctx_t* ctx);

extern ath9k_ctx_t g_ath9k;

#endif
