#ifndef IWL_FH_H
#define IWL_FH_H
#include "io.h"

void iwl_fh_bind(volatile u32* mmio);
int  iwl_fh_grab_nic_access(void);
void iwl_fh_release_nic_access(void);
int  iwl_fh_load_section(const u8* data, u32 size, u32 dst_addr);
void iwl_fh_release_cpu(void);
int  iwl_fh_rx_init(void);
u32  iwl_fh_rx_wptr(void);
u32  iwl_fh_rx_next(const u8** out);

#endif
int iwl_fh_tx_init(void);
void iwl_fh_scd_init(u32 scd_base);
int iwl_fh_send_hcmd(u8 group, u8 cmd, const u8* payload, u16 len);
int iwl_fh_tx_ready(void);
u32 iwl_fh_tx_wptr(void);
u32 iwl_fh_cmd_queue_id(void);
