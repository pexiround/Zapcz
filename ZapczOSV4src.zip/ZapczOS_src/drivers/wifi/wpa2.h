#ifndef WPA2_H
#define WPA2_H
#include "io.h"

void wpa2_pbkdf2_sha1(const u8* password, u32 pwlen,
                       const u8* ssid, u32 ssidlen,
                       u8 out_pmk[32]);

void wpa2_prf_sha1(const u8* key, u32 klen,
                    const char* label,
                    const u8* data, u32 datalen,
                    u8* out, u32 outlen);

void wpa2_derive_ptk(const u8 pmk[32],
                      const u8 anonce[32], const u8 snonce[32],
                      const u8 ap_mac[6], const u8 sta_mac[6],
                      u8* ptk, u32 ptk_len);

void wpa2_michael_mic(const u8* key, const u8* data, u32 datalen, u8 mic[8]);

#endif
