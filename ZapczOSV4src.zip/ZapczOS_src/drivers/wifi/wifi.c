#include "wifi.h"
#include "ath9k.h"
#include "wifi80211.h"
#include "wpa2.h"
#include "libc_shim.h"
#include "util.h"
#include "mm.h"
#include "random.h"
#include "pit.h"

#define WIFI_SCAN_CHAN_DWELL_MS 120
#define WIFI_AUTH_TIMEOUT_MS    3000
#define WIFI_ASSOC_TIMEOUT_MS   3000
#define WIFI_EAPOL_TIMEOUT_MS   5000

static int g_wifi_available = 0;
extern int g_iwl_available;
static wifi_ctx_t g_wctx;
static u8 g_rx_buf[2048];
static u16 g_seq_num = 0;

static u16 next_seq(void) { return g_seq_num++; }

static int ticks_elapsed(u32 start, u32 ms) {
    return (ticks_get() - start) >= (ms * ticks_per_sec() / 1000);
}

/* Which radio backend is driving the stack. Previously everything below was
   hardwired to ath9k, so an Intel card could never reach scan or connect even
   after its driver had initialised. */
typedef enum { WIFI_BACKEND_NONE = 0, WIFI_BACKEND_ATH9K, WIFI_BACKEND_IWL } wifi_backend_t;
static wifi_backend_t g_backend = WIFI_BACKEND_NONE;

wifi_backend_t wifi_backend(void) { return g_backend; }

void wifi_init(void) {
    memset(&g_wctx, 0, sizeof(g_wctx));

    if (ath9k_detect() && ath9k_init(&g_ath9k)) {
        memcpy(g_wctx.sta_mac, g_ath9k.mac_addr, 6);
        g_ath9k.wifi = &g_wctx;
        g_backend = WIFI_BACKEND_ATH9K;
        g_wifi_available = 1;
        return;
    }

    /* iwl_try_init_multi() has already run from kernel_main by this point, so
       if an Intel radio came up we adopt it as the backend. */
    if (g_iwl_available && iwl_is_up()) {
        g_backend = WIFI_BACKEND_IWL;
        g_wifi_available = 1;
        return;
    }

    g_backend = WIFI_BACKEND_NONE;
    g_wifi_available = 0;
}

int wifi_available(void) { return g_wifi_available; }

int wifi_scan(wifi_bss_t* results, u32 max_results, u32* count) {
    if (!g_wifi_available) return 0;
    *count = 0;

    if (g_backend == WIFI_BACKEND_IWL)
        return iwl_scan(results, max_results, count);

    for (u8 chan = 1; chan <= 13 && *count < max_results; chan++) {
        ath9k_set_channel(&g_ath9k, chan);
        u8 probe[128];
        u32 plen = wifi80211_build_probe_req(probe, sizeof(probe),
                                              g_wctx.sta_mac, "", 0);
        ath9k_tx(&g_ath9k, probe, plen);
        u32 t0 = ticks_get();
        while (!ticks_elapsed(t0, WIFI_SCAN_CHAN_DWELL_MS)) {
            u32 rx_len = 0; i32 rssi = 0;
            if (ath9k_rx_poll(&g_ath9k, g_rx_buf, sizeof(g_rx_buf), &rx_len, &rssi)) {
                wifi_bss_t bss;
                if (wifi80211_parse_beacon(g_rx_buf, rx_len, &bss) && bss.ssid_len > 0) {
                    bss.rssi = rssi;
                    int dup = 0;
                    for (u32 j = 0; j < *count; j++) {
                        if (memcmp(results[j].bssid, bss.bssid, 6) == 0) { dup = 1; break; }
                    }
                    if (!dup && *count < max_results) {
                        memcpy(&results[*count], &bss, sizeof(bss));
                        (*count)++;
                    }
                }
            }
        }
    }
    return 1;
}

static int find_bss(const char* ssid, wifi_bss_t* out) {
    wifi_bss_t results[WIFI_MAX_BSS];
    u32 count = 0;
    wifi_scan(results, WIFI_MAX_BSS, &count);
    for (u32 i = 0; i < count; i++) {
        if (str_eq_ci(results[i].ssid, ssid)) {
            memcpy(out, &results[i], sizeof(*out));
            return 1;
        }
    }
    return 0;
}

static int handle_eapol(const u8* frame, u32 framelen) {
    if (framelen < 24 + 4) return 0;
    const u8* payload = frame + 24;
    u32 paylen = framelen - 24;
    if (paylen < 8) return 0;
    if (payload[0] != 0xAA || payload[1] != 0xAA || payload[2] != 0x03) return 0;
    u16 etype = (u16)(((u32)payload[6] << 8) | payload[7]);
    if (etype != 0x888E) return 0;
    if (paylen < 12) return 0;
    const u8* eapol = payload + 8;
    u32 eapol_len = paylen - 8;
    if (eapol_len < 4 || eapol[0] != 0x02 || eapol[1] != 3) return 0;
    u32 body_len = ((u32)eapol[2] << 8) | eapol[3];
    if (body_len + 4 > eapol_len) return 0;
    const u8* kd = eapol + 4;
    u16 key_info = (u16)(((u32)kd[5] << 8) | kd[6]);
    int msg_num = 0;
    if ((key_info & 0x0100) && !(key_info & 0x0080)) msg_num = 1;
    else if ((key_info & 0x0100) && (key_info & 0x0080)) msg_num = 3;
    if (msg_num == 0) return 0;

    if (msg_num == 1) {
        if (body_len < 33) return 0;
        memcpy(g_wctx.anonce, kd + 17, 32);
        rng_bytes(g_wctx.snonce, 32);
        wpa2_derive_ptk(g_wctx.pmk, g_wctx.anonce, g_wctx.snonce,
                         g_wctx.bssid, g_wctx.sta_mac, g_wctx.ptk, 64);

        u8 msg2[128];
        u32 p = 0;
        msg2[p++]=0xAA; msg2[p++]=0xAA; msg2[p++]=0x03;
        msg2[p++]=0; msg2[p++]=0; msg2[p++]=0;
        msg2[p++]=0x88; msg2[p++]=0x8E;
        msg2[p++]=0x02; msg2[p++]=0x03;
        u32 body_start = p;
        msg2[p++]=0; msg2[p++]=0x77;
        msg2[p++]=0x01; msg2[p++]=0x01;
        msg2[p++]=0;
        for (int i=0;i<7;i++) msg2[p++]=0;
        memcpy(msg2+p, g_wctx.snonce, 32); p+=32;
        for (int i=0;i<18;i++) msg2[p++]=0;
        u8 mic[20];
        wpa2_prf_sha1(g_wctx.ptk, 16, "HMAC-SHA1-MIC",
                       msg2+body_start, p-body_start, mic, 16);
        memcpy(msg2+body_start+8, mic, 16);
        u8 frame2[200];
        u32 flen = wifi80211_build_data(frame2, sizeof(frame2),
                                         g_wctx.sta_mac, g_wctx.bssid, g_wctx.bssid,
                                         msg2, p, next_seq());
        ath9k_tx(&g_ath9k, frame2, flen);

    } else {
        u8 msg4[100];
        u32 p = 0;
        msg4[p++]=0xAA; msg4[p++]=0xAA; msg4[p++]=0x03;
        msg4[p++]=0; msg4[p++]=0; msg4[p++]=0;
        msg4[p++]=0x88; msg4[p++]=0x8E;
        msg4[p++]=0x02; msg4[p++]=0x03;
        msg4[p++]=0; msg4[p++]=0x5F;
        msg4[p++]=0x03; msg4[p++]=0x01;
        msg4[p++]=0;
        for (int i=0;i<55;i++) msg4[p++]=0;
        u8 frame4[200];
        u32 flen = wifi80211_build_data(frame4, sizeof(frame4),
                                         g_wctx.sta_mac, g_wctx.bssid, g_wctx.bssid,
                                         msg4, p, next_seq());
        ath9k_tx(&g_ath9k, frame4, flen);
        g_wctx.state = WIFI_STATE_CONNECTED;
        g_wctx.ready = 1;
        return 1;
    }
    return 0;
}

int wifi_connect(const char* ssid, const char* passphrase) {
    if (!g_wifi_available) return 0;

    if (g_backend == WIFI_BACKEND_IWL)
        return iwl_connect(ssid, passphrase);

    wifi_bss_t bss;
    if (!find_bss(ssid, &bss)) return 0;
    str_copy(g_wctx.ssid, ssid, WIFI_MAX_SSID_LEN);
    g_wctx.ssid_len = (u8)str_len(ssid);
    memcpy(g_wctx.bssid, bss.bssid, 6);
    g_wctx.channel = bss.channel;
    wpa2_pbkdf2_sha1((const u8*)passphrase, str_len(passphrase),
                      (const u8*)ssid, str_len(ssid), g_wctx.pmk);
    ath9k_set_channel(&g_ath9k, g_wctx.channel);

    u8 auth[64];
    u32 alen = wifi80211_build_auth_req(auth, sizeof(auth), g_wctx.sta_mac, g_wctx.bssid, 1);
    ath9k_tx(&g_ath9k, auth, alen);
    g_wctx.state = WIFI_STATE_AUTHENTICATING;

    u32 t0 = ticks_get();
    while (!ticks_elapsed(t0, WIFI_AUTH_TIMEOUT_MS)) {
        u32 rx_len=0; i32 rssi=0;
        if (ath9k_rx_poll(&g_ath9k, g_rx_buf, sizeof(g_rx_buf), &rx_len, &rssi)) {
            if (!wifi80211_frame_is_for_me(g_rx_buf, g_wctx.sta_mac)) continue;
            u16 status;
            if (wifi80211_parse_auth_resp(g_rx_buf, rx_len, &status) && status == 0) {
                g_wctx.state = WIFI_STATE_ASSOCIATING;
                break;
            }
        }
    }
    if (g_wctx.state != WIFI_STATE_ASSOCIATING) return 0;

    u8 assoc[256];
    u32 asslen = wifi80211_build_assoc_req(assoc, sizeof(assoc),
                                            g_wctx.sta_mac, g_wctx.bssid,
                                            ssid, g_wctx.ssid_len, 10, 1);
    ath9k_tx(&g_ath9k, assoc, asslen);

    t0 = ticks_get();
    while (!ticks_elapsed(t0, WIFI_ASSOC_TIMEOUT_MS)) {
        u32 rx_len=0; i32 rssi=0;
        if (ath9k_rx_poll(&g_ath9k, g_rx_buf, sizeof(g_rx_buf), &rx_len, &rssi)) {
            if (!wifi80211_frame_is_for_me(g_rx_buf, g_wctx.sta_mac)) continue;
            u16 status, aid;
            if (wifi80211_parse_assoc_resp(g_rx_buf, rx_len, &status, &aid) && status == 0) {
                g_wctx.assoc_id = aid;
                break;
            }
        }
    }
    if (!g_wctx.assoc_id) return 0;

    for (int pass = 0; pass < 2; pass++) {
        t0 = ticks_get();
        while (!ticks_elapsed(t0, WIFI_EAPOL_TIMEOUT_MS)) {
            u32 rx_len=0; i32 rssi=0;
            if (ath9k_rx_poll(&g_ath9k, g_rx_buf, sizeof(g_rx_buf), &rx_len, &rssi)) {
                if (!wifi80211_frame_is_for_me(g_rx_buf, g_wctx.sta_mac)) continue;
                if (handle_eapol(g_rx_buf, rx_len)) break;
            }
        }
        if (g_wctx.state == WIFI_STATE_CONNECTED) break;
    }
    return g_wctx.state == WIFI_STATE_CONNECTED;
}

void wifi_disconnect(void) {
    if (!g_wifi_available) return;
    if (g_wctx.state != WIFI_STATE_CONNECTED) return;
    u8 buf[64];
    u32 len = wifi80211_build_deauth(buf, sizeof(buf), g_wctx.sta_mac, g_wctx.bssid, 3);
    ath9k_tx(&g_ath9k, buf, len);
    g_wctx.state = WIFI_STATE_IDLE;
    g_wctx.ready = 0;
}

void wifi_tick(void) {
    if (!g_wifi_available || g_wctx.state != WIFI_STATE_CONNECTED) return;
    u32 rx_len=0; i32 rssi=0;
    if (ath9k_rx_poll(&g_ath9k, g_rx_buf, sizeof(g_rx_buf), &rx_len, &rssi)) {
        if (wifi80211_frame_is_for_me(g_rx_buf, g_wctx.sta_mac))
            handle_eapol(g_rx_buf, rx_len);
    }
}

int  wifi_connected(void) { return g_wifi_available && g_wctx.state == WIFI_STATE_CONNECTED; }

void wifi_get_status(wifi_status_t* out) {
    memset(out, 0, sizeof(*out));
    out->available = g_wifi_available;
    out->connected = wifi_connected();
    if (out->connected) {
        memcpy(out->bssid, g_wctx.bssid, 6);
        str_copy(out->ssid, g_wctx.ssid, sizeof(out->ssid));
        out->channel = g_wctx.channel;
    }
}

int wifi_send(const u8* dst_ip, const u8* payload, u32 len) {
    (void)dst_ip;
    if (!wifi_connected()) return 0;
    static const u8 bcast_mac[6] = {0xFF,0xFF,0xFF,0xFF,0xFF,0xFF};
    u8 frame[2048];
    u32 flen = wifi80211_build_data(frame, sizeof(frame),
                                     g_wctx.sta_mac, g_wctx.bssid, bcast_mac,
                                     payload, len, next_seq());
    return ath9k_tx(&g_ath9k, frame, flen);
}

#include "iwlwifi.h"

int g_iwl_available = 0;

/* Pick the firmware that matches the radio actually fitted, rather than
   trying blobs in a fixed order. iwl_detect_family() only touches PCI config
   space, so it is safe to call before any firmware is chosen. */
void iwl_try_init_multi(u32 fw8265_addr, u32 fw8265_size,
                        u32 fw3160_addr, u32 fw3160_size,
                        u32 fw7265_addr, u32 fw7265_size,
                        u32 fw9260_addr, u32 fw9260_size) {
    int fam = iwl_detect_family();
    u32 addr = 0, size = 0;
    int type = 0;

    if (fam == 3160)      { addr = fw3160_addr; size = fw3160_size; type = 1; }
    else if (fam == 7000) { addr = fw7265_addr; size = fw7265_size; type = 1; }
    else if (fam == 8000) { addr = fw8265_addr; size = fw8265_size; type = 0; }
    else if (fam == 9000) { addr = fw9260_addr; size = fw9260_size; type = 0; }

    /* fall back to whatever we were given if the exact blob is missing */
    if (!addr || size < 88) {
        if (fw8265_addr && fw8265_size > 88) { addr = fw8265_addr; size = fw8265_size; type = 0; }
        else if (fw3160_addr && fw3160_size > 88) { addr = fw3160_addr; size = fw3160_size; type = 1; }
        else if (fw7265_addr && fw7265_size > 88) { addr = fw7265_addr; size = fw7265_size; type = 1; }
        else if (fw9260_addr && fw9260_size > 88) { addr = fw9260_addr; size = fw9260_size; type = 0; }
    }

    if (addr && size > 88) iwl_fw_validate(addr, size);
    if (addr && size > 88 && iwl_init(addr, size, type)) g_iwl_available = 1;
}

void iwl_try_init(u32 fw8265_addr, u32 fw8265_size, u32 fw3160_addr, u32 fw3160_size) {
    iwl_try_init_multi(fw8265_addr, fw8265_size, fw3160_addr, fw3160_size, 0, 0, 0, 0);
}

