#ifndef WIFI_H
#define WIFI_H
#include "io.h"
#include "wifi80211.h"

typedef struct {
    int  available;
    int  connected;
    u8   bssid[6];
    char ssid[33];
    u8   channel;
    i32  rssi;
    u32  ip;
    u32  netmask;
    u32  gateway;
} wifi_status_t;

void wifi_init(void);
int  wifi_available(void);
int  wifi_scan(wifi_bss_t* results, u32 max_results, u32* count);
int  wifi_connect(const char* ssid, const char* passphrase);
void wifi_disconnect(void);
void wifi_tick(void);
int  wifi_connected(void);
void wifi_get_status(wifi_status_t* out);
int  wifi_send(const u8* dst_ip, const u8* payload, u32 len);

#endif
void iwl_try_init(u32 fw8265_addr, u32 fw8265_size, u32 fw3160_addr, u32 fw3160_size);
