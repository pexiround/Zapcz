#include "ath9k.h"
#include "ath9k_regs.h"
#include "pci.h"
#include "mm.h"
#include "libc_shim.h"
#include "util.h"

ath9k_ctx_t g_ath9k;

static const struct { u16 vid; u16 did; const char* name; } INTEL_WIFI_IDS[] = {
    {0x8086,0x24FD,"Intel 8265"},
    {0x8086,0x24FB,"Intel 8265D"},
    {0x8086,0x24F3,"Intel 8260"},
    {0x8086,0x08B3,"Intel 3160"},
    {0x8086,0x08B4,"Intel 3160"},
    {0x8086,0x3166,"Intel 3165"},
    {0x8086,0x3165,"Intel 3165"},
    {0x8086,0x3168,"Intel 3168"},
    {0x8086,0x2526,"Intel 9260"},
    {0x8086,0x2723,"Intel AX200"},
    {0x8086,0x02F0,"Intel AX201"},
    {0x8086,0x06F0,"Intel AX201"},
    {0x8086,0x4DF0,"Intel AX211"},
    {0x8086,0x34F0,"Intel AX201"},
    {0x8086,0x54F0,"Intel AX211"},
    {0x8086,0x7AF0,"Intel AX211"},
    {0x8086,0xA0F0,"Intel AX201"},
    {0x8086,0x51F0,"Intel AX211"},
    {0x8086,0xA370,"Intel 9560"},
    {0x8086,0x31DC,"Intel 9560"},
    {0x8086,0x9DF0,"Intel 9560"},
    {0x10EC,0xB723,"Realtek 8723BE"},
    {0x10EC,0xB822,"Realtek 8822BE"},
    {0x10EC,0xC822,"Realtek 8822CE"},
    {0x10EC,0x8176,"Realtek 8188CE"},
    {0x10EC,0xD723,"Realtek 8723DE"},
    {0x10EC,0xC821,"Realtek 8821CE"},
    {0x14E4,0x4365,"Broadcom BCM43142"},
    {0x14E4,0x4359,"Broadcom BCM43228"},
    {0x14E4,0x43A0,"Broadcom BCM4360"},
    {0x14E4,0x43BA,"Broadcom BCM43602"},
    {0x14E4,0x4311,"Broadcom BCM4311"},
    {0x14E4,0x4312,"Broadcom BCM4312"},
    {0x14E4,0x432B,"Broadcom BCM4322"},
    {0x14E4,0x4353,"Broadcom BCM43224"},
    {0x14E4,0x4727,"Broadcom BCM4313"},
    {0,0,0}
};

const char* wifi_detect_unsupported(void) {
    pci_dev_t d;
    for (int i = 0; INTEL_WIFI_IDS[i].vid; i++) {
        if (pci_find_device(INTEL_WIFI_IDS[i].vid, INTEL_WIFI_IDS[i].did, &d))
            return INTEL_WIFI_IDS[i].name;
    }
    return 0;
}

static const u16 ATH9K_DEVICE_IDS[] = {
    0x0023, 0x0024, 0x0027, 0x0029, 0x002A, 0x002B,
    0x002C, 0x002D, 0x002E, 0x0030, 0x0032, 0x0033,
    0x0034, 0x0036, 0x0037, 0x003C,
    0
};

static u32 ar_read(ath9k_ctx_t* ctx, u32 reg) {
    volatile u32* p = (volatile u32*)(ctx->pci_mmio + reg);
    return *p;
}
static void ar_write(ath9k_ctx_t* ctx, u32 reg, u32 val) {
    volatile u32* p = (volatile u32*)(ctx->pci_mmio + reg);
    *p = val;
}
static void ar_set_bits(ath9k_ctx_t* ctx, u32 reg, u32 bits) {
    ar_write(ctx, reg, ar_read(ctx, reg) | bits);
}
static void ar_clear_bits(ath9k_ctx_t* ctx, u32 reg, u32 bits) {
    ar_write(ctx, reg, ar_read(ctx, reg) & ~bits);
}

static void udelay(u32 us) {
    volatile u32 dummy;
    for (u32 i = 0; i < us * 100; i++) dummy = i;
    (void)dummy;
}
static void mdelay(u32 ms) { udelay(ms * 1000); }

static void ar_wait(ath9k_ctx_t* ctx, u32 reg, u32 mask, u32 val, u32 ms) {
    for (u32 i = 0; i < ms * 10; i++) {
        if ((ar_read(ctx, reg) & mask) == val) return;
        udelay(100);
    }
}

static void ath9k_force_wake(ath9k_ctx_t* ctx) {
    ar_write(ctx, AR_RTC_FORCE_WAKE, AR_RTC_FORCE_WAKE_EN | AR_RTC_FORCE_WAKE_ON_INT);
    udelay(50);
    ar_wait(ctx, AR_RTC_STATUS, AR_RTC_STATUS_M, AR_RTC_STATUS_ON, 200);
}

static int ath9k_hw_reset(ath9k_ctx_t* ctx) {
    ath9k_force_wake(ctx);
    ar_write(ctx, AR_RTC_RC, AR_RTC_RC_COLD);
    udelay(50);
    ar_write(ctx, AR_RTC_RC, 0);
    udelay(50);
    ar_write(ctx, AR_RC, AR_RC_AHB);
    ar_wait(ctx, AR_RTC_STATUS, AR_RTC_STATUS_M, AR_RTC_STATUS_ON, 200);
    ar_write(ctx, AR_RC, 0);
    udelay(50);
    ath9k_force_wake(ctx);
    return 1;
}

static void ath9k_hw_read_mac(ath9k_ctx_t* ctx) {
    u32 id0 = ar_read(ctx, AR_STA_ID0);
    u32 id1 = ar_read(ctx, AR_STA_ID1);
    ctx->mac_addr[0] = (u8)id0; ctx->mac_addr[1] = (u8)(id0>>8);
    ctx->mac_addr[2] = (u8)(id0>>16); ctx->mac_addr[3] = (u8)(id0>>24);
    ctx->mac_addr[4] = (u8)id1; ctx->mac_addr[5] = (u8)(id1>>8);
}

static void ath9k_hw_init_mac(ath9k_ctx_t* ctx) {
    u32 id0 = (u32)ctx->mac_addr[0]|((u32)ctx->mac_addr[1]<<8)|
              ((u32)ctx->mac_addr[2]<<16)|((u32)ctx->mac_addr[3]<<24);
    u32 id1 = (u32)ctx->mac_addr[4]|((u32)ctx->mac_addr[5]<<8);
    ar_write(ctx, AR_STA_ID0, id0);
    ar_write(ctx, AR_STA_ID1, id1 | AR_STA_ID1_PRESERVE_SEQNUM);
    ar_write(ctx, AR_MCAST_FIL0, 0xFFFFFFFF);
    ar_write(ctx, AR_MCAST_FIL1, 0xFFFFFFFF);
}

static void ath9k_hw_init_phy(ath9k_ctx_t* ctx) {
    ar_write(ctx, AR_PHY_ACTIVE, AR_PHY_ACTIVE_DIS);
    udelay(5);
    ar_write(ctx, AR_PHY_ACTIVE, AR_PHY_ACTIVE_EN);
    udelay(5);
}

static void ath9k_set_rx_filter(ath9k_ctx_t* ctx) {
    ar_write(ctx, AR_RX_FILTER,
             AR_RX_FILTER_UCAST | AR_RX_FILTER_MCAST | AR_RX_FILTER_BCAST |
             AR_RX_FILTER_BEACON | AR_RX_FILTER_PROBEREQ);
}

static void ath9k_hw_setup_rx_descs(ath9k_ctx_t* ctx) {
    for (u32 i = 0; i < ATH9K_MAX_RX_BUFS; i++) {
        ctx->rx_descs[i].ctl = ATH9K_RX_BUF_SIZE;
        ctx->rx_descs[i].data_ptr = (u32)(void*)ctx->rx_bufs[i];
        ctx->rx_descs[i].ctl2 = 0;
        ctx->rx_descs[i].status = 0;
    }
    ctx->rx_head = 0;
}

static void ath9k_hw_init_queues(ath9k_ctx_t* ctx) {
    ar_write(ctx, AR_Q0_TXDP, (u32)(void*)ctx->tx_descs);
    ar_write(ctx, AR_RXDP, (u32)(void*)ctx->rx_descs);
    ar_write(ctx, AR_TXCFG, AR_TXCFG_DMASZ_64B);
    ar_write(ctx, AR_RXCFG, AR_RXCFG_DMASZ_16B);
    ar_write(ctx, AR_CR, AR_CR_RXE);
}

static int ath9k_hw_set_channel_2g(ath9k_ctx_t* ctx, u8 channel) {
    if (channel < 1 || channel > 14) return 0;
    u32 freq = wifi80211_channel_to_freq(channel);
    ar_write(ctx, AR_PHY_PLL_CTL, AR_PHY_PLL_CTL_40);
    udelay(100);
    u32 lo_div = (freq * 2) / 40;
    u32 frac = ((freq * 2) % 40) * (1 << 15) / 40;
    ar_write(ctx, AR_PHY(0x25), (lo_div << 15) | frac);
    udelay(1000);
    ctx->current_channel = channel;
    return 1;
}

int ath9k_detect(void) {
    pci_dev_t d;
    for (u32 dev = 0; ATH9K_DEVICE_IDS[dev]; dev++) {
        if (pci_find_device(ATH9K_VENDOR_ID, ATH9K_DEVICE_IDS[dev], &d)) return 1;
    }
    return 0;
}

int ath9k_init(ath9k_ctx_t* ctx) {
    memset(ctx, 0, sizeof(*ctx));

    pci_dev_t pdev;
    int found = 0;
    for (u32 dev = 0; ATH9K_DEVICE_IDS[dev]; dev++) {
        if (pci_find_device(ATH9K_VENDOR_ID, ATH9K_DEVICE_IDS[dev], &pdev)) {
            ctx->device_id = ATH9K_DEVICE_IDS[dev];
            found = 1;
            break;
        }
    }
    if (!found) return 0;

    ctx->pci_mmio = pdev.bar[0] & 0xFFFFFFF0;
    if (!ctx->pci_mmio) return 0;

    pci_enable_bus_master(&pdev);

    ctx->rx_descs = (ath9k_desc_t*)kmalloc(ATH9K_MAX_RX_BUFS * sizeof(ath9k_desc_t));
    ctx->rx_bufs  = (u8**)kmalloc(ATH9K_MAX_RX_BUFS * sizeof(u8*));
    ctx->tx_descs = (ath9k_desc_t*)kmalloc(ATH9K_MAX_TX_BUFS * sizeof(ath9k_desc_t));
    ctx->tx_bufs  = (u8**)kmalloc(ATH9K_MAX_TX_BUFS * sizeof(u8*));
    if (!ctx->rx_descs || !ctx->rx_bufs || !ctx->tx_descs || !ctx->tx_bufs) return 0;

    memset(ctx->rx_descs, 0, ATH9K_MAX_RX_BUFS * sizeof(ath9k_desc_t));
    memset(ctx->tx_descs, 0, ATH9K_MAX_TX_BUFS * sizeof(ath9k_desc_t));

    for (u32 i = 0; i < ATH9K_MAX_RX_BUFS; i++) {
        ctx->rx_bufs[i] = (u8*)kmalloc(ATH9K_RX_BUF_SIZE);
        if (!ctx->rx_bufs[i]) return 0;
    }
    for (u32 i = 0; i < ATH9K_MAX_TX_BUFS; i++) {
        ctx->tx_bufs[i] = (u8*)kmalloc(ATH9K_TX_BUF_SIZE);
        if (!ctx->tx_bufs[i]) return 0;
    }

    if (!ath9k_hw_reset(ctx)) return 0;
    ath9k_hw_read_mac(ctx);
    ath9k_hw_init_mac(ctx);
    ath9k_hw_init_phy(ctx);
    ath9k_hw_setup_rx_descs(ctx);
    ath9k_hw_init_queues(ctx);
    ath9k_set_rx_filter(ctx);

    ar_write(ctx, AR_IMR, AR_ISR_RXOK | AR_ISR_RXEOL | AR_ISR_RXERR |
                          AR_ISR_TXOK | AR_ISR_TXERR);

    if (!ath9k_hw_set_channel_2g(ctx, 6)) return 0;

    ctx->initialized = 1;
    return 1;
}

int ath9k_set_channel(ath9k_ctx_t* ctx, u8 channel) {
    if (!ctx->initialized) return 0;
    ar_clear_bits(ctx, AR_CR, AR_CR_RXE);
    udelay(100);
    int ok = ath9k_hw_set_channel_2g(ctx, channel);
    ar_set_bits(ctx, AR_CR, AR_CR_RXE);
    return ok;
}

void ath9k_hw_set_bssid(ath9k_ctx_t* ctx, const u8* bssid) {
    u32 b0 = (u32)bssid[0]|((u32)bssid[1]<<8)|((u32)bssid[2]<<16)|((u32)bssid[3]<<24);
    u32 b1 = (u32)bssid[4]|((u32)bssid[5]<<8);
    ar_write(ctx, AR_BSS_ID0, b0);
    ar_write(ctx, AR_BSS_ID1, b1);
}

int ath9k_tx(ath9k_ctx_t* ctx, const u8* data, u32 len) {
    if (!ctx->initialized || len == 0 || len > ATH9K_TX_BUF_SIZE) return 0;
    u32 idx = ctx->tx_tail % ATH9K_MAX_TX_BUFS;
    ath9k_desc_t* desc = &ctx->tx_descs[idx];
    if (desc->status & 0x00000001) return 0;
    memcpy(ctx->tx_bufs[idx], data, len);
    desc->data_ptr = (u32)(void*)ctx->tx_bufs[idx];
    desc->ctl  = (len & 0x0FFF) | 0x00004000 | 0x00008000 | 0x40000000;
    desc->ctl2 = len & 0x0FFF;
    desc->status = 0;
    ar_write(ctx, AR_Q0_TXDP, (u32)(void*)desc);
    ar_set_bits(ctx, 0x0840, 0x00000001);
    ctx->tx_tail++;
    return 1;
}

int ath9k_rx_poll(ath9k_ctx_t* ctx, u8* buf, u32 bufsize, u32* rx_len, i32* rssi) {
    if (!ctx->initialized) return 0;
    ath9k_desc_t* desc = &ctx->rx_descs[ctx->rx_head];
    if (!(desc->status & 0x00000001)) return 0;
    u32 len = (desc->status >> 16) & 0x0FFF;
    i32 rx_rssi = (i32)((desc->status & 0xFF)) - 256;
    if (len > ATH9K_RX_BUF_SIZE - 4) len = ATH9K_RX_BUF_SIZE - 4;
    if (len > bufsize) len = bufsize;
    memcpy(buf, ctx->rx_bufs[ctx->rx_head], len);
    *rx_len = len;
    if (rssi) *rssi = rx_rssi;
    desc->ctl = ATH9K_RX_BUF_SIZE;
    desc->data_ptr = (u32)(void*)ctx->rx_bufs[ctx->rx_head];
    desc->status = 0;
    ctx->rx_head = (ctx->rx_head + 1) % ATH9K_MAX_RX_BUFS;
    if (ar_read(ctx, AR_CR) & AR_CR_RXD) ar_set_bits(ctx, AR_CR, AR_CR_RXE);
    return 1;
}

void ath9k_irq_handler(ath9k_ctx_t* ctx) {
    if (!ctx->initialized) return;
    u32 isr = ar_read(ctx, AR_ISR);
    ar_write(ctx, AR_ISR, isr);
    (void)isr;
}

