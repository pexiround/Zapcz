/* iwl_fh.c -- firmware upload over the device's FH (Flow Handler) DMA engine.

   Firmware sections live in device SRAM. They cannot be poked in through the
   PRPH register window (that window is for peripheral registers); the device
   has to fetch them itself over DMA. This is the documented sequence used by
   iwlwifi's iwl_pcie_load_firmware_chunk(): point the service channel at a
   destination SRAM address and a host buffer, mark the buffer valid, enable
   the channel, then wait for the channel to go idle again.

   Everything here is 32-bit and identity-mapped, so a buffer's virtual address
   is also its physical address. */

#include "io.h"
#include "libc_shim.h"
#include "iwl_fh.h"

/* ---- CSR bits we need locally ---- */
#define CSR_GP_CNTRL              0x024
#define CSR_RESET                 0x020
#define CSR_GP_CNTRL_MAC_ACCESS_REQ  (0x00000008)
#define CSR_GP_CNTRL_MAC_CLOCK_READY (0x00000001)
#define CSR_GP_CNTRL_SLEEP           (0x00000010)
#define CSR_RESET_FLAG_MASTER_DISABLED (0x00000100)

/* ---- FH register map (from iwlwifi fh.h) ---- */
#define FH_MEM_LOWER_BOUND        0x1000

#define FH_SRVC_CHNL              9
#define FH_SRVC_LOWER_BOUND       (FH_MEM_LOWER_BOUND + 0x9C8)
#define FH_SRVC_CHNL_SRAM_ADDR_REG(c)  (FH_SRVC_LOWER_BOUND + (c) * 0x4)

#define FH_TFDIB_LOWER_BOUND      (FH_MEM_LOWER_BOUND + 0x900)
#define FH_TFDIB_CTRL0_REG(c)     (FH_TFDIB_LOWER_BOUND + 0x8 * (c))
#define FH_TFDIB_CTRL1_REG(c)     (FH_TFDIB_LOWER_BOUND + 0x8 * (c) + 0x4)
#define FH_MEM_TFDIB_REG1_ADDR_BITSHIFT  28

#define FH_TCSR_LOWER_BOUND       (FH_MEM_LOWER_BOUND + 0xD00)
#define FH_TCSR_CHNL_TX_CONFIG_REG(c)   (FH_TCSR_LOWER_BOUND + 0x20 * (c))
#define FH_TCSR_CHNL_TX_BUF_STS_REG(c)  (FH_TCSR_LOWER_BOUND + 0x20 * (c) + 0x8)

#define FH_TCSR_TX_CONFIG_REG_VAL_MSG_MODE_DRIVER      0x00000000
#define FH_TCSR_TX_CONFIG_REG_VAL_DMA_CREDIT_DISABLE   0x00000000
#define FH_TCSR_TX_CONFIG_REG_VAL_CIRQ_HOST_ENDTFD     0x00100000
#define FH_TCSR_TX_CONFIG_REG_VAL_DMA_CHNL_ENABLE      0x80000000
#define FH_TCSR_TX_CONFIG_REG_VAL_DMA_CHNL_PAUSE       0x00000000

#define FH_TCSR_CHNL_TX_BUF_STS_REG_VAL_TFDB_VALID     0x00004000
#define FH_TCSR_CHNL_TX_BUF_STS_REG_POS_TB_NUM         20
#define FH_TCSR_CHNL_TX_BUF_STS_REG_POS_TB_IDX         12

#define FH_TSSR_TX_STATUS_REG     (FH_MEM_LOWER_BOUND + 0xEA0 + 0x010)
#define FH_TSSR_TX_STATUS_CHNL_IDLE(c)  ((1u << (c)) << 16)

#define FH_MEM_TFDIB_DRAM_ADDR_LSB_MSK 0xFFFFFFFF

/* 16 KB staging buffer, matching the chunk size iwlwifi uses. Must be
   physically contiguous and dword aligned. */
#define FW_CHUNK_SIZE 16384
static u8 fw_stage[FW_CHUNK_SIZE] __attribute__((aligned(4096)));

static volatile u32* regs = 0;

static u32 rd(u32 off)          { return regs[off / 4]; }
static void wr(u32 off, u32 v)  { regs[off / 4] = v; }

static void spin(u32 n) { for (volatile u32 i = 0; i < n * 30u; i++) __asm__ volatile("nop"); }

void iwl_fh_bind(volatile u32* mmio) { regs = mmio; }

/* FH registers live behind the MAC clock, so we must hold access while poking
   them. Returns 1 if the clock acknowledged. */
int iwl_fh_grab_nic_access(void) {
    if (!regs) return 0;
    wr(CSR_GP_CNTRL, rd(CSR_GP_CNTRL) | CSR_GP_CNTRL_MAC_ACCESS_REQ);
    for (int i = 0; i < 15000; i++) {
        u32 v = rd(CSR_GP_CNTRL);
        if ((v & CSR_GP_CNTRL_MAC_CLOCK_READY) && !(v & CSR_GP_CNTRL_SLEEP)) return 1;
        spin(2);
    }
    return 0;
}

void iwl_fh_release_nic_access(void) {
    if (!regs) return;
    wr(CSR_GP_CNTRL, rd(CSR_GP_CNTRL) & ~CSR_GP_CNTRL_MAC_ACCESS_REQ);
}

/* Push one chunk of already-staged host memory into device SRAM at dst_addr. */
static int load_chunk(u32 dst_addr, u32 phys_addr, u32 byte_cnt) {
    const u32 c = FH_SRVC_CHNL;

    /* pause the channel while we reprogram it */
    wr(FH_TCSR_CHNL_TX_CONFIG_REG(c), FH_TCSR_TX_CONFIG_REG_VAL_DMA_CHNL_PAUSE);

    /* destination inside device SRAM */
    wr(FH_SRVC_CHNL_SRAM_ADDR_REG(c), dst_addr);

    /* source in host memory: low 32 bits, then high bits packed with length */
    wr(FH_TFDIB_CTRL0_REG(c), phys_addr & FH_MEM_TFDIB_DRAM_ADDR_LSB_MSK);
    wr(FH_TFDIB_CTRL1_REG(c), (0u << FH_MEM_TFDIB_REG1_ADDR_BITSHIFT) | byte_cnt);

    /* one transfer buffer, index 0, and mark it valid */
    wr(FH_TCSR_CHNL_TX_BUF_STS_REG(c),
       (1u << FH_TCSR_CHNL_TX_BUF_STS_REG_POS_TB_NUM) |
       (1u << FH_TCSR_CHNL_TX_BUF_STS_REG_POS_TB_IDX) |
       FH_TCSR_CHNL_TX_BUF_STS_REG_VAL_TFDB_VALID);

    /* go */
    wr(FH_TCSR_CHNL_TX_CONFIG_REG(c),
       FH_TCSR_TX_CONFIG_REG_VAL_MSG_MODE_DRIVER |
       FH_TCSR_TX_CONFIG_REG_VAL_DMA_CREDIT_DISABLE |
       FH_TCSR_TX_CONFIG_REG_VAL_CIRQ_HOST_ENDTFD |
       FH_TCSR_TX_CONFIG_REG_VAL_DMA_CHNL_ENABLE);

    /* wait for the channel to report idle again */
    for (int i = 0; i < 20000; i++) {
        if (rd(FH_TSSR_TX_STATUS_REG) & FH_TSSR_TX_STATUS_CHNL_IDLE(c)) return 1;
        spin(2);
    }
    return 0;
}

/* Upload one firmware section, chunking through the staging buffer. */
int iwl_fh_load_section(const u8* data, u32 size, u32 dst_addr) {
    if (!regs || !data || size == 0) return 0;

    for (u32 off = 0; off < size; off += FW_CHUNK_SIZE) {
        u32 n = size - off;
        if (n > FW_CHUNK_SIZE) n = FW_CHUNK_SIZE;

        memcpy(fw_stage, data + off, n);

        /* DMA length must be a whole number of dwords */
        u32 dma_len = (n + 3u) & ~3u;
        if (dma_len > FW_CHUNK_SIZE) dma_len = FW_CHUNK_SIZE;
        if (dma_len > n) memset(fw_stage + n, 0, dma_len - n);

        if (!load_chunk(dst_addr + off, (u32)fw_stage, dma_len)) return 0;
    }
    return 1;
}

/* Release the firmware CPU so it starts executing what we uploaded. */
void iwl_fh_release_cpu(void) {
    if (!regs) return;
    wr(CSR_RESET, 0);
}

/* ---------------- RX ring ----------------

   The firmware announces itself with an ALIVE notification delivered through
   the RX queue, so the queue has to exist before the CPU is released. Layout:
     - a ring of 256 receive-buffer descriptors, each holding a physical
       address shifted right by 8
     - one 4 KB buffer per descriptor
     - a status page the device writes the closed-write-pointer into           */

#define RX_QUEUE_SIZE   256
#define RX_BUF_SIZE     4096

#define FH_MEM_RSCSR_LOWER_BOUND      (FH_MEM_LOWER_BOUND + 0xBC0)
#define FH_RSCSR_CHNL0_STTS_WPTR_REG  (FH_MEM_RSCSR_LOWER_BOUND)
#define FH_RSCSR_CHNL0_RBDCB_BASE_REG (FH_MEM_RSCSR_LOWER_BOUND + 0x004)
#define FH_RSCSR_CHNL0_WPTR           (FH_MEM_RSCSR_LOWER_BOUND + 0x008)

#define FH_MEM_RCSR_CHNL0_CONFIG_REG  (FH_MEM_LOWER_BOUND + 0xC00)
#define FH_RCSR_RX_CONFIG_DMA_CHNL_EN     0x80000000
#define FH_RCSR_RX_CONFIG_RB_SIZE_4K      0x00000000
#define FH_RCSR_CHNL0_RX_IGNORE_RXF_EMPTY 0x00000004
#define FH_RCSR_CHNL0_RX_CONFIG_IRQ_DEST  0x00001000
#define FH_RCSR_CHNL0_RX_CONFIG_SINGLE_FRAME 0x00008000
#define FH_RCSR_RX_CONFIG_RBDCB_SIZE_POS  20
#define FH_RCSR_RX_CONFIG_RB_TIMEOUT_MSK  0x00000FF0

#define FH_MEM_RSSR_SHARED_CTRL_REG   (FH_MEM_LOWER_BOUND + 0xC40)
#define FH_MEM_RSSR_RX_STATUS_REG     (FH_MEM_LOWER_BOUND + 0xC44)
#define FH_MEM_RSSR_RX_ENABLE_ERR_IRQ2DRV (FH_MEM_LOWER_BOUND + 0xC48)

/* 32-bit physical addresses, so the descriptor array is plain u32. */
static u32 rx_bd[RX_QUEUE_SIZE]          __attribute__((aligned(4096)));
static u8  rx_pool[RX_QUEUE_SIZE][RX_BUF_SIZE] __attribute__((aligned(4096)));
static u32 rx_status[8]                  __attribute__((aligned(4096)));
static u32 rx_read = 0;

int iwl_fh_rx_init(void) {
    if (!regs) return 0;

    for (u32 i = 0; i < RX_QUEUE_SIZE; i++)
        rx_bd[i] = (u32)((u32)rx_pool[i] >> 8);
    memset(rx_status, 0, sizeof(rx_status));
    rx_read = 0;

    if (!iwl_fh_grab_nic_access()) return 0;

    /* stop the RX DMA while we reprogram it */
    wr(FH_MEM_RCSR_CHNL0_CONFIG_REG, 0);
    wr(FH_RSCSR_CHNL0_WPTR, 0);

    wr(FH_RSCSR_CHNL0_RBDCB_BASE_REG, (u32)rx_bd >> 8);
    wr(FH_RSCSR_CHNL0_STTS_WPTR_REG, (u32)rx_status >> 4);

    wr(FH_MEM_RCSR_CHNL0_CONFIG_REG,
       FH_RCSR_RX_CONFIG_DMA_CHNL_EN |
       FH_RCSR_CHNL0_RX_IGNORE_RXF_EMPTY |
       FH_RCSR_CHNL0_RX_CONFIG_IRQ_DEST |
       FH_RCSR_CHNL0_RX_CONFIG_SINGLE_FRAME |
       (0 << FH_RCSR_RX_CONFIG_RBDCB_SIZE_POS) |
       FH_RCSR_RX_CONFIG_RB_SIZE_4K |
       (0x20 & FH_RCSR_RX_CONFIG_RB_TIMEOUT_MSK));

    wr(FH_MEM_RSSR_SHARED_CTRL_REG, 0);
    wr(FH_MEM_RSSR_RX_ENABLE_ERR_IRQ2DRV, 0);

    /* hand the device every buffer except the last (write pointer must trail) */
    wr(FH_RSCSR_CHNL0_WPTR, (RX_QUEUE_SIZE - 1) & ~0x7u);

    iwl_fh_release_nic_access();
    return 1;
}

/* Returns the device's current closed write pointer, i.e. how far it has
   filled the ring. Non-zero movement means the firmware is producing. */
u32 iwl_fh_rx_wptr(void) {
    return rx_status[0] & 0x0FFF;
}

/* Pull the next completed RX buffer, if any. Returns payload length. */
u32 iwl_fh_rx_next(const u8** out) {
    u32 wptr = iwl_fh_rx_wptr();
    if (rx_read == wptr) return 0;
    const u8* buf = rx_pool[rx_read % RX_QUEUE_SIZE];
    rx_read = (rx_read + 1) % RX_QUEUE_SIZE;
    if (out) *out = buf;
    /* first dword of an RX buffer is the byte count in the low 14 bits */
    u32 len = (*(const u32*)buf) & 0x3FFF;
    if (len > RX_BUF_SIZE) len = RX_BUF_SIZE;
    return len;
}

#define FH_PRPH_WADDR                 0x044
#define FH_PRPH_WDAT                  0x04C
#define FH_PRPH_ACCESS_MASK           0x03000000u

static void prph_w(u32 addr, u32 val) {
    wr(FH_PRPH_WADDR, (addr & 0x00FFFFFF) | FH_PRPH_ACCESS_MASK);
    for (volatile int i = 0; i < 100; i++) {}
    wr(FH_PRPH_WDAT, val);
}

#define FH_KW_MEM_ADDR_REG            (FH_MEM_LOWER_BOUND + 0x97C)
#define FH_MEM_CBBC_0_15_LOWER_BOUND  (FH_MEM_LOWER_BOUND + 0x9D0)
#define HBUS_TARG_WRPTR               0x460

#define SCD_BASE_PRPH          0xa02c00
#define SCD_SRAM_BASE_ADDR     (SCD_BASE_PRPH + 0x00)
#define SCD_DRAM_BASE_ADDR     (SCD_BASE_PRPH + 0x08)
#define SCD_AIT                (SCD_BASE_PRPH + 0x0c)
#define SCD_TXFACT             (SCD_BASE_PRPH + 0x10)
#define SCD_ACTIVE             (SCD_BASE_PRPH + 0x14)
#define SCD_QUEUECHAIN_SEL     (SCD_BASE_PRPH + 0xe8)
#define SCD_CHAINEXT_EN        (SCD_BASE_PRPH + 0x244)
#define SCD_AGGR_SEL           (SCD_BASE_PRPH + 0x248)
#define SCD_INTERRUPT_MASK     (SCD_BASE_PRPH + 0x108)
#define SCD_EN_CTRL            (SCD_BASE_PRPH + 0x254)
#define SCD_QUEUE_WRPTR(x)     (SCD_BASE_PRPH + 0x18 + (x) * 4)
#define SCD_QUEUE_RDPTR(x)     (SCD_BASE_PRPH + 0x68 + (x) * 4)
#define SCD_QUEUE_STATUS(x)    (SCD_BASE_PRPH + 0x10c + (x) * 4)

#define SCD_STTS_POS_TXF        0
#define SCD_STTS_POS_ACTIVE     3
#define SCD_STTS_POS_WSL        4
#define SCD_STTS_POS_SCD_ACT_EN 19

#define TFD_RING_SIZE   256
#define TFD_ENTRY_BYTES 128
#define TFD_MAX_TBS     20
#define TXQ_BC_ENTRIES  320

#define IWL_CMD_FIFO    7

static u8  tfd_ring[TFD_RING_SIZE * TFD_ENTRY_BYTES] __attribute__((aligned(4096)));
static u16 txq_bc_tbl[TXQ_BC_ENTRIES]                __attribute__((aligned(1024)));
static u8  txq_keep_warm[4096]                       __attribute__((aligned(4096)));
static u8  cmd_pool[TFD_RING_SIZE][512]              __attribute__((aligned(64)));

static u32 txq_write_ptr = 0;
static int txq_ready = 0;
static u32 g_cmd_queue_id = 9;

u32 iwl_fh_cmd_queue_id(void) { return g_cmd_queue_id; }
int iwl_fh_tx_ready(void)     { return txq_ready; }
u32 iwl_fh_tx_wptr(void)      { return txq_write_ptr; }

static void tfd_clear(u32 idx) {
    u8* t = tfd_ring + (u32)idx * TFD_ENTRY_BYTES;
    for (int i = 0; i < TFD_ENTRY_BYTES; i++) t[i] = 0;
}

static void tfd_add_tb(u32 idx, u32 addr, u16 len) {
    u8* t = tfd_ring + (u32)idx * TFD_ENTRY_BYTES;
    u8 num = t[3];
    if (num >= TFD_MAX_TBS) return;
    u8* tb = t + 4 + (u32)num * 6;
    tb[0] = (u8)(addr);
    tb[1] = (u8)(addr >> 8);
    tb[2] = (u8)(addr >> 16);
    tb[3] = (u8)(addr >> 24);
    u16 hi_n_len = (u16)((len & 0x0FFF) << 4);
    tb[4] = (u8)(hi_n_len);
    tb[5] = (u8)(hi_n_len >> 8);
    t[3] = (u8)(num + 1);
}

int iwl_fh_tx_init(void) {
    for (u32 i = 0; i < TXQ_BC_ENTRIES; i++) txq_bc_tbl[i] = 0;
    for (u32 i = 0; i < TFD_RING_SIZE; i++) tfd_clear(i);
    txq_write_ptr = 0;

    if (!iwl_fh_grab_nic_access()) return 0;

    wr(FH_KW_MEM_ADDR_REG, (u32)txq_keep_warm >> 4);
    wr(FH_MEM_CBBC_0_15_LOWER_BOUND + 4 * g_cmd_queue_id, (u32)tfd_ring >> 8);

    iwl_fh_release_nic_access();
    txq_ready = 1;
    return 1;
}

void iwl_fh_scd_init(u32 scd_base) {
    if (!iwl_fh_grab_nic_access()) return;

    prph_w(SCD_DRAM_BASE_ADDR, (u32)txq_bc_tbl >> 10);
    prph_w(SCD_QUEUECHAIN_SEL, 0);
    prph_w(SCD_AGGR_SEL, 0);
    prph_w(SCD_CHAINEXT_EN, 0);
    prph_w(SCD_QUEUE_RDPTR(g_cmd_queue_id), 0);
    prph_w(SCD_QUEUE_WRPTR(g_cmd_queue_id), 0);

    prph_w(SCD_QUEUE_STATUS(g_cmd_queue_id),
           (1u << SCD_STTS_POS_ACTIVE) |
           ((u32)IWL_CMD_FIFO << SCD_STTS_POS_TXF) |
           (1u << SCD_STTS_POS_WSL) |
           (1u << SCD_STTS_POS_SCD_ACT_EN));

    prph_w(SCD_TXFACT, 1u << g_cmd_queue_id);
    prph_w(SCD_INTERRUPT_MASK, 1u << g_cmd_queue_id);
    prph_w(SCD_EN_CTRL, 1u << g_cmd_queue_id);

    iwl_fh_release_nic_access();
    (void)scd_base;
}

int iwl_fh_send_hcmd(u8 group, u8 cmd, const u8* payload, u16 len) {
    if (!txq_ready) return 0;
    if (len + 4u > 512u) return 0;

    u32 idx = txq_write_ptr & (TFD_RING_SIZE - 1);
    u8* c = cmd_pool[idx];
    c[0] = cmd;
    c[1] = group;
    c[2] = (u8)(idx | ((g_cmd_queue_id & 0x1F) << 8));
    c[3] = (u8)((idx >> 8) | (g_cmd_queue_id >> 5));
    for (u16 i = 0; i < len; i++) c[4 + i] = payload ? payload[i] : 0;

    u16 total = (u16)(len + 4);
    tfd_clear(idx);
    tfd_add_tb(idx, (u32)c, total);

    txq_bc_tbl[idx] = (u16)((total + 3) >> 2);

    txq_write_ptr = (txq_write_ptr + 1) & (TFD_RING_SIZE - 1);

    if (!iwl_fh_grab_nic_access()) return 0;
    wr(HBUS_TARG_WRPTR, txq_write_ptr | (g_cmd_queue_id << 8));
    iwl_fh_release_nic_access();
    return 1;
}
