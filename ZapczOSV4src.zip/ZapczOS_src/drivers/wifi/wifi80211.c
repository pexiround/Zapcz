#include "wifi80211.h"
#include "libc_shim.h"
#include "util.h"

static u16 frame_ctrl(u8 ftype, u8 stype, u16 flags) {
    return (u16)(ftype | (stype << 4) | flags);
}

static void put_le16(u8* p, u16 v) { p[0]=(u8)v; p[1]=(u8)(v>>8); }
static u16 get_le16(const u8* p) { return (u16)(p[0]|(p[1]<<8)); }
static u16 get_le16_at(const u8* frame, u32 off) { return get_le16(frame+off); }

static void put_hdr(u8* buf, u16 fc, u16 dur, const u8* a1, const u8* a2, const u8* a3) {
    put_le16(buf, fc);
    put_le16(buf+2, dur);
    memcpy(buf+4,  a1, 6);
    memcpy(buf+10, a2, 6);
    memcpy(buf+16, a3, 6);
    put_le16(buf+22, 0);
}

static u32 put_ie(u8* buf, u8 id, const u8* data, u8 len) {
    buf[0]=id; buf[1]=len;
    if (len && data) memcpy(buf+2, data, len);
    return (u32)(2+len);
}

static const u8 SUPPORTED_RATES[] = {0x82,0x84,0x8B,0x96,0x24,0x30,0x48,0x6C};
static const u8 RSN_IE_WPA2_CCMP[] = {
    0x01,0x00,
    0x01,0x00, 0x00,0x0F,0xAC,0x04,
    0x01,0x00, 0x00,0x0F,0xAC,0x04,
    0x01,0x00, 0x00,0x0F,0xAC,0x02,
    0x00,0x00
};

u32 wifi80211_build_probe_req(u8* buf, u32 bufsize, const u8* sta_mac,
                               const char* ssid, u8 ssid_len) {
    if (bufsize < 64) return 0;
    static const u8 broadcast[6] = {0xFF,0xFF,0xFF,0xFF,0xFF,0xFF};
    put_hdr(buf, frame_ctrl(DOT11_FTYPE_MGMT, DOT11_STYPE_PROBE_REQ, 0),
            0, broadcast, sta_mac, broadcast);
    u32 p = 24;
    p += put_ie(buf+p, DOT11_IE_SSID, (const u8*)ssid, ssid_len);
    p += put_ie(buf+p, DOT11_IE_SUPPORTED_RATES, SUPPORTED_RATES, 8);
    return p;
}

u32 wifi80211_build_auth_req(u8* buf, u32 bufsize, const u8* sta_mac,
                              const u8* bssid, u16 auth_seq) {
    if (bufsize < 36) return 0;
    put_hdr(buf, frame_ctrl(DOT11_FTYPE_MGMT, DOT11_STYPE_AUTH, 0),
            0, bssid, sta_mac, bssid);
    u32 p = 24;
    put_le16(buf+p, DOT11_AUTH_OPEN); p+=2;
    put_le16(buf+p, auth_seq); p+=2;
    put_le16(buf+p, DOT11_STATUS_SUCCESS); p+=2;
    return p;
}

u32 wifi80211_build_assoc_req(u8* buf, u32 bufsize, const u8* sta_mac,
                               const u8* bssid, const char* ssid, u8 ssid_len,
                               u16 listen_interval, u8 has_wpa2) {
    if (bufsize < 128) return 0;
    put_hdr(buf, frame_ctrl(DOT11_FTYPE_MGMT, DOT11_STYPE_ASSOC_REQ, 0),
            0, bssid, sta_mac, bssid);
    u32 p = 24;
    u16 caps = DOT11_CAP_ESS | DOT11_CAP_SHORT_SLOT;
    if (has_wpa2) caps |= DOT11_CAP_PRIVACY;
    put_le16(buf+p, caps); p+=2;
    put_le16(buf+p, listen_interval); p+=2;
    p += put_ie(buf+p, DOT11_IE_SSID, (const u8*)ssid, ssid_len);
    p += put_ie(buf+p, DOT11_IE_SUPPORTED_RATES, SUPPORTED_RATES, 8);
    p += put_ie(buf+p, DOT11_IE_EXT_RATES, SUPPORTED_RATES+8, 0);
    if (has_wpa2) {
        p += put_ie(buf+p, DOT11_IE_RSN, RSN_IE_WPA2_CCMP, sizeof(RSN_IE_WPA2_CCMP));
    }
    return p;
}

u32 wifi80211_build_deauth(u8* buf, u32 bufsize, const u8* sta_mac,
                            const u8* bssid, u16 reason) {
    if (bufsize < 28) return 0;
    put_hdr(buf, frame_ctrl(DOT11_FTYPE_MGMT, DOT11_STYPE_DEAUTH, 0),
            0, bssid, sta_mac, bssid);
    put_le16(buf+24, reason);
    return 26;
}

u32 wifi80211_build_data(u8* buf, u32 bufsize, const u8* sta_mac,
                          const u8* bssid, const u8* dst_mac,
                          const u8* payload, u32 paylen, u16 seq) {
    if (bufsize < 26 + paylen) return 0;
    put_le16(buf, frame_ctrl(DOT11_FTYPE_DATA, 0x00, 0x0100));
    put_le16(buf+2, 0);
    memcpy(buf+4,  bssid,   6);
    memcpy(buf+10, sta_mac, 6);
    memcpy(buf+16, dst_mac, 6);
    put_le16(buf+22, (u16)(seq << 4));
    memcpy(buf+24, payload, paylen);
    return 24 + paylen;
}

static const u8* find_ie(const u8* ies, u32 ies_len, u8 id) {
    u32 p = 0;
    while (p + 2 <= ies_len) {
        if (ies[p] == id) return ies + p;
        p += 2 + ies[p+1];
    }
    return 0;
}

int wifi80211_parse_beacon(const u8* frame, u32 framelen, wifi_bss_t* out) {
    if (framelen < 36) return 0;
    u8 stype = (frame[0] >> 4) & 0x0F;
    if ((frame[0] & 0x0F) != DOT11_FTYPE_MGMT) return 0;
    if (stype != DOT11_STYPE_BEACON && stype != DOT11_STYPE_PROBE_RESP) return 0;

    memcpy(out->bssid, frame+16, 6);
    out->beacon_interval = get_le16_at(frame, 32);
    out->capability = get_le16_at(frame, 34);
    out->has_wpa2 = 0;
    out->ssid_len = 0;
    out->ssid[0] = 0;
    out->rate_count = 0;
    out->channel = 0;

    const u8* ies = frame + 36;
    u32 ies_len = framelen - 36;

    const u8* ie;
    if ((ie = find_ie(ies, ies_len, DOT11_IE_SSID))) {
        u8 len = ie[1];
        if (len > WIFI_MAX_SSID_LEN) len = WIFI_MAX_SSID_LEN;
        memcpy(out->ssid, ie+2, len);
        out->ssid[len] = 0;
        out->ssid_len = len;
    }
    if ((ie = find_ie(ies, ies_len, DOT11_IE_DS_PARAMS)) && ie[1] >= 1) {
        out->channel = ie[2];
    }
    if ((ie = find_ie(ies, ies_len, DOT11_IE_SUPPORTED_RATES))) {
        u8 n = ie[1]; if (n > 8) n = 8;
        memcpy(out->rates, ie+2, n);
        out->rate_count = n;
    }
    if ((ie = find_ie(ies, ies_len, DOT11_IE_RSN))) {
        out->has_wpa2 = 1;
    }

    return 1;
}

int wifi80211_parse_auth_resp(const u8* frame, u32 framelen, u16* status) {
    if (framelen < 30) return 0;
    if ((frame[0] & 0x0F) != DOT11_FTYPE_MGMT) return 0;
    if (((frame[0] >> 4) & 0x0F) != DOT11_STYPE_AUTH) return 0;
    *status = get_le16_at(frame, 26);
    return 1;
}

int wifi80211_parse_assoc_resp(const u8* frame, u32 framelen, u16* status, u16* assoc_id) {
    if (framelen < 30) return 0;
    if ((frame[0] & 0x0F) != DOT11_FTYPE_MGMT) return 0;
    if (((frame[0] >> 4) & 0x0F) != DOT11_STYPE_ASSOC_RESP) return 0;
    *status = get_le16_at(frame, 26);
    *assoc_id = get_le16_at(frame, 28) & 0x3FFF;
    return 1;
}

u8 wifi80211_frame_type(const u8* frame) { return frame[0] & 0x0F; }
u8 wifi80211_frame_subtype(const u8* frame) { return (frame[0] >> 4) & 0x0F; }

int wifi80211_frame_is_for_me(const u8* frame, const u8* my_mac) {
    const u8* addr1 = frame + 4;
    if (memcmp(addr1, my_mac, 6) == 0) return 1;
    static const u8 broadcast[6] = {0xFF,0xFF,0xFF,0xFF,0xFF,0xFF};
    if (memcmp(addr1, broadcast, 6) == 0) return 1;
    return 0;
}

u32 wifi80211_channel_to_freq(u8 channel) {
    if (channel >= 1 && channel <= 13) return 2407 + (u32)channel * 5;
    if (channel == 14) return 2484;
    if (channel >= 36) return 5000 + (u32)channel * 5;
    return 0;
}
