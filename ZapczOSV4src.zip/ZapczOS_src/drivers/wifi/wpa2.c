#include "wpa2.h"
#include "libc_shim.h"
#include "util.h"

static u32 sha1_rol(u32 v, int n) { return (v << n) | (v >> (32 - n)); }

typedef struct { u32 h[5]; u64 bits; u8 buf[64]; u32 buflen; } sha1_ctx_t;

static void sha1_init(sha1_ctx_t* c) {
    c->h[0]=0x67452301; c->h[1]=0xEFCDAB89; c->h[2]=0x98BADCFE;
    c->h[3]=0x10325476; c->h[4]=0xC3D2E1F0;
    c->bits=0; c->buflen=0;
}

static void sha1_compress(sha1_ctx_t* c) {
    u32 w[80];
    for (int i = 0; i < 16; i++)
        w[i] = ((u32)c->buf[i*4]<<24)|((u32)c->buf[i*4+1]<<16)|
               ((u32)c->buf[i*4+2]<<8)|(u32)c->buf[i*4+3];
    for (int i = 16; i < 80; i++)
        w[i] = sha1_rol(w[i-3]^w[i-8]^w[i-14]^w[i-16], 1);
    u32 a=c->h[0],b=c->h[1],cc=c->h[2],d=c->h[3],e=c->h[4];
    for (int i = 0; i < 80; i++) {
        u32 f, k;
        if (i<20){f=(b&cc)|(~b&d);k=0x5A827999;}
        else if(i<40){f=b^cc^d;k=0x6ED9EBA1;}
        else if(i<60){f=(b&cc)|(b&d)|(cc&d);k=0x8F1BBCDC;}
        else{f=b^cc^d;k=0xCA62C1D6;}
        u32 t=sha1_rol(a,5)+f+e+k+w[i];
        e=d; d=cc; cc=sha1_rol(b,30); b=a; a=t;
    }
    c->h[0]+=a; c->h[1]+=b; c->h[2]+=cc; c->h[3]+=d; c->h[4]+=e;
}

static void sha1_update(sha1_ctx_t* c, const u8* data, u32 len) {
    c->bits += (u64)len * 8;
    for (u32 i = 0; i < len; i++) {
        c->buf[c->buflen++] = data[i];
        if (c->buflen == 64) { sha1_compress(c); c->buflen = 0; }
    }
}

static void sha1_final(sha1_ctx_t* c, u8 out[20]) {
    c->buf[c->buflen++] = 0x80;
    if (c->buflen > 56) {
        while (c->buflen < 64) c->buf[c->buflen++] = 0;
        sha1_compress(c); c->buflen = 0;
    }
    while (c->buflen < 56) c->buf[c->buflen++] = 0;
    for (int i = 7; i >= 0; i--) c->buf[56+7-i] = (u8)(c->bits >> (i*8));
    sha1_compress(c);
    for (int i = 0; i < 5; i++) {
        out[i*4]   = (u8)(c->h[i]>>24); out[i*4+1] = (u8)(c->h[i]>>16);
        out[i*4+2] = (u8)(c->h[i]>>8);  out[i*4+3] = (u8)c->h[i];
    }
}

static void hmac_sha1(const u8* key, u32 klen,
                       const u8* msg, u32 mlen, u8 out[20]) {
    u8 k[64]; memset(k, 0, 64);
    if (klen <= 64) memcpy(k, key, klen);
    else {
        sha1_ctx_t c; sha1_init(&c); sha1_update(&c, key, klen); sha1_final(&c, k);
    }
    u8 ipad[64], opad[64];
    for (int i = 0; i < 64; i++) {
        ipad[i] = (u8)(k[i] ^ 0x36);
        opad[i] = (u8)(k[i] ^ 0x5C);
    }
    u8 inner[20];
    sha1_ctx_t c;
    sha1_init(&c); sha1_update(&c, ipad, 64); sha1_update(&c, msg, mlen); sha1_final(&c, inner);
    sha1_init(&c); sha1_update(&c, opad, 64); sha1_update(&c, inner, 20); sha1_final(&c, out);
}

void wpa2_pbkdf2_sha1(const u8* password, u32 pwlen,
                       const u8* ssid, u32 ssidlen,
                       u8 out_pmk[32]) {
    u8 salt_block[64 + 4];
    u8 u[20], t[20];
    u32 done = 0, block = 1;
    while (done < 32) {
        memcpy(salt_block, ssid, ssidlen);
        salt_block[ssidlen]   = (u8)(block >> 24);
        salt_block[ssidlen+1] = (u8)(block >> 16);
        salt_block[ssidlen+2] = (u8)(block >> 8);
        salt_block[ssidlen+3] = (u8)block;
        hmac_sha1(password, pwlen, salt_block, ssidlen + 4, u);
        memcpy(t, u, 20);
        for (u32 i = 1; i < 4096; i++) {
            hmac_sha1(password, pwlen, u, 20, u);
            for (int j = 0; j < 20; j++) t[j] ^= u[j];
        }
        u32 copy = 32 - done; if (copy > 20) copy = 20;
        memcpy(out_pmk + done, t, copy);
        done += copy; block++;
    }
}

void wpa2_prf_sha1(const u8* key, u32 klen,
                    const char* label,
                    const u8* data, u32 datalen,
                    u8* out, u32 outlen) {
    u8 buf[256];
    u32 lablen = str_len(label);
    memcpy(buf, label, lablen);
    buf[lablen] = 0x00;
    memcpy(buf + lablen + 1, data, datalen);
    u32 total = lablen + 1 + datalen;
    u32 done = 0; u8 ctr = 0;
    while (done < outlen) {
        buf[total] = ctr++;
        u8 h[20];
        hmac_sha1(key, klen, buf, total + 1, h);
        u32 copy = outlen - done; if (copy > 20) copy = 20;
        memcpy(out + done, h, copy);
        done += copy;
    }
}

void wpa2_derive_ptk(const u8 pmk[32],
                      const u8 anonce[32], const u8 snonce[32],
                      const u8 ap_mac[6], const u8 sta_mac[6],
                      u8* ptk, u32 ptk_len) {
    u8 data[76];
    if (memcmp(ap_mac, sta_mac, 6) < 0) {
        memcpy(data,    ap_mac,  6);
        memcpy(data+6,  sta_mac, 6);
    } else {
        memcpy(data,    sta_mac, 6);
        memcpy(data+6,  ap_mac,  6);
    }
    if (memcmp(anonce, snonce, 32) < 0) {
        memcpy(data+12, anonce,  32);
        memcpy(data+44, snonce,  32);
    } else {
        memcpy(data+12, snonce,  32);
        memcpy(data+44, anonce,  32);
    }
    wpa2_prf_sha1(pmk, 32, "Pairwise key expansion", data, 76, ptk, ptk_len);
}

void wpa2_michael_mic(const u8* key, const u8* data, u32 datalen, u8 mic[8]) {
    u32 l = ((u32)key[0]|(u32)key[1]<<8|(u32)key[2]<<16|(u32)key[3]<<24);
    u32 r = ((u32)key[4]|(u32)key[5]<<8|(u32)key[6]<<16|(u32)key[7]<<24);
    u32 p = 0;
    while (p + 4 <= datalen) {
        u32 w = (u32)data[p]|(u32)data[p+1]<<8|(u32)data[p+2]<<16|(u32)data[p+3]<<24;
        l ^= w;
        r ^= (l << 17) | (l >> 15);
        l += r;
        r ^= ((l & 0xFF00FF00) >> 8) | ((l & 0x00FF00FF) << 8);
        l += r;
        r ^= (l << 3) | (l >> 29);
        l += r;
        r ^= (l >> 2) | (l << 30);
        l += r;
        p += 4;
    }
    if (p < datalen) {
        u32 w = 0;
        for (u32 i = p; i < datalen; i++) w |= (u32)data[i] << ((i-p)*8);
        l ^= w;
        r ^= (l << 17) | (l >> 15);
        l += r;
        r ^= ((l & 0xFF00FF00) >> 8) | ((l & 0x00FF00FF) << 8);
        l += r;
        r ^= (l << 3) | (l >> 29);
        l += r;
        r ^= (l >> 2) | (l << 30);
        l += r;
    }
    mic[0]=(u8)l; mic[1]=(u8)(l>>8); mic[2]=(u8)(l>>16); mic[3]=(u8)(l>>24);
    mic[4]=(u8)r; mic[5]=(u8)(r>>8); mic[6]=(u8)(r>>16); mic[7]=(u8)(r>>24);
}
