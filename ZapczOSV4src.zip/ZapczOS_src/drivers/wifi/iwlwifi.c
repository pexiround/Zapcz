#include "iwlwifi.h"
#include "iwl_fh.h"
#include "pci.h"
#include "io.h"
#include "libc_shim.h"
#include "mm.h"
#include "net.h"
#include "util.h"

#define CSR_HW_IF_CONFIG_REG     0x000
#define CSR_INT                  0x008
#define CSR_INT_MASK             0x00C
#define CSR_FH_INT_STATUS        0x010
#define CSR_GPIO_IN              0x018
#define CSR_RESET                0x020
#define CSR_GP_CNTRL             0x024
#define CSR_HW_REV               0x028
#define CSR_EEPROM_REG           0x02C
#define CSR_EEPROM_GP            0x030
#define CSR_OTP_GP_REG           0x034
#define CSR_UCODE_DRV_GP1        0x054
#define CSR_UCODE_DRV_GP1_SET    0x058
#define CSR_UCODE_DRV_GP1_CLR   0x05C
#define CSR_UCODE_DRV_GP2        0x060
#define CSR_MBOX_SET_REG         0x088
#define CSR_DRAM_INT_TBL_REG     0x0A0
#define CSR_MAC_SHADOW_REG_CTRL  0x0A8
/* HBUS peripheral-register window. These were scrambled: WDAT pointed at
   RDAT, RADDR pointed at WDAT, and RDAT pointed at CSR_GP_DRIVER, so every
   PRPH access read or wrote the wrong register and the APMG clock requests
   silently did nothing. Correct layout per iwlwifi: */
#define CSR_PRPH_RADDR           0x040
#define CSR_PRPH_WADDR           0x044
#define CSR_PRPH_RDAT            0x048
#define CSR_PRPH_WDAT            0x04C

/* the address word carries a byte-enable mask in bits 24-27; 3<<24 selects a
   full 32-bit access. 0x00100000 was meaningless here. */
#define CSR_PRPH_ACCESS_MASK     0x03000000u

#define CSR_RESET_FLAG_NEVO_RESET    0x00000001u
#define CSR_RESET_FLAG_FORCE_NMI     0x00000002u
#define CSR_RESET_FLAG_SW_RESET      0x00000080u
#define CSR_RESET_FLAG_MASTER_DISABLED 0x00000100u
#define CSR_RESET_FLAG_STOP_MASTER   0x00000200u

#define CSR_GP_CNTRL_REG_FLAG_INIT_DONE    0x00000004u
#define CSR_GP_CNTRL_REG_FLAG_MAC_ACCESS_REQ 0x00000008u
#define CSR_GP_CNTRL_REG_FLAG_GOING_TO_SLEEP 0x00000040u
#define CSR_GP_CNTRL_REG_FLAG_MAC_CLOCK_READY 0x00000001u
#define CSR_GP_CNTRL_REG_FLAG_HW_RF_KILL_SW    0x08000000u
#define CSR_HW_IF_CONFIG_REG_BIT_NIC_READY     0x00400000u
#define CSR_HW_IF_CONFIG_REG_PREPARE           0x08000000u
#define CSR_MBOX_SET_REG_ADDR                  0x088
#define CSR_GIO_REG_ADDR                       0x03C
#define CSR_GIO_REG_VAL_L0S_DISABLED           0x00000002u
#define CSR_MBOX_SET_REG_OS_ALIVE              0x00000020u
#define CSR_DBG_LINK_PWR_MGMT_REG_ADDR         0x250
#define CSR_RESET_LINK_PWR_MGMT_DISABLED       0x80000000u
#define CSR_GP_CNTRL_REG_FLAG_RFKILL_WAKE_L1A 0x00000010u

#define CSR_HW_IF_CONFIG_REG_BIT_NIC_READY  0x00400000u
#define CSR_HW_IF_CONFIG_REG_BIT_HAP_WAKE_L1A 0x00080000u
#define CSR_HW_IF_CONFIG_REG_BITS_SILICON_TYPE_B 0x00000200u
#define CSR_HW_IF_CONFIG_REG_D3_DEBUG       0x20000000u

/* APMG block, PRPH-relative. These were wrong: CLK_EN was pointing at
   PS_CTRL, so every "enable clocks" write landed in the power-save register
   and the DMA clock was never actually requested -- which is why the FH
   firmware DMA never completed on 7000-family parts. */
#define APMG_CLK_CTRL_REG     0x3000
#define APMG_CLK_EN_REG       0x3004
#define APMG_CLK_DIS_REG      0x3008
#define APMG_PS_CTRL_REG      0x300C
#define APMG_PCIDEV_STT_REG   0x3010
#define APMG_RTC_INT_STT_REG  0x301C
#define APMG_DIGITAL_SVR_REG  0x3058
#define APMG_ANALOG_SVR_REG   0x306C
#define APMG_LARC_EN_REG      0x3090
#define APMG_SVR_REG          0x3058

#define APMG_CLK_VAL_DMA_CLK_RQT      0x00000200
#define APMG_CLK_VAL_BSM_CLK_RQT      0x00000800
#define APMG_PS_CTRL_VAL_PWR_SRC_VMAIN 0x00000000
#define APMG_PS_CTRL_MSK_PWR_SRC      0x03000000
#define APMG_PCIDEV_STT_VAL_L1_ACT_DIS 0x00000800
#define APMG_RTC_INT_STT_RFKILL       0x10000000

#define APMG_CLK_CTRL_EN     0x00600006u
#define APMG_CLK_SEL_MSK     0x000403FFu

#define FH_MEM_RSCSR_CHNL0_STTS_WPTR 0x1BC0
#define FH_MEM_RSCSR_CHNL0_RBDCB_BASE_REG 0x1900
#define FH_MEM_RSCSR_CHNL0_WPTR 0x1904

#define LMPM_CPU_SELECT         0x250
#define LMPM_SECURE_UCODE_LOAD_CPU1_HDR_ADDR 0x1C00 
#define LMPM_SECURE_TIME_OUT    0xA0
#define LMPM_CPU1_UCODE_LOAD_ADDR 0x1C0
#define LMPM_CPU2_UCODE_LOAD_ADDR 0x1C4
#define LMPM_CPU1_HDR_BUFSZ     0x200
#define LMPM_CPU2_HDR_BUFSZ     0x204

#define IWL_TLV_CALIB_CTRL_ADDR 0x1C0
#define IWL_ALIVE_STATUS_OK     0xCAFEBEEF

#define RELEASE_CPU_RESET        0x300C
#define RELEASE_CPU_RESET_BIT    0x01000000u
#define FH_UCODE_LOAD_STATUS     0x1AF0

#define CSR_INT_BIT_FH_RX    0x80000000u
#define CSR_INT_BIT_HW_ERR   0x20000000u
#define CSR_INT_BIT_RX_PERIODIC 0x10000000u
#define CSR_INT_BIT_FH_TX    0x00800000u
#define CSR_INT_BIT_SW_ERR   0x02000000u
#define CSR_INT_BIT_RF_KILL  0x00000080u
#define CSR_INT_BIT_CT_KILL  0x00000040u
#define CSR_INT_BIT_SW_RX    0x00000008u
#define CSR_INT_BIT_WAKEUP   0x00000004u
#define CSR_INT_BIT_ALIVE    0x00000001u

extern void serial_puts(const char*);

/* An RX buffer the FH engine fills starts with a le32 byte-count, then the
   command header: { u8 cmd; u8 group_id; u8 seq[2] }. Draining the ring after
   the CPU starts lets us read what the firmware actually produced (an ALIVE
   notification is cmd 0x01) instead of only noticing the write pointer moved.
   This is bounded and read-only, so it cannot stall the boot path. */
extern u32 iwl_fh_rx_next(const u8**);
static int g_fw_ntfy_count = 0;
static u8  g_fw_first_cmd = 0xFF, g_fw_first_grp = 0xFF;
static int g_fw_saw_alive = 0;
static u32 g_alive_status = 0;
static u32 g_alive_scd_base = 0;
static u32 g_alive_err_table = 0;
static void dbg(const char* s) { serial_puts("[iwl] "); serial_puts(s); serial_puts("\r\n"); }
static void dbg_hex(const char* s, u32 v) {
    char b[16]; const char* hx = "0123456789ABCDEF";
    b[0]='0'; b[1]='x';
    for (int i = 0; i < 8; i++) b[2+i] = hx[(v >> ((7-i)*4)) & 0xF];
    b[10] = 0;
    serial_puts("[iwl] "); serial_puts(s); serial_puts(b); serial_puts("\r\n");
}

static void hex32(u32 v, char* out) {
    const char* hx = "0123456789ABCDEF";
    for (int i = 0; i < 8; i++) out[i] = hx[(v >> ((7 - i) * 4)) & 0xF];
    out[8] = 0;
}

static volatile u32* g_regs = 0;
static int g_ok = 0;
static int g_family = 0;
static char g_status[64] = "Not initialized";
static char g_fw_fail_reason[64] = "";
static u8 g_mac[6] = {0};
static int g_rfkill = 0;

static u32 REG(u32 off) { return g_regs[off/4]; }
static void REG_W(u32 off, u32 val) { g_regs[off/4] = val; }
static u32 PRPH_R(u32 addr) {
    REG_W(CSR_PRPH_RADDR, (addr & 0x00FFFFFF) | CSR_PRPH_ACCESS_MASK);
    for (volatile int i = 0; i < 100; i++) {}
    return REG(CSR_PRPH_RDAT);
}
static void PRPH_W(u32 addr, u32 val) {
    REG_W(CSR_PRPH_WADDR, (addr & 0x00FFFFFF) | CSR_PRPH_ACCESS_MASK);
    for (volatile int i = 0; i < 100; i++) {}
    REG_W(CSR_PRPH_WDAT, val);
}

static int wait_bit(u32 off, u32 mask, u32 val, int loops) {
    for (int i = 0; i < loops; i++) {
        if ((REG(off) & mask) == val) return 1;
        for (volatile int j = 0; j < 1000; j++) {}
    }
    return 0;
}

static void grab_mac_access(void) {
    u32 gp = REG(CSR_GP_CNTRL);
    if (gp & CSR_GP_CNTRL_REG_FLAG_GOING_TO_SLEEP) {
        REG_W(CSR_GP_CNTRL, gp | CSR_GP_CNTRL_REG_FLAG_MAC_ACCESS_REQ);
        for (volatile int i = 0; i < 200000; i++) {
            if (REG(CSR_GP_CNTRL) & CSR_GP_CNTRL_REG_FLAG_MAC_CLOCK_READY) break;
        }
    }
}

static void apmg_set(u32 reg, u32 set_bits, u32 clear_bits) {
    grab_mac_access();
    u32 val = PRPH_R(reg);
    val &= ~clear_bits;
    val |= set_bits;
    PRPH_W(reg, val);
}

static int set_hw_ready(void) {
    REG_W(CSR_HW_IF_CONFIG_REG, REG(CSR_HW_IF_CONFIG_REG) | CSR_HW_IF_CONFIG_REG_BIT_NIC_READY);
    for (int t = 0; t < 60; t++) {
        if (REG(CSR_HW_IF_CONFIG_REG) & CSR_HW_IF_CONFIG_REG_BIT_NIC_READY) {
            REG_W(CSR_MBOX_SET_REG_ADDR, REG(CSR_MBOX_SET_REG_ADDR) | CSR_MBOX_SET_REG_OS_ALIVE);
            return 1;
        }
        for (volatile int i = 0; i < 20000; i++) {}
    }
    return 0;
}

static int prepare_card_hw(void) {
    if (set_hw_ready()) { dbg("card ownership: hardware ready"); return 1; }

    REG_W(CSR_DBG_LINK_PWR_MGMT_REG_ADDR,
          REG(CSR_DBG_LINK_PWR_MGMT_REG_ADDR) | CSR_RESET_LINK_PWR_MGMT_DISABLED);
    for (volatile int i = 0; i < 200000; i++) {}

    for (int iter = 0; iter < 10; iter++) {
        REG_W(CSR_HW_IF_CONFIG_REG, REG(CSR_HW_IF_CONFIG_REG) | CSR_HW_IF_CONFIG_REG_PREPARE);
        for (int t = 0; t < 15; t++) {
            if (set_hw_ready()) { dbg_hex("card ownership: taken after prepare, iter=", (u32)iter); return 1; }
            for (volatile int i = 0; i < 40000; i++) {}
        }
    }
    dbg("card ownership: NOT ready (card may be held by BIOS/ME)");
    return 0;
}

static int power_up(void) {
    u32 hif = REG(CSR_HW_IF_CONFIG_REG);
    REG_W(CSR_HW_IF_CONFIG_REG, hif | CSR_HW_IF_CONFIG_REG_BIT_HAP_WAKE_L1A);

    REG_W(CSR_GP_CNTRL, REG(CSR_GP_CNTRL) | CSR_GP_CNTRL_REG_FLAG_INIT_DONE);
    for (volatile int i = 0; i < 200000; i++) {
        if (REG(CSR_GP_CNTRL) & CSR_GP_CNTRL_REG_FLAG_MAC_CLOCK_READY) break;
    }
    if (!(REG(CSR_GP_CNTRL) & CSR_GP_CNTRL_REG_FLAG_MAC_CLOCK_READY)) return 0;

    /* 7000/3160-family bring-up: request the DMA clock and let it settle,
       disable L1-Active, then clear any latched RF-kill interrupt. Without the
       DMA clock the FH engine cannot fetch firmware from host memory. */
    if (g_family != 8000) {
        /* APMG_CLK_EN is a set-register: writing a bit turns that clock on.
           The state is read back from APMG_CLK_CTRL, not from CLK_EN. */
        PRPH_W(APMG_CLK_EN_REG, APMG_CLK_VAL_DMA_CLK_RQT);
        for (volatile int i = 0; i < 60000; i++) {}

        u32 ctrl = PRPH_R(APMG_CLK_CTRL_REG);
        dbg_hex("APMG_CLK_CTRL after DMA clock request = ", ctrl);
        if (ctrl & APMG_CLK_VAL_DMA_CLK_RQT) dbg("APMG: DMA clock is RUNNING");
        else dbg("APMG: DMA clock did NOT come up");

        apmg_set(APMG_PCIDEV_STT_REG, APMG_PCIDEV_STT_VAL_L1_ACT_DIS, 0);
        PRPH_W(APMG_RTC_INT_STT_REG, APMG_RTC_INT_STT_RFKILL);
        dbg("APMG: L1-Active disabled, RF-kill interrupt cleared");
    }
    return 1;
}

/* Firmware sections go into device SRAM over the FH DMA engine. The old code
   wrote them through the PRPH register window, which addresses peripheral
   registers rather than SRAM, so the microcode never actually landed. */
static int upload_fw_section(const u8* data, u32 size, u32 dst_addr,
                             int do_status, u32 status_val) {
    if (!data || size == 0) return 1;

    if (!iwl_fh_grab_nic_access()) {
        dbg("fw upload: could not hold MAC clock for FH access");
        str_copy(g_fw_fail_reason, "FW load: MAC clock not held", 64);
        return 0;
    }
    int ok = iwl_fh_load_section(data, size, dst_addr);
    if (ok && do_status)
        REG_W(FH_UCODE_LOAD_STATUS, REG(FH_UCODE_LOAD_STATUS) | status_val);
    iwl_fh_release_nic_access();
    if (!ok) {
        dbg_hex("fw upload: DMA stalled at dst=", dst_addr);
        str_copy(g_fw_fail_reason, "FW load: FH DMA never went idle", 64);
    }
    return ok;
}

static void fw_status_marker(u32 val) {
    if (iwl_fh_grab_nic_access()) {
        REG_W(FH_UCODE_LOAD_STATUS, val);
        iwl_fh_release_nic_access();
    }
}

static void fw_release_secure_cpu(void) {
    if (iwl_fh_grab_nic_access()) {
        PRPH_W(RELEASE_CPU_RESET, RELEASE_CPU_RESET_BIT);
        iwl_fh_release_nic_access();
    }
}

#define CPU1_CPU2_SEPARATOR_SECTION  0xFFFFCCCCu
#define PAGING_SEPARATOR_SECTION     0xAAAABBBBu

static int g_fw_cpu1_secs = 0, g_fw_cpu2_secs = 0, g_fw_paging_secs = 0;

/* Parse the firmware image without touching the device. Lets us confirm a
   blob is the right shape (and that our TLV walk is correct) on machines
   where the radio is absent, e.g. under emulation. */
int iwl_fw_validate(u32 fw_addr, u32 fw_size) {
    const u8* fw = (const u8*)fw_addr;
    if (!fw || fw_size < 88) { dbg("fw validate: too small"); return 0; }
    u32 magic; memcpy(&magic, fw + 4, 4);
    if (magic != 0x0a4c5749u) { dbg_hex("fw validate: bad magic ", magic); return 0; }

    char hr[65];
    for (int i = 0; i < 64; i++) hr[i] = (char)fw[8 + i];
    hr[64] = 0;
    dbg("fw validate: magic OK");
    dbg(hr);

    u32 off = 88, tlvs = 0, cpu1 = 0, cpu2 = 0, paging = 0, bytes = 0;
    int cur_cpu = 1, in_pg = 0;
    while (off + 8 <= fw_size) {
        u32 t, l;
        memcpy(&t, fw + off, 4);
        memcpy(&l, fw + off + 4, 4);
        if (l > fw_size - off - 8) break;
        tlvs++;
        if (t == 19 && l > 4) {
            u32 a; memcpy(&a, fw + off + 8, 4);
            if (a == CPU1_CPU2_SEPARATOR_SECTION) cur_cpu = 2;
            else if (a == PAGING_SEPARATOR_SECTION) in_pg = 1;
            else if (in_pg) paging++;
            else { if (cur_cpu == 1) cpu1++; else cpu2++; bytes += l - 4; }
        }
        off += 8 + ((l + 3) & ~3u);
    }
    dbg_hex("fw validate: TLVs=", tlvs);
    dbg_hex("fw validate: CPU1 sections=", cpu1);
    dbg_hex("fw validate: CPU2 sections=", cpu2);
    dbg_hex("fw validate: paging sections=", paging);
    dbg_hex("fw validate: total image bytes=", bytes);
    return (cpu1 > 0);
}

static int parse_and_load_fw(const u8* fw, u32 fw_size) {
    if (!fw || fw_size < 88) return 0;

    /* iwl_tlv_ucode_header is:
         le32 zero; le32 magic; u8 human_readable[64];
         le32 ver;  le32 build; le64 ignore;
       which is 88 bytes -- the TLV stream starts after it. Starting at 84
       shifted every subsequent type/length by four bytes, so no section was
       ever recognised. */
    {
        u32 magic;
        memcpy(&magic, fw + 4, 4);
        if (magic != 0x0a4c5749u) {          /* "IWL\n" */
            dbg_hex("firmware magic mismatch, got ", magic);
            return 0;
        }
    }

    int secure = (g_family == 8000);
    if (secure) {
        fw_release_secure_cpu();
        dbg("8000 secure boot: RELEASE_CPU_RESET asserted before load");
    }

    u32 off = 88;
    int loaded = 0;
    int cur_cpu = 1;
    int in_paging = 0;
    u32 sec_num = 1;
    g_fw_cpu1_secs = g_fw_cpu2_secs = g_fw_paging_secs = 0;

    while (off + 8 <= fw_size) {
        u32 t, l;
        memcpy(&t, fw + off, 4);
        memcpy(&l, fw + off + 4, 4);
        if (l > fw_size - off - 8) break;
        u32 padded = (l + 3) & ~3u;

        /* IWL_UCODE_TLV_SEC_RT: payload is { le32 load_address; u8 data[] } --
           the address is four bytes, not eight.

           Two address values are not addresses at all but markers:
             0xFFFFCCCC  everything after this belongs to CPU2
             0xAAAABBBB  everything after this is paged memory
           Writing to them would scribble over unrelated device memory. */
        if (t == 19 && l > 4) {
            u32 sec_addr;
            memcpy(&sec_addr, fw + off + 8, 4);
            const u8* sec_data = fw + off + 12;
            u32 sec_len = l - 4;

            if (sec_addr == CPU1_CPU2_SEPARATOR_SECTION) {
                dbg("fw: CPU1/CPU2 separator - switching to CPU2 sections");
                if (secure) { fw_status_marker(0xFFFF); sec_num = 1; }
                cur_cpu = 2;
            } else if (sec_addr == PAGING_SEPARATOR_SECTION) {
                dbg("fw: paging separator - remaining sections are paged memory");
                in_paging = 1;
            } else if (sec_addr != 0xFFFFFFFFu && sec_len > 0) {
                if (in_paging) {
                    /* paged sections are DMAed into host memory by the device
                       once it is alive; they are not poked in here */
                    dbg_hex("fw: paging section (deferred) addr=", sec_addr);
                    g_fw_paging_secs++;
                } else {
                    dbg_hex(cur_cpu == 1 ? "fw CPU1 section addr=" : "fw CPU2 section addr=", sec_addr);
                    dbg_hex("   len=", sec_len);
                    u32 shift = (cur_cpu == 1) ? 0u : 16u;
                    if (upload_fw_section(sec_data, sec_len, sec_addr, secure, sec_num << shift)) {
                        if (secure) sec_num = (sec_num << 1) | 1u;
                        if (cur_cpu == 1) g_fw_cpu1_secs++; else g_fw_cpu2_secs++;
                        loaded++;
                    }
                }
            }
        }

        off += 8 + padded;
        if (t == 0 && l == 0) break;
    }

    if (secure) {
        fw_status_marker(0xFFFFFFFFu);
        dbg("8000 secure boot: CPU2 load-complete marker written");
    }

    return loaded > 0;
}

static int start_fw(void) {
    if (g_family == 8000) {
        for (volatile int i = 0; i < 1000000; i++) {}
        return 1;
    }

    REG_W(CSR_UCODE_DRV_GP1_CLR, 0xFFFFFFFFu);
    REG_W(CSR_RESET, REG(CSR_RESET) & ~CSR_RESET_FLAG_MASTER_DISABLED);

    REG_W(LMPM_CPU_SELECT & 0xFFFFF, 0);

    u32 gp_cntrl = REG(CSR_GP_CNTRL);
    gp_cntrl &= ~CSR_GP_CNTRL_REG_FLAG_GOING_TO_SLEEP;
    REG_W(CSR_GP_CNTRL, gp_cntrl);

    REG_W(CSR_RESET, 0);

    for (volatile int i = 0; i < 1000000; i++) {}

    return 1;
}

/* Identify the fitted radio from PCI config space alone. Returns a family
   number (3160/7000/8000/9000) or 0 when no supported device is present. */
int iwl_detect_family(void) {
    static const u16 f3160[] = { 0x08B3, 0x08B4, 0 };
    static const u16 f7000[] = { 0x08B1, 0x08B2, 0x095A, 0x095B, 0x095E,
                                 0x3165, 0x3166, 0x3168, 0 };
    static const u16 f8000[] = { 0x24F3, 0x24F4, 0x24FB, 0x24FD, 0 };
    static const u16 f9000[] = { 0x2526, 0x9DF0, 0xA370, 0x31DC, 0x30DC,
                                 0x2723, 0x02F0, 0x34F0, 0x4DF0, 0x43F0, 0xA0F0, 0 };
    pci_dev_t d;
    for (int i = 0; f3160[i]; i++) if (pci_find_device(0x8086, f3160[i], &d)) return 3160;
    for (int i = 0; f7000[i]; i++) if (pci_find_device(0x8086, f7000[i], &d)) return 7000;
    for (int i = 0; f8000[i]; i++) if (pci_find_device(0x8086, f8000[i], &d)) return 8000;
    for (int i = 0; f9000[i]; i++) if (pci_find_device(0x8086, f9000[i], &d)) return 9000;
    return 0;
}

/* Read back whatever the firmware has posted to the RX ring. Bounded to a
   small number of buffers so a chatty or a silent device both return quickly.
   Records honest diagnostics only; it does not act on the notifications, which
   is the piece (the MVM host-command dialogue) still to be written. */
static void drain_rx_notifications(void) {
    g_fw_ntfy_count = 0;
    g_fw_first_cmd = g_fw_first_grp = 0xFF;
    g_fw_saw_alive = 0;
    for (int i = 0; i < 32; i++) {
        const u8* buf = 0;
        u32 len = iwl_fh_rx_next(&buf);
        if (!len || !buf) break;
        if (len < 8) continue;
        u8 cmd = buf[4];
        u8 grp = buf[5];
        if (g_fw_ntfy_count == 0) { g_fw_first_cmd = cmd; g_fw_first_grp = grp; }
        g_fw_ntfy_count++;
        if (cmd == 0x01) {
            g_fw_saw_alive = 1;
            if (len >= 52) {
                g_alive_status = (u32)buf[8] | ((u32)buf[9] << 8);
                memcpy(&g_alive_err_table, buf + 28, 4);
                memcpy(&g_alive_scd_base, buf + 48, 4);
                dbg_hex("ALIVE status (0xCAFE=ok, 0xDEAD=err)=", g_alive_status);
                dbg_hex("ALIVE lmac error-log table=", g_alive_err_table);
                dbg_hex("ALIVE lmac SCD base ptr=", g_alive_scd_base);
                iwl_fh_scd_init(g_alive_scd_base);
                dbg("SCD scheduler programmed for command queue");
                if (iwl_fh_send_hcmd(0x00, 0x01, 0, 0))
                    dbg_hex("sent first host command, tx wptr=", iwl_fh_tx_wptr());
                else
                    dbg("host command send FAILED");
            } else {
                dbg_hex("ALIVE notification too short, len=", len);
            }
        }
        {
            char b[8]; const char* hx = "0123456789ABCDEF";
            b[0]='c'; b[1]='m'; b[2]='d'; b[3]=' ';
            b[4]=hx[(cmd>>4)&0xF]; b[5]=hx[cmd&0xF]; b[6]=0;
            dbg_hex(b, grp);
        }
    }
    if (g_fw_ntfy_count)
        dbg_hex("firmware posted RX notifications: n=", (u32)g_fw_ntfy_count);
}

int iwl_init(u32 fw_addr, u32 fw_size, int fw_type) {
    (void)fw_type;
    str_copy(g_status, "Initializing...", 64);
    g_ok = 0;

    pci_dev_t pdev;
    u16 ids[][2] = {
        {0x8086, 0x08B3}, {0x8086, 0x08B4},
        {0x8086, 0x3165}, {0x8086, 0x3166},
        {0x8086, 0x08B1}, {0x8086, 0x08B2},
        {0x8086, 0x095A}, {0x8086, 0x095B},
        {0x8086, 0x24F3}, {0x8086, 0x24FD}, {0x8086, 0x24FB},
        {0x8086, 0x2526}, {0x8086, 0xA370}, {0x8086, 0x31DC}, {0x8086, 0x9DF0},
        {0x8086, 0x3168},
        /* 3160 -- the usual card in a Lenovo E31-70 */
        {0x8086, 0x08B3}, {0x8086, 0x08B4},
        /* 7265D / 3165 / 3168 variants */
        {0x8086, 0x095E}, {0x8086, 0x9DF0}, {0x8086, 0x30DC},
        /* 6205/6235 (older ThinkPads) */
        {0x8086, 0x0085}, {0x8086, 0x0087}, {0x8086, 0x0089},
        {0x8086, 0x008A}, {0x8086, 0x008B}, {0x8086, 0x0090}, {0x8086, 0x0091},
        /* 6300/6200 */
        {0x8086, 0x422B}, {0x8086, 0x422C}, {0x8086, 0x4238}, {0x8086, 0x4239},
        /* AX200 / AX201 (newer machines) */
        {0x8086, 0x2723}, {0x8086, 0x02F0}, {0x8086, 0x34F0},
        {0x8086, 0x4DF0}, {0x8086, 0x43F0}, {0x8086, 0xA0F0},
        {0,0}
    };
    dbg("iwl_init: scanning PCI for Intel WiFi");
    int found = 0;
    u16 dev_id = 0;
    for (int i = 0; ids[i][0]; i++) {
        if (pci_find_device(ids[i][0], ids[i][1], &pdev)) { found = 1; dev_id = ids[i][1]; dbg_hex("found device id=", dev_id); break; }
    }
    if (!found) { dbg("no Intel WiFi device present (expected in QEMU)"); str_copy(g_status, "Intel WiFi chip not detected", 64); return 0; }

    if (dev_id == 0x08B3 || dev_id == 0x08B4 || dev_id == 0x08B1 || dev_id == 0x08B2 ||
        dev_id == 0x3165 || dev_id == 0x3166 || dev_id == 0x095A || dev_id == 0x095B ||
        dev_id == 0x095E) {
        g_family = 7000; dbg("chip family 7000 (3160/7260/7265 - non-secure fw load)");
    } else if (dev_id == 0x24F3 || dev_id == 0x24FD || dev_id == 0x24FB || dev_id == 0x3168 ||
               dev_id == 0x24F4) {
        g_family = 8000; dbg("chip family 8000 (8260/8265 - secure-boot fw load)");
    } else {
        g_family = 9000; dbg("chip family 9000 (context-info fw load)");
    }

    pci_enable_bus_master(&pdev);
    u32 bar0 = pdev.bar[0] & ~0xFu;
    dbg_hex("BAR0=", bar0);
    if (!bar0) { str_copy(g_status, "BAR0 mapping failed", 64); return 0; }
    g_regs = (volatile u32*)bar0;
    iwl_fh_bind(g_regs);

    u32 hw_rev = REG(CSR_HW_REV);
    dbg_hex("CSR_HW_REV=", hw_rev);
    dbg_hex("fw_size=", fw_size);
    str_copy(g_status, "HW detected, resetting...", 64);

    REG_W(CSR_INT_MASK, 0);
    REG_W(CSR_INT, 0xFFFFFFFFu);
    REG_W(CSR_FH_INT_STATUS, 0xFFFFFFFFu);

    u32 rf_val = REG(CSR_GP_CNTRL);
    dbg_hex("CSR_GP_CNTRL=", rf_val);
    g_rfkill = 0;

    dbg("claiming card ownership (NIC_READY handshake)");
    prepare_card_hw();

    REG_W(CSR_GIO_REG_ADDR, REG(CSR_GIO_REG_ADDR) | CSR_GIO_REG_VAL_L0S_DISABLED);
    dbg("PCIe L0S disabled (apm_config)");

    dbg("issuing SW reset");
    REG_W(CSR_RESET, CSR_RESET_FLAG_SW_RESET);
    for (volatile int i = 0; i < 3000000; i++) {}

    REG_W(CSR_INT, 0xFFFFFFFFu);
    REG_W(CSR_INT_MASK, 0);

    if (!power_up()) { dbg("APM power-up FAILED (MAC clock not ready)"); str_copy(g_status, "Power up failed", 64); return 0; }
    dbg("APM power-up OK");

    {
        u32 gp = REG(CSR_GP_CNTRL);
        for (int t = 0; t < 300; t++) {
            gp = REG(CSR_GP_CNTRL);
            if (gp & CSR_GP_CNTRL_REG_FLAG_HW_RF_KILL_SW) break;
            for (volatile int i = 0; i < 60000; i++) {}
        }
        if (!(gp & CSR_GP_CNTRL_REG_FLAG_HW_RF_KILL_SW)) {
            dbg_hex("RF-kill: line reads DISABLED, GP_CNTRL=", gp);
            dbg("RF-kill: continuing bring-up anyway (line can read stale)");
            g_rfkill = 1;
        } else {
            dbg("RF-kill: radio enabled, proceeding");
            g_rfkill = 0;
        }
    }

    str_copy(g_status, "Power OK, setting up RX queue...", 64);

    /* The ALIVE notification arrives through the RX queue, so it has to be
       live before the firmware CPU starts. */
    if (!iwl_fh_rx_init()) {
        dbg("RX queue init FAILED (could not hold MAC clock)");
        str_copy(g_status, "RX queue init failed", 64);
        return 0;
    }
    dbg("RX queue initialised (256 x 4K buffers)");

    if (iwl_fh_tx_init()) dbg("TX/command queue ring initialised");
    else dbg("TX/command queue init FAILED (no MAC access)");

    str_copy(g_status, "Loading firmware over DMA...", 64);

    if (!fw_addr || fw_size < 80) { dbg("no firmware blob supplied (need iwlwifi-8265-*.ucode)"); str_copy(g_status, "No firmware provided", 64); return 0; }

    const u8* fw = (const u8*)fw_addr;
    g_fw_fail_reason[0] = 0;
    if (!parse_and_load_fw(fw, fw_size)) {
        dbg("firmware parse/upload found no loadable sections");
        /* keep whatever specific reason the loader already recorded instead of
           clobbering it with a generic message */
        if (g_fw_fail_reason[0]) str_copy(g_status, g_fw_fail_reason, 64);
        else {
            u32 magic = 0;
            if (fw_size >= 8) memcpy(&magic, fw + 4, 4);
            if (magic != 0x0a4c5749u) str_copy(g_status, "FW blob corrupt (bad magic)", 64);
            else str_copy(g_status, "FW parsed but no sections found", 64);
        }
        return 0;
    }
    dbg("firmware sections uploaded over FH DMA");

    str_copy(g_status, "Firmware loaded, starting CPU...", 64);
    dbg("starting firmware CPU, watching for ALIVE interrupt");
    start_fw();

    REG_W(CSR_INT, 0xFFFFFFFFu);
    REG_W(CSR_INT_MASK, 0xFFFFFFFFu);
    u32 seen = 0;
    u32 rx_moved = 0;
    for (int t = 0; t < 60; t++) {
        u32 in = REG(CSR_INT);
        seen |= in;
        u32 w = iwl_fh_rx_wptr();
        if (w != 0) rx_moved = w;
        if (in & CSR_INT_BIT_ALIVE) { dbg("*** ALIVE interrupt received - firmware booted! ***"); break; }
        if (in & CSR_INT_BIT_HW_ERR) { dbg("HW_ERR interrupt - firmware load bad"); break; }
        if (in & CSR_INT_BIT_SW_ERR) { dbg("SW_ERR interrupt - firmware asserted"); break; }
        if (rx_moved) { dbg_hex("RX write pointer moved - firmware is producing, wptr=", rx_moved); break; }
        for (volatile int j = 0; j < 500000; j++) {}
    }
    dbg_hex("CSR_INT bits seen after CPU start=", seen);
    dbg_hex("RX wptr after CPU start=", iwl_fh_rx_wptr());
    dbg_hex("fw sections uploaded: CPU1=", (u32)g_fw_cpu1_secs);
    dbg_hex("                      CPU2=", (u32)g_fw_cpu2_secs);
    if (g_family == 8000)
        dbg_hex("8000 FH_UCODE_LOAD_STATUS after start=", REG(FH_UCODE_LOAD_STATUS));

    for (int t = 0; t < 400 && iwl_fh_rx_wptr() == 0; t++) {
        for (volatile int j = 0; j < 100000; j++) {}
    }
    dbg_hex("RX wptr after settle poll=", iwl_fh_rx_wptr());

    /* Read whatever the firmware wrote to the RX ring. This exercises the real
       RX path and lets the status line be specific about how far bring-up got,
       instead of guessing from the interrupt bits alone. */
    drain_rx_notifications();

    if ((seen & CSR_INT_BIT_ALIVE) || g_fw_saw_alive) {
        if (g_alive_status == 0xCAFE)
            str_copy(g_status, iwl_fh_tx_ready()
                ? "ALIVE + command queue up; NVM/scan next"
                : "Firmware ALIVE (status OK); cmd queue not ready", 64);
        else if (g_alive_status == 0xDEAD)
            str_copy(g_status, "Firmware ALIVE but reported error (0xDEAD)", 64);
        else if (g_fw_ntfy_count > 0)
            str_copy(g_status, "Firmware ALIVE, RX notifications read; MVM cmd path WIP", 64);
        else
            str_copy(g_status, "Firmware ALIVE (no RX notifications yet); assoc WIP", 64);
    } else if (g_fw_ntfy_count > 0) {
        str_copy(g_status, "Firmware producing RX notifications; assoc WIP", 64);
    } else if (seen & (CSR_INT_BIT_HW_ERR | CSR_INT_BIT_SW_ERR)) {
        str_copy(g_status, "FW error irq - load path needs DMA rework", 64);
    } else if (g_rfkill) {
        str_copy(g_status, "No ALIVE - radio is RF-killed (enable WiFi switch)", 64);
    } else {
        str_copy(g_status, "No ALIVE irq - FW did not boot (load path)", 64);
    }
    g_ok = 1;

    g_mac[0] = 0x02;
    g_mac[1] = (u8)(hw_rev >> 8);
    g_mac[2] = (u8)(hw_rev);
    g_mac[3] = 0xAB;
    g_mac[4] = 0xCD;
    g_mac[5] = 0xEF;

    return 1;
}

int iwl_scan(wifi_bss_t* out, u32 max, u32* found) {
    (void)out; (void)max;
    *found = 0;
    if (!g_ok || !g_regs) return 0;
    /* The RX ring is live and firmware notifications are read (see
       drain_rx_notifications), but issuing an MVM SCAN host command and parsing
       the results still needs the command-queue TX path, which is not written
       yet. Report that honestly rather than returning fabricated networks. */
    if (g_fw_saw_alive || g_fw_ntfy_count > 0)
        str_copy(g_status, "Scan needs MVM cmd path (firmware is alive)", 64);
    else
        str_copy(g_status, "Scan unavailable (firmware not alive)", 64);
    return 0;
}

int  iwl_connect(const char* ssid, const char* pass) { (void)ssid; (void)pass; return 0; }
void iwl_poll(void) {}
int  iwl_is_up(void) { return g_ok; }
const char* iwl_status(void) { return g_status; }

/* ---- diagnostics ----
   Dumps the registers that decide whether firmware can load, so a failure on
   real hardware can be read off directly instead of guessed at. */
void iwl_dump_diag(void (*emit)(const char*)) {
    char line[96];

    if (!g_regs) { emit("iwl: no register window (chip not mapped)"); return; }

    struct { const char* name; u32 off; } csr[] = {
        { "CSR_HW_IF_CONFIG", 0x000 },
        { "CSR_INT",          0x008 },
        { "CSR_INT_MASK",     0x00C },
        { "CSR_FH_INT_STATUS",0x010 },
        { "CSR_RESET",        0x020 },
        { "CSR_GP_CNTRL",     0x024 },
        { "CSR_HW_REV",       0x028 },
        { "CSR_EEPROM_GP",    0x030 },
        { "CSR_OTP_GP",       0x034 },
        { "CSR_GIO_REG",      0x03C },
        { "CSR_GP_DRIVER",    0x050 },
        { "CSR_UCODE_DRV_GP1",0x054 },
    };
    for (u32 i = 0; i < sizeof(csr)/sizeof(csr[0]); i++) {
        u32 v = REG(csr[i].off);
        str_copy(line, csr[i].name, sizeof(line));
        str_cat(line, " = 0x", sizeof(line));
        char hx[12]; hex32(v, hx); str_cat(line, hx, sizeof(line));
        emit(line);
    }

    /* APMG block lives behind the PRPH window */
    struct { const char* name; u32 addr; } apmg[] = {
        { "APMG_CLK_CTRL",    0x3000 },
        { "APMG_CLK_EN",      0x3004 },
        { "APMG_CLK_CTRL_ST", 0x3000 },
        { "APMG_PS_CTRL",     0x300C },
        { "APMG_PCIDEV_STT",  0x3010 },
        { "APMG_RTC_INT_STT", 0x301C },
    };
    for (u32 i = 0; i < sizeof(apmg)/sizeof(apmg[0]); i++) {
        u32 v = PRPH_R(apmg[i].addr);
        str_copy(line, apmg[i].name, sizeof(line));
        str_cat(line, " = 0x", sizeof(line));
        char hx[12]; hex32(v, hx); str_cat(line, hx, sizeof(line));
        emit(line);
    }

    /* FH engine state: is the service channel enabled, and does it report idle? */
    struct { const char* name; u32 off; } fh[] = {
        { "FH_TCSR9_TX_CONFIG", 0x1000 + 0xD00 + 0x20 * 9 },
        { "FH_TCSR9_BUF_STS",   0x1000 + 0xD00 + 0x20 * 9 + 0x8 },
        { "FH_TSSR_TX_STATUS",  0x1000 + 0xEA0 + 0x010 },
        { "FH_SRVC9_SRAM_ADDR", 0x1000 + 0x9C8 + 0x24 },
        { "FH_RCSR0_CONFIG",    0x1000 + 0xC00 },
        { "FH_RSCSR0_WPTR",     0x1000 + 0xBC0 + 0x008 },
    };
    for (u32 i = 0; i < sizeof(fh)/sizeof(fh[0]); i++) {
        u32 v = REG(fh[i].off);
        str_copy(line, fh[i].name, sizeof(line));
        str_cat(line, " = 0x", sizeof(line));
        char hx[12]; hex32(v, hx); str_cat(line, hx, sizeof(line));
        emit(line);
    }

    /* plain-language verdicts, so a failure can be reported without reading hex */
    emit("--- what this means ---");
    {
        u32 gp = REG(0x024);
        emit((gp & 0x00000001u) ? "MAC clock: READY" : "MAC clock: NOT ready  <-- blocks firmware load");
        emit((gp & 0x00000004u) ? "INIT_DONE: set" : "INIT_DONE: NOT set  <-- APM power-up incomplete");
        emit((gp & 0x08000000u) ? "RF-kill: radio ENABLED" : "RF-kill: radio DISABLED by switch");

        u32 clk = PRPH_R(0x3000);   /* APMG_CLK_CTRL holds the live state */
        emit((clk & 0x00000200u) ? "DMA clock: RUNNING" : "DMA clock: NOT running  <-- FH DMA cannot run");

        u32 tcfg = REG(0x1000 + 0xD00 + 0x20 * 9);
        emit((tcfg & 0x80000000u) ? "FH service channel: ENABLED" : "FH service channel: disabled");

        u32 tss = REG(0x1000 + 0xEA0 + 0x010);
        emit((tss & ((1u << 9) << 16)) ? "FH channel 9: idle (transfers complete)"
                                       : "FH channel 9: NOT idle  <-- DMA never finished");

        u32 rcfg = REG(0x1000 + 0xC00);
        emit((rcfg & 0x80000000u) ? "RX DMA: enabled" : "RX DMA: disabled");
    }

    str_copy(line, "family = ", sizeof(line));
    { char nb[12]; u32_to_str((u32)g_family, nb); str_cat(line, nb, sizeof(line)); }
    str_cat(line, "  rfkill = ", sizeof(line));
    { char nb[12]; u32_to_str((u32)g_rfkill, nb); str_cat(line, nb, sizeof(line)); }
    emit(line);
    str_copy(line, "status: ", sizeof(line));
    str_cat(line, g_status, sizeof(line));
    emit(line);
}
