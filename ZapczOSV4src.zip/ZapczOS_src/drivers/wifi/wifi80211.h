#ifndef WIFI80211_H
#define WIFI80211_H
#include "io.h"

#define DOT11_FTYPE_MGMT 0x00
#define DOT11_FTYPE_CTRL 0x01
#define DOT11_FTYPE_DATA 0x02

#define DOT11_STYPE_ASSOC_REQ    0x00
#define DOT11_STYPE_ASSOC_RESP   0x01
#define DOT11_STYPE_PROBE_REQ    0x04
#define DOT11_STYPE_PROBE_RESP   0x05
#define DOT11_STYPE_BEACON       0x08
#define DOT11_STYPE_AUTH         0x0B
#define DOT11_STYPE_DEAUTH       0x0C

#define DOT11_CAP_ESS       0x0001
#define DOT11_CAP_PRIVACY   0x0010
#define DOT11_CAP_SHORT_PRE 0x0020
#define DOT11_CAP_SHORT_SLOT 0x0400

#define DOT11_IE_SSID           0
#define DOT11_IE_SUPPORTED_RATES 1
#define DOT11_IE_DS_PARAMS      3
#define DOT11_IE_TIM            5
#define DOT11_IE_RSN            48
#define DOT11_IE_EXT_RATES      50
#define DOT11_IE_HT_CAP         45
#define DOT11_IE_HT_INFO        61
#define DOT11_IE_VENDOR         221

#define DOT11_AUTH_OPEN   0
#define DOT11_AUTH_WEP    1

#define DOT11_STATUS_SUCCESS   0
#define DOT11_STATUS_REFUSED   1
#define DOT11_STATUS_AP_FULL   17

#define DOT11_REASON_DEAUTH_LEAVING 3

#define WIFI_CHAN_2G_BASE_MHZ 2407
#define WIFI_MAX_SSID_LEN 32
#define WIFI_MAX_BSS 16

typedef struct {
    u8  bssid[6];
    char ssid[WIFI_MAX_SSID_LEN + 1];
    u8   ssid_len;
    u8   channel;
    u16  beacon_interval;
    u16  capability;
    i32  rssi;
    u8   has_wpa2;
    u8   rates[16];
    u8   rate_count;
} wifi_bss_t;

typedef enum {
    WIFI_STATE_IDLE = 0,
    WIFI_STATE_SCANNING,
    WIFI_STATE_AUTHENTICATING,
    WIFI_STATE_ASSOCIATING,
    WIFI_STATE_CONNECTED,
    WIFI_STATE_ERROR
} wifi_state_t;

typedef struct {
    u8  sta_mac[6];
    char ssid[WIFI_MAX_SSID_LEN + 1];
    u8   ssid_len;
    char passphrase[64];
    u8   bssid[6];
    u8   channel;
    u8   pmk[32];
    u8   ptk[64];
    u8   gtk[32];
    u8   anonce[32];
    u8   snonce[32];
    u16  assoc_id;
    u32  gtk_keyid;
    wifi_state_t state;
    wifi_bss_t scan_results[WIFI_MAX_BSS];
    u8   scan_count;
    u32  state_timeout;
    u8   eapol_seq;
    u8   ready;
} wifi_ctx_t;

typedef struct __attribute__((packed)) {
    u16 frame_ctrl;
    u16 duration;
    u8  addr1[6];
    u8  addr2[6];
    u8  addr3[6];
    u16 seq_ctrl;
} dot11_hdr_t;

u32 wifi80211_build_probe_req(u8* buf, u32 bufsize, const u8* sta_mac,
                               const char* ssid, u8 ssid_len);
u32 wifi80211_build_auth_req(u8* buf, u32 bufsize, const u8* sta_mac,
                              const u8* bssid, u16 auth_seq);
u32 wifi80211_build_assoc_req(u8* buf, u32 bufsize, const u8* sta_mac,
                               const u8* bssid, const char* ssid, u8 ssid_len,
                               u16 listen_interval, u8 has_wpa2);
u32 wifi80211_build_deauth(u8* buf, u32 bufsize, const u8* sta_mac,
                            const u8* bssid, u16 reason);
u32 wifi80211_build_data(u8* buf, u32 bufsize, const u8* sta_mac,
                          const u8* bssid, const u8* dst_mac,
                          const u8* payload, u32 paylen, u16 seq);

int wifi80211_parse_beacon(const u8* frame, u32 framelen, wifi_bss_t* out);
int wifi80211_parse_auth_resp(const u8* frame, u32 framelen, u16* status);
int wifi80211_parse_assoc_resp(const u8* frame, u32 framelen, u16* status, u16* assoc_id);

u8  wifi80211_frame_type(const u8* frame);
u8  wifi80211_frame_subtype(const u8* frame);
int wifi80211_frame_is_for_me(const u8* frame, const u8* my_mac);

u32 wifi80211_channel_to_freq(u8 channel);

#endif
