#include "e1000.h"
#include "pci.h"
#include "mm.h"
#include "libc_shim.h"

#define REG_CTRL    0x0000
#define REG_STATUS  0x0008
#define REG_EERD    0x0014
#define REG_ICR     0x00C0
#define REG_IMS     0x00D0
#define REG_IMC     0x00D8
#define REG_RCTL    0x0100
#define REG_TCTL    0x0400
#define REG_TIPG    0x0410
#define REG_RDBAL   0x2800
#define REG_RDBAH   0x2804
#define REG_RDLEN   0x2808
#define REG_RDH     0x2810
#define REG_RDT     0x2818
#define REG_TDBAL   0x3800
#define REG_TDBAH   0x3804
#define REG_TDLEN   0x3808
#define REG_TDH     0x3810
#define REG_TDT     0x3818
#define REG_RAL0    0x5400
#define REG_RAH0    0x5404

#define CTRL_RST    0x04000000u
#define CTRL_SLU    0x00000040u
#define CTRL_ASDE   0x00000020u

#define RCTL_EN     0x00000002u
#define RCTL_SBP    0x00000004u
#define RCTL_UPE    0x00000008u
#define RCTL_MPE    0x00000010u
#define RCTL_BAM    0x00008000u
#define RCTL_BSIZE_2048 0x00000000u
#define RCTL_SECRC  0x04000000u

#define TCTL_EN     0x00000002u
#define TCTL_PSP    0x00000008u
#define TCTL_CT_SHIFT 4
#define TCTL_COLD_SHIFT 12

#define RX_RING_SIZE 32
#define TX_RING_SIZE 16
#define PKT_BUF_SIZE 2048

typedef struct {
    u64 addr;
    u16 length;
    u16 checksum;
    u8  status;
    u8  errors;
    u16 special;
} __attribute__((packed)) rx_desc_t;

typedef struct {
    u64 addr;
    u16 length;
    u8  cso;
    u8  cmd;
    u8  status;
    u8  css;
    u16 special;
} __attribute__((packed)) tx_desc_t;

static volatile u32* mmio = 0;
static rx_desc_t* rx_ring = 0;
static tx_desc_t* tx_ring = 0;
static u8* rx_bufs[RX_RING_SIZE];
static u8* tx_bufs[TX_RING_SIZE];
static u32 rx_tail = 0;
static u32 tx_tail = 0;
static int dev_ok = 0;
static u8 mac[6];
static pci_dev_t pdev;

static void* dma_alloc(u32 size) {
    u8* raw = (u8*)kmalloc(size + 16);
    if (!raw) return 0;
    u32 aligned = ((u32)raw + 15u) & ~15u;
    return (void*)aligned;
}

static u32 reg_read(u32 offset) { return mmio[offset / 4]; }
static void reg_write(u32 offset, u32 val) { mmio[offset / 4] = val; }

static int known_device(u16 vendor, u16 device) {
    if (vendor != 0x8086) return 0;
    switch (device) {
        case 0x100E: case 0x100F: case 0x1004: case 0x1019:
        case 0x101E: case 0x1010: case 0x1011: case 0x1012:
        case 0x1026: case 0x1027: case 0x1028:
        case 0x153A: case 0x153B:
        case 0x1559: case 0x155A: case 0x15A0: case 0x15A1: case 0x15A2: case 0x15A3:
        case 0x15B7: case 0x15B8: case 0x15B9:
        case 0x15D6: case 0x15D7: case 0x15D8:
        case 0x15E3:
        case 0x0D4E: case 0x0D4F: case 0x0D4C: case 0x0D4D:
        case 0x15F2: case 0x15F3:
        case 0x125B: case 0x125C: case 0x125D:
        case 0x15FD: case 0x15FC:
            return 1;
        default:
            return 0;
    }
}

static void read_mac(void) {
    u32 lo = reg_read(REG_RAL0);
    u32 hi = reg_read(REG_RAH0);
    if (lo != 0 || (hi & 0xFFFF) != 0) {
        mac[0] = (u8)(lo & 0xFF);
        mac[1] = (u8)((lo >> 8) & 0xFF);
        mac[2] = (u8)((lo >> 16) & 0xFF);
        mac[3] = (u8)((lo >> 24) & 0xFF);
        mac[4] = (u8)(hi & 0xFF);
        mac[5] = (u8)((hi >> 8) & 0xFF);
        return;
    }
    mac[0] = 0x52; mac[1] = 0x54; mac[2] = 0x00;
    mac[3] = 0x12; mac[4] = 0x34; mac[5] = 0x56;
}

int e1000_init(void) {
    dev_ok = 0;
    pci_dev_t found;
    int hit = 0;
    static const u16 ids[] = {
        0x100E, 0x100F, 0x1004, 0x1019, 0x101E, 0x1010, 0x1011, 0x1012, 0x1026, 0x1027, 0x1028,
        0x153A, 0x153B,
        0x1559, 0x155A, 0x15A0, 0x15A1, 0x15A2, 0x15A3,
        0x15B7, 0x15B8, 0x15B9,
        0x15D6, 0x15D7, 0x15D8, 0x15E3,
        0x0D4E, 0x0D4F, 0x0D4C, 0x0D4D,
        0x15F2, 0x15F3,
        0x125B, 0x125C, 0x125D,
        0x15FD, 0x15FC,
    };
    for (u32 i = 0; i < sizeof(ids) / sizeof(ids[0]); i++) {
        if (pci_find_device(0x8086, ids[i], &found)) { hit = 1; break; }
    }
    if (!hit) return 0;
    pdev = found;
    if (!known_device(pdev.vendor_id, pdev.device_id)) return 0;

    pci_enable_bus_master(&pdev);

    u32 bar0 = pdev.bar[0];
    if (bar0 & 0x1) return 0;
    bar0 &= 0xFFFFFFF0u;
    mmio = (volatile u32*)bar0;

    u16 devid = pdev.device_id;
    int is_modern = (devid == 0x153A || devid == 0x153B ||
                     devid == 0x15A0 || devid == 0x15A1 || devid == 0x15A2 || devid == 0x15A3 ||
                     devid == 0x15B7 || devid == 0x15B8 || devid == 0x15B9 ||
                     devid == 0x15D6 || devid == 0x15D7 || devid == 0x15D8 ||
                     devid == 0x0D4C || devid == 0x0D4D || devid == 0x0D4E || devid == 0x0D4F ||
                     devid == 0x15E3 || devid == 0x15F2 || devid == 0x15F3 ||
                     devid == 0x125B || devid == 0x125C || devid == 0x125D ||
                     devid == 0x15FD || devid == 0x15FC);

    if (is_modern) {
        u32 ctrl_ext = reg_read(0x0018);
        reg_write(0x0018, ctrl_ext | 0x10000000u);
        for (volatile int i = 0; i < 500000; i++) { }
    }

    reg_write(REG_IMC, 0xFFFFFFFFu);
    reg_write(REG_CTRL, reg_read(REG_CTRL) | CTRL_RST);
    for (volatile int i = 0; i < 2000000; i++) { }
    reg_write(REG_IMC, 0xFFFFFFFFu);

    if (is_modern) {
        u32 ctrl_ext = reg_read(0x0018);
        reg_write(0x0018, ctrl_ext | 0x10000000u);
    }

    u32 ctrl = reg_read(REG_CTRL);
    ctrl |= CTRL_SLU | CTRL_ASDE;
    ctrl &= ~(0x00000300u | 0x00000C00u);
    reg_write(REG_CTRL, ctrl);

    for (volatile int i = 0; i < 500000; i++) { }

    read_mac();

    rx_ring = (rx_desc_t*)dma_alloc(sizeof(rx_desc_t) * RX_RING_SIZE);
    tx_ring = (tx_desc_t*)dma_alloc(sizeof(tx_desc_t) * TX_RING_SIZE);
    if (!rx_ring || !tx_ring) return 0;
    memset(rx_ring, 0, sizeof(rx_desc_t) * RX_RING_SIZE);
    memset(tx_ring, 0, sizeof(tx_desc_t) * TX_RING_SIZE);

    for (u32 i = 0; i < RX_RING_SIZE; i++) {
        rx_bufs[i] = (u8*)dma_alloc(PKT_BUF_SIZE);
        rx_ring[i].addr = (u64)(u32)rx_bufs[i];
        rx_ring[i].status = 0;
    }
    for (u32 i = 0; i < TX_RING_SIZE; i++) {
        tx_bufs[i] = (u8*)dma_alloc(PKT_BUF_SIZE);
        tx_ring[i].addr = (u64)(u32)tx_bufs[i];
        tx_ring[i].status = 0x1;
        tx_ring[i].cmd = 0;
    }

    reg_write(REG_RDBAL, (u32)rx_ring);
    reg_write(REG_RDBAH, 0);
    reg_write(REG_RDLEN, sizeof(rx_desc_t) * RX_RING_SIZE);
    reg_write(REG_RDH, 0);
    reg_write(REG_RDT, RX_RING_SIZE - 1);
    rx_tail = RX_RING_SIZE - 1;
    reg_write(REG_RCTL, RCTL_EN | RCTL_SBP | RCTL_UPE | RCTL_MPE | RCTL_BAM | RCTL_BSIZE_2048 | RCTL_SECRC);

    reg_write(REG_TDBAL, (u32)tx_ring);
    reg_write(REG_TDBAH, 0);
    reg_write(REG_TDLEN, sizeof(tx_desc_t) * TX_RING_SIZE);
    reg_write(REG_TDH, 0);
    reg_write(REG_TDT, 0);
    tx_tail = 0;
    reg_write(REG_TCTL, TCTL_EN | TCTL_PSP | (15u << TCTL_CT_SHIFT) | (64u << TCTL_COLD_SHIFT));
    reg_write(REG_TIPG, 0x0060200Au);

    dev_ok = 1;
    return 1;
}

int e1000_available(void) { return dev_ok; }

void e1000_get_mac(u8 out[6]) {
    for (int i = 0; i < 6; i++) out[i] = mac[i];
}

const char* e1000_card_name(void) { return "Intel e1000 (emulated/compatible)"; }

int e1000_send(const u8* data, u32 len) {
    if (!dev_ok) return 0;
    if (len > PKT_BUF_SIZE) len = PKT_BUF_SIZE;

    u32 idx = tx_tail;
    if (!(tx_ring[idx].status & 0x1)) return 0;

    memcpy(tx_bufs[idx], data, len);
    tx_ring[idx].length = (u16)len;
    tx_ring[idx].cso = 0;
    tx_ring[idx].cmd = 0x0B;
    tx_ring[idx].status = 0;
    tx_ring[idx].css = 0;
    tx_ring[idx].special = 0;

    tx_tail = (tx_tail + 1) % TX_RING_SIZE;
    reg_write(REG_TDT, tx_tail);

    u32 spins = 0;
    while (!(tx_ring[idx].status & 0x1) && spins < 200000) spins++;
    return 1;
}

int e1000_poll_recv(u8* buf, u32 bufsize) {
    if (!dev_ok) return 0;
    u32 idx = (rx_tail + 1) % RX_RING_SIZE;
    if (!(rx_ring[idx].status & 0x1)) return 0;

    u32 len = rx_ring[idx].length;
    if (len > bufsize) len = bufsize;
    memcpy(buf, rx_bufs[idx], len);

    rx_ring[idx].status = 0;
    rx_tail = idx;
    reg_write(REG_RDT, rx_tail);
    return (int)len;
}
