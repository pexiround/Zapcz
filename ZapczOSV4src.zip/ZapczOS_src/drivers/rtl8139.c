#include "rtl8139.h"
#include "pci.h"
#include "io.h"

#define RTL_VENDOR 0x10EC
#define RTL_DEVICE 0x8139

#define R_IDR0    0x00
#define R_TSD0    0x10
#define R_TSAD0   0x20
#define R_RBSTART 0x30
#define R_CMD     0x37
#define R_CAPR    0x38
#define R_IMR     0x3C
#define R_ISR     0x3E
#define R_RCR     0x44
#define R_CONFIG1 0x52

#define CMD_RST  0x10
#define CMD_RE   0x08
#define CMD_TE   0x04
#define CMD_BUFE 0x01

#define RX_BUF_SIZE 8192

static u8 rx_buf[RX_BUF_SIZE + 16 + 1500] __attribute__((aligned(16)));
static u8 tx_buf[4][2048] __attribute__((aligned(16)));

static u16 io_base = 0;
static int rtl_ok = 0;
static u8  rtl_mac[6];
static u32 rx_offset = 0;
static int tx_cur = 0;

int rtl8139_init(void) {
    pci_dev_t dev;
    if (!pci_find_device(RTL_VENDOR, RTL_DEVICE, &dev)) return 0;
    pci_enable_bus_master(&dev);
    io_base = (u16)(dev.bar[0] & ~0x3u);
    if (!io_base) return 0;

    outb(io_base + R_CONFIG1, 0x00);              /* power on */
    outb(io_base + R_CMD, CMD_RST);               /* soft reset */
    for (int i = 0; i < 1000000; i++) { if (!(inb(io_base + R_CMD) & CMD_RST)) break; }

    for (int i = 0; i < 6; i++) rtl_mac[i] = inb(io_base + R_IDR0 + i);

    outl(io_base + R_RBSTART, (u32)rx_buf);       /* rx ring physical addr */
    outw(io_base + R_IMR, 0x0005);                /* ROK | TOK */
    outl(io_base + R_RCR, 0xfu | (1u << 7));      /* AB|AM|APM|AAP + WRAP */
    outb(io_base + R_CMD, CMD_RE | CMD_TE);       /* enable rx + tx */

    rx_offset = 0; tx_cur = 0; rtl_ok = 1;
    return 1;
}

int rtl8139_available(void) { return rtl_ok; }
void rtl8139_get_mac(u8 out[6]) { for (int i = 0; i < 6; i++) out[i] = rtl_mac[i]; }
const char* rtl8139_card_name(void) { return "RTL8139"; }

int rtl8139_send(const u8* data, u32 len) {
    if (!rtl_ok) return 0;
    if (len > 1792) len = 1792;
    u8* b = tx_buf[tx_cur];
    for (u32 i = 0; i < len; i++) b[i] = data[i];
    if (len < 60) { for (u32 i = len; i < 60; i++) b[i] = 0; len = 60; }
    outl(io_base + R_TSAD0 + tx_cur * 4, (u32)b);
    outl(io_base + R_TSD0 + tx_cur * 4, len);     /* clears OWN -> starts DMA */
    tx_cur = (tx_cur + 1) & 3;
    return 1;
}

int rtl8139_poll_recv(u8* buf, u32 bufsize) {
    if (!rtl_ok) return 0;
    if (inb(io_base + R_CMD) & CMD_BUFE) return 0; /* rx empty */
    u16 isr = inw(io_base + R_ISR);
    outw(io_base + R_ISR, isr);                    /* ack */

    u8* rx = rx_buf + rx_offset;
    u16 length = (u16)(rx[2] | (rx[3] << 8));      /* frame + 4 CRC */
    if (length < 4 || length > 1600) { rx_offset = 0; outw(io_base + R_CAPR, (u16)(0 - 16)); return 0; }

    u32 plen = (u32)length - 4;
    if (plen > bufsize) plen = bufsize;
    for (u32 i = 0; i < plen; i++) buf[i] = rx[4 + i];

    rx_offset = (rx_offset + length + 4 + 3) & ~3u; /* skip header + dword-align */
    rx_offset %= RX_BUF_SIZE;
    outw(io_base + R_CAPR, (u16)(rx_offset - 16));
    return (int)plen;
}
