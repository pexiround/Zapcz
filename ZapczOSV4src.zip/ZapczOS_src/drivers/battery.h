#ifndef BATTERY_H
#define BATTERY_H
#include "io.h"

typedef struct {
    int present;
    int ac_online;
    int charging;
    int percent;
} battery_status_t;

void battery_init(void);
void battery_read(battery_status_t* out);

#endif
