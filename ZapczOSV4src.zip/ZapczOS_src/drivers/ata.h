#ifndef ATA_H
#define ATA_H
#include "io.h"

int  ata_detect(void);
int  ata_identify(char* model_out, u32 model_buf_size, u32* sectors_out);
int  ata_read_sector(u32 lba, u8* buf512);
int  ata_write_sector(u32 lba, const u8* buf512);
int  ata_read_sectors(u32 lba, u32 count, u8* buf);
int  ata_write_sectors(u32 lba, u32 count, const u8* buf);

#define ATA_MAX_DRIVES 4

int  ata_scan_all(void);
int  ata_drive_present(int idx);
int  ata_drive_is_atapi(int idx);
const char* ata_drive_model(int idx);
u32  ata_drive_sectors(int idx);
int  ata_drive_read_sectors(int idx, u32 lba, u32 count, u8* buf);
int  ata_drive_write_sectors(int idx, u32 lba, u32 count, const u8* buf);
int  ata_drive_flush(int idx);

#endif
