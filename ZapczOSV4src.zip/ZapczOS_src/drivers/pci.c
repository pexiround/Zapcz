#include "pci.h"
#include "io.h"

#define PCI_CONFIG_ADDR 0xCF8
#define PCI_CONFIG_DATA 0xCFC

u32 pci_read32(u8 bus, u8 dev, u8 func, u8 offset) {
    u32 addr = 0x80000000u | ((u32)bus << 16) | ((u32)dev << 11) | ((u32)func << 8) | (offset & 0xFC);
    outl(PCI_CONFIG_ADDR, addr);
    return inl(PCI_CONFIG_DATA);
}
u16 pci_read16(u8 bus, u8 dev, u8 func, u8 offset) {
    u32 v = pci_read32(bus, dev, func, (u8)(offset & 0xFC));
    return (u16)((v >> ((offset & 2) * 8)) & 0xFFFF);
}
u8 pci_read8(u8 bus, u8 dev, u8 func, u8 offset) {
    u32 v = pci_read32(bus, dev, func, (u8)(offset & 0xFC));
    return (u8)((v >> ((offset & 3) * 8)) & 0xFF);
}
void pci_write16(u8 bus, u8 dev, u8 func, u8 offset, u16 val) {
    u32 addr = 0x80000000u | ((u32)bus << 16) | ((u32)dev << 11) | ((u32)func << 8) | (offset & 0xFC);
    outl(PCI_CONFIG_ADDR, addr);
    u32 v = inl(PCI_CONFIG_DATA);
    int shift = (offset & 2) * 8;
    v = (v & ~(0xFFFFu << shift)) | ((u32)val << shift);
    outl(PCI_CONFIG_DATA, v);
}

#define PCI_CACHE_MAX 64
static pci_dev_t pci_cache[PCI_CACHE_MAX];
static int pci_cache_count = 0;
static int pci_scanned = 0;

static void scan_one(u8 bus, u8 dev, u8 func, pci_dev_t* out) {
    out->bus = bus; out->dev = dev; out->func = func;
    out->vendor_id  = pci_read16(bus, dev, func, 0x00);
    out->device_id  = pci_read16(bus, dev, func, 0x02);
    u32 cr = pci_read32(bus, dev, func, 0x08);
    out->class_code = (u8)(cr >> 24);
    out->subclass   = (u8)(cr >> 16);
    for (int i = 0; i < 6; i++)
        out->bar[i] = pci_read32(bus, dev, func, (u8)(0x10 + i * 4));
}

static void pci_scan_all(void) {
    if (pci_scanned) return;
    pci_scanned = 1;
    pci_cache_count = 0;
    for (u32 bus = 0; bus < 256; bus++) {
        for (u32 dev = 0; dev < 32; dev++) {
            u16 vendor = pci_read16((u8)bus, (u8)dev, 0, 0x00);
            if (vendor == 0xFFFF) continue;
            u8 header = pci_read8((u8)bus, (u8)dev, 0, 0x0E);
            int nfuncs = (header & 0x80) ? 8 : 1;
            for (int func = 0; func < nfuncs; func++) {
                if (pci_cache_count >= PCI_CACHE_MAX) return;
                pci_dev_t d;
                scan_one((u8)bus, (u8)dev, (u8)func, &d);
                if (d.vendor_id == 0xFFFF) continue;
                pci_cache[pci_cache_count++] = d;
            }
        }
    }
}

int pci_find_device(u16 vendor_id, u16 device_id, pci_dev_t* out) {
    pci_scan_all();
    for (int i = 0; i < pci_cache_count; i++) {
        if (pci_cache[i].vendor_id == vendor_id && pci_cache[i].device_id == device_id) {
            *out = pci_cache[i];
            return 1;
        }
    }
    return 0;
}

int pci_find_class(u8 class_code, u8 subclass, pci_dev_t* out) {
    pci_scan_all();
    for (int i = 0; i < pci_cache_count; i++) {
        if (pci_cache[i].class_code == class_code && pci_cache[i].subclass == subclass) {
            *out = pci_cache[i];
            return 1;
        }
    }
    return 0;
}

void pci_enable_bus_master(const pci_dev_t* d) {
    u16 cmd = pci_read16(d->bus, d->dev, d->func, 0x04);
    cmd |= 0x0006u;
    pci_write16(d->bus, d->dev, d->func, 0x04, cmd);
}
