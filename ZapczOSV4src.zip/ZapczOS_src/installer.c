#include "installer.h"
#include "apps.h"
#include "ata.h"
#include "fat32.h"
#include "util.h"
#include "libc_shim.h"
#include "mm.h"
#include "kernel.h"

#define ISO_BUF_SIZE (6 * 1024 * 1024)
static u8* iso_buf = 0;
static u8* write_src = 0;

static int active = 0;
static u32 total_sectors = 0;
static u32 cur_sector = 0;
static int last_pct = -1;
static int target_drive_idx = 0;
static u32 target_lba_offset = 0;   /* start LBA: 0 = whole disk, else partition start */

/* partition table state (defined early: the install path needs it) */
#define MAX_PARTS 16          /* 4 primaries + logical partitions */
typedef struct {
    int used;
    u8  type;
    u32 lba_start;            /* absolute LBA of the partition's first sector */
    u32 sectors;
    int bootable;
    int number;               /* Linux-style: primaries 1-4, logicals 5+ */
    int logical;
} part_t;
static part_t parts[MAX_PARTS];
static int part_count = 0;
static int part_selected = -1;
static char gui_status[64] = "";

static int drive_selected;
static void part_name(int idx, int p, char* out, u32 outlen);

static void split3(const char* args, char* a, u32 alen, char* b, u32 blen, char* c, u32 clen) {
    a[0] = 0; b[0] = 0; c[0] = 0;
    while (*args == ' ') args++;
    u32 p = 0;
    while (*args && *args != ' ' && p + 1 < alen) a[p++] = *args++;
    a[p] = 0;
    while (*args == ' ') args++;
    p = 0;
    while (*args && *args != ' ' && p + 1 < blen) b[p++] = *args++;
    b[p] = 0;
    while (*args == ' ') args++;
    p = 0;
    while (*args && *args != ' ' && p + 1 < clen) c[p++] = *args++;
    c[p] = 0;
}

static void format_disk_size(u32 sectors, char* out, u32 outlen) {
    u32 kb = sectors / 2;
    if (kb < 1024) {
        u32_to_str(kb, out);
        str_cat(out, " KB", outlen);
    } else if (kb < 1024u * 1024u) {
        u32_to_str(kb / 1024, out);
        str_cat(out, " MB", outlen);
    } else {
        u32_to_str(kb / (1024u * 1024u), out);
        str_cat(out, " GB", outlen);
    }
}

static int drive_letter_to_index(const char* target) {
    if (str_len(target) != 8) return -1;
    if (target[0] != '/' || target[1] != 'd' || target[2] != 'e' || target[3] != 'v' || target[4] != '/') return -1;
    char c0 = target[5], c1 = target[6], c2 = target[7];
    if ((c0 != 's' && c0 != 'S') || (c1 != 'd' && c1 != 'D')) return -1;
    char letter = (c2 >= 'A' && c2 <= 'Z') ? (char)(c2 - 'A' + 'a') : c2;
    if (letter < 'a' || letter > ('a' + ATA_MAX_DRIVES - 1)) return -1;
    return letter - 'a';
}

static void drive_name(int idx, char* out, u32 outlen) {
    str_copy(out, "/dev/sd", outlen);
    char letter[2] = { (char)('a' + idx), 0 };
    str_cat(out, letter, outlen);
}

void installer_cmd_disklist(void) {
    ata_scan_all();
    term_print("NAME       TYPE   SIZE        MODEL");
    int any = 0;
    for (int i = 0; i < ATA_MAX_DRIVES; i++) {
        if (!ata_drive_present(i)) continue;
        any = 1;
        char line[100];
        char name[12]; drive_name(i, name, sizeof(name));
        str_copy(line, name, 100);
        while (str_len(line) < 11) str_cat(line, " ", 100);
        if (ata_drive_is_atapi(i)) {
            str_cat(line, "CD/DVD ", 100);
            str_cat(line, "n/a         ", 100);
        } else {
            str_cat(line, "HDD    ", 100);
            char sz[32]; format_disk_size(ata_drive_sectors(i), sz, sizeof(sz));
            str_cat(line, sz, 100);
            u32 padded = str_len(sz);
            while (padded < 12) { str_cat(line, " ", 100); padded++; }
        }
        str_cat(line, ata_drive_model(i), 100);
        if (i == 0) str_cat(line, "  (this OS's own boot/live disk)", 100);
        term_print(line);
    }
    if (!any) term_print("(no disks detected on the primary or secondary ATA channels)");
    term_print("");
    term_print("note: this driver covers the primary+secondary IDE/ATA buses");
    term_print("(master+slave each) in PIO mode only -- no AHCI/SATA-native,");
    term_print("NVMe, or USB storage. CD/DVD (ATAPI) drives are listed but");
    term_print("can't be used as an install target.");
}

void installer_cmd_install(const char* args) {
    char target[32], iso_name[32], confirm[16];
    split3(args, target, sizeof(target), iso_name, sizeof(iso_name), confirm, sizeof(confirm));

    if (target[0] == 0 || iso_name[0] == 0) {
        term_print("usage: install-os /dev/sdX <isofile> [confirm]  (X = a..d)");
        return;
    }
    int idx = drive_letter_to_index(target);
    if (idx < 0) {
        term_print("unknown target -- run 'disklist' and use a name shown there");
        return;
    }
    if (active) {
        term_print("an install is already in progress");
        return;
    }
    if (!fat32_persistent()) {
        term_print("no real filesystem mounted -- nothing to read the image from.");
        term_print("the source .img/.iso needs to be on a real IDE/SATA disk this");
        term_print("driver can see (a live/Ventoy boot has no mounted disk by default --");
        term_print("attach a second drive with the image on it, or use the .img boot path).");
        return;
    }

    ata_scan_all();
    if (!ata_drive_present(idx)) {
        term_print("no disk detected at that target -- run 'disklist' to check again");
        return;
    }
    if (ata_drive_is_atapi(idx)) {
        term_print("that target is a CD/DVD (ATAPI) drive -- can't write an install there");
        return;
    }

    fat_dirent_t ents[32];
    int n = fat32_list_root(ents, 32);
    const fat_dirent_t* found = 0;
    for (int i = 0; i < n; i++) if (str_eq_ci(ents[i].display_name, iso_name)) { found = &ents[i]; break; }
    if (!found) {
        term_print("image file not found on disk -- check the name with 'ls'");
        return;
    }
    if (found->size > ISO_BUF_SIZE) {
        term_print("image file is too large for this installer to handle");
        return;
    }

    int confirmed = str_eq_ci(confirm, "confirm");
    char tname[12]; drive_name(idx, tname, sizeof(tname));

    if (!confirmed) {
        term_print("=== install-os: read this before continuing ===");
        char line[80];
        str_copy(line, "Target disk:  ", 80); str_cat(line, tname, 80);
        str_cat(line, "  (", 80); str_cat(line, ata_drive_model(idx), 80); str_cat(line, ")", 80);
        term_print(line);
        if (idx == 0) term_print("              -- this is the same disk this OS booted from");
        char sz[32];
        str_copy(line, "Target size:  ", 80); format_disk_size(ata_drive_sectors(idx), sz, sizeof(sz)); str_cat(line, sz, 80);
        term_print(line);
        str_copy(line, "Image file:   ", 80); str_cat(line, found->display_name, 80);
        term_print(line);
        str_copy(line, "Image size:   ", 80); u32_to_kb_str(found->size, sz); str_cat(line, sz, 80);
        term_print(line);
        term_print("");
        char line2[100];
        str_copy(line2, "This will overwrite ", 100); str_cat(line2, tname, 100);
        str_cat(line2, "'s boot sectors with the image,", 100);
        term_print(line2);
        term_print("starting at sector 0. EVERYTHING currently on that disk will be");
        term_print("PERMANENTLY LOST, with no undo. Only do this if you mean it.");
        term_print("");
        term_print("To proceed, run this exact command again with confirm added:");
        char cmdline[80] = "  install-os ";
        str_cat(cmdline, target, 80); str_cat(cmdline, " ", 80);
        str_cat(cmdline, iso_name, 80); str_cat(cmdline, " confirm", 80);
        term_print(cmdline);
        return;
    }

    if (!iso_buf) iso_buf = (u8*)kmalloc(ISO_BUF_SIZE);
    if (!iso_buf) {
        term_print("out of memory -- can't allocate a buffer for the image");
        return;
    }

    int len = fat32_read_file(found, iso_buf, ISO_BUF_SIZE);
    if (len <= 0) {
        term_print("failed to read the image file -- aborting, nothing was written");
        return;
    }

    target_drive_idx = idx;
    if (part_selected >= 0 && parts[part_selected].used && idx == drive_selected) {
        u32 need = ((u32)len + 511) / 512;
        if (need > parts[part_selected].sectors) {
            term_print("that image is larger than the selected partition -- nothing written");
            str_copy(gui_status, "Image is larger than that partition", sizeof(gui_status));
            return;
        }
        target_lba_offset = parts[part_selected].lba_start;
        char pmsg[80];
        char pn[16];
        part_name(idx, part_selected, pn, sizeof(pn));
        str_copy(pmsg, "target partition: ", sizeof(pmsg));
        str_cat(pmsg, pn, sizeof(pmsg));
        str_cat(pmsg, " -- other partitions untouched", sizeof(pmsg));
        term_print(pmsg);
    } else {
        target_lba_offset = 0;
        term_print("target: WHOLE DISK -- every partition on it is being replaced");
    }
    write_src = iso_buf;
    total_sectors = ((u32)len + 511) / 512;
    cur_sector = 0;
    last_pct = -1;
    active = 1;
    term_print("=== starting install -- do not power off ===");
}

int installer_bundled_image_available(void) {
    return kernel_get_install_img_buf() != 0 && kernel_get_install_img_size() >= 1024;
}

u32 installer_bundled_image_size(void) {
    return kernel_get_install_img_size();
}

void installer_start_bundled_install(int idx) {
    if (idx < 0 || !ata_drive_present(idx) || ata_drive_is_atapi(idx)) return;
    u8* buf = kernel_get_install_img_buf();
    u32 size = kernel_get_install_img_size();
    if (!buf || size < 1024) return;

    target_drive_idx = idx;
    if (part_selected >= 0 && parts[part_selected].used) {
        target_lba_offset = parts[part_selected].lba_start;
        u32 need = (size + 511) / 512;
        if (need > parts[part_selected].sectors) {
            str_copy(gui_status, "Image is larger than that partition", sizeof(gui_status));
            return;
        }
    } else {
        target_lba_offset = 0;
    }
    write_src = buf;
    total_sectors = (size + 511) / 512;
    cur_sector = 0;
    last_pct = -1;
    active = 1;
}

int installer_active(void) { return active; }

void installer_tick(void) {
    if (!active) return;

    u32 chunk = total_sectors - cur_sector;
    if (chunk > 128) chunk = 128;

    if (!ata_drive_write_sectors(target_drive_idx, target_lba_offset + cur_sector, chunk, write_src + (u32)cur_sector * 512)) {
        term_print("write failed -- the target disk may now be in a bad state");
        active = 0;
        return;
    }
    cur_sector += chunk;

    int pct = (int)(cur_sector * 100 / total_sectors);
    if (pct >= last_pct + 10 || cur_sector >= total_sectors) {
        char line[32] = "writing: ";
        char n[12]; u32_to_str((u32)pct, n);
        str_cat(line, n, 32); str_cat(line, "%", 32);
        term_print(line);
        last_pct = pct - (pct % 10);
    }

    if (cur_sector >= total_sectors) {
        char done[80] = "=== install complete -- you can now boot from ";
        char tname[12]; drive_name(target_drive_idx, tname, sizeof(tname));
        str_cat(done, tname, 80); str_cat(done, " ===", 80);
        term_print(done);
        active = 0;
    }
}

#include "desktop.h"
#include "graphics.h"
#include "theme.h"
#include "keyboard.h"
#include "pit.h"

#define CANDIDATES_MAX 16
static fat_dirent_t candidates[CANDIDATES_MAX];
static int candidates_count = 0;
static int candidate_selected = -1;

static int drive_selected = -1;
static char confirm_text[16] = "";
static u32 confirm_len = 0;

static int name_has_img_or_iso(const char* name) {
    u32 n = str_len(name);
    if (n >= 4 && name[n-4] == '.') {
        char a = name[n-3], b = name[n-2], c = name[n-1];
        if ((a=='I'||a=='i') && (b=='M'||b=='m') && (c=='G'||c=='g')) return 1;
        if ((a=='I'||a=='i') && (b=='S'||b=='s') && (c=='O'||c=='o')) return 1;
    }
    return 0;
}

static void rescan_candidates(void) {
    candidates_count = 0;
    candidate_selected = -1;
    if (!fat32_available()) return;
    fat_dirent_t ents[32];
    int n = fat32_list_root(ents, 32);
    for (int i = 0; i < n && candidates_count < CANDIDATES_MAX; i++) {
        if (name_has_img_or_iso(ents[i].display_name)) {
            candidates[candidates_count++] = ents[i];
        }
    }
}

static void rescan_drives(void) {
    drive_selected = -1;
    ata_scan_all();
    for (int i = 1; i < ATA_MAX_DRIVES; i++) {
        if (ata_drive_present(i) && !ata_drive_is_atapi(i)) { drive_selected = i; break; }
    }
    if (drive_selected < 0 && ata_drive_present(0)) drive_selected = 0;
}


/* ---- MBR partition table helpers ---- */
static const char* part_type_name(u8 t) {
    switch (t) {
        case 0x00: return "empty";
        case 0x05: case 0x0F: return "extended";
        case 0x07: return "NTFS/exFAT";
        case 0x0B: case 0x0C: return "FAT32";
        case 0x06: case 0x0E: return "FAT16";
        case 0x83: return "Linux";
        case 0x82: return "Linux swap";
        case 0xEF: return "EFI System";
        case 0xEE: return "GPT protective";
        default:   return "unknown";
    }
}

/* Build "/dev/sdaN" for partition index p (0-based) on drive idx. */
static void part_name(int idx, int p, char* out, u32 outlen) {
    drive_name(idx, out, outlen);
    int num = (p >= 0 && p < MAX_PARTS && parts[p].used) ? parts[p].number : (p + 1);
    char n[8];
    if (num >= 10) { n[0] = (char)('0' + num / 10); n[1] = (char)('0' + num % 10); n[2] = 0; }
    else { n[0] = (char)('0' + num); n[1] = 0; }
    str_cat(out, n, outlen);
}

static u8 part_type_of(const u8* e) { return e[4]; }
static u32 part_lba_of(const u8* e) {
    return (u32)e[8] | ((u32)e[9] << 8) | ((u32)e[10] << 16) | ((u32)e[11] << 24);
}
static u32 part_cnt_of(const u8* e) {
    return (u32)e[12] | ((u32)e[13] << 8) | ((u32)e[14] << 16) | ((u32)e[15] << 24);
}
static int type_is_extended(u8 t) { return t == 0x05 || t == 0x0F || t == 0x85; }

/* Read the MBR plus, for any extended partition, walk the EBR chain so that
   logical partitions (/dev/sda5, /dev/sda6, ...) are discovered too. */
static void rescan_partitions(void) {
    part_count = 0;
    part_selected = -1;
    for (int i = 0; i < MAX_PARTS; i++) parts[i].used = 0;
    if (drive_selected < 0 || !ata_drive_present(drive_selected)) return;
    if (ata_drive_is_atapi(drive_selected)) return;

    u8 sec[512];
    if (!ata_drive_read_sectors(drive_selected, 0, 1, sec)) return;
    if (sec[510] != 0x55 || sec[511] != 0xAA) return;

    u32 ext_base = 0;
    int slot = 0;

    /* primaries keep their slot number: 1..4 */
    for (int i = 0; i < 4; i++) {
        const u8* e = sec + 446 + i * 16;
        u8 type = part_type_of(e);
        u32 lba = part_lba_of(e);
        u32 cnt = part_cnt_of(e);
        if (type == 0 || cnt == 0) continue;
        if (type_is_extended(type) && ext_base == 0) ext_base = lba;
        parts[slot].used = 1;
        parts[slot].type = type;
        parts[slot].lba_start = lba;
        parts[slot].sectors = cnt;
        parts[slot].bootable = (e[0] == 0x80);
        parts[slot].number = i + 1;
        parts[slot].logical = 0;
        slot++; part_count++;
    }

    if (ext_base == 0) return;

    /* logical partitions start numbering at 5 regardless of primary count */
    u32 ebr = ext_base;
    int number = 5;
    int guard = 0;
    while (ebr && slot < MAX_PARTS && guard++ < 32) {
        if (!ata_drive_read_sectors(drive_selected, ebr, 1, sec)) break;
        if (sec[510] != 0x55 || sec[511] != 0xAA) break;

        const u8* e0 = sec + 446;          /* the logical partition itself */
        const u8* e1 = sec + 446 + 16;     /* link to the next EBR */

        u8 t0 = part_type_of(e0);
        u32 c0 = part_cnt_of(e0);
        if (t0 != 0 && c0 != 0) {
            parts[slot].used = 1;
            parts[slot].type = t0;
            /* logical starts are relative to this EBR */
            parts[slot].lba_start = ebr + part_lba_of(e0);
            parts[slot].sectors = c0;
            parts[slot].bootable = (e0[0] == 0x80);
            parts[slot].number = number++;
            parts[slot].logical = 1;
            slot++; part_count++;
        }

        u32 next = part_lba_of(e1);
        if (part_cnt_of(e1) == 0 || next == 0) break;
        /* next EBR offset is relative to the extended partition base */
        ebr = ext_base + next;
    }
}

void installer_init(void) {
    confirm_text[0] = 0;
    confirm_len = 0;
    gui_status[0] = 0;
    rescan_candidates();
    rescan_drives();
    rescan_partitions();
}

#define DRIVE_LIST_Y 40
#define DRIVE_ROW_H 24
#define DRIVE_ROWS_MAX 3

#define PART_LIST_Y (DRIVE_LIST_Y + DRIVE_ROWS_MAX * DRIVE_ROW_H + 22)
#define PART_ROW_H 22
#define PART_ROWS_VISIBLE 6
#define PART_ROWS_TOTAL (PART_ROWS_VISIBLE + 1)

#define FILE_LIST_LABEL_Y (PART_LIST_Y + PART_ROWS_TOTAL * PART_ROW_H + 22)
#define FILE_LIST_Y (FILE_LIST_LABEL_Y + 20)
#define FILE_ROW_H 20
#define FILE_ROWS_MAX 2

void app_installer_draw(i32 x, i32 y, i32 w, i32 h) {
    (void)h;
    gfx_string(x + 16, y + 12, "Install ZapczOS to a Hard Drive", THEME_TEXT, THEME_PANEL, 0);

    gfx_string(x + 16, y + DRIVE_LIST_Y - 18, "Step 1: choose a target disk", THEME_TEXT_DIM, THEME_PANEL, 0);
    ui_button(x + w - 96, y + DRIVE_LIST_Y - 22, 80, 20, "Rescan", 0);

    int any_drive = 0;
    for (int i = 0; i < ATA_MAX_DRIVES && i < DRIVE_ROWS_MAX; i++) {
        i32 ry = y + DRIVE_LIST_Y + i * DRIVE_ROW_H;
        if (!ata_drive_present(i)) continue;
        any_drive = 1;
        int sel = (i == drive_selected);
        int usable = !ata_drive_is_atapi(i);
        color_t row_bg = sel ? THEME_ACCENT : THEME_PANEL_ALT;
        gfx_rounded_rect(x + 8, ry, w - 16, DRIVE_ROW_H - 2, 5, row_bg);
        color_t tc = sel ? THEME_ACCENT_TEXT : (usable ? THEME_TEXT_DIM : THEME_TEXT_FAINT);

        char line[80];
        char name[12]; drive_name(i, name, sizeof(name));
        str_copy(line, name, 80); str_cat(line, "  ", 80);
        if (usable) {
            char sz[32]; format_disk_size(ata_drive_sectors(i), sz, sizeof(sz));
            str_cat(line, sz, 80); str_cat(line, "  ", 80);
            str_cat(line, ata_drive_model(i), 80);
        } else {
            str_cat(line, "CD/DVD -- not usable as a target", 80);
        }
        gfx_string(x + 14, ry + 3, line, tc, row_bg, 0);
    }
    if (!any_drive) {
        gfx_string(x + 16, y + DRIVE_LIST_Y + 2, "(no disks detected -- click Rescan)", THEME_WARNING, THEME_PANEL, 0);
    }

    /* ---- Step 1b: mount point / partition ---- */
    {
        i32 py = y + PART_LIST_Y;
        gfx_string(x + 16, py - 18, "Step 1b: install target (partition)", THEME_TEXT_DIM, THEME_PANEL, 0);

        /* whole-disk row */
        {
            int sel = (part_selected < 0);
            color_t rb = sel ? THEME_ACCENT : THEME_PANEL_ALT;
            gfx_rounded_rect(x + 8, py, w - 16, PART_ROW_H - 2, 5, rb);
            char line[80];
            char dn[12]; drive_name(drive_selected < 0 ? 0 : drive_selected, dn, sizeof(dn));
            str_copy(line, dn, 80);
            str_cat(line, "   whole disk -- DESTROYS all partitions", 80);
            gfx_string(x + 14, py + 3, line, sel ? THEME_ACCENT_TEXT : THEME_TEXT_DIM, rb, 0);
        }

        int shown = 0;
        for (int p = 0; p < MAX_PARTS && shown < PART_ROWS_VISIBLE; p++) {
            if (!parts[p].used) continue;
            i32 ry2 = py + (shown + 1) * PART_ROW_H;
            shown++;
            int sel = (part_selected == p);
            color_t rb = sel ? THEME_ACCENT : THEME_PANEL_ALT;
            gfx_rounded_rect(x + 8, ry2, w - 16, PART_ROW_H - 2, 5, rb);
            char line[80];
            char pn[16]; part_name(drive_selected < 0 ? 0 : drive_selected, p, pn, sizeof(pn));
            str_copy(line, pn, 80); str_cat(line, "  ", 80);
            char sz[32]; format_disk_size(parts[p].sectors, sz, sizeof(sz));
            str_cat(line, sz, 80); str_cat(line, "  ", 80);
            str_cat(line, part_type_name(parts[p].type), 80);
            if (parts[p].logical) str_cat(line, "  (logical)", 80);
            if (parts[p].bootable) str_cat(line, "  *boot", 80);
            color_t ptc = sel ? THEME_ACCENT_TEXT
                        : (type_is_extended(parts[p].type) ? THEME_TEXT_FAINT : THEME_TEXT_DIM);
            gfx_string(x + 14, ry2 + 3, line, ptc, rb, 0);
        }

        if (part_count == 0) {
            gfx_string(x + 16, py + PART_ROW_H + 3,
                       "(no partition table -- whole-disk install only)",
                       THEME_TEXT_FAINT, THEME_PANEL, 0);
        }
    }

    i32 ty = y + FILE_LIST_LABEL_Y - 18;
    gfx_string(x + 16, ty, "USB boot sticks (Ventoy included) won't appear above -- IDE/SATA only.",
               THEME_TEXT_FAINT, THEME_PANEL, 0);

    gfx_string(x + 16, y + FILE_LIST_LABEL_Y, "Step 2: pick a .img or .iso already on disk to write:",
               THEME_TEXT_DIM, THEME_PANEL, 0);

    gfx_hline(x + 8, y + FILE_LIST_Y - 6, w - 16, THEME_BORDER);
    if (candidates_count == 0) {
        gfx_string(x + 16, y + FILE_LIST_Y + 2, "(no .img/.iso files found in the root directory)", THEME_TEXT_FAINT, THEME_PANEL, 0);
    }
    for (int i = 0; i < candidates_count && i < FILE_ROWS_MAX; i++) {
        i32 ry = y + FILE_LIST_Y + i * FILE_ROW_H;
        int sel = (i == candidate_selected);
        color_t row_bg = sel ? THEME_ACCENT : THEME_PANEL;
        if (sel) gfx_rounded_rect(x + 8, ry, w - 16, FILE_ROW_H - 2, 5, row_bg);
        color_t tc = sel ? THEME_ACCENT_TEXT : THEME_TEXT_DIM;
        gfx_string(x + 14, ry + 2, candidates[i].display_name, tc, row_bg, 0);
        char szbuf[24]; u32_to_kb_str(candidates[i].size, szbuf);
        gfx_string(x + w - 100, ry + 2, szbuf, tc, row_bg, 0);
    }

    i32 by = y + FILE_LIST_Y + FILE_ROWS_MAX * FILE_ROW_H + 14;
    gfx_hline(x + 8, by - 8, w - 16, THEME_BORDER);

    if (part_selected >= 0 && parts[part_selected].used) {
        char pn[16];
        part_name(drive_selected < 0 ? 0 : drive_selected, part_selected, pn, sizeof(pn));
        char l1[96];
        str_copy(l1, "Writes to ", sizeof(l1));
        str_cat(l1, pn, sizeof(l1));
        str_cat(l1, " only. Other partitions are left untouched.", sizeof(l1));
        gfx_string(x + 16, by, l1, THEME_SUCCESS, THEME_PANEL, 0);
        by += 16;
        char l2[96];
        str_copy(l2, "Everything currently on ", sizeof(l2));
        str_cat(l2, pn, sizeof(l2));
        str_cat(l2, " is lost. Type ERASE to confirm:", sizeof(l2));
        gfx_string(x + 16, by, l2, THEME_DANGER, THEME_PANEL, 0);
        by += 22;
    } else {
        gfx_string(x + 16, by, "WHOLE DISK: every partition on this disk is destroyed, including",
                   THEME_DANGER, THEME_PANEL, 0);
        by += 16;
        gfx_string(x + 16, by, "other operating systems. Pick a partition above to install safely.",
                   THEME_DANGER, THEME_PANEL, 0);
        by += 22;
    }

    color_t fbg = RGB(18,19,25);
    gfx_rounded_rect(x + 16, by, 140, 28, THEME_RADIUS_CTRL, fbg);
    gfx_rounded_rect_outline(x + 16, by, 140, 28, THEME_RADIUS_CTRL, THEME_BORDER);
    char shown[20]; str_copy(shown, confirm_text, 20);
    if ((ticks_get() / 30) % 2 == 0 && str_len(shown) < 14) str_cat(shown, "_", 20);
    gfx_string(x + 24, by + 6, shown, THEME_TEXT, fbg, 0);

    int target_ok = drive_selected >= 0 && ata_drive_present(drive_selected) && !ata_drive_is_atapi(drive_selected);
    int ready = target_ok && candidate_selected >= 0 && str_eq(confirm_text, "ERASE") && !active;
    ui_button(x + 170, by, 130, 28, "Install Now", ready);

    if (installer_bundled_image_available()) {
        char bsz[24]; u32_to_kb_str(installer_bundled_image_size(), bsz);
        char bline[64] = "Bundled ZapczOS image available (";
        str_cat(bline, bsz, 64); str_cat(bline, "):", 64);
        gfx_string(x + 16, by + 90, bline, THEME_TEXT_DIM, THEME_PANEL, 0);
        int bundled_ready = target_ok && str_eq(confirm_text, "ERASE") && !active;
        ui_button(x + 16, by + 108, 200, 28, "Install Bundled OS", bundled_ready);
    }

    if (active) {
        u32 pct = (total_sectors > 0) ? (cur_sector * 100u / total_sectors) : 0;
        gfx_string(x + 16, by + 40, "Installing -- do not power off...", THEME_WARNING, THEME_PANEL, 0);
        gfx_rounded_rect(x + 16, by + 60, w - 32, 16, 8, THEME_PANEL_ALT);
        i32 fillw = (i32)((u32)(w - 34) * pct / 100u);
        if (fillw > 0) gfx_rounded_rect(x + 17, by + 61, fillw, 14, 7, THEME_ACCENT);
    } else if (gui_status[0]) {
        gfx_string(x + 16, by + 40, gui_status, THEME_SUCCESS, THEME_PANEL, 0);
    }
}

void app_installer_click(i32 rx, i32 ry) {
    i32 w = windows[APP_INSTALLER].w;

    if (ui_point_in(rx, ry, w - 96, DRIVE_LIST_Y - 22, 80, 20)) {
        rescan_drives();
        rescan_partitions();
        gui_status[0] = 0;
        return;
    }

    if (ry >= DRIVE_LIST_Y && ry < DRIVE_LIST_Y + DRIVE_ROWS_MAX * DRIVE_ROW_H) {
        int idx = (ry - DRIVE_LIST_Y) / DRIVE_ROW_H;
        if (idx < ATA_MAX_DRIVES && ata_drive_present(idx) && !ata_drive_is_atapi(idx)) {
            drive_selected = idx;
            rescan_partitions();
            gui_status[0] = 0;
        }
        return;
    }

    if (ry >= PART_LIST_Y && ry < PART_LIST_Y + PART_ROWS_TOTAL * PART_ROW_H) {
        int row = (ry - PART_LIST_Y) / PART_ROW_H;
        if (row == 0) {
            part_selected = -1;                   /* whole disk */
        } else {
            int want = row - 1, shown = 0;
            for (int p = 0; p < MAX_PARTS; p++) {
                if (!parts[p].used) continue;
                if (shown == want) {
                    if (type_is_extended(parts[p].type))
                        str_copy(gui_status, "That is an extended container -- pick a partition inside it",
                                 sizeof(gui_status));
                    else
                        part_selected = p;
                    break;
                }
                shown++;
            }
        }
        gui_status[0] = 0;
        return;
    }

    if (ry >= FILE_LIST_Y && ry < FILE_LIST_Y + FILE_ROWS_MAX * FILE_ROW_H) {
        int idx = (ry - FILE_LIST_Y) / FILE_ROW_H;
        if (idx < candidates_count) { candidate_selected = idx; gui_status[0] = 0; }
        return;
    }

    i32 by = FILE_LIST_Y + FILE_ROWS_MAX * FILE_ROW_H + 14 + 16 + 22;
    if (ui_point_in(rx, ry, 170, by, 130, 28)) {
        if (active) return;
        int target_ok = drive_selected >= 0 && ata_drive_present(drive_selected) && !ata_drive_is_atapi(drive_selected);
        if (!target_ok) { str_copy(gui_status, "Pick a target disk first.", 64); return; }
        if (candidate_selected < 0) { str_copy(gui_status, "Pick an image file first.", 64); return; }
        if (!str_eq(confirm_text, "ERASE")) { str_copy(gui_status, "Type ERASE in the box to confirm.", 64); return; }

        char target[12]; drive_name(drive_selected, target, sizeof(target));
        char args[64]; str_copy(args, target, 64); str_cat(args, " ", 64);
        str_cat(args, candidates[candidate_selected].display_name, 64);
        str_cat(args, " confirm", 64);
        installer_cmd_install(args);
        gui_status[0] = 0;
        return;
    }

    if (installer_bundled_image_available() && ui_point_in(rx, ry, 16, by + 108, 200, 28)) {
        if (active) return;
        int target_ok = drive_selected >= 0 && ata_drive_present(drive_selected) && !ata_drive_is_atapi(drive_selected);
        if (!target_ok) { str_copy(gui_status, "Pick a target disk first.", 64); return; }
        if (!str_eq(confirm_text, "ERASE")) { str_copy(gui_status, "Type ERASE in the box to confirm.", 64); return; }
        installer_start_bundled_install(drive_selected);
        gui_status[0] = 0;
    }
}

void app_installer_key(int key) {
    if (key == KEY_BACKSPACE) {
        if (confirm_len > 0) confirm_text[--confirm_len] = 0;
    } else if (kbd_is_printable(key)) {
        if (confirm_len < sizeof(confirm_text) - 1) {
            confirm_text[confirm_len++] = (char)key;
            confirm_text[confirm_len] = 0;
        }
    }
}
