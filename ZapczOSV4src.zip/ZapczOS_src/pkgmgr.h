#ifndef PKGMGR_H
#define PKGMGR_H
#include "io.h"

void pkgmgr_cmd_list(void);
void pkgmgr_cmd_install(const char* name);
void pkgmgr_cmd_remove(const char* name);
void pkgmgr_cmd_info(const char* name);
void pkgmgr_cmd_apps(void);

#endif
