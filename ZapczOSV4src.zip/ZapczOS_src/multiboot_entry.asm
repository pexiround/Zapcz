
BITS 32
SECTION .text

MB2_MAGIC equ 0xE85250D6
MB2_ARCH  equ 0

align 8
mb2_header_start:
    dd MB2_MAGIC
    dd MB2_ARCH
    dd mb2_header_end - mb2_header_start
    dd 0x100000000 - (MB2_MAGIC + MB2_ARCH + (mb2_header_end - mb2_header_start))

;; Framebuffer request.
;;   flags bit 0 = 1 -> optional: if the loader cannot honour this exactly it
;;   still boots us instead of bailing back to the menu.
;;   width/height/depth of 0 means "no preference" -- take the mode the
;;   firmware already has. Demanding 1024x768x32 made GRUB refuse to load the
;;   kernel on machines whose GOP/VBE does not offer that exact mode.
align 8
fb_tag_start:
    dw 5
    dw 1
    dd fb_tag_end - fb_tag_start
    dd 0
    dd 0
    dd 32
fb_tag_end:

align 8
    dw 0
    dw 0
    dd 8
mb2_header_end:

extern multiboot2_entry
extern kernel_main
extern bss_start
extern bss_end

global _start
_start:
    cli
    lgdt [gdt_descriptor]
    jmp dword CODE_SEL:reload_cs
reload_cs:
    mov cx, DATA_SEL

    mov ds, cx
    mov es, cx
    mov fs, cx
    mov gs, cx
    mov ss, cx

    mov esp, stack_top

    mov edi, bss_start
    mov ecx, bss_end
    sub ecx, edi
    cmp ecx, 0
    je bss_zeroed
zero_bss_loop:
    mov byte [edi], 0
    inc edi
    dec ecx
    jnz zero_bss_loop
bss_zeroed:

    push ebx
    push eax
    call multiboot2_entry

    push eax
    call kernel_main

    cli
hang_forever:
    hlt
    jmp hang_forever

SECTION .bss
align 16
stack_bottom:
    resb 65536
stack_top:

SECTION .data
align 8
gdt_start:
    dq 0
gdt_code:
    dw 0xFFFF, 0x0000
    db 0x00, 0x9A, 0xCF, 0x00
gdt_data:
    dw 0xFFFF, 0x0000
    db 0x00, 0x92, 0xCF, 0x00
gdt_end:

gdt_descriptor:
    dw gdt_end - gdt_start - 1
    dd gdt_start

CODE_SEL equ gdt_code - gdt_start
DATA_SEL equ gdt_data - gdt_start
