#ifndef TUI_INSTALL_H
#define TUI_INSTALL_H
#include "io.h"

void tui_install_run(void);

#endif
