#ifndef INSTALLER_H
#define INSTALLER_H
#include "io.h"

void installer_cmd_disklist(void);
void installer_cmd_install(const char* args);
int  installer_active(void);
void installer_tick(void);
int  installer_bundled_image_available(void);
u32  installer_bundled_image_size(void);
void installer_start_bundled_install(int idx);

void installer_init(void);
void app_installer_draw(i32 x, i32 y, i32 w, i32 h);
void app_installer_click(i32 rx, i32 ry);
void app_installer_key(int key);

#endif
