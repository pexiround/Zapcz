#ifndef AES_GCM_H
#define AES_GCM_H
#include "io.h"

void aes128_gcm_encrypt(const u8 key[16], const u8 iv[12],
                         const u8* aad, u32 aad_len,
                         const u8* pt, u32 pt_len,
                         u8* ct_out, u8 tag_out[16]);

int aes128_gcm_decrypt(const u8 key[16], const u8 iv[12],
                        const u8* aad, u32 aad_len,
                        const u8* ct, u32 ct_len, const u8 tag_in[16],
                        u8* pt_out);

#endif
