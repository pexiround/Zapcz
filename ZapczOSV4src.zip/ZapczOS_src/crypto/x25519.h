#ifndef X25519_H
#define X25519_H
#include "io.h"

void x25519_scalarmult(u8 out[32], const u8 scalar[32], const u8 point[32]);
void x25519_derive_public(u8 out_pub[32], const u8 scalar[32]);

#endif
