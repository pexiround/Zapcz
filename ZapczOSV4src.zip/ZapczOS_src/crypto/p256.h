#ifndef P256_H
#define P256_H
#include "io.h"

/* Verify an ECDSA/P-256 signature over a 32-byte hash.
   pub_point: 65 bytes, uncompressed (0x04 || X(32) || Y(32)).
   r,s: signature integers, big-endian (up to 32 bytes each).
   Returns 1 if valid, 0 otherwise. */
int p256_ecdsa_verify(const u8* pub_point, u32 pub_len,
                      const u8 hash32[32],
                      const u8* r, u32 r_len,
                      const u8* s, u32 s_len);

void p256_ecdh_keypair(const u8 priv[32], u8 pub[65]);
int  p256_ecdh_shared(const u8 priv[32], const u8 peer[65], u8 out[32]);

#endif
