#ifndef AES_H
#define AES_H
#include "io.h"

#define AES128_ROUNDS 10
#define AES128_ROUNDKEY_WORDS 44

typedef struct {
    u32 round_keys[AES128_ROUNDKEY_WORDS];
} aes128_ctx_t;

void aes128_init(aes128_ctx_t* ctx, const u8 key[16]);
void aes128_encrypt_block(const aes128_ctx_t* ctx, const u8 in[16], u8 out[16]);
void aes128_decrypt_block(const aes128_ctx_t* ctx, const u8 in[16], u8 out[16]);

void aes128_cbc_encrypt(const aes128_ctx_t* ctx, const u8 iv[16],
                         const u8* in, u32 len, u8* out);
void aes128_cbc_decrypt(const aes128_ctx_t* ctx, const u8 iv[16],
                         const u8* in, u32 len, u8* out);

#endif
