#include "p256.h"

/* ---- fixed 256-bit bignum, 8 little-endian u32 limbs (limb[0]=LSW) ---- */
#define NL 8

static void bn_set0(u32* a) { for (int i = 0; i < NL; i++) a[i] = 0; }
static void bn_cpy(u32* d, const u32* s) { for (int i = 0; i < NL; i++) d[i] = s[i]; }

static int bn_cmp(const u32* a, const u32* b) {
    for (int i = NL - 1; i >= 0; i--) { if (a[i] != b[i]) return a[i] > b[i] ? 1 : -1; }
    return 0;
}
static int bn_is0(const u32* a) { for (int i = 0; i < NL; i++) if (a[i]) return 0; return 1; }

/* r = a + b, returns carry */
static u32 bn_add(u32* r, const u32* a, const u32* b) {
    u64 c = 0;
    for (int i = 0; i < NL; i++) { c += (u64)a[i] + b[i]; r[i] = (u32)c; c >>= 32; }
    return (u32)c;
}
/* r = a - b, returns borrow */
static u32 bn_sub(u32* r, const u32* a, const u32* b) {
    u64 br = 0;
    for (int i = 0; i < NL; i++) {
        u64 t = (u64)a[i] - b[i] - br;
        r[i] = (u32)t; br = (t >> 32) & 1;
    }
    return (u32)br;
}

static void bn_from_be(u32* r, const u8* be, u32 len) {
    bn_set0(r);
    int bit = 0;
    for (int i = (int)len - 1; i >= 0; i--) {
        r[bit / 32] |= (u32)be[i] << (bit % 32);
        bit += 8;
        if (bit >= NL * 32) break;
    }
}
static void bn_to_be32(const u32* a, u8 out[32]) {
    for (int i = 0; i < 32; i++) {
        int bit = (31 - i) * 8;
        out[i] = (u8)(a[bit / 32] >> (bit % 32));
    }
}

static int bn_bit(const u32* a, int i) { return (int)((a[i / 32] >> (i % 32)) & 1u); }

/* 256x256 -> 512 (16 limbs) */
static void bn_mul_wide(const u32* a, const u32* b, u32* r16) {
    for (int i = 0; i < 2 * NL; i++) r16[i] = 0;
    for (int i = 0; i < NL; i++) {
        u64 carry = 0;
        for (int j = 0; j < NL; j++) {
            u64 t = (u64)a[i] * b[j] + r16[i + j] + carry;
            r16[i + j] = (u32)t; carry = t >> 32;
        }
        r16[i + NL] = (u32)carry;
    }
}

/* reduce 512-bit prod (16 limbs) mod m (8 limbs) -> r (8 limbs), schoolbook bitwise */
static void bn_mod_wide(const u32* prod, const u32* m, u32* r) {
    u32 rem[NL + 1]; for (int i = 0; i <= NL; i++) rem[i] = 0;
    u32 mext[NL + 1]; for (int i = 0; i < NL; i++) mext[i] = m[i]; mext[NL] = 0;
    for (int bit = 2 * NL * 32 - 1; bit >= 0; bit--) {
        /* rem <<= 1 */
        u32 carry = 0;
        for (int i = 0; i <= NL; i++) { u32 nc = rem[i] >> 31; rem[i] = (rem[i] << 1) | carry; carry = nc; }
        /* bring in bit */
        if ((prod[bit / 32] >> (bit % 32)) & 1u) rem[0] |= 1u;
        /* if rem >= mext, subtract */
        int ge = 0;
        for (int i = NL; i >= 0; i--) { if (rem[i] != mext[i]) { ge = rem[i] > mext[i]; break; } if (i == 0) ge = 1; }
        if (ge) {
            u64 br = 0;
            for (int i = 0; i <= NL; i++) { u64 t = (u64)rem[i] - mext[i] - br; rem[i] = (u32)t; br = (t >> 32) & 1; }
        }
    }
    for (int i = 0; i < NL; i++) r[i] = rem[i];
}

static void bn_mulmod(u32* r, const u32* a, const u32* b, const u32* m) {
    u32 prod[2 * NL];
    bn_mul_wide(a, b, prod);
    bn_mod_wide(prod, m, r);
}

/* r = base^exp mod m  (exp is a full bignum) */
static void bn_modexp(u32* r, const u32* base, const u32* exp, const u32* m) {
    u32 acc[NL]; bn_set0(acc); acc[0] = 1;
    u32 b[NL]; bn_cpy(b, base);
    for (int i = 0; i < NL * 32; i++) {
        if (bn_bit(exp, i)) { u32 t[NL]; bn_mulmod(t, acc, b, m); bn_cpy(acc, t); }
        u32 t2[NL]; bn_mulmod(t2, b, b, m); bn_cpy(b, t2);
    }
    bn_cpy(r, acc);
}

/* ---- P-256 constants ---- */
static const u8 P_be[32] = {
 0xff,0xff,0xff,0xff,0x00,0x00,0x00,0x01,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
 0x00,0x00,0x00,0x00,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff };
static const u8 N_be[32] = {
 0xff,0xff,0xff,0xff,0x00,0x00,0x00,0x00,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,
 0xbc,0xe6,0xfa,0xad,0xa7,0x17,0x9e,0x84,0xf3,0xb9,0xca,0xc2,0xfc,0x63,0x25,0x51 };
static const u8 B_be[32] = {
 0x5a,0xc6,0x35,0xd8,0xaa,0x3a,0x93,0xe7,0xb3,0xeb,0xbd,0x55,0x76,0x98,0x86,0xbc,
 0x65,0x1d,0x06,0xb0,0xcc,0x53,0xb0,0xf6,0x3b,0xce,0x3c,0x3e,0x27,0xd2,0x60,0x4b };
static const u8 GX_be[32] = {
 0x6b,0x17,0xd1,0xf2,0xe1,0x2c,0x42,0x47,0xf8,0xbc,0xe6,0xe5,0x63,0xa4,0x40,0xf2,
 0x77,0x03,0x7d,0x81,0x2d,0xeb,0x33,0xa0,0xf4,0xa1,0x39,0x45,0xd8,0x98,0xc2,0x96 };
static const u8 GY_be[32] = {
 0x4f,0xe3,0x42,0xe2,0xfe,0x1a,0x7f,0x9b,0x8e,0xe7,0xeb,0x4a,0x7c,0x0f,0x9e,0x16,
 0x2b,0xce,0x33,0x57,0x6b,0x31,0x5e,0xce,0xcb,0xb6,0x40,0x68,0x37,0xbf,0x51,0xf5 };

static u32 P[NL], Nn[NL], B[NL], Gx[NL], Gy[NL], A[NL];
static int inited = 0;
static void p256_init(void) {
    if (inited) return;
    bn_from_be(P, P_be, 32); bn_from_be(Nn, N_be, 32); bn_from_be(B, B_be, 32);
    bn_from_be(Gx, GX_be, 32); bn_from_be(Gy, GY_be, 32);
    u32 three[NL]; bn_set0(three); three[0] = 3;
    bn_sub(A, P, three); /* a = p - 3 */
    inited = 1;
}

/* field ops mod P */
static void fe_add(u32* r, const u32* a, const u32* b) {
    u32 c = bn_add(r, a, b);
    if (c || bn_cmp(r, P) >= 0) bn_sub(r, r, P);
}
static void fe_sub(u32* r, const u32* a, const u32* b) {
    u32 br = bn_sub(r, a, b);
    if (br) bn_add(r, r, P);
}
static void fe_mul(u32* r, const u32* a, const u32* b) { bn_mulmod(r, a, b, P); }
static void fe_sqr(u32* r, const u32* a) { bn_mulmod(r, a, a, P); }
static void fe_inv(u32* r, const u32* a) {
    u32 e[NL], two[NL]; bn_set0(two); two[0] = 2;
    bn_sub(e, P, two); /* p-2 */
    bn_modexp(r, a, e, P);
}

/* Jacobian point */
typedef struct { u32 X[NL], Y[NL], Z[NL]; } jpt;
static int j_is_inf(const jpt* p) { return bn_is0(p->Z); }

static void j_double(jpt* R, const jpt* Pt) {
    if (j_is_inf(Pt) || bn_is0(Pt->Y)) { bn_set0(R->X); bn_set0(R->Y); bn_set0(R->Z); return; }
    u32 XX[NL], YY[NL], YYYY[NL], ZZ[NL], S[NL], M[NL], T[NL], t1[NL], t2[NL];
    fe_sqr(XX, Pt->X);
    fe_sqr(YY, Pt->Y);
    fe_sqr(YYYY, YY);
    fe_sqr(ZZ, Pt->Z);
    /* S = 2*((X+YY)^2 - XX - YYYY) */
    fe_add(t1, Pt->X, YY); fe_sqr(t1, t1); fe_sub(t1, t1, XX); fe_sub(t1, t1, YYYY);
    fe_add(S, t1, t1);
    /* M = 3*XX + a*ZZ^2 */
    fe_sqr(t2, ZZ); fe_mul(t2, A, t2);
    fe_add(M, XX, XX); fe_add(M, M, XX); fe_add(M, M, t2);
    /* X3 = M^2 - 2S */
    fe_sqr(T, M); fe_sub(T, T, S); fe_sub(T, T, S); bn_cpy(R->X, T);
    /* Y3 = M*(S - X3) - 8*YYYY */
    fe_sub(t1, S, R->X); fe_mul(t1, M, t1);
    fe_add(t2, YYYY, YYYY); fe_add(t2, t2, t2); fe_add(t2, t2, t2); /* 8*YYYY */
    fe_sub(R->Y, t1, t2);
    /* Z3 = 2*Y*Z */
    fe_mul(t1, Pt->Y, Pt->Z); fe_add(R->Z, t1, t1);
}

/* R = P + Q (both Jacobian) */
static void j_add(jpt* R, const jpt* Pp, const jpt* Qq) {
    if (j_is_inf(Pp)) { *R = *Qq; return; }
    if (j_is_inf(Qq)) { *R = *Pp; return; }
    u32 Z1Z1[NL], Z2Z2[NL], U1[NL], U2[NL], S1[NL], S2[NL], H[NL], Rr[NL];
    u32 t1[NL], t2[NL];
    fe_sqr(Z1Z1, Pp->Z);
    fe_sqr(Z2Z2, Qq->Z);
    fe_mul(U1, Pp->X, Z2Z2);
    fe_mul(U2, Qq->X, Z1Z1);
    fe_mul(t1, Qq->Z, Z2Z2); fe_mul(S1, Pp->Y, t1);
    fe_mul(t2, Pp->Z, Z1Z1); fe_mul(S2, Qq->Y, t2);
    if (bn_cmp(U1, U2) == 0) {
        if (bn_cmp(S1, S2) != 0) { bn_set0(R->X); bn_set0(R->Y); bn_set0(R->Z); return; }
        j_double(R, Pp); return;
    }
    fe_sub(H, U2, U1);
    fe_sub(Rr, S2, S1);
    u32 HH[NL], HHH[NL], U1HH[NL], X3[NL], Y3[NL], Z3[NL];
    fe_sqr(HH, H);
    fe_mul(HHH, H, HH);
    fe_mul(U1HH, U1, HH);
    /* X3 = R^2 - HHH - 2*U1HH */
    fe_sqr(X3, Rr); fe_sub(X3, X3, HHH); fe_sub(X3, X3, U1HH); fe_sub(X3, X3, U1HH);
    /* Y3 = R*(U1HH - X3) - S1*HHH */
    fe_sub(t1, U1HH, X3); fe_mul(t1, Rr, t1);
    fe_mul(t2, S1, HHH);
    fe_sub(Y3, t1, t2);
    /* Z3 = Z1*Z2*H */
    fe_mul(t1, Pp->Z, Qq->Z); fe_mul(Z3, t1, H);
    bn_cpy(R->X, X3); bn_cpy(R->Y, Y3); bn_cpy(R->Z, Z3);
}

/* R = k*P (P affine in (px,py)), double-and-add */
static void scalar_mul(jpt* R, const u32* k, const u32* px, const u32* py) {
    jpt base; bn_cpy(base.X, px); bn_cpy(base.Y, py); bn_set0(base.Z); base.Z[0] = 1;
    bn_set0(R->X); bn_set0(R->Y); bn_set0(R->Z); /* infinity */
    for (int i = NL * 32 - 1; i >= 0; i--) {
        jpt t; j_double(&t, R); *R = t;
        if (bn_bit(k, i)) { jpt t2; j_add(&t2, R, &base); *R = t2; }
    }
}

/* affine x of a Jacobian point, reduced: out = X/Z^2 mod p */
static void j_affine_x(u32* out, const jpt* Pt) {
    u32 zinv[NL], zinv2[NL];
    fe_inv(zinv, Pt->Z);
    fe_sqr(zinv2, zinv);
    fe_mul(out, Pt->X, zinv2);
}

static void j_affine_xy(u32* ox, u32* oy, const jpt* Pt) {
    u32 zinv[NL], zinv2[NL], zinv3[NL];
    fe_inv(zinv, Pt->Z);
    fe_sqr(zinv2, zinv);
    fe_mul(zinv3, zinv2, zinv);
    fe_mul(ox, Pt->X, zinv2);
    fe_mul(oy, Pt->Y, zinv3);
}

void p256_ecdh_keypair(const u8 priv[32], u8 pub[65]) {
    p256_init();
    u32 d[NL]; bn_from_be(d, priv, 32);
    jpt R; scalar_mul(&R, d, Gx, Gy);
    u32 x[NL], y[NL]; j_affine_xy(x, y, &R);
    pub[0] = 0x04; bn_to_be32(x, pub + 1); bn_to_be32(y, pub + 33);
}

int p256_ecdh_shared(const u8 priv[32], const u8 peer[65], u8 out[32]) {
    p256_init();
    if (peer[0] != 0x04) return 0;
    u32 d[NL], px[NL], py[NL];
    bn_from_be(d, priv, 32);
    bn_from_be(px, peer + 1, 32);
    bn_from_be(py, peer + 33, 32);
    jpt R; scalar_mul(&R, d, px, py);
    if (j_is_inf(&R)) return 0;
    u32 x[NL], y[NL]; j_affine_xy(x, y, &R);
    bn_to_be32(x, out);
    return 1;
}

int p256_ecdsa_verify(const u8* pub_point, u32 pub_len,
                      const u8 hash32[32],
                      const u8* r, u32 r_len,
                      const u8* s, u32 s_len) {
    p256_init();
    if (pub_len != 65 || pub_point[0] != 0x04) return 0;

    u32 Qx[NL], Qy[NL], rr[NL], ss[NL], e[NL];
    bn_from_be(Qx, pub_point + 1, 32);
    bn_from_be(Qy, pub_point + 33, 32);
    bn_from_be(rr, r, r_len);
    bn_from_be(ss, s, s_len);
    bn_from_be(e, hash32, 32);

    /* r,s must be in [1, n-1] */
    if (bn_is0(rr) || bn_is0(ss) || bn_cmp(rr, Nn) >= 0 || bn_cmp(ss, Nn) >= 0) return 0;
    /* reduce e mod n */
    if (bn_cmp(e, Nn) >= 0) bn_sub(e, e, Nn);

    /* w = s^-1 mod n */
    u32 w[NL], nm2[NL], two[NL];
    bn_set0(two); two[0] = 2; bn_sub(nm2, Nn, two);
    bn_modexp(w, ss, nm2, Nn);

    /* u1 = e*w mod n, u2 = r*w mod n */
    u32 u1[NL], u2[NL];
    bn_mulmod(u1, e, w, Nn);
    bn_mulmod(u2, rr, w, Nn);

    /* R = u1*G + u2*Q */
    jpt R1, R2, R;
    scalar_mul(&R1, u1, Gx, Gy);
    scalar_mul(&R2, u2, Qx, Qy);
    j_add(&R, &R1, &R2);
    if (j_is_inf(&R)) return 0;

    u32 x[NL];
    j_affine_x(x, &R);
    /* v = x mod n */
    if (bn_cmp(x, Nn) >= 0) bn_sub(x, x, Nn);
    return bn_cmp(x, rr) == 0 ? 1 : 0;
}
