#include "random.h"
#include "pit.h"

static int have_rdrand = 0;
static u32 fallback_state = 0;

static inline u32 cpuid_feat_ecx1(void) {
    u32 a, c, d;
    __asm__ volatile ("cpuid" : "=a"(a), "=c"(c), "=d"(d) : "a"(1) : "ebx");
    return c;
}

static inline int rdrand32(u32* out) {
    u32 v;
    u8 ok;
    __asm__ volatile ("rdrand %0\n\tsetc %1" : "=r"(v), "=qm"(ok) :: "cc");
    *out = v;
    return ok;
}

static inline u64 rdtsc64(void) {
    u32 lo, hi;
    __asm__ volatile ("rdtsc" : "=a"(lo), "=d"(hi));
    return ((u64)hi << 32) | (u64)lo;
}

void rng_init(void) {
    have_rdrand = (int)((cpuid_feat_ecx1() >> 30) & 1u);
    fallback_state = (u32)rdtsc64() ^ ticks_get() ^ 0x9e3779b9u;
    if (fallback_state == 0) fallback_state = 0x9e3779b9u;
}

int rng_have_hw_entropy(void) { return have_rdrand; }

static u32 fallback_u32(void) {
    fallback_state ^= (u32)rdtsc64();
    fallback_state ^= fallback_state << 13;
    fallback_state ^= fallback_state >> 17;
    fallback_state ^= fallback_state << 5;
    fallback_state += ticks_get();
    if (fallback_state == 0) fallback_state = 0x9e3779b9u;
    return fallback_state;
}

void rng_bytes(u8* out, u32 len) {
    u32 i = 0;
    while (i < len) {
        u32 v;
        if (have_rdrand) {
            int tries = 0;
            while (!rdrand32(&v) && tries < 10) tries++;
            if (tries >= 10) v = fallback_u32();
        } else {
            v = fallback_u32();
        }
        u32 take = (len - i < 4) ? (len - i) : 4;
        for (u32 k = 0; k < take; k++) out[i + k] = (u8)(v >> (k * 8));
        i += take;
    }
}
