#include "rsa_pub.h"
#include "libc_shim.h"
#include "random.h"

#define BN_LIMBS (RSA_MAX_MODULUS_BYTES / 4)

static void bn_zero(u32* a, u32 n) { memset(a, 0, n * 4); }

static void bn_from_be_bytes(u32* r, u32 n_limbs, const u8* be, u32 be_len) {
    bn_zero(r, n_limbs);
    i32 bi = (i32)be_len - 1;
    for (u32 li = 0; li < n_limbs && bi >= 0; li++) {
        u32 v = 0;
        for (int k = 0; k < 4 && bi >= 0; k++) {
            v |= ((u32)be[bi]) << (k * 8);
            bi--;
        }
        r[li] = v;
    }
}

static void bn_to_be_bytes(const u32* a, u32 n_limbs, u8* out, u32 out_len) {
    memset(out, 0, out_len);
    i32 oi = (i32)out_len - 1;
    for (u32 li = 0; li < n_limbs && oi >= 0; li++) {
        u32 v = a[li];
        for (int k = 0; k < 4 && oi >= 0; k++) {
            out[oi] = (u8)(v >> (k * 8));
            oi--;
        }
    }
}

static int bn_cmp(const u32* a, const u32* b, u32 n) {
    for (i32 i = (i32)n - 1; i >= 0; i--) {
        if (a[i] != b[i]) return (a[i] > b[i]) ? 1 : -1;
    }
    return 0;
}

static void bn_sub(const u32* a, const u32* b, u32* r, u32 n) {
    u64 borrow = 0;
    for (u32 i = 0; i < n; i++) {
        u64 sub = (u64)b[i] + borrow;
        if ((u64)a[i] >= sub) {
            r[i] = (u32)((u64)a[i] - sub);
            borrow = 0;
        } else {
            r[i] = (u32)(((u64)a[i] + ((u64)1 << 32)) - sub);
            borrow = 1;
        }
    }
}

static int bn_bit(const u32* a, u32 n, u32 bit_index) {
    u32 li = bit_index / 32, bi = bit_index % 32;
    if (li >= n) return 0;
    return (int)((a[li] >> bi) & 1u);
}

static void bn_mul(const u32* a, const u32* b, u32 n, u32* r) {
    memset(r, 0, 2 * n * 4);
    for (u32 i = 0; i < n; i++) {
        u64 carry = 0;
        for (u32 j = 0; j < n; j++) {
            u64 prod = (u64)a[i] * (u64)b[j] + (u64)r[i + j] + carry;
            r[i + j] = (u32)prod;
            carry = prod >> 32;
        }
        u32 k = i + n;
        while (carry) {
            u64 sum = (u64)r[k] + carry;
            r[k] = (u32)sum;
            carry = sum >> 32;
            k++;
        }
    }
}

static void bn_mod_wide(const u32* p, const u32* m, u32 n, u32* result) {
    u32 rem[BN_LIMBS + 1];
    u32 mext[BN_LIMBS + 1];
    memset(rem, 0, (n + 1) * 4);
    memcpy(mext, m, n * 4);
    mext[n] = 0;

    for (i32 bit = (i32)(2 * n * 32) - 1; bit >= 0; bit--) {
        u32 carry = 0;
        for (u32 i = 0; i <= n; i++) {
            u32 newcarry = (rem[i] >> 31) & 1u;
            rem[i] = (u32)((rem[i] << 1) | carry);
            carry = newcarry;
        }
        if (bn_bit(p, 2 * n, (u32)bit)) rem[0] |= 1u;
        if (bn_cmp(rem, mext, n + 1) >= 0) {
            bn_sub(rem, mext, rem, n + 1);
        }
    }
    memcpy(result, rem, n * 4);
}

static void bn_mulmod(const u32* a, const u32* b, const u32* m, u32 n, u32* result) {
    u32 prod[2 * BN_LIMBS];
    bn_mul(a, b, n, prod);
    bn_mod_wide(prod, m, n, result);
}

static void bn_modexp_u32(const u32* base, u32 exp, const u32* m, u32 n, u32* result) {
    u32 acc[BN_LIMBS];
    bn_zero(acc, n);
    acc[0] = 1;
    for (i32 bit = 31; bit >= 0; bit--) {
        u32 sq[BN_LIMBS];
        bn_mulmod(acc, acc, m, n, sq);
        memcpy(acc, sq, n * 4);
        if ((exp >> bit) & 1u) {
            u32 mu[BN_LIMBS];
            bn_mulmod(acc, base, m, n, mu);
            memcpy(acc, mu, n * 4);
        }
    }
    memcpy(result, acc, n * 4);
}

int rsa_pub_encrypt_pkcs1(const u8* modulus_be, u32 modulus_len,
                           u32 pub_exponent,
                           const u8* msg, u32 msg_len,
                           u8* out) {
    while (modulus_len > 1 && modulus_be[0] == 0) {
        modulus_be++;
        modulus_len--;
    }
    if (modulus_len == 0 || modulus_len > RSA_MAX_MODULUS_BYTES) return 0;
    if (msg_len + 11 > modulus_len) return 0;

    u32 n_limbs = (modulus_len + 3) / 4;

    u8 em[RSA_MAX_MODULUS_BYTES];
    em[0] = 0x00;
    em[1] = 0x02;
    u32 ps_len = modulus_len - msg_len - 3;
    u32 i = 2;
    while (i < 2 + ps_len) {
        u8 r;
        rng_bytes(&r, 1);
        if (r == 0) continue;
        em[i++] = r;
    }
    em[2 + ps_len] = 0x00;
    memcpy(em + 3 + ps_len, msg, msg_len);

    u32 m[BN_LIMBS], mod[BN_LIMBS], c[BN_LIMBS];
    bn_from_be_bytes(m, n_limbs, em, modulus_len);
    bn_from_be_bytes(mod, n_limbs, modulus_be, modulus_len);
    bn_modexp_u32(m, pub_exponent, mod, n_limbs, c);
    bn_to_be_bytes(c, n_limbs, out, modulus_len);
    return 1;
}

static const u8 SHA256_DIGESTINFO_PREFIX[19] = {
    0x30, 0x31, 0x30, 0x0d, 0x06, 0x09, 0x60, 0x86, 0x48, 0x01,
    0x65, 0x03, 0x04, 0x02, 0x01, 0x05, 0x00, 0x04, 0x20
};

int rsa_pub_verify_pkcs1_sha256(const u8* modulus_be, u32 modulus_len,
                                 u32 pub_exponent,
                                 const u8 hash32[32],
                                 const u8* sig, u32 sig_len) {
    while (modulus_len > 1 && modulus_be[0] == 0) {
        modulus_be++;
        modulus_len--;
    }
    if (modulus_len == 0 || modulus_len > RSA_MAX_MODULUS_BYTES) return 0;
    if (sig_len != modulus_len) return 0;

    u32 n_limbs = (modulus_len + 3) / 4;
    u32 s[BN_LIMBS], mod[BN_LIMBS], m[BN_LIMBS];
    bn_from_be_bytes(s, n_limbs, sig, sig_len);
    bn_from_be_bytes(mod, n_limbs, modulus_be, modulus_len);
    bn_modexp_u32(s, pub_exponent, mod, n_limbs, m);

    u8 em[RSA_MAX_MODULUS_BYTES];
    bn_to_be_bytes(m, n_limbs, em, modulus_len);

    if (em[0] != 0x00 || em[1] != 0x01) return 0;
    u32 i = 2;
    while (i < modulus_len && em[i] == 0xFF) i++;
    if (i >= modulus_len || em[i] != 0x00) return 0;
    i++;

    u32 tail_len = modulus_len - i;
    if (tail_len != 19 + 32) return 0;
    if (memcmp(em + i, SHA256_DIGESTINFO_PREFIX, 19) != 0) return 0;
    if (memcmp(em + i + 19, hash32, 32) != 0) return 0;

    return 1;
}
