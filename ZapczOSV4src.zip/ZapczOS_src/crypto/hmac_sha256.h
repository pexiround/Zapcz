#ifndef HMAC_SHA256_H
#define HMAC_SHA256_H
#include "io.h"

void hmac_sha256(const u8* key, u32 keylen, const u8* msg, u32 msglen, u8 out[32]);

void tls_prf_sha256(const u8* secret, u32 secretlen,
                     const char* label,
                     const u8* seed, u32 seedlen,
                     u8* out, u32 outlen);

#endif
