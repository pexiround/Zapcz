#ifndef SHA256_H
#define SHA256_H
#include "io.h"

#define SHA256_DIGEST_SIZE 32
#define SHA256_BLOCK_SIZE 64

typedef struct {
    u32 state[8];
    u64 bitlen;
    u8 buf[64];
    u32 buflen;
} sha256_ctx_t;

void sha256_init(sha256_ctx_t* ctx);
void sha256_update(sha256_ctx_t* ctx, const u8* data, u32 len);
void sha256_final(sha256_ctx_t* ctx, u8 out[SHA256_DIGEST_SIZE]);
void sha256_hash(const u8* data, u32 len, u8 out[SHA256_DIGEST_SIZE]);

#endif
