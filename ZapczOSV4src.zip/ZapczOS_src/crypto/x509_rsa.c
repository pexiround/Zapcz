#include "x509_rsa.h"

static int der_tlv(const u8* buf, u32 pos, u32 end, u8* tag,
                    u32* content_off, u32* content_len, u32* next_off) {
    if (pos >= end) return 0;
    *tag = buf[pos];
    pos++;
    if (pos >= end) return 0;
    u8 lb = buf[pos];
    pos++;
    u32 len;
    if (lb < 0x80) {
        len = lb;
    } else {
        u32 nbytes = lb & 0x7Fu;
        if (nbytes == 0 || nbytes > 4) return 0;
        if (pos + nbytes > end) return 0;
        len = 0;
        for (u32 i = 0; i < nbytes; i++) len = (len << 8) | buf[pos + i];
        pos += nbytes;
    }
    if (pos + len > end) return 0;
    *content_off = pos;
    *content_len = len;
    *next_off = pos + len;
    return 1;
}

static int der_enter(const u8* buf, u32 off, u32 len, u32* inner_off, u32* inner_end) {
    u8 tag; u32 coff, clen, noff;
    if (!der_tlv(buf, off, off + len, &tag, &coff, &clen, &noff)) return 0;
    *inner_off = coff;
    *inner_end = coff + clen;
    return 1;
}

int x509_extract_rsa_pubkey(const u8* cert_der, u32 cert_len,
                             const u8** out_modulus, u32* out_modulus_len,
                             u32* out_exponent) {
    u32 cert_inner_off, cert_inner_end;
    if (!der_enter(cert_der, 0, cert_len, &cert_inner_off, &cert_inner_end)) return 0;

    u8 tag; u32 coff, clen, noff;
    if (!der_tlv(cert_der, cert_inner_off, cert_inner_end, &tag, &coff, &clen, &noff)) return 0;
    if (tag != 0x30) return 0;
    u32 tbs_off = coff, tbs_end = coff + clen;

    u32 pos = tbs_off;
    if (!der_tlv(cert_der, pos, tbs_end, &tag, &coff, &clen, &noff)) return 0;
    if (tag == 0xA0) {
        pos = noff;
        if (!der_tlv(cert_der, pos, tbs_end, &tag, &coff, &clen, &noff)) return 0;
    }

    for (int field = 0; field < 5; field++) {
        pos = noff;
        if (!der_tlv(cert_der, pos, tbs_end, &tag, &coff, &clen, &noff)) return 0;
    }

    if (tag != 0x30) return 0;
    u32 spki_off = coff, spki_end = coff + clen;

    u32 spki_pos = spki_off;
    if (!der_tlv(cert_der, spki_pos, spki_end, &tag, &coff, &clen, &noff)) return 0;
    if (tag != 0x30) return 0;
    spki_pos = noff;

    if (!der_tlv(cert_der, spki_pos, spki_end, &tag, &coff, &clen, &noff)) return 0;
    if (tag != 0x03) return 0;
    if (clen < 1) return 0;
    if (cert_der[coff] != 0) return 0;
    u32 bitstr_off = coff + 1, bitstr_len = clen - 1;

    u32 rsakey_off, rsakey_end;
    if (!der_enter(cert_der, bitstr_off, bitstr_len, &rsakey_off, &rsakey_end)) return 0;

    if (!der_tlv(cert_der, rsakey_off, rsakey_end, &tag, &coff, &clen, &noff)) return 0;
    if (tag != 0x02) return 0;
    *out_modulus = cert_der + coff;
    *out_modulus_len = clen;

    if (!der_tlv(cert_der, noff, rsakey_end, &tag, &coff, &clen, &noff)) return 0;
    if (tag != 0x02) return 0;
    if (clen == 0 || clen > 4) return 0;
    u32 exp = 0;
    for (u32 i = 0; i < clen; i++) exp = (exp << 8) | cert_der[coff + i];
    *out_exponent = exp;

    return 1;
}

/* Extract an uncompressed EC public-key point (0x04||X||Y, 65 bytes) from an
   ECDSA certificate's SubjectPublicKeyInfo. Returns 1 on success.
   A P-256 subjectPublicKey is always the BIT STRING prefix 03 42 00 04 followed
   by 64 bytes (X||Y); matching that exact 4-byte prefix avoids stray 0x03 bytes
   inside the algorithm OIDs. */
int x509_extract_ec_point(const u8* cert, u32 len, u8 out[65]) {
    for (u32 i = 0; i + 4 + 64 <= len; i++) {
        if (cert[i] == 0x03 && cert[i + 1] == 0x42 && cert[i + 2] == 0x00 && cert[i + 3] == 0x04) {
            out[0] = 0x04;
            for (int b = 0; b < 64; b++) out[b + 1] = cert[i + 4 + b];
            return 1;
        }
    }
    return 0;
}
