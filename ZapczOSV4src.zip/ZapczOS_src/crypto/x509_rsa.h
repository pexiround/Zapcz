#ifndef X509_RSA_H
#define X509_RSA_H
#include "io.h"

int x509_extract_ec_point(const u8* cert_der, u32 cert_len, u8 out_point[65]);
int x509_extract_rsa_pubkey(const u8* cert_der, u32 cert_len,
                             const u8** out_modulus, u32* out_modulus_len,
                             u32* out_exponent);

#endif
