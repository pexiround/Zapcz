#ifndef RSA_PUB_H
#define RSA_PUB_H
#include "io.h"

#define RSA_MAX_MODULUS_BYTES 512

int rsa_pub_encrypt_pkcs1(const u8* modulus_be, u32 modulus_len,
                           u32 pub_exponent,
                           const u8* msg, u32 msg_len,
                           u8* out);

int rsa_pub_verify_pkcs1_sha256(const u8* modulus_be, u32 modulus_len,
                                 u32 pub_exponent,
                                 const u8 hash32[32],
                                 const u8* sig, u32 sig_len);

#endif
