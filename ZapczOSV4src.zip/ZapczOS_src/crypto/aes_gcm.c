#include "aes_gcm.h"
#include "aes.h"
#include "libc_shim.h"

/* GHASH over GF(2^128).
   The straightforward version multiplies bit by bit: 128 iterations for every
   16-byte block, which dominates the cost of decrypting a large TLS response.
   This uses the standard 4-bit table method instead -- a 16-entry table of
   multiples of H, consuming four bits at a time. */

static u8  GH_TBL[16][16];
static u8  GH_TBL_H[16];
static int GH_TBL_READY = 0;

static const u16 GH_R4[16] = {
    0x0000, 0x1c20, 0x3840, 0x2460, 0x7080, 0x6ca0, 0x48c0, 0x54e0,
    0xe100, 0xfd20, 0xd940, 0xc560, 0x9180, 0x8da0, 0xa9c0, 0xb5e0
};

static void gh_mul_x(u8 v[16]) {
    int lsb = v[15] & 1;
    for (int k = 15; k > 0; k--) v[k] = (u8)((v[k] >> 1) | ((v[k - 1] & 1) << 7));
    v[0] = (u8)(v[0] >> 1);
    if (lsb) v[0] ^= 0xE1;
}

static void gh_build(const u8 h[16]) {
    if (GH_TBL_READY) {
        int same = 1;
        for (int i = 0; i < 16; i++) if (GH_TBL_H[i] != h[i]) { same = 0; break; }
        if (same) return;
    }
    memset(GH_TBL[0], 0, 16);
    memcpy(GH_TBL[8], h, 16);
    for (int i = 4; i > 0; i >>= 1) { memcpy(GH_TBL[i], GH_TBL[i * 2], 16); gh_mul_x(GH_TBL[i]); }
    for (int i = 2; i < 16; i <<= 1)
        for (int j = 1; j < i; j++)
            for (int k = 0; k < 16; k++) GH_TBL[i + j][k] = GH_TBL[i][k] ^ GH_TBL[j][k];
    memcpy(GH_TBL_H, h, 16);
    GH_TBL_READY = 1;
}

static void gh_mul_x4(u8 z[16]) {
    u8 lo = z[15] & 0x0F;
    for (int k = 15; k > 0; k--) z[k] = (u8)((z[k] >> 4) | ((z[k - 1] & 0x0F) << 4));
    z[0] = (u8)(z[0] >> 4);
    u16 r = GH_R4[lo];
    z[0] ^= (u8)(r >> 8);
    z[1] ^= (u8)(r & 0xFF);
}

static void ghash_mul(u8 r[16], const u8 x[16], const u8 h[16]) {
    gh_build(h);
    u8 z[16];
    for (int i = 15; i >= 0; i--) {
        int lo = x[i] & 0x0F, hi = (x[i] >> 4) & 0x0F;
        if (i == 15) { memcpy(z, GH_TBL[lo], 16); }
        else { gh_mul_x4(z); for (int k = 0; k < 16; k++) z[k] ^= GH_TBL[lo][k]; }
        gh_mul_x4(z);
        for (int k = 0; k < 16; k++) z[k] ^= GH_TBL[hi][k];
    }
    memcpy(r, z, 16);
}

static void ghash(const u8 h[16], const u8* aad, u32 aad_len,
                   const u8* ct, u32 ct_len, u8 out[16]) {
    u8 y[16]; memset(y, 0, 16);
    u32 i = 0;
    for (; i + 16 <= aad_len; i += 16) {
        for (int k = 0; k < 16; k++) y[k] ^= aad[i + k];
        ghash_mul(y, y, h);
    }
    if (i < aad_len) {
        u8 block[16]; memset(block, 0, 16);
        memcpy(block, aad + i, aad_len - i);
        for (int k = 0; k < 16; k++) y[k] ^= block[k];
        ghash_mul(y, y, h);
    }
    i = 0;
    for (; i + 16 <= ct_len; i += 16) {
        for (int k = 0; k < 16; k++) y[k] ^= ct[i + k];
        ghash_mul(y, y, h);
    }
    if (i < ct_len) {
        u8 block[16]; memset(block, 0, 16);
        memcpy(block, ct + i, ct_len - i);
        for (int k = 0; k < 16; k++) y[k] ^= block[k];
        ghash_mul(y, y, h);
    }
    u8 lenblock[16]; memset(lenblock, 0, 16);
    u64 aad_bits = (u64)aad_len * 8;
    u64 ct_bits = (u64)ct_len * 8;
    for (int k = 0; k < 8; k++) lenblock[7 - k] = (u8)(aad_bits >> (k * 8));
    for (int k = 0; k < 8; k++) lenblock[15 - k] = (u8)(ct_bits >> (k * 8));
    for (int k = 0; k < 16; k++) y[k] ^= lenblock[k];
    ghash_mul(y, y, h);
    memcpy(out, y, 16);
}

static void incr_counter(u8 ctr[16]) {
    for (int i = 15; i >= 12; i--) {
        if (++ctr[i]) break;
    }
}

static void gcm_ctr_crypt(const aes128_ctx_t* ctx, const u8 j0[16],
                           const u8* in, u32 len, u8* out) {
    u8 ctr[16]; memcpy(ctr, j0, 16);
    incr_counter(ctr);
    u32 off = 0;
    while (off < len) {
        u8 ks[16];
        aes128_encrypt_block(ctx, ctr, ks);
        u32 chunk = (len - off) < 16 ? (len - off) : 16;
        for (u32 k = 0; k < chunk; k++) out[off + k] = (u8)(in[off + k] ^ ks[k]);
        incr_counter(ctr);
        off += chunk;
    }
}

void aes128_gcm_encrypt(const u8 key[16], const u8 iv[12],
                         const u8* aad, u32 aad_len,
                         const u8* pt, u32 pt_len,
                         u8* ct_out, u8 tag_out[16]) {
    aes128_ctx_t ctx;
    aes128_init(&ctx, key);
    u8 h[16]; u8 zero[16]; memset(zero, 0, 16);
    aes128_encrypt_block(&ctx, zero, h);

    u8 j0[16];
    memcpy(j0, iv, 12);
    j0[12] = 0; j0[13] = 0; j0[14] = 0; j0[15] = 1;

    gcm_ctr_crypt(&ctx, j0, pt, pt_len, ct_out);

    u8 s[16];
    ghash(h, aad, aad_len, ct_out, pt_len, s);

    u8 ek_j0[16];
    aes128_encrypt_block(&ctx, j0, ek_j0);
    for (int k = 0; k < 16; k++) tag_out[k] = (u8)(s[k] ^ ek_j0[k]);
}

int aes128_gcm_decrypt(const u8 key[16], const u8 iv[12],
                        const u8* aad, u32 aad_len,
                        const u8* ct, u32 ct_len, const u8 tag_in[16],
                        u8* pt_out) {
    aes128_ctx_t ctx;
    aes128_init(&ctx, key);
    u8 h[16]; u8 zero[16]; memset(zero, 0, 16);
    aes128_encrypt_block(&ctx, zero, h);

    u8 j0[16];
    memcpy(j0, iv, 12);
    j0[12] = 0; j0[13] = 0; j0[14] = 0; j0[15] = 1;

    u8 s[16];
    ghash(h, aad, aad_len, ct, ct_len, s);
    u8 ek_j0[16];
    aes128_encrypt_block(&ctx, j0, ek_j0);
    u8 tag_check[16];
    for (int k = 0; k < 16; k++) tag_check[k] = (u8)(s[k] ^ ek_j0[k]);

    int diff = 0;
    for (int k = 0; k < 16; k++) diff |= (tag_check[k] ^ tag_in[k]);
    if (diff) return 0;

    gcm_ctr_crypt(&ctx, j0, ct, ct_len, pt_out);
    return 1;
}
