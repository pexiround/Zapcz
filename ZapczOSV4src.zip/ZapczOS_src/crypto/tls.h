#ifndef TLS_H
#define TLS_H
#include "io.h"

typedef struct tls_conn tls_conn_t;

tls_conn_t* tls_connect(u32 dst_ip, u16 dst_port, const char* hostname, u32 timeout_ms);
int  tls_send(tls_conn_t* c, const u8* data, u32 len);
int  tls_recv(tls_conn_t* c, u8* buf, u32 bufsize, u32 timeout_ms);
void tls_close(tls_conn_t* c);

#endif
