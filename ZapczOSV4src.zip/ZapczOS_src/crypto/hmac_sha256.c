#include "hmac_sha256.h"
#include "sha256.h"
#include "libc_shim.h"

void hmac_sha256(const u8* key, u32 keylen, const u8* msg, u32 msglen, u8 out[32]) {
    u8 k[64];
    if (keylen > 64) {
        sha256_hash(key, keylen, k);
        memset(k + 32, 0, 32);
    } else {
        memcpy(k, key, keylen);
        memset(k + keylen, 0, 64 - keylen);
    }

    u8 ipad[64], opad[64];
    for (int i = 0; i < 64; i++) {
        ipad[i] = (u8)(k[i] ^ 0x36);
        opad[i] = (u8)(k[i] ^ 0x5c);
    }

    sha256_ctx_t ctx;
    u8 inner[32];
    sha256_init(&ctx);
    sha256_update(&ctx, ipad, 64);
    sha256_update(&ctx, msg, msglen);
    sha256_final(&ctx, inner);

    sha256_init(&ctx);
    sha256_update(&ctx, opad, 64);
    sha256_update(&ctx, inner, 32);
    sha256_final(&ctx, out);
}

#define PRF_LSEED_MAX 256

void tls_prf_sha256(const u8* secret, u32 secretlen,
                     const char* label,
                     const u8* seed, u32 seedlen,
                     u8* out, u32 outlen) {
    u32 labellen = strlen(label);
    u8 lseed[PRF_LSEED_MAX];
    u32 lslen = labellen + seedlen;
    memcpy(lseed, label, labellen);
    memcpy(lseed + labellen, seed, seedlen);

    u8 a[32];
    hmac_sha256(secret, secretlen, lseed, lslen, a);

    u8 buf[32 + PRF_LSEED_MAX];
    u32 produced = 0;
    while (produced < outlen) {
        memcpy(buf, a, 32);
        memcpy(buf + 32, lseed, lslen);
        u8 chunk[32];
        hmac_sha256(secret, secretlen, buf, 32 + lslen, chunk);

        u32 take = outlen - produced;
        if (take > 32) take = 32;
        memcpy(out + produced, chunk, take);
        produced += take;

        u8 a_next[32];
        hmac_sha256(secret, secretlen, a, 32, a_next);
        memcpy(a, a_next, 32);
    }
}
