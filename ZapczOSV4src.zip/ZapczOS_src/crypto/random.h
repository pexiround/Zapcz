#ifndef RANDOM_H
#define RANDOM_H
#include "io.h"

void rng_init(void);
int  rng_have_hw_entropy(void);
void rng_bytes(u8* out, u32 len);

#endif
