#include "x25519.h"
#include "libc_shim.h"

#define FE_LIMBS 8

static void fe_zero(u32* a) { memset(a, 0, FE_LIMBS * 4); }
static void fe_copy(u32* r, const u32* a) { memcpy(r, a, FE_LIMBS * 4); }

static void fe_from_le_bytes(u32* r, const u8* le, u32 len) {
    fe_zero(r);
    for (u32 i = 0; i < len && i < FE_LIMBS * 4; i++) {
        r[i / 4] |= ((u32)le[i]) << ((i % 4) * 8);
    }
}
static void fe_to_le_bytes(const u32* a, u8* out, u32 len) {
    memset(out, 0, len);
    for (u32 i = 0; i < len && i < FE_LIMBS * 4; i++) {
        out[i] = (u8)(a[i / 4] >> ((i % 4) * 8));
    }
}

static int fe_cmp(const u32* a, const u32* b) {
    for (i32 i = FE_LIMBS - 1; i >= 0; i--) {
        if (a[i] != b[i]) return (a[i] > b[i]) ? 1 : -1;
    }
    return 0;
}
static u32 fe_raw_add(u32* r, const u32* a, const u32* b) {
    u64 carry = 0;
    for (u32 i = 0; i < FE_LIMBS; i++) {
        u64 s = (u64)a[i] + (u64)b[i] + carry;
        r[i] = (u32)s;
        carry = s >> 32;
    }
    return (u32)carry;
}
static u32 fe_raw_sub(u32* r, const u32* a, const u32* b) {
    u64 borrow = 0;
    for (u32 i = 0; i < FE_LIMBS; i++) {
        u64 sub = (u64)b[i] + borrow;
        if ((u64)a[i] >= sub) { r[i] = (u32)((u64)a[i] - sub); borrow = 0; }
        else { r[i] = (u32)(((u64)a[i] + ((u64)1 << 32)) - sub); borrow = 1; }
    }
    return (u32)borrow;
}
static void fe_mul_wide(u32* r16, const u32* a, const u32* b) {
    memset(r16, 0, 16 * 4);
    for (u32 i = 0; i < FE_LIMBS; i++) {
        u64 carry = 0;
        for (u32 j = 0; j < FE_LIMBS; j++) {
            u64 prod = (u64)a[i] * (u64)b[j] + (u64)r16[i + j] + carry;
            r16[i + j] = (u32)prod;
            carry = prod >> 32;
        }
        u32 k = i + FE_LIMBS;
        while (carry) {
            u64 sum = (u64)r16[k] + carry;
            r16[k] = (u32)sum;
            carry = sum >> 32;
            k++;
        }
    }
}
static int fe_bit_wide(const u32* a, u32 bit) {
    u32 li = bit / 32, bi = bit % 32;
    if (li >= 16) return 0;
    return (int)((a[li] >> bi) & 1u);
}
static int fe_cmp_n(const u32* a, const u32* b, u32 n) {
    for (i32 i = (i32)n - 1; i >= 0; i--) { if (a[i] != b[i]) return a[i] > b[i] ? 1 : -1; }
    return 0;
}
static void fe_sub_n(u32* r, const u32* a, const u32* b, u32 n) {
    u64 borrow = 0;
    for (u32 i = 0; i < n; i++) {
        u64 sub = (u64)b[i] + borrow;
        if ((u64)a[i] >= sub) { r[i] = (u32)((u64)a[i] - sub); borrow = 0; }
        else { r[i] = (u32)(((u64)a[i] + ((u64)1 << 32)) - sub); borrow = 1; }
    }
}

static u32 P[FE_LIMBS];
static int p_inited = 0;
static void init_p(void) {
    for (int i = 0; i < FE_LIMBS; i++) P[i] = 0xFFFFFFFFu;
    P[FE_LIMBS - 1] = 0x7FFFFFFFu;
    P[0] = 0xFFFFFFEDu;
    p_inited = 1;
}

static void fe_mod_wide(const u32* wide16, u32* result) {
    u32 rem[FE_LIMBS + 1];
    u32 mext[FE_LIMBS + 1];
    memset(rem, 0, (FE_LIMBS + 1) * 4);
    memcpy(mext, P, FE_LIMBS * 4);
    mext[FE_LIMBS] = 0;
    for (i32 bit = 16 * 32 - 1; bit >= 0; bit--) {
        u32 carry = 0;
        for (u32 i = 0; i <= FE_LIMBS; i++) {
            u32 nc = (rem[i] >> 31) & 1u;
            rem[i] = (u32)((rem[i] << 1) | carry);
            carry = nc;
        }
        if (fe_bit_wide(wide16, (u32)bit)) rem[0] |= 1u;
        if (fe_cmp_n(rem, mext, FE_LIMBS + 1) >= 0) fe_sub_n(rem, rem, mext, FE_LIMBS + 1);
    }
    memcpy(result, rem, FE_LIMBS * 4);
}

static void fe_mulmod(u32* r, const u32* a, const u32* b) {
    u32 w[16];
    fe_mul_wide(w, a, b);
    fe_mod_wide(w, r);
}
static void fe_sqmod(u32* r, const u32* a) { fe_mulmod(r, a, a); }
static void fe_addmod(u32* r, const u32* a, const u32* b) {
    u32 t[FE_LIMBS];
    u32 c = fe_raw_add(t, a, b);
    if (c || fe_cmp(t, P) >= 0) fe_raw_sub(t, t, P);
    fe_copy(r, t);
}
static void fe_submod(u32* r, const u32* a, const u32* b) {
    u32 t[FE_LIMBS];
    if (fe_cmp(a, b) >= 0) { fe_raw_sub(t, a, b); }
    else { u32 tmp[FE_LIMBS]; fe_raw_add(tmp, a, P); fe_raw_sub(t, tmp, b); }
    fe_copy(r, t);
}
static void fe_invert(u32* r, const u32* a) {
    u32 e[FE_LIMBS];
    fe_copy(e, P);
    u32 two[FE_LIMBS]; fe_zero(two); two[0] = 2;
    fe_raw_sub(e, e, two);
    u32 acc[FE_LIMBS]; fe_zero(acc); acc[0] = 1;
    for (i32 bit = FE_LIMBS * 32 - 1; bit >= 0; bit--) {
        u32 sq[FE_LIMBS]; fe_sqmod(sq, acc); fe_copy(acc, sq);
        if ((e[bit / 32] >> (bit % 32)) & 1u) {
            u32 mu[FE_LIMBS]; fe_mulmod(mu, acc, a); fe_copy(acc, mu);
        }
    }
    fe_copy(r, acc);
}
static void fe_cswap(int swap, u32* a, u32* b) {
    u32 mask = (u32)(-(i32)swap);
    for (int i = 0; i < FE_LIMBS; i++) {
        u32 t = mask & (a[i] ^ b[i]);
        a[i] ^= t; b[i] ^= t;
    }
}
static void clamp_scalar(u8* k) {
    k[0] &= 248;
    k[31] &= 127;
    k[31] |= 64;
}

void x25519_scalarmult(u8 out[32], const u8 scalar_in[32], const u8 point_in[32]) {
    if (!p_inited) init_p();

    u8 k[32]; memcpy(k, scalar_in, 32); clamp_scalar(k);
    u8 u_bytes[32]; memcpy(u_bytes, point_in, 32);
    u_bytes[31] &= 127;

    u32 x1[FE_LIMBS]; fe_from_le_bytes(x1, u_bytes, 32);
    u32 x2[FE_LIMBS]; fe_zero(x2); x2[0] = 1;
    u32 z2[FE_LIMBS]; fe_zero(z2);
    u32 x3[FE_LIMBS]; fe_copy(x3, x1);
    u32 z3[FE_LIMBS]; fe_zero(z3); z3[0] = 1;
    int swap = 0;
    u32 a24[FE_LIMBS]; fe_zero(a24); a24[0] = 121665;

    for (i32 t = 254; t >= 0; t--) {
        int kt = (k[t / 8] >> (t % 8)) & 1;
        swap ^= kt;
        fe_cswap(swap, x2, x3);
        fe_cswap(swap, z2, z3);
        swap = kt;

        u32 A[FE_LIMBS], AA[FE_LIMBS], B[FE_LIMBS], BB[FE_LIMBS], E[FE_LIMBS];
        u32 C[FE_LIMBS], D[FE_LIMBS], DA[FE_LIMBS], CB[FE_LIMBS];
        fe_addmod(A, x2, z2); fe_sqmod(AA, A);
        fe_submod(B, x2, z2); fe_sqmod(BB, B);
        fe_submod(E, AA, BB);
        fe_addmod(C, x3, z3);
        fe_submod(D, x3, z3);
        fe_mulmod(DA, D, A);
        fe_mulmod(CB, C, B);

        u32 sum1[FE_LIMBS], diff1[FE_LIMBS], sqd[FE_LIMBS];
        fe_addmod(sum1, DA, CB);
        fe_sqmod(x3, sum1);
        fe_submod(diff1, DA, CB);
        fe_sqmod(sqd, diff1);
        fe_mulmod(z3, x1, sqd);

        fe_mulmod(x2, AA, BB);
        u32 a24E[FE_LIMBS], sumAABB[FE_LIMBS];
        fe_mulmod(a24E, a24, E);
        fe_addmod(sumAABB, AA, a24E);
        fe_mulmod(z2, E, sumAABB);
    }
    fe_cswap(swap, x2, x3);
    fe_cswap(swap, z2, z3);

    u32 zinv[FE_LIMBS]; fe_invert(zinv, z2);
    u32 res[FE_LIMBS]; fe_mulmod(res, x2, zinv);
    fe_to_le_bytes(res, out, 32);
}

void x25519_derive_public(u8 out_pub[32], const u8 scalar[32]) {
    u8 basepoint[32];
    memset(basepoint, 0, 32);
    basepoint[0] = 9;
    x25519_scalarmult(out_pub, scalar, basepoint);
}
