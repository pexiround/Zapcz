#include "tls.h"
#include "pit.h"
#include "net.h"
#include "libc_shim.h"
#include "sha256.h"
#include "hmac_sha256.h"
#include "aes.h"
#include "aes_gcm.h"
#include "x25519.h"
#include "p256.h"
#include "random.h"
#include "rsa_pub.h"
#include "x509_rsa.h"

#define TLS_REC_CHANGE_CIPHER_SPEC 20
#define TLS_REC_ALERT 21
#define TLS_REC_HANDSHAKE 22
#define TLS_REC_APPLICATION_DATA 23

#define TLS_HS_CLIENT_HELLO 1
#define TLS_HS_SERVER_HELLO 2
#define TLS_HS_CERTIFICATE 11
#define TLS_HS_SERVER_KEY_EXCHANGE 12
#define TLS_HS_SERVER_HELLO_DONE 14
#define TLS_HS_CLIENT_KEY_EXCHANGE 16
#define TLS_HS_FINISHED 20

#define TLS_CIPHER_ECDHE_RSA_AES128_GCM_SHA256 0xC02F
#define TLS_CIPHER_RSA_AES128_CBC_SHA256 0x003C
#define TLS_CIPHER_ECDHE_ECDSA_AES128_GCM_SHA256 0xC02B

#define TLS_MAX_RECORD_PLAIN 16384
#define TLS_MAX_RECORD_CIPHER (TLS_MAX_RECORD_PLAIN + 32 + 16 + 16)
#define TLS_HS_BUF_SIZE 24576

struct tls_conn {
    tcp_conn_t* tcp;
    int active;
    int read_cipher_active;
    int write_cipher_active;
    int cipher_is_gcm;
    int cipher_is_ecdsa;

    u8 client_random[32];
    u8 server_random[32];

    aes128_ctx_t client_write_ctx;
    aes128_ctx_t server_write_ctx;
    u8 client_write_mac[32];
    u8 server_write_mac[32];

    u8 client_write_gcm_key[16];
    u8 server_write_gcm_key[16];
    u8 client_write_iv[4];
    u8 server_write_iv[4];

    u64 client_seq;
    u64 server_seq;

    sha256_ctx_t transcript;

    u8 hs_buf[TLS_HS_BUF_SIZE];
    u32 hs_len;
    u32 hs_pos;

    u8 app_buf[TLS_MAX_RECORD_PLAIN];
    u32 app_len;
    u32 app_pos;
};

static struct tls_conn g_tls;
static u8 g_body_scratch[TLS_MAX_RECORD_CIPHER];
static u8 g_dec_scratch[TLS_MAX_RECORD_CIPHER];
static u8 g_send_pt_scratch[TLS_MAX_RECORD_CIPHER];
static u8 g_send_ct_scratch[TLS_MAX_RECORD_CIPHER];

static int tcp_read_exact(tcp_conn_t* tcp, u8* buf, u32 need, u32 timeout_ms) {
    u32 got = 0;
    int idle = 0;
    while (got < need) {
        int n = tcp_recv(tcp, buf + got, need - got, timeout_ms);
        if (n > 0) {
            got += (u32)n;
            idle = 0;
        } else if (n == 0) {
            return 0;
        } else {
            idle++;
            if (idle > 20) return -1;
        }
    }
    return 1;
}

static void compute_mac(const u8 mac_key[32], u64 seq, u8 type, u32 data_len,
                         const u8* data, u8 out[32]) {
    u8 seqbuf[8];
    for (int i = 0; i < 8; i++) seqbuf[i] = (u8)(seq >> (56 - 8 * i));
    u8 hdr[5];
    hdr[0] = type; hdr[1] = 0x03; hdr[2] = 0x03;
    hdr[3] = (u8)(data_len >> 8); hdr[4] = (u8)data_len;

    u8 k[64];
    memcpy(k, mac_key, 32);
    memset(k + 32, 0, 32);
    u8 ipad[64], opad[64];
    for (int i = 0; i < 64; i++) {
        ipad[i] = (u8)(k[i] ^ 0x36);
        opad[i] = (u8)(k[i] ^ 0x5c);
    }

    sha256_ctx_t ctx;
    u8 inner[32];
    sha256_init(&ctx);
    sha256_update(&ctx, ipad, 64);
    sha256_update(&ctx, seqbuf, 8);
    sha256_update(&ctx, hdr, 5);
    sha256_update(&ctx, data, data_len);
    sha256_final(&ctx, inner);

    sha256_init(&ctx);
    sha256_update(&ctx, opad, 64);
    sha256_update(&ctx, inner, 32);
    sha256_final(&ctx, out);
}

static void build_gcm_aad(u64 seq, u8 type, u32 plain_len, u8 aad[13]) {
    for (int i = 0; i < 8; i++) aad[i] = (u8)(seq >> (56 - 8 * i));
    aad[8] = type;
    aad[9] = 0x03; aad[10] = 0x03;
    aad[11] = (u8)(plain_len >> 8);
    aad[12] = (u8)plain_len;
}

static int read_record(struct tls_conn* c, u8* out_type, u8* plain_out, u32* plain_len, u32 timeout_ms) {
    u8 hdr[5];
    int rc = tcp_read_exact(c->tcp, hdr, 5, timeout_ms);
    if (rc <= 0) return rc;
    u8 type = hdr[0];
    u32 rlen = ((u32)hdr[3] << 8) | hdr[4];
    if (rlen == 0 || rlen > TLS_MAX_RECORD_CIPHER) return -1;

    rc = tcp_read_exact(c->tcp, g_body_scratch, rlen, timeout_ms);
    if (rc <= 0) return rc;

    if (!c->read_cipher_active) {
        if (rlen > TLS_MAX_RECORD_PLAIN) return -1;
        memcpy(plain_out, g_body_scratch, rlen);
        *plain_len = rlen;
        *out_type = type;
        return 1;
    }

    if (c->cipher_is_gcm) {
        if (rlen < 8 + 16) {
return -1; }
        const u8* nonce_explicit = g_body_scratch;
        const u8* ct = g_body_scratch + 8;
        u32 ct_len = rlen - 8 - 16;
        const u8* tag = g_body_scratch + 8 + ct_len;
        if (ct_len > TLS_MAX_RECORD_PLAIN) {
return -1; }

        u8 nonce[12];
        memcpy(nonce, c->server_write_iv, 4);
        memcpy(nonce + 4, nonce_explicit, 8);

        u8 aad[13];
        build_gcm_aad(c->server_seq, type, ct_len, aad);

        watchdog_heartbeat("tls: decrypting");
        if (!aes128_gcm_decrypt(c->server_write_gcm_key, nonce, aad, 13, ct, ct_len, tag, g_dec_scratch)) {
            return -1;
        }
c->server_seq++;
        memcpy(plain_out, g_dec_scratch, ct_len);
        *plain_len = ct_len;
        *out_type = type;
        return 1;
    }

    if (rlen < 16 + 32 + 1) return -1;
    const u8* iv = g_body_scratch;
    const u8* ct = g_body_scratch + 16;
    u32 ct_len = rlen - 16;
    if (ct_len % 16 != 0) return -1;

    aes128_cbc_decrypt(&c->server_write_ctx, iv, ct, ct_len, g_dec_scratch);

    u8 padlen = g_dec_scratch[ct_len - 1];
    if ((u32)padlen + 1 > ct_len) return -1;
    u32 data_and_mac_len = ct_len - padlen - 1;
    if (data_and_mac_len < 32) return -1;
    u32 data_len = data_and_mac_len - 32;
    if (data_len > TLS_MAX_RECORD_PLAIN) return -1;
    const u8* mac_recv = g_dec_scratch + data_len;

    u8 mac_calc[32];
    compute_mac(c->server_write_mac, c->server_seq, type, data_len, g_dec_scratch, mac_calc);
    if (memcmp(mac_calc, mac_recv, 32) != 0) return -1;

    c->server_seq++;
    memcpy(plain_out, g_dec_scratch, data_len);
    *plain_len = data_len;
    *out_type = type;
    return 1;
}

static int write_record(struct tls_conn* c, u8 type, const u8* data, u32 len) {
    if (len > TLS_MAX_RECORD_PLAIN) return 0;

    if (!c->write_cipher_active) {
        u8 hdr[5];
        hdr[0] = type; hdr[1] = 0x03; hdr[2] = 0x03;
        hdr[3] = (u8)(len >> 8); hdr[4] = (u8)len;
        if (tcp_send(c->tcp, hdr, 5) != 5) return 0;
        if (len > 0 && tcp_send(c->tcp, data, len) != (int)len) return 0;
        return 1;
    }

    if (c->cipher_is_gcm) {
        u8 nonce_explicit[8];
        for (int i = 0; i < 8; i++) nonce_explicit[i] = (u8)(c->client_seq >> (56 - 8 * i));
        u8 nonce[12];
        memcpy(nonce, c->client_write_iv, 4);
        memcpy(nonce + 4, nonce_explicit, 8);

        u8 aad[13];
        build_gcm_aad(c->client_seq, type, len, aad);

        u8 tag[16];
        aes128_gcm_encrypt(c->client_write_gcm_key, nonce, aad, 13, data, len, g_send_ct_scratch, tag);

        u8 hdr[5];
        u32 rlen = 8 + len + 16;
        hdr[0] = type; hdr[1] = 0x03; hdr[2] = 0x03;
        hdr[3] = (u8)(rlen >> 8); hdr[4] = (u8)rlen;

        if (tcp_send(c->tcp, hdr, 5) != 5) return 0;
        if (tcp_send(c->tcp, nonce_explicit, 8) != 8) return 0;
        if (len > 0 && tcp_send(c->tcp, g_send_ct_scratch, len) != (int)len) return 0;
        if (tcp_send(c->tcp, tag, 16) != 16) return 0;

        c->client_seq++;
        return 1;
    }

    u8 mac[32];
    compute_mac(c->client_write_mac, c->client_seq, type, len, data, mac);

    memcpy(g_send_pt_scratch, data, len);
    memcpy(g_send_pt_scratch + len, mac, 32);
    u32 base = len + 32;
    u8 padlen = (u8)(15 - (base % 16));
    for (u32 i = 0; i <= padlen; i++) g_send_pt_scratch[base + i] = padlen;
    u32 total = base + padlen + 1;

    u8 iv[16];
    rng_bytes(iv, 16);
    aes128_cbc_encrypt(&c->client_write_ctx, iv, g_send_pt_scratch, total, g_send_ct_scratch);

    u8 hdr[5];
    u32 rlen = 16 + total;
    hdr[0] = type; hdr[1] = 0x03; hdr[2] = 0x03;
    hdr[3] = (u8)(rlen >> 8); hdr[4] = (u8)rlen;

    if (tcp_send(c->tcp, hdr, 5) != 5) return 0;
    if (tcp_send(c->tcp, iv, 16) != 16) return 0;
    if (tcp_send(c->tcp, g_send_ct_scratch, total) != (int)total) return 0;

    c->client_seq++;
    return 1;
}

static int hs_fill(struct tls_conn* c, u32 timeout_ms) {
    u8 type;
    u32 plen;
    int rc = read_record(c, &type, g_dec_scratch, &plen, timeout_ms);
    if (rc <= 0) return rc;
    if (type != TLS_REC_HANDSHAKE) {
        if (type == TLS_REC_ALERT) return -2;
        return -1;
    }
    if (c->hs_len + plen > TLS_HS_BUF_SIZE) return -1;
    memcpy(c->hs_buf + c->hs_len, g_dec_scratch, plen);
    c->hs_len += plen;
    return 1;
}

static int hs_next_message(struct tls_conn* c, u8* out_type, const u8** out_body,
                            u32* out_body_len, u32 timeout_ms) {
    while (c->hs_len - c->hs_pos < 4) {
        int rc = hs_fill(c, timeout_ms);
        if (rc <= 0) return rc;
    }
    u8 type = c->hs_buf[c->hs_pos];
    u32 body_len = ((u32)c->hs_buf[c->hs_pos + 1] << 16) |
                   ((u32)c->hs_buf[c->hs_pos + 2] << 8) |
                   (u32)c->hs_buf[c->hs_pos + 3];
    while (c->hs_len - c->hs_pos < 4 + body_len) {
        int rc = hs_fill(c, timeout_ms);
        if (rc <= 0) return rc;
    }

    sha256_update(&c->transcript, c->hs_buf + c->hs_pos, 4 + body_len);

    *out_type = type;
    *out_body = c->hs_buf + c->hs_pos + 4;
    *out_body_len = body_len;
    c->hs_pos += 4 + body_len;
    return 1;
}

static int hs_send_message(struct tls_conn* c, u8 type, const u8* body, u32 body_len) {
    u8 hdr[4];
    hdr[0] = type;
    hdr[1] = (u8)(body_len >> 16);
    hdr[2] = (u8)(body_len >> 8);
    hdr[3] = (u8)body_len;

    sha256_update(&c->transcript, hdr, 4);
    sha256_update(&c->transcript, body, body_len);

    u8 full_msg[4 + 1024];
    if (body_len > 1020) return 0;
    memcpy(full_msg, hdr, 4);
    if (body_len > 0) memcpy(full_msg + 4, body, body_len);
    return write_record(c, TLS_REC_HANDSHAKE, full_msg, 4 + body_len);
}

tls_conn_t* tls_connect(u32 dst_ip, u16 dst_port, const char* hostname, u32 timeout_ms) {
    struct tls_conn* c = &g_tls;
    memset(c, 0, sizeof(*c));

c->tcp = tcp_connect(dst_ip, dst_port, timeout_ms);
    if (!c->tcp) {
return 0; }
    c->active = 1;
sha256_init(&c->transcript);
    rng_bytes(c->client_random, 32);

    u32 hostlen = strlen(hostname);
    u8 hello[512];
    u32 p = 0;
    hello[p++] = 0x03; hello[p++] = 0x03;
    memcpy(hello + p, c->client_random, 32); p += 32;
    hello[p++] = 0x00;

    hello[p++] = 0x00; hello[p++] = 0x06;
    hello[p++] = 0xC0; hello[p++] = 0x2B;
    hello[p++] = 0xC0; hello[p++] = 0x2F;
    hello[p++] = 0x00; hello[p++] = 0x3C;

    hello[p++] = 0x01;
    hello[p++] = 0x00;

    u32 ext_len = 9 + hostlen + 12 + 10 + 6;
    hello[p++] = (u8)(ext_len >> 8); hello[p++] = (u8)ext_len;

    hello[p++] = 0x00; hello[p++] = 0x00;
    u32 sni_ext_data_len = 5 + hostlen;
    hello[p++] = (u8)(sni_ext_data_len >> 8); hello[p++] = (u8)sni_ext_data_len;
    u32 sn_list_len = 3 + hostlen;
    hello[p++] = (u8)(sn_list_len >> 8); hello[p++] = (u8)sn_list_len;
    hello[p++] = 0x00;
    hello[p++] = (u8)(hostlen >> 8); hello[p++] = (u8)hostlen;
    memcpy(hello + p, hostname, hostlen); p += hostlen;

    hello[p++] = 0x00; hello[p++] = 0x0D;
    hello[p++] = 0x00; hello[p++] = 0x08;
    hello[p++] = 0x00; hello[p++] = 0x06;
    hello[p++] = 0x04; hello[p++] = 0x03;
    hello[p++] = 0x04; hello[p++] = 0x01;
    hello[p++] = 0x02; hello[p++] = 0x01;

    hello[p++] = 0x00; hello[p++] = 0x0A;
    hello[p++] = 0x00; hello[p++] = 0x06;
    hello[p++] = 0x00; hello[p++] = 0x04;
    hello[p++] = 0x00; hello[p++] = 0x1D;
    hello[p++] = 0x00; hello[p++] = 0x17;

    hello[p++] = 0x00; hello[p++] = 0x0B;
    hello[p++] = 0x00; hello[p++] = 0x02;
    hello[p++] = 0x01; hello[p++] = 0x00;

    if (!hs_send_message(c, TLS_HS_CLIENT_HELLO, hello, p)) goto fail;
u8 mtype; const u8* mbody; u32 mlen;
    u16 selected_suite = 0;

    if (!hs_next_message(c, &mtype, &mbody, &mlen, timeout_ms)) {
goto fail; }
    if (mtype != TLS_HS_SERVER_HELLO || mlen < 2 + 32 + 1) {
goto fail; }
memcpy(c->server_random, mbody + 2, 32);
    {
        u32 sp = 2 + 32;
        u8 sidlen = mbody[sp]; sp += 1 + sidlen;
        if (sp + 3 > mlen) goto fail;
        selected_suite = (u16)((mbody[sp] << 8) | mbody[sp + 1]);
        if (selected_suite != TLS_CIPHER_ECDHE_RSA_AES128_GCM_SHA256 &&
            selected_suite != TLS_CIPHER_ECDHE_ECDSA_AES128_GCM_SHA256 &&
            selected_suite != TLS_CIPHER_RSA_AES128_CBC_SHA256) goto fail;
        c->cipher_is_ecdsa = (selected_suite == TLS_CIPHER_ECDHE_ECDSA_AES128_GCM_SHA256);
        c->cipher_is_gcm = (selected_suite == TLS_CIPHER_ECDHE_RSA_AES128_GCM_SHA256) || c->cipher_is_ecdsa;
    }

    if (!hs_next_message(c, &mtype, &mbody, &mlen, timeout_ms)) {
goto fail; }
    if (mtype != TLS_HS_CERTIFICATE || mlen < 3 + 3) {
goto fail; }
u32 cert_list_len = ((u32)mbody[0] << 16) | ((u32)mbody[1] << 8) | mbody[2];
    if (3 + cert_list_len > mlen) goto fail;
    u32 cert0_len = ((u32)mbody[3] << 16) | ((u32)mbody[4] << 8) | mbody[5];
    if (6 + cert0_len > mlen) goto fail;
    const u8* cert0 = mbody + 6;

    const u8* modulus; u32 modulus_len = 0; u32 pub_exp = 0;
    u8 modulus_buf[RSA_MAX_MODULUS_BYTES];
    u8 ec_point[65];
    if (c->cipher_is_ecdsa) {
        if (!x509_extract_ec_point(cert0, cert0_len, ec_point)) goto fail;
    } else {
        if (!x509_extract_rsa_pubkey(cert0, cert0_len, &modulus, &modulus_len, &pub_exp)) goto fail;
        while (modulus_len > 1 && modulus[0] == 0) { modulus++; modulus_len--; }
        if (modulus_len > RSA_MAX_MODULUS_BYTES) goto fail;
        memcpy(modulus_buf, modulus, modulus_len);
    }

    u8 premaster[48];
    u32 premaster_len;

    if (c->cipher_is_gcm) {
        if (!hs_next_message(c, &mtype, &mbody, &mlen, timeout_ms)) {
goto fail; }
        if (mtype != TLS_HS_SERVER_KEY_EXCHANGE || mlen < 4) {
goto fail; }

        if (mbody[0] != 0x03) {
goto fail; }
        u16 named_curve = (u16)((mbody[1] << 8) | mbody[2]);
        int is_p256 = (named_curve == 0x0017);
        if (named_curve != 0x001D && named_curve != 0x0017) {
goto fail; }
        u32 expect_pub = is_p256 ? 65 : 32;
        u8 srv_pub_len = mbody[3];
        if (srv_pub_len != expect_pub || 4 + expect_pub > mlen) {
goto fail; }
        const u8* srv_pub = mbody + 4;
u32 signed_params_len = 4 + expect_pub;
        if (signed_params_len + 4 > mlen) {
goto fail; }
        u16 sig_hash_alg = (u16)((mbody[signed_params_len] << 8) | mbody[signed_params_len + 1]);
        u16 sig_len = (u16)((mbody[signed_params_len + 2] << 8) | mbody[signed_params_len + 3]);
        if (signed_params_len + 4 + sig_len != mlen) {
goto fail; }
        const u8* sig = mbody + signed_params_len + 4;

        u8 signed_data[32 + 32 + 4 + 65];
        if (64 + signed_params_len > sizeof(signed_data)) goto fail;
        memcpy(signed_data, c->client_random, 32);
        memcpy(signed_data + 32, c->server_random, 32);
        memcpy(signed_data + 64, mbody, signed_params_len);
        u8 signed_hash[32];
        sha256_hash(signed_data, 64 + signed_params_len, signed_hash);

        if (c->cipher_is_ecdsa) {
            if (sig_hash_alg != 0x0403) goto fail;
            if (sig_len < 8 || sig[0] != 0x30) goto fail;
            u32 si = 2;
            if (sig[si++] != 0x02) goto fail;
            u32 rl = sig[si++]; const u8* rp = sig + si; si += rl;
            if (si + 2 > sig_len || sig[si++] != 0x02) goto fail;
            u32 sl = sig[si++]; const u8* sp = sig + si;
            if (si + sl > (u32)sig_len) goto fail;
            if (!p256_ecdsa_verify(ec_point, 65, signed_hash, rp, rl, sp, sl)) {
goto fail;
            }
        } else {
            if (sig_hash_alg != 0x0401) {
goto fail; }
            if (!rsa_pub_verify_pkcs1_sha256(modulus_buf, modulus_len, pub_exp, signed_hash, sig, sig_len)) {
goto fail;
            }
        }
        u8 our_pub[65]; u32 our_pub_len;
        u8 our_priv[32];
        rng_bytes(our_priv, 32);
        if (is_p256) {
            p256_ecdh_keypair(our_priv, our_pub);
            our_pub_len = 65;
            if (!p256_ecdh_shared(our_priv, srv_pub, premaster)) {
goto fail; }
            premaster_len = 32;
        } else {
            x25519_derive_public(our_pub, our_priv);
            our_pub_len = 32;
            x25519_scalarmult(premaster, our_priv, srv_pub);
            premaster_len = 32;
        }

        if (!hs_next_message(c, &mtype, &mbody, &mlen, timeout_ms)) {
goto fail; }
        if (mtype != TLS_HS_SERVER_HELLO_DONE) {
goto fail; }
u8 cke_body[1 + 65];
        cke_body[0] = (u8)our_pub_len;
        memcpy(cke_body + 1, our_pub, our_pub_len);
        if (!hs_send_message(c, TLS_HS_CLIENT_KEY_EXCHANGE, cke_body, 1 + our_pub_len)) {
goto fail; }
} else {
        if (!hs_next_message(c, &mtype, &mbody, &mlen, timeout_ms)) goto fail;
        if (mtype != TLS_HS_SERVER_HELLO_DONE) goto fail;

        premaster[0] = 0x03; premaster[1] = 0x03;
        rng_bytes(premaster + 2, 46);
        premaster_len = 48;

        u8 encrypted_pm[RSA_MAX_MODULUS_BYTES];
        memset(encrypted_pm, 0, sizeof(encrypted_pm));
        if (!rsa_pub_encrypt_pkcs1(modulus_buf, modulus_len, pub_exp, premaster, 48, encrypted_pm)) goto fail;

        u8 cke_body[2 + RSA_MAX_MODULUS_BYTES];
        cke_body[0] = (u8)(modulus_len >> 8);
        cke_body[1] = (u8)modulus_len;
        memcpy(cke_body + 2, encrypted_pm, modulus_len);
        if (!hs_send_message(c, TLS_HS_CLIENT_KEY_EXCHANGE, cke_body, 2 + modulus_len)) goto fail;
    }

    u8 seed[64];
    memcpy(seed, c->client_random, 32);
    memcpy(seed + 32, c->server_random, 32);
    u8 master_secret[48];
    tls_prf_sha256(premaster, premaster_len, "master secret", seed, 64, master_secret, 48);

    u8 srv_cli_seed[64];
    memcpy(srv_cli_seed, c->server_random, 32);
    memcpy(srv_cli_seed + 32, c->client_random, 32);

    if (c->cipher_is_gcm) {
        u8 key_block[40];
        tls_prf_sha256(master_secret, 48, "key expansion", srv_cli_seed, 64, key_block, 40);
        memcpy(c->client_write_gcm_key, key_block, 16);
        memcpy(c->server_write_gcm_key, key_block + 16, 16);
        memcpy(c->client_write_iv, key_block + 32, 4);
        memcpy(c->server_write_iv, key_block + 36, 4);
    } else {
        u8 key_block[96];
        tls_prf_sha256(master_secret, 48, "key expansion", srv_cli_seed, 64, key_block, 96);
        memcpy(c->client_write_mac, key_block, 32);
        memcpy(c->server_write_mac, key_block + 32, 32);
        aes128_init(&c->client_write_ctx, key_block + 64);
        aes128_init(&c->server_write_ctx, key_block + 80);
    }

    if (!write_record(c, TLS_REC_CHANGE_CIPHER_SPEC, (const u8[]){0x01}, 1)) {
goto fail; }
c->write_cipher_active = 1;
    c->client_seq = 0;

    sha256_ctx_t t1_copy = c->transcript;
    u8 t1_hash[32];
    sha256_final(&t1_copy, t1_hash);

    u8 client_verify[12];
    tls_prf_sha256(master_secret, 48, "client finished", t1_hash, 32, client_verify, 12);

    if (!hs_send_message(c, TLS_HS_FINISHED, client_verify, 12)) {
goto fail; }
sha256_ctx_t t2_copy = c->transcript;
    u8 t2_hash[32];
    sha256_final(&t2_copy, t2_hash);

    {
        u8 dummy_type;
        u32 plen;
        int rc = read_record(c, &dummy_type, g_dec_scratch, &plen, timeout_ms);
        if (rc <= 0) {
goto fail; }
        if (dummy_type != TLS_REC_CHANGE_CIPHER_SPEC) {
goto fail; }
c->server_seq = 0;
        c->read_cipher_active = 1;
    }

    if (!hs_next_message(c, &mtype, &mbody, &mlen, timeout_ms)) {
goto fail; }
    if (mtype != TLS_HS_FINISHED || mlen != 12) {
goto fail; }
u8 server_verify_expected[12];
    tls_prf_sha256(master_secret, 48, "server finished", t2_hash, 32, server_verify_expected, 12);
    if (memcmp(mbody, server_verify_expected, 12) != 0) {
goto fail; }
return c;

fail:
    if (c->tcp) tcp_close(c->tcp);
    c->active = 0;
    return 0;
}

int tls_send(tls_conn_t* conn, const u8* data, u32 len) {
    struct tls_conn* c = conn;
    if (!c || !c->active) {
return 0; }
u32 sent = 0;
    while (sent < len) {
        u32 chunk = len - sent;
        if (chunk > TLS_MAX_RECORD_PLAIN) chunk = TLS_MAX_RECORD_PLAIN;
        if (!write_record(c, TLS_REC_APPLICATION_DATA, data + sent, chunk)) return (int)sent;
        sent += chunk;
    }
return (int)sent;
}

int tls_recv(tls_conn_t* conn, u8* buf, u32 bufsize, u32 timeout_ms) {
    struct tls_conn* c = conn;
    if (!c || !c->active) {
return -1; }
if (c->app_pos < c->app_len) {
        u32 avail = c->app_len - c->app_pos;
        u32 n = (avail < bufsize) ? avail : bufsize;
        memcpy(buf, c->app_buf + c->app_pos, n);
        c->app_pos += n;
        return (int)n;
    }

    u8 type;
    u32 plen;
    int rc = read_record(c, &type, g_dec_scratch, &plen, timeout_ms);
    if (rc < 0) {
return -1; }
    if (rc == 0) {
return 0; }
    if (type == TLS_REC_ALERT) {
return 0; }
    if (type != TLS_REC_APPLICATION_DATA) {
return -1; }

    memcpy(c->app_buf, g_dec_scratch, plen);
    c->app_len = plen;
    c->app_pos = 0;

    u32 n = (plen < bufsize) ? plen : bufsize;
    memcpy(buf, c->app_buf, n);
    c->app_pos = n;
return (int)n;
}

void tls_close(tls_conn_t* conn) {
    struct tls_conn* c = conn;
    if (!c || !c->active) return;
    tcp_close(c->tcp);
    c->active = 0;
}
