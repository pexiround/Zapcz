#include "tui_install.h"
#include "graphics.h"
#include "keyboard.h"
#include "ata.h"
#include "fat32.h"
#include "kernel.h"
#include "mm.h"
#include "util.h"
#include "libc_shim.h"

extern void watchdog_heartbeat(const char* label);

#define COL_BG        RGB(18, 20, 28)
#define COL_BAR       RGB(53, 132, 228)
#define COL_BARTEXT   RGB(255, 255, 255)
#define COL_PANEL     RGB(28, 32, 42)
#define COL_PANEL_HI  RGB(40, 46, 60)
#define COL_BORDER    RGB(64, 72, 92)
#define COL_TEXT      RGB(228, 231, 240)
#define COL_DIM       RGB(150, 156, 172)
#define COL_FAINT     RGB(105, 112, 130)
#define COL_WARN      RGB(232, 128, 96)
#define COL_GOOD      RGB(96, 202, 122)
#define COL_SELBG     RGB(53, 132, 228)
#define COL_SELTX     RGB(255, 255, 255)

enum {
    ST_WELCOME = 0,
    ST_DISK,
    ST_TARGET,
    ST_DONE,
    ST_ERROR
};

#define TUI_MAX_IMG (32u * 1024u * 1024u)

static int   g_state = ST_WELCOME;
static int   g_disk_list[ATA_MAX_DRIVES];
static int   g_disk_count = 0;
static int   g_disk_sel = 0;
static int   g_target = -1;

static u8*   g_src = 0;
static u32   g_src_size = 0;
static char  g_src_name[24] = "";
static int   g_src_ok = 0;
static int   g_src_from_fat = 0;

static char  g_confirm[8] = "";
static u32   g_confirm_len = 0;

static u32   g_total_sectors = 0;
static u32   g_cur_sectors = 0;
static u32   g_part_sectors = 0;
static char  g_err[64] = "";

static i32 SW(void) { return (i32)gfx.width; }
static i32 SH(void) { return (i32)gfx.height; }

static void tstr(i32 x, i32 y, const char* s, color_t fg) { gfx_string(x, y, s, fg, COL_BG, 0); }

static void tstr_c(i32 cx, i32 y, const char* s, color_t fg) {
    i32 w = gfx_string_width(s);
    gfx_string(cx - w / 2, y, s, fg, COL_BG, 0);
}

static int name_is_img_iso(const char* name) {
    u32 n = str_len(name);
    if (n >= 4 && name[n-4] == '.') {
        char a = name[n-3], b = name[n-2], c = name[n-1];
        if ((a=='I'||a=='i') && (b=='M'||b=='m') && (c=='G'||c=='g')) return 1;
        if ((a=='I'||a=='i') && (b=='S'||b=='s') && (c=='O'||c=='o')) return 1;
    }
    return 0;
}

static void fmt_size(u32 sectors, char* out, u32 outlen) {
    u32 kb = sectors / 2;
    if (kb < 1024) { u32_to_str(kb, out); str_cat(out, " KB", outlen); }
    else if (kb < 1024u * 1024u) { u32_to_str(kb / 1024, out); str_cat(out, " MB", outlen); }
    else { u32_to_str(kb / (1024u * 1024u), out); str_cat(out, " GB", outlen); }
}

static void drive_name(int idx, char* out, u32 outlen) {
    str_copy(out, "/dev/sd", outlen);
    char letter[2] = { (char)('a' + idx), 0 };
    str_cat(out, letter, outlen);
}

static void detect_source(void) {
    g_src = 0; g_src_size = 0; g_src_ok = 0; g_src_from_fat = 0; g_src_name[0] = 0;

    u8* b = kernel_get_install_img_buf();
    u32 s = kernel_get_install_img_size();
    if (b && s >= 1024) {
        g_src = b; g_src_size = s; g_src_from_fat = 0;
        str_copy(g_src_name, "ZapczOS system image", sizeof(g_src_name));
        g_src_ok = 1;
        return;
    }

    if (fat32_available()) {
        fat_dirent_t ents[32];
        int n = fat32_list_root(ents, 32);
        for (int i = 0; i < n; i++) {
            if (!name_is_img_iso(ents[i].display_name)) continue;
            if (ents[i].size == 0 || ents[i].size > TUI_MAX_IMG) continue;
            u8* buf = (u8*)kmalloc(ents[i].size);
            if (!buf) continue;
            int rd = fat32_read_file(&ents[i], buf, ents[i].size);
            if (rd <= 0) continue;
            g_src = buf; g_src_size = (u32)rd; g_src_from_fat = 1;
            str_copy(g_src_name, ents[i].display_name, sizeof(g_src_name));
            g_src_ok = 1;
            return;
        }
    }
}

static void rescan_disks(void) {
    ata_scan_all();
    g_disk_count = 0;
    for (int i = 0; i < ATA_MAX_DRIVES; i++)
        if (ata_drive_present(i)) g_disk_list[g_disk_count++] = i;
    if (g_disk_sel >= g_disk_count) g_disk_sel = g_disk_count ? g_disk_count - 1 : 0;
}

static void draw_frame(const char* subtitle) {
    gfx_rect(0, 0, SW(), SH(), COL_BG);

    gfx_rect(0, 0, SW(), 40, COL_BAR);
    gfx_string(20, 12, "ZapczOS V4  -  Text-Mode Installer", COL_BARTEXT, COL_BAR, 0);
    {
        const char* r = "console setup";
        gfx_string(SW() - 20 - gfx_string_width(r), 12, r, COL_BARTEXT, COL_BAR, 0);
    }

    if (subtitle) tstr(20, 52, subtitle, COL_DIM);

    gfx_hline(0, SH() - 34, SW(), COL_BORDER);
}

static void draw_footer(const char* hints) {
    tstr(20, SH() - 26, hints, COL_FAINT);
}

static void panel(i32 x, i32 y, i32 w, i32 h) {
    gfx_rect(x, y, w, h, COL_PANEL);
    gfx_rect_outline(x, y, w, h, COL_BORDER);
}

static void draw_source_line(i32 x, i32 y) {
    if (g_src_ok) {
        char line[96] = "Install source: ";
        str_cat(line, g_src_name, sizeof(line));
        str_cat(line, "  (", sizeof(line));
        char sz[16]; u32_to_kb_str(g_src_size, sz); str_cat(line, sz, sizeof(line));
        str_cat(line, g_src_from_fat ? ", from disk)" : ", this build)", sizeof(line));
        tstr(x, y, line, COL_GOOD);
    } else {
        tstr(x, y, "Install source: none found in this boot", COL_WARN);
    }
}

static void screen_welcome(void) {
    draw_frame("Welcome");
    i32 cx = SW() / 2;
    i32 bx = 60, by = 90, bw = SW() - 120, bh = SH() - 90 - 70;
    panel(bx, by, bw, bh);

    i32 y = by + 24;
    tstr_c(cx, y, "ZapczOS V4 -- install this system to a hard disk", COL_TEXT); y += 34;
    tstr_c(cx, y, "This writes a bootable copy of the ZapczOS you are", COL_DIM); y += 20;
    tstr_c(cx, y, "running right now onto a disk of your choice.", COL_DIM); y += 30;

    draw_source_line(bx + 24, y); y += 28;

    tstr(bx + 24, y, "The image is the same build you booted, so the installed", COL_FAINT); y += 18;
    tstr(bx + 24, y, "disk boots into exactly this version. (A small .img/.iso on", COL_FAINT); y += 18;
    tstr(bx + 24, y, "a FAT32 disk is used instead if one is present.)", COL_FAINT); y += 28;

    tstr(bx + 24, y, "The target disk is erased completely. There is no undo.", COL_WARN); y += 28;

    tstr(bx + 24, y, "The keyboard drives everything -- there is no mouse here.", COL_DIM); y += 20;
    tstr(bx + 24, y, "Arrow keys move, Enter selects, Esc goes back.", COL_DIM);

    draw_footer("Enter: continue to disk selection");
}

static void screen_disk(void) {
    draw_frame("Step 1 of 2  -  Select the disk to install to");
    i32 bx = 60, by = 90, bw = SW() - 120, bh = SH() - 90 - 70;
    panel(bx, by, bw, bh);

    i32 y = by + 20;
    tstr(bx + 20, y, "Disks detected on the IDE/ATA buses:", COL_TEXT); y += 28;

    if (g_disk_count == 0) {
        tstr(bx + 28, y, "No disks found. The ATA driver covers primary+secondary", COL_WARN); y += 18;
        tstr(bx + 28, y, "IDE (master+slave) in PIO mode only -- no AHCI/NVMe/USB.", COL_DIM);
    } else {
        for (int i = 0; i < g_disk_count; i++) {
            int idx = g_disk_list[i];
            int sel = (i == g_disk_sel);
            i32 rowh = 24;
            if (sel) gfx_rect(bx + 16, y - 4, bw - 32, rowh, COL_SELBG);

            char line[110];
            char nm[12]; drive_name(idx, nm, sizeof(nm));
            str_copy(line, nm, sizeof(line));
            while (str_len(line) < 10) str_cat(line, " ", sizeof(line));

            if (ata_drive_is_atapi(idx)) {
                str_cat(line, "CD/DVD  ", sizeof(line));
                str_cat(line, "(not a valid target)  ", sizeof(line));
            } else {
                char sz[24]; fmt_size(ata_drive_sectors(idx), sz, sizeof(sz));
                str_cat(line, sz, sizeof(line));
                u32 pad = str_len(sz);
                while (pad < 12) { str_cat(line, " ", sizeof(line)); pad++; }
            }
            str_cat(line, ata_drive_model(idx), sizeof(line));
            gfx_string(bx + 24, y, line, sel ? COL_SELTX : COL_TEXT, sel ? COL_SELBG : COL_PANEL, sel ? 1 : 0);
            if (idx == 0) {
                const char* note = " (boot/live disk)";
                gfx_string(bx + 24 + gfx_string_width(line) + 6, y, note,
                           sel ? COL_SELTX : COL_FAINT, sel ? COL_SELBG : COL_PANEL, sel ? 1 : 0);
            }
            y += rowh + 4;
        }
    }

    draw_source_line(bx + 20, by + bh - 30);
    draw_footer("Up/Down: choose    Enter: use this disk    Esc: back");
}

static void bar(i32 x, i32 y, i32 w, i32 h, i32 pct, color_t fill) {
    gfx_rect_outline(x, y, w, h, COL_BORDER);
    i32 fw = (w - 4) * (pct < 0 ? 0 : pct > 100 ? 100 : pct) / 100;
    if (fw > 0) gfx_rect(x + 2, y + 2, fw, h - 4, fill);
}

static void render_progress(void) {
    draw_frame("Installing");
    i32 bx = 60, by = 90, bw = SW() - 120, bh = SH() - 90 - 70;
    panel(bx, by, bw, bh);

    i32 y = by + 30;
    char t[80] = "Writing ";
    str_cat(t, g_src_name, sizeof(t));
    char tn[12]; drive_name(g_target, tn, sizeof(tn));
    str_cat(t, " to ", sizeof(t));
    str_cat(t, tn, sizeof(t));
    tstr(bx + 24, y, t, COL_TEXT); y += 36;

    int pct = g_total_sectors ? (int)(g_cur_sectors * 100u / g_total_sectors) : 0;
    bar(bx + 24, y, bw - 48, 26, pct, COL_BAR); y += 34;

    char pl[48];
    char nb[12]; u32_to_str((u32)pct, nb);
    str_copy(pl, nb, sizeof(pl)); str_cat(pl, "%   ", sizeof(pl));
    u32_to_str(g_cur_sectors / 2048, nb); str_cat(pl, nb, sizeof(pl)); str_cat(pl, " / ", sizeof(pl));
    u32_to_str(g_total_sectors / 2048, nb); str_cat(pl, nb, sizeof(pl)); str_cat(pl, " MB", sizeof(pl));
    tstr(bx + 24, y, pl, COL_DIM); y += 34;

    if (g_part_sectors) {
        char pt[64] = "Creating partition table  -  ZapczOS partition: ";
        char nb2[12]; u32_to_str(g_part_sectors / 2048, nb2);
        str_cat(pt, nb2, sizeof(pt)); str_cat(pt, " MB", sizeof(pt));
        tstr(bx + 24, y, pt, COL_DIM); y += 28;
    }

    tstr(bx + 24, y, "Do not power off or remove media.", COL_WARN);
    draw_footer("Please wait...");

    gfx_mark_all_dirty();
    gfx_present();
}

static void lba_to_chs(u32 lba, u8* out) {
    u32 H = 255, S = 63;
    u32 c = lba / (H * S);
    if (c > 1023) { out[0] = 254; out[1] = 63 | 0xC0; out[2] = 255; return; }
    u32 t = lba % (H * S);
    u32 h = t / S;
    u32 s = t % S + 1;
    out[0] = (u8)(h & 0xFF);
    out[1] = (u8)((s & 0x3F) | ((c >> 2) & 0xC0));
    out[2] = (u8)(c & 0xFF);
}

#define PKBOOT_SECTORS 2048u
#define PART_START     2048u
static u32 stamp_partition_table(u8* img, u32 img_size) {
    if (img_size <= PKBOOT_SECTORS * 512) return 0;
    u32 part_sectors = (img_size - PKBOOT_SECTORS * 512 + 511) / 512;
    u8* pe = img + 446;
    u8 cs[3], ce[3];
    lba_to_chs(PART_START, cs);
    lba_to_chs(PART_START + part_sectors - 1, ce);
    pe[0] = 0x80;
    pe[1] = cs[0]; pe[2] = cs[1]; pe[3] = cs[2];
    pe[4] = 0x0C;
    pe[5] = ce[0]; pe[6] = ce[1]; pe[7] = ce[2];
    pe[8]  = (u8)(PART_START & 0xFF);
    pe[9]  = (u8)((PART_START >> 8) & 0xFF);
    pe[10] = (u8)((PART_START >> 16) & 0xFF);
    pe[11] = (u8)((PART_START >> 24) & 0xFF);
    pe[12] = (u8)(part_sectors & 0xFF);
    pe[13] = (u8)((part_sectors >> 8) & 0xFF);
    pe[14] = (u8)((part_sectors >> 16) & 0xFF);
    pe[15] = (u8)((part_sectors >> 24) & 0xFF);
    for (int i = 462; i < 510; i++) img[i] = 0;
    img[510] = 0x55; img[511] = 0xAA;
    return part_sectors;
}

static void do_install(void) {
    if (!g_src_ok || g_target < 0) return;
    g_part_sectors = stamp_partition_table(g_src, g_src_size);
    g_total_sectors = (g_src_size + 511) / 512;
    g_cur_sectors = 0;

    while (g_cur_sectors < g_total_sectors) {
        u32 chunk = g_total_sectors - g_cur_sectors;
        if (chunk > 128) chunk = 128;

        int wrote = ata_drive_write_sectors(g_target, g_cur_sectors, chunk,
                                            g_src + (u32)g_cur_sectors * 512);
        if (wrote != (int)chunk) {
            str_copy(g_err, "Write failed -- the target disk may be in a bad state", sizeof(g_err));
            g_state = ST_ERROR;
            return;
        }
        g_cur_sectors += chunk;

        watchdog_heartbeat("tui install write");
        render_progress();
    }
    ata_drive_flush(g_target);
    g_state = ST_DONE;
}

static void screen_target(void) {
    draw_frame("Step 2 of 2  -  Confirm and install");
    i32 bx = 60, by = 90, bw = SW() - 120, bh = SH() - 90 - 70;
    panel(bx, by, bw, bh);

    i32 y = by + 24;
    char tn[12]; drive_name(g_target, tn, sizeof(tn));

    char line[110];
    str_copy(line, "Target disk:  ", sizeof(line));
    str_cat(line, tn, sizeof(line));
    str_cat(line, "  (", sizeof(line));
    str_cat(line, ata_drive_model(g_target), sizeof(line));
    str_cat(line, ")", sizeof(line));
    tstr(bx + 24, y, line, COL_TEXT); y += 24;

    char sz[24]; fmt_size(ata_drive_sectors(g_target), sz, sizeof(sz));
    str_copy(line, "Target size:  ", sizeof(line)); str_cat(line, sz, sizeof(line));
    tstr(bx + 24, y, line, COL_DIM); y += 24;

    draw_source_line(bx + 24, y); y += 30;

    if (g_target == 0)
        { tstr(bx + 24, y, "NOTE: this is the same disk ZapczOS booted from.", COL_WARN); y += 24; }

    tstr(bx + 24, y, "Everything on this disk will be PERMANENTLY ERASED and", COL_WARN); y += 18;
    tstr(bx + 24, y, "replaced with the install image. This cannot be undone.", COL_WARN); y += 32;

    if (!g_src_ok) {
        tstr(bx + 24, y, "No install image is available in this boot, so nothing", COL_DIM); y += 18;
        tstr(bx + 24, y, "can be written. Add install_payload.img to the disc, or", COL_DIM); y += 18;
        tstr(bx + 24, y, "put a small .img/.iso on a FAT32 disk, then reboot.", COL_DIM);
        draw_footer("Esc: back");
        return;
    }

    tstr(bx + 24, y, "To proceed, type  YES  and press Enter:", COL_TEXT); y += 26;

    i32 fx = bx + 24, fw = 180, fh = 30;
    gfx_rounded_rect(fx, y, fw, fh, 6, RGB(12, 13, 18));
    gfx_rounded_rect_outline(fx, y, fw, fh, 6, COL_BORDER);
    char shown[16];
    str_copy(shown, g_confirm, sizeof(shown));
    tstr(fx + 10, y + 7, shown[0] ? shown : "type YES",
         shown[0] ? COL_TEXT : COL_FAINT);

    draw_footer("Type YES + Enter: erase and install    Esc: back");
}

static void screen_done(void) {
    draw_frame("Done");
    i32 bx = 60, by = 90, bw = SW() - 120, bh = SH() - 90 - 70;
    panel(bx, by, bw, bh);
    i32 cx = SW() / 2, y = by + bh / 2 - 40;
    tstr_c(cx, y, "Installation complete.", COL_GOOD); y += 30;
    char tn[12]; drive_name(g_target, tn, sizeof(tn));
    char line[64] = "ZapczOS was written to ";
    str_cat(line, tn, sizeof(line)); str_cat(line, ".", sizeof(line));
    tstr_c(cx, y, line, COL_TEXT); y += 30;
    tstr_c(cx, y, "Remove the install media and reboot to start it.", COL_DIM);
    draw_footer("You can now power off (hold the power button) or reboot.");
}

static void screen_error(void) {
    draw_frame("Error");
    i32 bx = 60, by = 90, bw = SW() - 120, bh = SH() - 90 - 70;
    panel(bx, by, bw, bh);
    i32 cx = SW() / 2, y = by + bh / 2 - 20;
    tstr_c(cx, y, g_err[0] ? g_err : "An error occurred.", COL_WARN); y += 30;
    tstr_c(cx, y, "Esc to go back to disk selection.", COL_DIM);
    draw_footer("Esc: back");
}

static void render(void) {
    switch (g_state) {
        case ST_WELCOME: screen_welcome(); break;
        case ST_DISK:    screen_disk();    break;
        case ST_TARGET:  screen_target();  break;
        case ST_DONE:    screen_done();    break;
        case ST_ERROR:   screen_error();   break;
    }
    gfx_mark_all_dirty();
    gfx_present();
}

static void handle_key(int key) {
    switch (g_state) {
        case ST_WELCOME:
            if (key == KEY_ENTER) { rescan_disks(); g_state = ST_DISK; }
            break;

        case ST_DISK:
            if (key == KEY_ESC) { g_state = ST_WELCOME; }
            else if (key == KEY_UP)   { if (g_disk_sel > 0) g_disk_sel--; }
            else if (key == KEY_DOWN) { if (g_disk_sel < g_disk_count - 1) g_disk_sel++; }
            else if (key == KEY_ENTER && g_disk_count > 0) {
                int idx = g_disk_list[g_disk_sel];
                if (!ata_drive_is_atapi(idx)) {
                    g_target = idx;
                    g_confirm[0] = 0; g_confirm_len = 0;
                    g_state = ST_TARGET;
                }
            }
            break;

        case ST_TARGET:
            if (key == KEY_ESC) { g_state = ST_DISK; }
            else if (g_src_ok) {
                if (key == KEY_ENTER) {
                    if (str_eq_ci(g_confirm, "YES")) do_install();
                } else if (key == KEY_BACKSPACE) {
                    if (g_confirm_len > 0) g_confirm[--g_confirm_len] = 0;
                } else if (key >= 32 && key < 127 && g_confirm_len < sizeof(g_confirm) - 1) {
                    char c = (char)key;
                    if (c >= 'a' && c <= 'z') c = (char)(c - 'a' + 'A');
                    g_confirm[g_confirm_len++] = c;
                    g_confirm[g_confirm_len] = 0;
                }
            }
            break;

        case ST_ERROR:
            if (key == KEY_ESC) { g_confirm[0] = 0; g_confirm_len = 0; g_state = ST_DISK; }
            break;

        case ST_DONE:
        default:
            break;
    }
}

void tui_install_run(void) {
    detect_source();
    rescan_disks();
    g_state = ST_WELCOME;

    render();
    for (;;) {
        int key = kbd_getchar();
        if (key != KEY_NONE) {
            handle_key(key);
            render();
        }
        watchdog_heartbeat("tui installer idle");
        for (volatile int i = 0; i < 300000; i++) { }
    }
}
