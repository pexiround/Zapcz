#include "kernel.h"
#include "graphics.h"
#include "battery.h"
#include "wifi.h"
#include "iwlwifi.h"
#include "mm.h"
#include "idt.h"
#include "desktop.h"
#include "keyboard.h"
#include "mouse.h"
#include "fat32.h"
#include "io.h"
#include "theme.h"
#include "boot_screen.h"
#include "util.h"
#include "ps2.h"
#include "pit.h"
#include "net.h"
#include "tui_install.h"
#include "ui/zapcc.h"
#include "ui/screenshot.h"
#include "ui/html.h"

static u32 g_total_ram_kb = 0;
static boot_info_t* g_boot_info_ptr = 0;
static u8* g_safe_mod_buf = 0;
static u32 g_safe_mod_size = 0;
static u8* g_safe_instimg_buf = 0;
static u32 g_safe_instimg_size = 0;

u32 kernel_total_ram_kb(void) { return g_total_ram_kb; }
u8* kernel_get_mod_buf(void) { return g_safe_mod_buf; }
u32 kernel_get_mod_size(void) { return g_safe_mod_size; }
u8* kernel_get_install_img_buf(void) { return g_safe_instimg_buf; }
u32 kernel_get_install_img_size(void) { return g_safe_instimg_size; }
int  kernel_disk_safe(void) { return g_boot_info_ptr ? g_boot_info_ptr->disk_safe : 0; }

static void scan_e820(boot_info_t* bi) {
    u64 total = 0;
    mmap_entry_t* entries = (mmap_entry_t*)(u32)bi->mmap_addr;
    for (u32 i = 0; i < bi->mmap_count; i++) {
        if (entries[i].type == 1) total += entries[i].length;
    }
    g_total_ram_kb = (u32)(total / 1024);
}

void paging_init(void);

/* Boot self-test: only when the kernel command line contains "zapcctest".
   Compiles and runs DEMO.C and reports to the serial port, so the compiler
   can be regression-tested inside the OS without driving the GUI. */
static u8 st_src[49152];
static u8 st_img[ZAP_IMAGE_MAX];

static void cc_selftest_run(void) {
    serial_puts("\r\n=== ZAPCC SELFTEST ===\r\n");

    static fat_dirent_t list[128];
    int n = fat32_list_dir(FAT32_ROOT_ID, list, 128);
    fat_dirent_t* f = 0;
    for (int i = 0; i < n; i++)
        if (!list[i].is_dir && str_eq_ci(list[i].display_name, "DEMO.C")) { f = &list[i]; break; }

    if (!f) { serial_puts("SELFTEST FAIL: DEMO.C not found\r\n"); return; }

    int len = fat32_read_file(f, st_src, sizeof(st_src) - 1);
    if (len <= 0) { serial_puts("SELFTEST FAIL: cannot read DEMO.C\r\n"); return; }
    st_src[len] = 0;

    u32 sz = 0;
    if (!zapcc_compile((const char*)st_src, (u32)len, st_img, ZAP_IMAGE_MAX, &sz)) {
        serial_puts("SELFTEST FAIL: compile error: ");
        serial_puts(zapcc_error());
        serial_puts("\r\n");
        return;
    }
    char nb[16];
    serial_puts("compiled OK, machine code bytes = ");
    u32_to_str(zapcc_stat_code(), nb);
    serial_puts(nb);
    serial_puts("\r\n");

    if (fat32_write_file("DEMO.ZAP", st_img, sz) > 0) serial_puts("wrote DEMO.ZAP\r\n");
    else serial_puts("SELFTEST WARN: could not write DEMO.ZAP\r\n");

    zrt_reset();
    int rc = 0;
    if (!zap_run(st_img, sz, &rc)) {
        serial_puts("SELFTEST FAIL: run error: ");
        serial_puts(zap_run_error());
        serial_puts("\r\n");
        return;
    }
    serial_puts("--- program output ---\r\n");
    for (int i = 0; i < zrt_line_count(); i++) {
        serial_puts(zrt_line(i));
        serial_puts("\r\n");
    }
    serial_puts("--- end, exit code ");
    i32_to_str(rc, nb);
    serial_puts(nb);
    serial_puts(" ---\r\n");

    int shot = screenshot_take();
    serial_puts(shot ? "screenshot OK: " : "screenshot FAIL: ");
    serial_puts(screenshot_message() ? screenshot_message() : "(no message)");

    serial_puts("\r\n--- html/css/js check ---\r\n");
    {
        static const char page[] =
            "<html><head><style>"
            "h1{color:#ff8844;text-align:center;font-size:32px}"
            ".warn{color:red;font-weight:bold}"
            "#note{background-color:#202040;color:yellow}"
            "p.small{font-size:small;font-style:italic}"
            ".gone{display:none}"
            "</style></head><body>"
            "<h1>Heading</h1>"
            "<p class=\"warn\">warned</p>"
            "<p id=\"note\">noted</p>"
            "<p class=\"small\">tiny</p>"
            "<div class=\"gone\">hidden</div>"
            "<ol><li>one</li><li>two</li></ol>"
            "<p style=\"text-align:right;color:#00ff00\">right</p>"
            "<p id=\"dom\">before</p>"
            "<script>"
            "var t=0; for(var i=1;i<=10;i++) t+=i;"
            "document.write('sum='+t+' fact='+f(5)+'\\n');"
            "function f(n){ if(n<=1) return 1; return n*f(n-1); }"
            "document.getElementById('dom').innerHTML='CHANGED';"
            "</script>"
            "</body></html>";
        static html_doc_t d;
        html_parse(page, sizeof(page) - 1, 80, &d);
        char nb[16];
        serial_puts("elements="); u32_to_str((u32)d.count, nb); serial_puts(nb);
        serial_puts(" cssrules="); u32_to_str((u32)d.css_rules, nb); serial_puts(nb);
        serial_puts(" scripts="); u32_to_str((u32)d.scripts_run, nb); serial_puts(nb);
        serial_puts(" jserr="); u32_to_str((u32)d.js_errors, nb); serial_puts(nb);
        serial_puts("\r\n");
        if (d.js_errors) { serial_puts("JSERR: "); serial_puts(d.js_error); serial_puts("\r\n"); }
        for (int i = 0; i < d.count; i++) {
            html_el_t* e = &d.els[i];
            if (e->type == HEL_GAP) continue;
            char tb[120];
            html_text(&d, e->text_off, e->text_len, tb, sizeof(tb));
            if (!tb[0]) continue;
            serial_puts("  fg="); u32_to_str(e->fg_r, nb); serial_puts(nb);
            serial_puts(","); u32_to_str(e->fg_g, nb); serial_puts(nb);
            serial_puts(","); u32_to_str(e->fg_b, nb); serial_puts(nb);
            serial_puts(" bg="); u32_to_str(e->bg_r, nb); serial_puts(nb);
            serial_puts(","); u32_to_str(e->bg_g, nb); serial_puts(nb);
            serial_puts(","); u32_to_str(e->bg_b, nb); serial_puts(nb);
            serial_puts(" al="); u32_to_str(e->align, nb); serial_puts(nb);
            serial_puts(" fs="); u32_to_str(e->fsize, nb); serial_puts(nb);
            serial_puts(" ind="); u32_to_str(e->indent, nb); serial_puts(nb);
            serial_puts(" hid="); u32_to_str(e->hidden, nb); serial_puts(nb);
            serial_puts(" b="); u32_to_str((u32)(e->bold ? 1 : 0), nb); serial_puts(nb);
            serial_puts(" '"); serial_puts(tb); serial_puts("'\r\n");
        }
    }
    serial_puts("--- compiler app path ---\r\n");
    {
        extern void compiler_selftest(void);
        compiler_selftest();
    }
    serial_puts("=== ZAPCC SELFTEST DONE ===\r\n");
}

void kernel_main(boot_info_t* bi) {
    g_boot_info_ptr = bi;
    serial_init();
    serial_puts("kernel_main: alive\r\n");
    if (!bi->vbe_ok) panic("no vbe_info from bios");
    if (!gfx_mode_fits(bi->width, bi->height, bi->bpp))
        panic("display mode too large for the reserved backbuffer");

    scan_e820(bi);
    u32 heap_size = (g_total_ram_kb / 2) * 1024;
    /* Every module GRUB handed us must sit below the dynamic area, otherwise
       the backbuffer or heap will scribble over it. Firmware blobs are several
       megabytes, so this matters. */
    {
        u32 mods_end = 0;
        u32 ends[6];
        ends[0] = bi->mod_addr  ? bi->mod_addr  + bi->mod_size  : 0;
        ends[1] = bi->mod2_addr ? bi->mod2_addr + bi->mod2_size : 0;
        ends[2] = bi->mod3_addr ? bi->mod3_addr + bi->mod3_size : 0;
        ends[3] = bi->mod4_addr ? bi->mod4_addr + bi->mod4_size : 0;
        ends[4] = bi->mod5_addr ? bi->mod5_addr + bi->mod5_size : 0;
        ends[5] = bi->instimg_addr ? bi->instimg_addr + bi->instimg_size : 0;
        for (int i = 0; i < 6; i++) if (ends[i] > mods_end) mods_end = ends[i];
        mm_set_safe_base(mods_end);

        char m[96] = "modules_end=";
        char d[12]; u32_to_str(mods_end, d); str_cat(m, d, 96);
        str_cat(m, " dyn_base=", 96);
        u32_to_str(g_dyn_base, d); str_cat(m, d, 96);
        str_cat(m, "\r\n", 96);
        serial_puts(m);
    }

    if (heap_size < HEAP_SIZE_MIN) heap_size = HEAP_SIZE_MIN;
    if (heap_size > HEAP_SIZE_MAX) heap_size = HEAP_SIZE_MAX;
    heap_init(heap_size);

    {
        u32 heap_start = HEAP_ADDR;
        u32 danger_end = heap_start;
        u32 mod_end = bi->mod_addr + bi->mod_size;
        u32 instimg_end = bi->instimg_addr + bi->instimg_size;
        if (bi->mod_addr && mod_end > danger_end) danger_end = mod_end;
        if (bi->instimg_addr && instimg_end > danger_end) danger_end = instimg_end;
        if (danger_end > heap_start) {
            u32 pad = danger_end - heap_start;
            kmalloc(pad);
        }
    }

    {
        char dbg[64] = "mod_addr=";
        char dec1[12]; u32_to_str(bi->mod_addr, dec1); str_cat(dbg, dec1, 64);
        str_cat(dbg, " mod_size=", 64);
        char dec2[12]; u32_to_str(bi->mod_size, dec2); str_cat(dbg, dec2, 64);
        str_cat(dbg, "\r\n", 64);
        serial_puts(dbg);
    }
    if (bi->mod_addr && bi->mod_size >= 1024) {
        g_safe_mod_buf = (u8*)kmalloc(bi->mod_size);
        if (g_safe_mod_buf) {
            const u8* src = (const u8*)(void*)bi->mod_addr;
            u32 n = bi->mod_size;
            if (g_safe_mod_buf > src) {
                for (u32 i = n; i > 0; i--) g_safe_mod_buf[i - 1] = src[i - 1];
            } else {
                for (u32 i = 0; i < n; i++) g_safe_mod_buf[i] = src[i];
            }
            g_safe_mod_size = bi->mod_size;
        }
    }

    {
        char dbg[64] = "instimg_addr=";
        char dec1[12]; u32_to_str(bi->instimg_addr, dec1); str_cat(dbg, dec1, 64);
        str_cat(dbg, " instimg_size=", 64);
        char dec2[12]; u32_to_str(bi->instimg_size, dec2); str_cat(dbg, dec2, 64);
        str_cat(dbg, "\r\n", 64);
        serial_puts(dbg);
    }
    if (bi->instimg_addr && bi->instimg_size >= 1024) {
        g_safe_instimg_buf = (u8*)kmalloc(bi->instimg_size);
        if (g_safe_instimg_buf) {
            const u8* src = (const u8*)(void*)bi->instimg_addr;
            u32 n = bi->instimg_size;
            if (g_safe_instimg_buf > src) {
                for (u32 i = n; i > 0; i--) g_safe_instimg_buf[i - 1] = src[i - 1];
            } else {
                for (u32 i = 0; i < n; i++) g_safe_instimg_buf[i] = src[i];
            }
            g_safe_instimg_size = bi->instimg_size;
        }
    }

    gfx_init(bi->fb_addr, bi->width, bi->height, bi->pitch, bi->bpp);
    theme_set_mode(THEME_MODE_LIGHT);
    idt_init();
    paging_init();
    pic_remap();
    pit_init(1000);
    kbd_init();

    boot_screen_init();
    boot_screen_section("Initializing basic system settings ...");

    char modeline[64] = "Graphics mode: ";
    char wbuf[12], hbuf[12], bbuf[12];
    u32_to_str(bi->width, wbuf); u32_to_str(bi->height, hbuf); u32_to_str(bi->bpp, bbuf);
    str_cat(modeline, wbuf, 64); str_cat(modeline, "x", 64);
    str_cat(modeline, hbuf, 64); str_cat(modeline, "x", 64); str_cat(modeline, bbuf, 64);
    boot_screen_log(modeline);
    boot_screen_status(1);
    boot_screen_log("VBE linear framebuffer, double-buffered compositor");
    boot_screen_status(1);
    boot_screen_log("Bitmap fonts: Latin, Nordic, German, French diacritics");
    boot_screen_status(1);

    char ramline[64] = "Memory: ";
    char rbuf[12]; u32_to_str(g_total_ram_kb / 1024, rbuf);
    str_cat(ramline, rbuf, 64); str_cat(ramline, " MB usable (from BIOS/GRUB memory map)", 64);
    boot_screen_log(ramline);
    boot_screen_status(g_total_ram_kb > 0);
    boot_screen_note("Physical memory manager and kernel heap online");

    boot_screen_log("Interrupt tables and system timer");
    boot_screen_status(1);
    boot_screen_log("PIT system timer @ 1000 Hz");
    boot_screen_status(1);
    boot_screen_log("RTC real-time clock");
    boot_screen_status(1);
    boot_screen_good("IDT, GDT, PIC remap, watchdog armed");

    boot_screen_section("Initializing input devices ...");

    ps2_controller_init();

    kbd_init();
    boot_screen_log("PS/2 keyboard driver");
    boot_screen_status(1);
    boot_screen_note("9 keyboard layouts (Swedish default, AltGr support)");

    int mouse_ok = mouse_init();
    mouse_set_bounds((i32)gfx.width, (i32)gfx.height);
    boot_screen_log("PS/2 mouse / TrackPoint driver");
    boot_screen_status(mouse_ok);

    boot_screen_section("Setting up storage ...");

    int disk_ok = 0;
    if (!bi->disk_safe) {
        boot_screen_log("Disk access (skipped: not safe via this boot path)");
        boot_screen_status(0);
        serial_puts("fat32: running RAM-only (boot path marked it unsafe to touch a disk)\r\n");
    } else {
        disk_ok = fat32_init();
        boot_screen_log("Detecting disk and mounting FAT32 filesystem");
        boot_screen_status(disk_ok);
        if (disk_ok) serial_puts("fat32: real disk filesystem mounted\r\n");
        else serial_puts("fat32: no disk found, running RAM-only\r\n");
    }
    boot_screen_log("ATA hard-disk driver (LBA, 4-device enumeration)");
    boot_screen_status(disk_ok);
    boot_screen_log("RAM filesystem (session storage) with folders");
    boot_screen_status(1);
    boot_screen_good("Mounted /System (read-only) with system files");

    if (bi->tui_install) {
        tui_install_run();
        for (;;) { __asm__ volatile("hlt"); }
    }

    boot_screen_section("Setting up networking ...");
    net_init();
    wifi_init();
    boot_screen_note("PCI bus enumeration");
    boot_screen_log("Intel e1000 Ethernet driver (DMA rx/tx rings)");
    boot_screen_status(1);
    boot_screen_log("ARP / IPv4 / ICMP");
    boot_screen_status(1);
    boot_screen_log("UDP / DHCP / DNS");
    boot_screen_status(1);
    boot_screen_log("TCP (reliable stream)");
    boot_screen_status(1);
    boot_screen_good("TLS 1.2 client: ECDHE-RSA-AES128-GCM, X25519");
    if (!wifi_available() && (bi->mod2_addr || bi->mod3_addr)) {
        boot_screen_log("Intel WiFi firmware detected, initializing...");
        { extern void iwl_try_init_multi(u32,u32,u32,u32,u32,u32,u32,u32);
          iwl_try_init_multi(bi->mod2_addr, bi->mod2_size, bi->mod3_addr, bi->mod3_size,
                             bi->mod4_addr, bi->mod4_size, bi->mod5_addr, bi->mod5_size); }
        if (iwl_is_up()) {
            boot_screen_log(iwl_status());
            boot_screen_status(1);
        } else {
            boot_screen_log(iwl_status());
            boot_screen_status(0);
        }
    }
    if (net_ready()) {
        char ipline[48] = "Network: DHCP lease ";
        char ipbuf[16]; net_ip_to_str(net_get_ip(), ipbuf);
        str_cat(ipline, ipbuf, 48);
        boot_screen_log(ipline);
        boot_screen_status(1);
    } else {
        boot_screen_log("Network (no Ethernet link found, or no DHCP server)");
        boot_screen_status(0);
    }

    boot_screen_section("Starting desktop environment ...");
    battery_init();
    boot_screen_log("Window manager, compositor, traffic-light controls");
    boot_screen_status(1);
    boot_screen_log("Dock, menu bar, spotlight launcher");
    boot_screen_status(1);
    boot_screen_log("Light / Dark theme engine");
    boot_screen_status(1);
    boot_screen_note("Procedural wallpapers, PNG codec, HTML/Markdown renderer");
    boot_screen_log("3D software rasterizer");
    boot_screen_status(1);
    boot_screen_good("Loading 21 applications");

    {
        static const char welcome_txt[] =
            "Welcome to ZapczOS V4\r\n"
            "======================\r\n"
            "\r\n"
            "This is a hobby x86 OS written from scratch in C and NASM.\r\n"
            "Boot from USB or CD on any x86 PC.\r\n"
            "\r\n"
            "WiFi Hardware Support\r\n"
            "---------------------\r\n"
            "SUPPORTED (native driver, no firmware blob needed):\r\n"
            "  Atheros AR9xxx family (ath9k): AR9285, AR9287,\r\n"
            "  AR9485, AR9380, AR9462, AR9565. These do open/WPA2\r\n"
            "  scan + associate straight from the built-in driver.\r\n"
            "  Common in older ThinkPads, HP laptops, netbooks.\r\n"
            "\r\n"
            "EXPERIMENTAL (Intel iwlwifi, firmware now bundled):\r\n"
            "  Intel 8265 (ThinkPad T480, X1 Carbon 6th gen)\r\n"
            "  Intel 3160 / 3165 (ThinkPad E31-70, budget Lenovos)\r\n"
            "  The matching firmware ships on the disc and is\r\n"
            "  uploaded to the adapter at boot. The MVM host-command\r\n"
            "  path is still being written, so on these cards the\r\n"
            "  driver powers the chip up and loads firmware but does\r\n"
            "  NOT yet complete association. This is honest status,\r\n"
            "  not a bug on your end -- use Ethernet on these laptops.\r\n"
            "\r\n"
            "For reliable internet, use the wired Ethernet port.\r\n"
            "Intel I217/I218/I219 wired ethernet is fully supported.\r\n"
            "\r\n"
            "Tips\r\n"
            "----\r\n"
            "- Click the diamond logo (or press Super) for the menu\r\n"
            "- Right-click the desktop to cycle the wallpaper\r\n"
            "- Click the WiFi tray icon to scan / see link status\r\n"
            "- Type 'curl https://...' in Terminal to fetch URLs\r\n"
            "- Browser supports basic HTTPS with TLS 1.2\r\n"
            "- In the browser, just type zapcz.com (no http:// needed)\r\n"
            "  to visit the project site over the wired network\r\n"
            "- A text-mode installer is on the GRUB boot menu\r\n"
            "  (\"Install ZapczOS V4 (text mode)\")\r\n";
        fat32_write_file("WELCOME.TXT", (const u8*)welcome_txt, sizeof(welcome_txt) - 1);

        static const char demo_c[] =
            "int square(int n) { return n * n; }\n"
            "\n"
            "int fib(int n) {\n"
            "    if (n < 2) return n;\n"
            "    return fib(n - 1) + fib(n - 2);\n"
            "}\n"
            "\n"
            "int main() {\n"
            "    print(\"Hello from a program you compiled yourself.\\n\");\n"
            "\n"
            "    print(\"squares: \");\n"
            "    for (int i = 1; i <= 8; i++) {\n"
            "        print_int(square(i));\n"
            "        put_char(32);\n"
            "    }\n"
            "    print(\"\\n\");\n"
            "\n"
            "    print(\"fib:     \");\n"
            "    for (int i = 0; i < 12; i++) {\n"
            "        print_int(fib(i));\n"
            "        put_char(32);\n"
            "    }\n"
            "    print(\"\\n\");\n"
            "\n"
            "    int primes = 0;\n"
            "    for (int n = 2; n < 100; n++) {\n"
            "        int is = 1;\n"
            "        for (int d = 2; d * d <= n; d++) if (n % d == 0) is = 0;\n"
            "        if (is) primes++;\n"
            "    }\n"
            "    print(\"primes under 100: \");\n"
            "    print_int(primes);\n"
            "    print(\"\\n\");\n"
            "    return 0;\n"
            "}\n";
        fat32_write_file("DEMO.C", (const u8*)demo_c, sizeof(demo_c) - 1);
    }

    {
        int sys = fat32_mkdir_id(FAT32_ROOT_ID, "System", 1);
        if (sys >= 0) {
            static const char version_txt[] =
                "ZapczOS V4\r\n"
                "From-scratch x86 (i386) operating system.\r\n"
                "Language: C + NASM. Bootloader: GRUB2 / Multiboot2.\r\n"
                "Display: VBE framebuffer, 1024x768x32.\r\n"
                "Filesystem: FAT32 (disk) with in-memory fallback.\r\n"
                "These System files are read-only.\r\n";
            static const char kernel_inf[] =
                "KERNEL SUBSYSTEMS\r\n"
                "-----------------\r\n"
                "multiboot_entry.asm  boot entry, stack, paging bring-up\r\n"
                "kernel.c             init sequence, boot screen, main loop\r\n"
                "mm.c                 physical + heap memory allocator\r\n"
                "idt / isr            interrupts, PIT timer, watchdog\r\n"
                "rtc.c                real-time clock\r\n";
            static const char drivers_inf[] =
                "DRIVERS\r\n"
                "-------\r\n"
                "ps2 keyboard   9 layouts, AltGr, per-user persistence\r\n"
                "ps2 mouse      IntelliMouse scroll wheel\r\n"
                "ata            hard-disk read/write (LBA)\r\n"
                "pci            bus enumeration\r\n"
                "e1000          Intel gigabit ethernet (DMA rings)\r\n"
                "iwlwifi        Intel wifi (firmware load; assoc WIP)\r\n";
            static const char net_inf[] =
                "NETWORK STACK (from scratch)\r\n"
                "----------------------------\r\n"
                "ARP, IPv4, ICMP, UDP, DHCP, DNS, TCP\r\n"
                "TLS 1.2 client: ECDHE-RSA-AES128-GCM-SHA256, X25519\r\n"
                "Wired ethernet reaches the internet; wifi does not yet.\r\n";
            static const char graphics_inf[] =
                "GRAPHICS + UI\r\n"
                "-------------\r\n"
                "Software compositor over a double-buffered framebuffer.\r\n"
                "Windows, dock, menu, spotlight, light/dark themes.\r\n"
                "PNG encode/decode, HTML/Markdown render, 3D rasterizer.\r\n";
            static const char sourcemap_inf[] =
                "SOURCE LAYOUT\r\n"
                "-------------\r\n"
                "arch/    cpu, gdt, idt, isr, ports\r\n"
                "drivers/ ps2, ata, pci, e1000, wifi, rtc\r\n"
                "fs/      fat32\r\n"
                "net/     arp ip icmp udp dhcp dns tcp tls\r\n"
                "ui/      desktop, apps, graphics, icons, theme, cube3d\r\n"
                "lib/     freestanding libc shims\r\n";
            fat32_write_protected((u32)sys, "VERSION.TXT",  (const u8*)version_txt,   sizeof(version_txt) - 1);
            fat32_write_protected((u32)sys, "KERNEL.INF",   (const u8*)kernel_inf,    sizeof(kernel_inf) - 1);
            fat32_write_protected((u32)sys, "DRIVERS.INF",  (const u8*)drivers_inf,   sizeof(drivers_inf) - 1);
            fat32_write_protected((u32)sys, "NETWORK.INF",  (const u8*)net_inf,       sizeof(net_inf) - 1);
            fat32_write_protected((u32)sys, "GRAPHICS.INF", (const u8*)graphics_inf,  sizeof(graphics_inf) - 1);
            fat32_write_protected((u32)sys, "SOURCEMAP.INF",(const u8*)sourcemap_inf, sizeof(sourcemap_inf) - 1);
        }
    }
    boot_screen_log("ZapczOS V4 desktop");
    boot_screen_status(1);
    boot_screen_finish();


    desktop_init();
    if (bi->cc_selftest) cc_selftest_run();
    if (bi->demo_mode) desktop_demo_enable();

    watchdog_arm();
    for (;;) {
        desktop_run_frame();
    }
}
#include "pic.h"
