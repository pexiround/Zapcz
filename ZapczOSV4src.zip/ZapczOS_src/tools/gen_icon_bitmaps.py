#!/usr/bin/env python3
import sys
import os

try:
    from PIL import Image
except ImportError:
    sys.exit("This script needs Pillow: pip install pillow --break-system-packages")

ICON_W = 80
ICON_H = 60

APP_ICON_FILES = [
    ("APP_ABOUT",     "About_icon.png"),
    ("APP_CLOCK",     "Clock_icon.png"),
    ("APP_FILES",     "Files_icon.png"),
    ("APP_EDITOR",    "Editor_icon.png"),
    ("APP_TERMINAL",  "Terminal_icon.png"),
    ("APP_PERF",      "Performance_icon.png"),
    ("APP_WALLPAPER", "Wallpaper_icon.png"),
    ("APP_SNAKE",     "Snake_icon.png"),
    ("APP_BROWSER",   "Browser_icon.png"),
    ("APP_STORE",     "AppStore_icon.png"),
    ("APP_SETTINGS",  "Settings_icon.png"),
    ("APP_PHOTOS",    "Photos_icon.png"),
    ("APP_ACCOUNTS",  "Accounts_icon.png"),
    ("APP_INSTALLER", "InstallOS_icon.png"),
    ("APP_CALC",      "Calculator_icon.png"),
    ("APP_PAINT",     "Paint_icon.png"),
    ("APP_TTT",       "TicTacToe_icon.png"),
    ("APP_CUBE3D",    "Cube3D_icon.png"),
    ("APP_DOOM",      "DOOM_icon.png"),
]


def c_array_name(app_const):
    return "ICON_BMP_" + app_const[4:]


def emit_icon(f, app_const, path):
    im = Image.open(path).convert("RGBA")
    if im.size != (ICON_W, ICON_H):
        im = im.resize((ICON_W, ICON_H), Image.LANCZOS)
    data = im.tobytes()
    assert len(data) == ICON_W * ICON_H * 4

    arrname = c_array_name(app_const)
    f.write(f"static const u8 {arrname}[{ICON_W * ICON_H * 4}] = {{\n")
    line = []
    for i, b in enumerate(data):
        line.append(f"{b}")
        if len(line) == 20:
            f.write("    " + ",".join(line) + ",\n")
            line = []
    if line:
        f.write("    " + ",".join(line) + "\n")
    f.write("};\n\n")
    return arrname


def main():
    if len(sys.argv) != 3:
        sys.exit(f"usage: {sys.argv[0]} <icons_dir> <output_header>")
    icons_dir, out_path = sys.argv[1], sys.argv[2]

    entries = []
    with open(out_path, "w") as f:
        f.write("#ifndef ICON_BITMAPS_H\n#define ICON_BITMAPS_H\n#include \"io.h\"\n\n")
        f.write(f"#define ICON_BMP_W {ICON_W}\n#define ICON_BMP_H {ICON_H}\n\n")

        for app_const, fname in APP_ICON_FILES:
            path = os.path.join(icons_dir, fname)
            if not os.path.exists(path):
                sys.exit(f"missing icon file: {path}")
            arrname = emit_icon(f, app_const, path)
            entries.append((app_const, arrname))

        f.write("static const u8* const ICON_BITMAP_TABLE[APP_COUNT] = {\n")
        for app_const, arrname in entries:
            f.write(f"    [{app_const}] = {arrname},\n")
        f.write("};\n\n#endif\n")

    print(f"wrote {out_path} with {len(entries)} icons "
          f"({len(entries) * ICON_W * ICON_H * 4} raw bytes)")


if __name__ == "__main__":
    main()
