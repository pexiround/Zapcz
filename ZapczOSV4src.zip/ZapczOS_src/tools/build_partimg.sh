#!/bin/sh
set -e
SRCTREE="$1"
OUT="$2"
[ -z "$SRCTREE" ] && SRCTREE=build/payload
[ -z "$OUT" ] && OUT=install_payload.img

if [ "$(id -u)" != "0" ] || ! command -v losetup >/dev/null 2>&1; then
    echo "build_partimg: root + losetup required to build the partition install image" >&2
    exit 1
fi
for t in sfdisk mkfs.vfat mcopy mmd grub-mkimage python3; do
    command -v "$t" >/dev/null 2>&1 || { echo "build_partimg: missing tool: $t" >&2; exit 1; }
done
GPC=/usr/lib/grub/i386-pc
[ -f "$GPC/boot.img" ] || { echo "build_partimg: missing $GPC/boot.img (install grub-pc-bin)" >&2; exit 1; }

D=$(mktemp -d)
IMG="$D/scratch.img"
TREEKB=$(du -sk "$SRCTREE" | cut -f1)
SIZEMB=$(( (TREEKB / 1024) + 9 ))
[ "$SIZEMB" -lt 16 ] && SIZEMB=16

dd if=/dev/zero of="$IMG" bs=1M count="$SIZEMB" status=none
echo 'start=2048,type=c,bootable' | sfdisk "$IMG" >/dev/null 2>&1
LP=$(losetup -f --show -o 1048576 "$IMG")
mkfs.vfat -F 32 -n ZAPCZOS "$LP" >/dev/null 2>&1

( cd "$SRCTREE" && find . -mindepth 1 -type d | while read -r dd; do mmd -i "$LP" "::${dd#.}" 2>/dev/null || true; done )
( cd "$SRCTREE" && find . -type f | while read -r ff; do mcopy -i "$LP" -o "$ff" "::${ff#./}" 2>/dev/null; done )
sync
losetup -d "$LP"

grub-mkimage -O i386-pc -o "$D/core.img" -p '(hd0,msdos1)/boot/grub' \
    biosdisk part_msdos fat multiboot2 normal configfile boot all_video vbe vga video gfxterm echo gfxmenu png font

python3 - "$IMG" "$GPC/boot.img" "$D/core.img" "$OUT" <<'PY'
import sys, os, struct
img, bootp, corep, out = sys.argv[1], sys.argv[2], sys.argv[3], sys.argv[4]
boot = bytearray(open(bootp, 'rb').read())
core = bytearray(open(corep, 'rb').read())
core_sectors = (len(core) + 511) // 512
if core_sectors >= 2048:
    raise SystemExit('build_partimg: core.img too large for MBR gap')
struct.pack_into('<Q', boot, 0x5c, 1)
struct.pack_into('<Q', core, 500, 2)
struct.pack_into('<H', core, 508, core_sectors - 1)
with open(img, 'r+b') as f:
    disk = bytearray(f.read())
    disk[0:446] = boot[0:446]
    disk[512:512 + len(core)] = core
    f.seek(0)
    f.write(disk)
open(out, 'wb').write(open(img, 'rb').read())
n = os.path.getsize(out)
print('install_payload.img', n, 'bytes =', n // 512, 'sectors; core.img', len(core), 'bytes embedded in MBR gap')
PY
rm -rf "$D"
