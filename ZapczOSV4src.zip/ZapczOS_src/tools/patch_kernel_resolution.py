import struct
import sys

SIGNATURE = bytes([0x05, 0x00, 0x00, 0x00, 0x14, 0x00, 0x00, 0x00])

def patch_resolution(src_path, dst_path, width, height, depth=32):
    with open(src_path, "rb") as f:
        data = bytearray(f.read())

    idx = data.find(SIGNATURE)
    if idx < 0:
        sys.exit(f"framebuffer tag signature not found in {src_path}")
    if data.find(SIGNATURE, idx + 1) != -1:
        sys.exit(f"framebuffer tag signature is not unique in {src_path}")

    off = idx + len(SIGNATURE)
    struct.pack_into("<III", data, off, width, height, depth)

    with open(dst_path, "wb") as f:
        f.write(data)

if __name__ == "__main__":
    src = sys.argv[1]
    dst = sys.argv[2]
    w = int(sys.argv[3])
    h = int(sys.argv[4])
    patch_resolution(src, dst, w, h)
    print(f"patched {dst}: {w}x{h}x32")
