#!/bin/bash
set -e

KERNEL_ELF="$1"
WAD_FILE="$2"
OUT_IMG="$3"
SIZE_MB="${4:-56}"

if [ -z "$KERNEL_ELF" ] || [ -z "$WAD_FILE" ] || [ -z "$OUT_IMG" ]; then
    echo "usage: $0 <kernel_mb.elf> <freedoom1.wad> <out.img> [size_mb]"
    exit 1
fi

WORK=$(mktemp -d)
trap 'losetup -d "$LOOP_PART" 2>/dev/null; losetup -d "$LOOP_WHOLE" 2>/dev/null; rm -rf "$WORK"' EXIT

dd if=/dev/zero of="$OUT_IMG" bs=1M count="$SIZE_MB" status=none
echo 'start=2048,type=c,bootable' | sfdisk "$OUT_IMG" > /dev/null

LOOP_WHOLE=$(losetup -f --show "$OUT_IMG")
LOOP_PART=$(losetup -f --show -o 1048576 "$OUT_IMG")

mkfs.vfat -F 32 -n ZAPCZINST "$LOOP_PART" > /dev/null

grub-mkimage -O i386-pc -o "$WORK/core.img" -p '(hd0,msdos1)/boot/grub' \
    biosdisk part_msdos fat multiboot2 normal configfile boot
mkdir -p "$WORK/i386pc"
cp "$WORK/core.img" "$WORK/i386pc/core.img"
cp /usr/lib/grub/i386-pc/boot.img "$WORK/i386pc/boot.img"
/usr/lib/grub/i386-pc/grub-bios-setup -d "$WORK/i386pc" "$LOOP_WHOLE" > /dev/null 2>&1

mkdir -p "$WORK/mnt/boot/grub/i386-pc" "$WORK/mnt/boot/grub/fonts"
cp /usr/lib/grub/i386-pc/*.mod "$WORK/mnt/boot/grub/i386-pc/" 2>/dev/null || true
cp /usr/lib/grub/i386-pc/*.lst "$WORK/mnt/boot/grub/i386-pc/" 2>/dev/null || true
cp /usr/share/grub/unicode.pf2 "$WORK/mnt/boot/grub/fonts/" 2>/dev/null || true
cp "$KERNEL_ELF" "$WORK/mnt/boot/kernel_mb.elf"
cp "$WAD_FILE" "$WORK/mnt/boot/freedoom1.wad"
cat > "$WORK/mnt/boot/grub/grub.cfg" << 'EOF'
insmod part_msdos
insmod fat
insmod biosdisk
set timeout=0
set default=0
insmod all_video
insmod vbe
insmod gfxterm

menuentry "ZapczOS V3" {
    multiboot2 /boot/kernel_mb.elf
    module2 /boot/freedoom1.wad waddata
    boot
}
EOF

mmd -i "$LOOP_PART" ::/boot 2>/dev/null || true
find "$WORK/mnt/boot" -type d | sed "s#$WORK/mnt##" | sort | while read -r d; do
    mmd -i "$LOOP_PART" "::$d" 2>/dev/null || true
done
find "$WORK/mnt/boot" -type f | while read -r f; do
    rel="${f#$WORK/mnt}"
    mcopy -i "$LOOP_PART" -o "$f" "::$rel" 2>&1 | grep -v geometry || true
done

sync
echo "built $OUT_IMG"
