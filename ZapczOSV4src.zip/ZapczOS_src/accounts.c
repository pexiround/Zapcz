#include "accounts.h"
#include "icons.h"
#include "graphics.h"
#include "desktop.h"
#include "theme.h"
#include "util.h"
#include "fat32.h"
#include "mouse.h"
#include "keyboard.h"
#include "pit.h"
#include "logo.h"
#include "libc_shim.h"

#define ACC_FILENAME "ZAPCZUSR.DAT"
#define ACC_MAGIC0 'Z'
#define ACC_MAGIC1 'A'
#define ACC_MAGIC2 'U'
#define ACC_MAGIC3 'S'
#define ACC_RECORD_SIZE 24

typedef struct {
    char name[ACCOUNT_NAME_LEN];
    u32  pass_hash;
    u8   has_password;
    u8   kbd_layout;
} account_t;

static account_t accounts[ACCOUNTS_MAX];
static int account_count = 0;
static int disk_was_available = 0;
static int disk_is_persistent = 0;
static int logged_in = 0;
static int current_idx = -1;

static u32 simple_hash(const char* s) {
    u32 h = 2166136261u;
    for (; *s; s++) { h ^= (u8)(*s); h *= 16777619u; }
    return h;
}

static void pack_record(const account_t* a, u8* out) {
    for (int i = 0; i < ACCOUNT_NAME_LEN; i++) out[i] = (u8)a->name[i];
    out[16] = (u8)(a->pass_hash & 0xFF);
    out[17] = (u8)((a->pass_hash >> 8) & 0xFF);
    out[18] = (u8)((a->pass_hash >> 16) & 0xFF);
    out[19] = (u8)((a->pass_hash >> 24) & 0xFF);
    out[20] = a->has_password;
    out[21] = a->kbd_layout;
    out[22] = 0; out[23] = 0;
}

static void unpack_record(account_t* a, const u8* in) {
    for (int i = 0; i < ACCOUNT_NAME_LEN; i++) a->name[i] = (char)in[i];
    a->name[ACCOUNT_NAME_LEN - 1] = 0;
    a->pass_hash = (u32)in[16] | ((u32)in[17] << 8) | ((u32)in[18] << 16) | ((u32)in[19] << 24);
    a->has_password = in[20];
    a->kbd_layout = in[21];
    if (a->kbd_layout >= KBD_LAYOUT_COUNT) a->kbd_layout = KBD_LAYOUT_US;
}

static void save_accounts(void) {
    if (!fat32_available()) return;
    u8 buf[5 + ACCOUNTS_MAX * ACC_RECORD_SIZE];
    buf[0] = ACC_MAGIC0; buf[1] = ACC_MAGIC1; buf[2] = ACC_MAGIC2; buf[3] = ACC_MAGIC3;
    buf[4] = (u8)account_count;
    for (int i = 0; i < account_count; i++) {
        pack_record(&accounts[i], buf + 5 + i * ACC_RECORD_SIZE);
    }
    fat32_write_file(ACC_FILENAME, buf, 5 + (u32)account_count * ACC_RECORD_SIZE);
}

static void create_default_account(void) {
    account_count = 1;
    str_copy(accounts[0].name, "User", ACCOUNT_NAME_LEN);
    accounts[0].pass_hash = 0;
    accounts[0].has_password = 0;
    accounts[0].kbd_layout = KBD_LAYOUT_US;
}

void accounts_init(void) {
    disk_was_available = fat32_available();
    disk_is_persistent = fat32_persistent();
    account_count = 0;

    if (disk_was_available) {
        fat_dirent_t ents[32];
        int n = fat32_list_root(ents, 32);
        for (int i = 0; i < n; i++) {
            if (str_eq_ci(ents[i].display_name, ACC_FILENAME)) {
                u8 buf[5 + ACCOUNTS_MAX * ACC_RECORD_SIZE];
                int len = fat32_read_file(&ents[i], buf, sizeof(buf));
                if (len >= 5 && buf[0] == ACC_MAGIC0 && buf[1] == ACC_MAGIC1 &&
                    buf[2] == ACC_MAGIC2 && buf[3] == ACC_MAGIC3) {
                    int cnt = buf[4];
                    if (cnt > ACCOUNTS_MAX) cnt = ACCOUNTS_MAX;
                    int avail = (len - 5) / ACC_RECORD_SIZE;
                    if (cnt > avail) cnt = avail;
                    for (int a = 0; a < cnt; a++) {
                        unpack_record(&accounts[a], buf + 5 + a * ACC_RECORD_SIZE);
                    }
                    account_count = cnt;
                }
                break;
            }
        }
    }

    if (account_count == 0) {
        create_default_account();
        save_accounts();
    }

    logged_in = 0;
    current_idx = -1;
}

int accounts_logged_in(void) { return logged_in; }

void accounts_logout(void) {
    logged_in = 0;
    current_idx = -1;
}

int accounts_count(void) { return account_count; }
const char* accounts_name_at(int idx) {
    if (idx < 0 || idx >= account_count) return "";
    return accounts[idx].name;
}
int accounts_has_password_at(int idx) {
    if (idx < 0 || idx >= account_count) return 0;
    return accounts[idx].has_password;
}
int accounts_current_index(void) { return current_idx; }

int accounts_get_keyboard_layout(void) {
    if (current_idx < 0 || current_idx >= account_count) return KBD_LAYOUT_US;
    return accounts[current_idx].kbd_layout;
}
void accounts_set_keyboard_layout(int layout) {
    if (current_idx < 0 || current_idx >= account_count) return;
    if (layout < 0 || layout >= KBD_LAYOUT_COUNT) return;
    accounts[current_idx].kbd_layout = (u8)layout;
    kbd_set_layout(layout);
    save_accounts();
}

static void do_login(int idx) {
    current_idx = idx;
    logged_in = 1;
    kbd_set_layout(accounts[idx].kbd_layout);
    desktop_reset_session();
}

#define LM_LIST 0
#define LM_PASSWORD 1
#define LM_NEW 2

static int login_mode = LM_LIST;
static u32 login_auto_tick = 0;
static int login_auto_armed = 0;
static int login_selected = -1;
static char login_input[24];
static u32 login_input_len = 0;
static char login_error[48] = "";

#define CARD_W ui_scale(150)
#define CARD_H ui_scale(108)
#define CARD_GAP ui_scale(18)

static void login_card_rect(int idx, int total, i32* ox, i32* oy) {
    i32 cols = ((i32)gfx.width - 40) / (CARD_W + CARD_GAP);
    if (cols < 1) cols = 1;
    if (cols > total) cols = total;
    i32 rows = (total + cols - 1) / cols;
    i32 grid_w = cols * (CARD_W + CARD_GAP) - CARD_GAP;
    i32 grid_h = rows * (CARD_H + CARD_GAP) - CARD_GAP;
    i32 start_x = ((i32)gfx.width - grid_w) / 2;
    i32 start_y = ((i32)gfx.height - grid_h) / 2 + 60;
    i32 col = idx % cols, row = idx / cols;
    *ox = start_x + col * (CARD_W + CARD_GAP);
    *oy = start_y + row * (CARD_H + CARD_GAP);
}

static void draw_text_field(i32 x, i32 y, i32 w, const char* shown, int focused) {
    color_t bg = RGB(18, 19, 25);
    gfx_rounded_rect(x, y, w, 32, THEME_RADIUS_CTRL, bg);
    gfx_rounded_rect_outline(x, y, w, 32, THEME_RADIUS_CTRL, focused ? THEME_ACCENT : THEME_BORDER);
    char buf[40];
    str_copy(buf, shown, 40);
    if (focused && (ticks_get() / 30) % 2 == 0 && str_len(buf) < 38) str_cat(buf, "_", 40);
    gfx_string(x + 10, y + 8, buf, THEME_TEXT, bg, 0);
}

static i32 login_panel_y(void) {
    i32 ly = ui_scale(40);
    i32 scale = ui_scale(2);
    if (scale < 2) scale = 2;
    i32 logo_h = LOGO_H_ * scale;
    i32 ty = ly + logo_h + ui_scale(10);
    return ty + ui_scale(50);
}

void accounts_login_draw(void) {
    if (login_mode == LM_LIST && account_count == 1 && !accounts[0].has_password) {
        if (!login_auto_armed) {
            login_auto_tick = ticks_get() + ticks_per_sec();
            login_auto_armed = 1;
        } else if (ticks_get() >= login_auto_tick) {
            do_login(0);
            return;
        }
    }
    gfx_gradient_v(0, 0, (i32)gfx.width, (i32)gfx.height, RGB(22, 24, 32), RGB(10, 11, 16));

    i32 scale = ui_scale(2);
    if (scale < 2) scale = 2;
    i32 logo_w = LOGO_W * scale, logo_h = LOGO_H_ * scale;
    i32 lx = ((i32)gfx.width - logo_w) / 2;
    i32 ly = ui_scale(40);
    logo_draw(lx, ly, logo_w, logo_h, RGB(20, 22, 30));
    i32 ty = ly + logo_h + ui_scale(10);
    const char* title = (login_mode == LM_LIST) ? "Who's using ZapczOS?" :
                        (login_mode == LM_PASSWORD) ? "Enter password" : "New account";
    gfx_string(((i32)gfx.width - gfx_string_width(title)) / 2, ty, title, THEME_TEXT, RGB(0,0,0), 0);

    if (login_mode == LM_LIST) {
        int total = account_count + 1;
        for (int i = 0; i < account_count; i++) {
            i32 cx, cy;
            login_card_rect(i, total, &cx, &cy);
            int hot = ui_point_in(mouse_x(), mouse_y(), cx, cy, CARD_W, CARD_H);
            gfx_rounded_rect(cx, cy, CARD_W, CARD_H, THEME_RADIUS_WIN,
                              hot ? THEME_PANEL_RAISED : THEME_PANEL_ALT);
            gfx_rounded_rect_outline(cx, cy, CARD_W, CARD_H, THEME_RADIUS_WIN, THEME_BORDER);

            i32 av = 22;
            gfx_circle_fill(cx + CARD_W / 2, cy + 32, av, THEME_ACCENT);
            char initial[2] = { accounts[i].name[0], 0 };
            gfx_string(cx + CARD_W / 2 - 4, cy + 32 - 8, initial, RGB(255,255,255), THEME_ACCENT, 0);

            char nm[ACCOUNT_NAME_LEN];
            str_copy(nm, accounts[i].name, ACCOUNT_NAME_LEN);
            gfx_string(cx + (CARD_W - gfx_string_width(nm)) / 2, cy + 62, nm, THEME_TEXT, THEME_PANEL_ALT, 0);
            if (accounts[i].has_password) {
                gfx_string(cx + (CARD_W - gfx_string_width("locked")) / 2, cy + 82, "locked",
                           THEME_TEXT_FAINT, THEME_PANEL_ALT, 0);
            } else {
                gfx_string(cx + (CARD_W - gfx_string_width("click to log in")) / 2, cy + 82, "click to log in",
                           THEME_TEXT_FAINT, THEME_PANEL_ALT, 0);
            }
        }
        i32 cx, cy;
        login_card_rect(account_count, total, &cx, &cy);
        int hot = ui_point_in(mouse_x(), mouse_y(), cx, cy, CARD_W, CARD_H);
        gfx_rounded_rect(cx, cy, CARD_W, CARD_H, THEME_RADIUS_WIN, hot ? THEME_PANEL_RAISED : THEME_PANEL_ALT);
        gfx_rounded_rect_outline(cx, cy, CARD_W, CARD_H, THEME_RADIUS_WIN, THEME_BORDER);
        gfx_string(cx + (CARD_W - gfx_string_width("+ New account")) / 2, cy + CARD_H / 2 - 8,
                   "+ New account", THEME_ACCENT, THEME_PANEL_ALT, 0);
    } else if (login_mode == LM_PASSWORD) {
        i32 w = 280, h = 150;
        i32 px = ((i32)gfx.width - w) / 2, py = login_panel_y();
        gfx_rounded_rect(px, py, w, h, THEME_RADIUS_WIN, THEME_PANEL);
        gfx_rounded_rect_outline(px, py, w, h, THEME_RADIUS_WIN, THEME_BORDER);
        char nm[40] = "";
        if (login_selected >= 0) str_copy(nm, accounts[login_selected].name, 40);
        gfx_string(px + (w - gfx_string_width(nm)) / 2, py + 14, nm, THEME_TEXT, THEME_PANEL, 0);

        char masked[24]; u32 ml = login_input_len; if (ml > 23) ml = 23;
        for (u32 i = 0; i < ml; i++) masked[i] = '*';
        masked[ml] = 0;
        draw_text_field(px + 16, py + 44, w - 32, masked, 1);

        if (login_error[0]) gfx_string(px + 16, py + 84, login_error, THEME_DANGER, THEME_PANEL, 0);

        ui_button(px + 16, py + h - 40, (w - 40) / 2, 30, "Back", 0);
        ui_button(px + 24 + (w - 40) / 2, py + h - 40, (w - 40) / 2, 30, "Log In", 1);
    } else {
        i32 w = 280, h = 150;
        i32 px = ((i32)gfx.width - w) / 2, py = login_panel_y();
        gfx_rounded_rect(px, py, w, h, THEME_RADIUS_WIN, THEME_PANEL);
        gfx_rounded_rect_outline(px, py, w, h, THEME_RADIUS_WIN, THEME_BORDER);
        gfx_string(px + 16, py + 14, "Name for the new account:", THEME_TEXT_DIM, THEME_PANEL, 0);
        draw_text_field(px + 16, py + 40, w - 32, login_input, 1);
        if (login_error[0]) gfx_string(px + 16, py + 80, login_error, THEME_DANGER, THEME_PANEL, 0);
        ui_button(px + 16, py + h - 40, (w - 40) / 2, 30, "Cancel", 0);
        ui_button(px + 24 + (w - 40) / 2, py + h - 40, (w - 40) / 2, 30, "Create", 1);
    }

    desktop_draw_cursor();
}

static void login_submit_password(void) {
    if (login_selected >= 0 && simple_hash(login_input) == accounts[login_selected].pass_hash) {
        int idx = login_selected;
        login_mode = LM_LIST; login_selected = -1; login_input_len = 0; login_input[0] = 0;
        login_error[0] = 0;
        do_login(idx);
    } else {
        str_copy(login_error, "Wrong password -- try again.", 48);
        login_input_len = 0; login_input[0] = 0;
    }
}

static void login_submit_new(void) {
    if (login_input_len == 0) {
        str_copy(login_error, "Type a name first.", 48);
        return;
    }
    if (account_count >= ACCOUNTS_MAX) {
        str_copy(login_error, "Account limit reached.", 48);
        return;
    }
    for (int i = 0; i < account_count; i++) {
        if (str_eq_ci(accounts[i].name, login_input)) {
            str_copy(login_error, "That name is already taken.", 48);
            return;
        }
    }
    int idx = account_count++;
    str_copy(accounts[idx].name, login_input, ACCOUNT_NAME_LEN);
    accounts[idx].pass_hash = 0;
    accounts[idx].has_password = 0;
    accounts[idx].kbd_layout = KBD_LAYOUT_US;
    save_accounts();
    login_mode = LM_LIST; login_input_len = 0; login_input[0] = 0; login_error[0] = 0;
    do_login(idx);
}

void accounts_login_click(i32 mx, i32 my) {
    if (login_mode == LM_LIST) {
        int total = account_count + 1;
        for (int i = 0; i < account_count; i++) {
            i32 cx, cy;
            login_card_rect(i, total, &cx, &cy);
            if (ui_point_in(mx, my, cx, cy, CARD_W, CARD_H)) {
                if (accounts[i].has_password) {
                    login_selected = i;
                    login_mode = LM_PASSWORD;
                    login_input_len = 0; login_input[0] = 0;
                    login_error[0] = 0;
                } else {
                    do_login(i);
                }
                return;
            }
        }
        i32 cx, cy;
        login_card_rect(account_count, total, &cx, &cy);
        if (ui_point_in(mx, my, cx, cy, CARD_W, CARD_H)) {
            login_mode = LM_NEW;
            login_input_len = 0; login_input[0] = 0;
            login_error[0] = 0;
        }
    } else if (login_mode == LM_PASSWORD) {
        i32 w = 280, h = 150;
        i32 px = ((i32)gfx.width - w) / 2, py = login_panel_y();
        if (ui_point_in(mx, my, px + 16, py + h - 40, (w - 40) / 2, 30)) {
            login_mode = LM_LIST; login_selected = -1; login_error[0] = 0;
            return;
        }
        if (ui_point_in(mx, my, px + 24 + (w - 40) / 2, py + h - 40, (w - 40) / 2, 30)) {
            login_submit_password();
        }
    } else {
        i32 w = 280, h = 150;
        i32 px = ((i32)gfx.width - w) / 2, py = login_panel_y();
        if (ui_point_in(mx, my, px + 16, py + h - 40, (w - 40) / 2, 30)) {
            login_mode = LM_LIST; login_error[0] = 0;
            return;
        }
        if (ui_point_in(mx, my, px + 24 + (w - 40) / 2, py + h - 40, (w - 40) / 2, 30)) {
            login_submit_new();
        }
    }
}

void accounts_login_key(int key) {
    if (login_mode == LM_LIST) {
        if (key == KEY_ENTER && account_count > 0 && !accounts[0].has_password) {
            do_login(0);
        }
        return;
    }
    if (key == KEY_BACKSPACE) {
        if (login_input_len > 0) login_input[--login_input_len] = 0;
    } else if (key == KEY_ENTER) {
        if (login_mode == LM_PASSWORD) login_submit_password();
        else login_submit_new();
    } else if (key == KEY_ESC) {
        login_mode = LM_LIST; login_error[0] = 0;
    } else if (kbd_is_printable(key) && key != ' ') {
        if (login_input_len < sizeof(login_input) - 1) {
            login_input[login_input_len++] = (char)key;
            login_input[login_input_len] = 0;
        }
    }
}

#define AM_NONE 0
#define AM_NEW_NAME 1
#define AM_SET_PASS1 2
#define AM_SET_PASS2 3

static int am_mode = AM_NONE;
static char am_input[24];
static u32 am_input_len = 0;
static char am_pass1[24];
static char am_status[64] = "";
static int am_selected = -1;

void app_accounts_draw(i32 x, i32 y, i32 w, i32 h) {
    (void)h;
    gfx_string(x + 16, y + 14, "Accounts", THEME_TEXT, THEME_PANEL, 0);
    char who[64] = "Logged in as: ";
    if (current_idx >= 0) str_cat(who, accounts[current_idx].name, 64);
    gfx_string(x + 16, y + 34, who, THEME_TEXT_FAINT, THEME_PANEL, 0);

    if (!disk_is_persistent) {
        gfx_string(x + w - 230, y + 14, "no disk: won't persist", THEME_WARNING, THEME_PANEL, 0);
    }

    i32 ly = y + 60;
    gfx_hline(x + 12, ly - 8, w - 24, THEME_BORDER);
    for (int i = 0; i < account_count; i++) {
        i32 ry = ly + i * 30;
        int sel = (i == am_selected);
        color_t row_bg = sel ? THEME_ACCENT : THEME_PANEL;
        if (sel) gfx_rounded_rect(x + 8, ry, w - 16, 26, 5, row_bg);
        color_t tc = sel ? THEME_ACCENT_TEXT : THEME_TEXT;
        char line[48];
        str_copy(line, accounts[i].name, 48);
        if (i == current_idx) str_cat(line, "  (this session)", 48);
        else if (accounts[i].has_password) str_cat(line, "  (password set)", 48);
        gfx_string(x + 14, ry + 5, line, tc, row_bg, 0);
    }

    i32 by = ly + account_count * 30 + 14;
    gfx_hline(x + 12, by - 8, w - 24, THEME_BORDER);

    if (am_mode == AM_NEW_NAME) {
        gfx_string(x + 16, by, "New account name:", THEME_TEXT_DIM, THEME_PANEL, 0);
        draw_text_field(x + 16, by + 20, 200, am_input, 1);
        ui_button(x + 226, by + 20, 80, 32, "Create", 1);
        ui_button(x + 312, by + 20, 80, 32, "Cancel", 0);
    } else if (am_mode == AM_SET_PASS1 || am_mode == AM_SET_PASS2) {
        char masked[24]; u32 ml = am_input_len; if (ml > 23) ml = 23;
        for (u32 i = 0; i < ml; i++) masked[i] = '*';
        masked[ml] = 0;
        gfx_string(x + 16, by, am_mode == AM_SET_PASS1 ? "New password:" : "Confirm password:",
                   THEME_TEXT_DIM, THEME_PANEL, 0);
        draw_text_field(x + 16, by + 20, 200, masked, 1);
        ui_button(x + 226, by + 20, 80, 32, "OK", 1);
        ui_button(x + 312, by + 20, 80, 32, "Cancel", 0);
    } else {
        ui_button(x + 16,  by, 110, 32, "New Account", 0);
        ui_button(x + 134, by, 130, 32, "Set Password", 0);
        int has_pw = (current_idx >= 0 && accounts[current_idx].has_password);
        if (has_pw) ui_button(x + 272, by, 140, 32, "Remove Password", 0);
        ui_button(x + 16, by + 40, 100, 32, "Delete", 0);
        ui_button(x + 134, by + 40, 100, 32, "Log Out", 1);
    }

    if (am_status[0]) gfx_string(x + 16, by + 84, am_status, THEME_SUCCESS, THEME_PANEL, 0);
}

static void am_submit_new_name(void) {
    if (am_input_len == 0) { str_copy(am_status, "Type a name first.", 64); return; }
    if (account_count >= ACCOUNTS_MAX) { str_copy(am_status, "Account limit reached.", 64); return; }
    for (int i = 0; i < account_count; i++) {
        if (str_eq_ci(accounts[i].name, am_input)) { str_copy(am_status, "That name is taken.", 64); return; }
    }
    int idx = account_count++;
    str_copy(accounts[idx].name, am_input, ACCOUNT_NAME_LEN);
    accounts[idx].pass_hash = 0; accounts[idx].has_password = 0; accounts[idx].kbd_layout = KBD_LAYOUT_US;
    save_accounts();
    str_copy(am_status, "Account created.", 64);
    am_mode = AM_NONE; am_input_len = 0; am_input[0] = 0;
}

static void am_submit_pass1(void) {
    str_copy(am_pass1, am_input, 24);
    am_input_len = 0; am_input[0] = 0;
    am_mode = AM_SET_PASS2;
}

static void am_submit_pass2(void) {
    if (!str_eq(am_pass1, am_input) || am_input_len == 0) {
        str_copy(am_status, "Passwords didn't match -- try again.", 64);
    } else if (current_idx >= 0) {
        accounts[current_idx].pass_hash = simple_hash(am_input);
        accounts[current_idx].has_password = 1;
        save_accounts();
        str_copy(am_status, "Password set.", 64);
    }
    am_mode = AM_NONE; am_input_len = 0; am_input[0] = 0;
}

void app_accounts_click(i32 rx, i32 ry) {
    i32 w = windows[APP_ACCOUNTS].w;
    i32 ly = 60;

    if (am_mode == AM_NONE) {
        for (int i = 0; i < account_count; i++) {
            i32 row_ry = ly + i * 30;
            if (ui_point_in(rx, ry, 8, row_ry, w - 16, 26)) { am_selected = i; return; }
        }
    }

    i32 by = ly + account_count * 30 + 14;

    if (am_mode == AM_NEW_NAME) {
        if (ui_point_in(rx, ry, 226, by + 20, 80, 32)) {
            am_submit_new_name();
        } else if (ui_point_in(rx, ry, 312, by + 20, 80, 32)) {
            am_mode = AM_NONE;
        }
        return;
    }
    if (am_mode == AM_SET_PASS1) {
        if (ui_point_in(rx, ry, 226, by + 20, 80, 32)) {
            am_submit_pass1();
        } else if (ui_point_in(rx, ry, 312, by + 20, 80, 32)) {
            am_mode = AM_NONE;
        }
        return;
    }
    if (am_mode == AM_SET_PASS2) {
        if (ui_point_in(rx, ry, 226, by + 20, 80, 32)) {
            am_submit_pass2();
        } else if (ui_point_in(rx, ry, 312, by + 20, 80, 32)) {
            am_mode = AM_NONE;
        }
        return;
    }

    if (ui_point_in(rx, ry, 16, by, 110, 32)) {
        am_mode = AM_NEW_NAME; am_input_len = 0; am_input[0] = 0; am_status[0] = 0;
        return;
    }
    if (ui_point_in(rx, ry, 134, by, 130, 32)) {
        am_mode = AM_SET_PASS1; am_input_len = 0; am_input[0] = 0; am_status[0] = 0;
        return;
    }
    int has_pw = (current_idx >= 0 && accounts[current_idx].has_password);
    if (has_pw && ui_point_in(rx, ry, 272, by, 140, 32)) {
        accounts[current_idx].has_password = 0;
        accounts[current_idx].pass_hash = 0;
        save_accounts();
        str_copy(am_status, "Password removed.", 64);
        return;
    }
    if (ui_point_in(rx, ry, 16, by + 40, 100, 32)) {
        if (am_selected < 0) {
            str_copy(am_status, "Select an account in the list first.", 64);
        } else if (am_selected == current_idx) {
            str_copy(am_status, "Can't delete the account you're using.", 64);
        } else if (account_count <= 1) {
            str_copy(am_status, "Can't delete the last account.", 64);
        } else {
            for (int i = am_selected; i < account_count - 1; i++) accounts[i] = accounts[i + 1];
            account_count--;
            if (current_idx > am_selected) current_idx--;
            am_selected = -1;
            save_accounts();
            str_copy(am_status, "Account deleted.", 64);
        }
        return;
    }
    if (ui_point_in(rx, ry, 134, by + 40, 100, 32)) {
        am_mode = AM_NONE; am_status[0] = 0; am_selected = -1;
        accounts_logout();
        return;
    }
}

void app_accounts_key(int key) {
    char* buf = 0; u32* len = 0;
    if (am_mode == AM_NEW_NAME) { buf = am_input; len = &am_input_len; }
    else if (am_mode == AM_SET_PASS1 || am_mode == AM_SET_PASS2) { buf = am_input; len = &am_input_len; }
    else return;

    if (key == KEY_BACKSPACE) {
        if (*len > 0) buf[--(*len)] = 0;
    } else if (key == KEY_ENTER) {
        if (am_mode == AM_NEW_NAME) am_submit_new_name();
        else if (am_mode == AM_SET_PASS1) am_submit_pass1();
        else if (am_mode == AM_SET_PASS2) am_submit_pass2();
    } else if (kbd_is_printable(key) && key != ' ') {
        if (*len < sizeof(am_input) - 1) {
            buf[(*len)++] = (char)key;
            buf[*len] = 0;
        }
    }
}
