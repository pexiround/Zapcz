#include "net.h"
#include "http.h"
#include "nic.h"
#include "e1000.h"
#include "libc_shim.h"
#include "pit.h"
#include "util.h"

#define ETH_TYPE_ARP  0x0806
#define ETH_TYPE_IPV4 0x0800
#define IP_PROTO_ICMP 1
#define IP_PROTO_TCP  6
#define IP_PROTO_UDP  17

typedef struct __attribute__((packed)) {
    u8  dst[6];
    u8  src[6];
    u16 ethertype;
} eth_hdr_t;

typedef struct __attribute__((packed)) {
    u16 htype, ptype;
    u8  hlen, plen;
    u16 oper;
    u8  sha[6];
    u32 spa;
    u8  tha[6];
    u32 tpa;
} arp_pkt_t;

typedef struct __attribute__((packed)) {
    u8  ver_ihl;
    u8  tos;
    u16 total_len;
    u16 id;
    u16 flags_frag;
    u8  ttl;
    u8  proto;
    u16 checksum;
    u32 src;
    u32 dst;
} ip_hdr_t;

typedef struct __attribute__((packed)) {
    u8  type, code;
    u16 checksum;
    u16 id, seq;
} icmp_hdr_t;

typedef struct __attribute__((packed)) {
    u16 sport, dport, len, checksum;
} udp_hdr_t;

typedef struct __attribute__((packed)) {
    u16 sport, dport;
    u32 seq, ack;
    u8  doff;
    u8  flags;
    u16 window;
    u16 checksum;
    u16 urgent;
} tcp_hdr_t;

#define TCP_FIN 0x01
#define TCP_SYN 0x02
#define TCP_RST 0x04
#define TCP_PSH 0x08
#define TCP_ACK 0x10

static u8 my_mac[6];
static u32 my_ip = 0, my_netmask = 0, my_gw = 0, my_dns = 0;
static int state = 0;
static const char* STATE_NAMES[] = { "no link", "link up, no IP", "ready (DHCP)" };

static u16 hswap16(u16 v) { return (u16)((v << 8) | (v >> 8)); }
static u32 hswap32(u32 v) {
    return ((v & 0xFFu) << 24) | ((v & 0xFF00u) << 8) | ((v >> 8) & 0xFF00u) | ((v >> 24) & 0xFFu);
}

static u32 csum_acc(const void* data, u32 len, u32 sum) {
    const u8* p = (const u8*)data;
    while (len > 1) { sum += ((u32)p[0] << 8) | p[1]; p += 2; len -= 2; }
    if (len) sum += ((u32)p[0] << 8);
    return sum;
}
static u16 csum_fold(u32 sum) {
    while (sum >> 16) sum = (sum & 0xFFFFu) + (sum >> 16);
    return (u16)~sum;
}

void net_ip_to_str(u32 ip, char* out) {
    u8 b[4] = { (u8)(ip & 0xFF), (u8)((ip >> 8) & 0xFF), (u8)((ip >> 16) & 0xFF), (u8)((ip >> 24) & 0xFF) };
    char nb[4];
    out[0] = 0;
    for (int i = 0; i < 4; i++) {
        u32_to_str(b[i], nb);
        str_cat(out, nb, 16);
        if (i < 3) str_cat(out, ".", 16);
    }
}

int net_str_to_ip(const char* s, u32* out) {
    u32 parts[4] = {0,0,0,0};
    int part = 0;
    u32 cur = 0;
    int any = 0;
    while (*s) {
        if (*s >= '0' && *s <= '9') { cur = cur * 10 + (u32)(*s - '0'); any = 1; }
        else if (*s == '.') {
            if (part >= 4 || !any) return 0;
            parts[part++] = cur; cur = 0; any = 0;
        } else return 0;
        s++;
    }
    if (part != 3 || !any) return 0;
    parts[3] = cur;
    for (int i = 0; i < 4; i++) if (parts[i] > 255) return 0;
    *out = parts[0] | (parts[1] << 8) | (parts[2] << 16) | (parts[3] << 24);
    return 1;
}

const char* net_state_str(void) { return STATE_NAMES[state]; }
int  net_ready(void) { return state == 2; }
int  net_state(void) { return state; }
void net_get_mac(u8 out[6]) { for (int i = 0; i < 6; i++) out[i] = my_mac[i]; }
u32  net_get_ip(void) { return my_ip; }
u32  net_get_gateway(void) { return my_gw; }
u32  net_get_netmask(void) { return my_netmask; }
u32  net_get_dns(void) { return my_dns; }

#define ARP_CACHE_SIZE 8
typedef struct { u32 ip; u8 mac[6]; int valid; } arp_entry_t;
static arp_entry_t arp_cache[ARP_CACHE_SIZE];

static void arp_cache_put(u32 ip, const u8* mac) {
    for (int i = 0; i < ARP_CACHE_SIZE; i++) {
        if (arp_cache[i].valid && arp_cache[i].ip == ip) {
            memcpy(arp_cache[i].mac, mac, 6);
            return;
        }
    }
    for (int i = 0; i < ARP_CACHE_SIZE; i++) {
        if (!arp_cache[i].valid) {
            arp_cache[i].ip = ip;
            memcpy(arp_cache[i].mac, mac, 6);
            arp_cache[i].valid = 1;
            return;
        }
    }
    arp_cache[0].ip = ip;
    memcpy(arp_cache[0].mac, mac, 6);
    arp_cache[0].valid = 1;
}

static int arp_cache_get(u32 ip, u8* mac_out) {
    for (int i = 0; i < ARP_CACHE_SIZE; i++) {
        if (arp_cache[i].valid && arp_cache[i].ip == ip) {
            memcpy(mac_out, arp_cache[i].mac, 6);
            return 1;
        }
    }
    return 0;
}

static u8 rx_buf[2048];
static u8 tx_buf[2048];

static void eth_send(const u8* dst_mac, u16 ethertype, const u8* payload, u32 len) {
    eth_hdr_t* eh = (eth_hdr_t*)tx_buf;
    memcpy(eh->dst, dst_mac, 6);
    memcpy(eh->src, my_mac, 6);
    eh->ethertype = hswap16(ethertype);
    if (len > sizeof(tx_buf) - sizeof(eth_hdr_t)) len = sizeof(tx_buf) - sizeof(eth_hdr_t);
    memcpy(tx_buf + sizeof(eth_hdr_t), payload, len);
    nic_send(tx_buf, sizeof(eth_hdr_t) + len);
}

static void send_arp_request(u32 target_ip) {
    arp_pkt_t pkt;
    memset(&pkt, 0, sizeof(pkt));
    pkt.htype = hswap16(1);
    pkt.ptype = hswap16(ETH_TYPE_IPV4);
    pkt.hlen = 6; pkt.plen = 4;
    pkt.oper = hswap16(1);
    memcpy(pkt.sha, my_mac, 6);
    pkt.spa = my_ip;
    memset(pkt.tha, 0, 6);
    pkt.tpa = target_ip;
    u8 bcast[6] = {0xFF,0xFF,0xFF,0xFF,0xFF,0xFF};
    eth_send(bcast, ETH_TYPE_ARP, (const u8*)&pkt, sizeof(pkt));
}

static void send_arp_reply(u32 target_ip, const u8* target_mac) {
    arp_pkt_t pkt;
    memset(&pkt, 0, sizeof(pkt));
    pkt.htype = hswap16(1);
    pkt.ptype = hswap16(ETH_TYPE_IPV4);
    pkt.hlen = 6; pkt.plen = 4;
    pkt.oper = hswap16(2);
    memcpy(pkt.sha, my_mac, 6);
    pkt.spa = my_ip;
    memcpy(pkt.tha, target_mac, 6);
    pkt.tpa = target_ip;
    eth_send(target_mac, ETH_TYPE_ARP, (const u8*)&pkt, sizeof(pkt));
}

static int arp_resolve(u32 ip, u8* mac_out, u32 timeout_ms) {
    if (arp_cache_get(ip, mac_out)) return 1;
    send_arp_request(ip);
    u32 start = ticks_get();
    u32 limit = (timeout_ms * ticks_per_sec()) / 1000;
    while (ticks_get() - start < limit) {
        net_poll();
        if (arp_cache_get(ip, mac_out)) return 1;
    }
    return 0;
}

static u32 route_next_hop(u32 dst_ip) {
    if ((dst_ip & my_netmask) == (my_ip & my_netmask)) return dst_ip;
    return my_gw;
}

static int icmp_reply_pending = 0;
static u32 icmp_reply_from = 0;
static u16 icmp_reply_id = 0, icmp_reply_seq = 0;

#define UDP_WAIT_BUF 1024
static int udp_wait_active = 0;
static u16 udp_wait_local_port = 0;
static u8  udp_wait_buf[UDP_WAIT_BUF];
static u32 udp_wait_len = 0;
static u32 udp_wait_from_ip = 0;
static u16 udp_wait_from_port = 0;

struct tcp_conn {
    int active;
    int state;
    u32 dst_ip;
    u16 dst_port;
    u16 src_port;
    u32 seq, ack;
    u8  dst_mac[6];
    u8  rxbuf[65536];
    u32 rxlen;
    int got_fin;
    int connected;
    int error;
};
static tcp_conn_t g_conn;

enum { TCPS_CLOSED=0, TCPS_SYN_SENT, TCPS_ESTABLISHED, TCPS_FIN_WAIT, TCPS_CLOSEWAIT, TCPS_DONE };

static void ip_send(u32 dst_ip, u8 proto, const u8* payload, u32 len) {
    static u16 ip_id = 1;
    u8 buf[2048 - 14];
    ip_hdr_t* ih = (ip_hdr_t*)buf;
    ih->ver_ihl = 0x45;
    ih->tos = 0;
    ih->total_len = hswap16((u16)(20 + len));
    ih->id = hswap16(ip_id++);
    ih->flags_frag = 0;
    ih->ttl = 64;
    ih->proto = proto;
    ih->checksum = 0;
    ih->src = my_ip;
    ih->dst = dst_ip;
    ih->checksum = hswap16(csum_fold(csum_acc(ih, 20, 0)));
    if (len > sizeof(buf) - 20) len = sizeof(buf) - 20;
    memcpy(buf + 20, payload, len);

    u32 hop = route_next_hop(dst_ip);
    u8 mac[6];
    if (!arp_resolve(hop, mac, 1500)) return;
    eth_send(mac, ETH_TYPE_IPV4, buf, 20 + len);
}

static void handle_icmp(u32 src_ip, const u8* data, u32 len) {
    if (len < 8) return;
    icmp_hdr_t hdr;
    memcpy(&hdr, data, 8);
    if (hdr.type == 8) {
        u8 reply[1024];
        u32 rlen = len; if (rlen > sizeof(reply)) rlen = sizeof(reply);
        memcpy(reply, data, rlen);
        icmp_hdr_t* rh = (icmp_hdr_t*)reply;
        rh->type = 0; rh->code = 0; rh->checksum = 0;
        rh->checksum = hswap16(csum_fold(csum_acc(reply, rlen, 0)));
        ip_send(src_ip, IP_PROTO_ICMP, reply, rlen);
    } else if (hdr.type == 0) {
        icmp_reply_pending = 1;
        icmp_reply_from = src_ip;
        icmp_reply_id = hswap16(hdr.id);
        icmp_reply_seq = hswap16(hdr.seq);
    }
}

static void handle_udp(u32 src_ip, const u8* data, u32 len) {
    if (len < 8) return;
    udp_hdr_t hdr;
    memcpy(&hdr, data, 8);
    u16 dport = hswap16(hdr.dport);
    u16 sport = hswap16(hdr.sport);
    if (udp_wait_active && dport == udp_wait_local_port) {
        u32 plen = len - 8;
        if (plen > UDP_WAIT_BUF) plen = UDP_WAIT_BUF;
        memcpy(udp_wait_buf, data + 8, plen);
        udp_wait_len = plen;
        udp_wait_from_ip = src_ip;
        udp_wait_from_port = sport;
        udp_wait_active = 0;
    }
}

static void tcp_send_segment(tcp_conn_t* c, u8 flags, const u8* data, u32 dlen) {
    u8 buf[2048 - 14 - 20];
    tcp_hdr_t* th = (tcp_hdr_t*)buf;
    th->sport = hswap16(c->src_port);
    th->dport = hswap16(c->dst_port);
    th->seq = hswap32(c->seq);
    th->ack = hswap32((flags & TCP_ACK) ? c->ack : 0);
    th->doff = (5 << 4);
    th->flags = flags;
    { u32 avail = (u32)sizeof(c->rxbuf) - c->rxlen; if (avail > 65535) avail = 65535; th->window = hswap16((u16)avail); }
    th->checksum = 0;
    th->urgent = 0;
    u32 hlen = 20;
    if (dlen > sizeof(buf) - hlen) dlen = sizeof(buf) - hlen;
    if (dlen) memcpy(buf + hlen, data, dlen);

    u32 seg_len = hlen + dlen;
    u32 sum = 0;
    sum = csum_acc(&my_ip, 4, sum);
    sum = csum_acc(&c->dst_ip, 4, sum);
    u8 ph[4] = { 0, IP_PROTO_TCP, (u8)((seg_len >> 8) & 0xFF), (u8)(seg_len & 0xFF) };
    sum = csum_acc(ph, 4, sum);
    sum = csum_acc(buf, seg_len, sum);
    th->checksum = hswap16(csum_fold(sum));

    ip_send(c->dst_ip, IP_PROTO_TCP, buf, seg_len);

    if (dlen) c->seq += dlen;
    if (flags & (TCP_SYN | TCP_FIN)) c->seq += 1;
}

static void handle_tcp(u32 src_ip, const u8* data, u32 len) {
    if (len < 20) return;
    tcp_hdr_t hdr;
    memcpy(&hdr, data, 20);
    tcp_conn_t* c = &g_conn;
    if (!c->active) return;
    if (src_ip != c->dst_ip) return;
    u16 sport = hswap16(hdr.sport);
    if (sport != c->dst_port) return;
    u16 dport = hswap16(hdr.dport);
    if (dport != c->src_port) return;

    u32 seg_seq = hswap32(hdr.seq);
    u32 hlen = ((hdr.doff >> 4) & 0xF) * 4;
    u32 dlen = (len > hlen) ? (len - hlen) : 0;

    if (c->state == TCPS_SYN_SENT) {
        if ((hdr.flags & TCP_SYN) && (hdr.flags & TCP_ACK)) {
            c->ack = seg_seq + 1;
            c->connected = 1;
            c->state = TCPS_ESTABLISHED;
            tcp_send_segment(c, TCP_ACK, 0, 0);
        } else if (hdr.flags & TCP_RST) {
            c->error = 1; c->state = TCPS_DONE;
        }
        return;
    }

    if (dlen > 0 && seg_seq == c->ack) {
        u32 space = (u32)sizeof(c->rxbuf) - c->rxlen;
        u32 copy = dlen; if (copy > space) copy = space;
        if (copy > 0) memcpy(c->rxbuf + c->rxlen, data + hlen, copy);
        c->rxlen += copy;
        c->ack += copy;
        tcp_send_segment(c, TCP_ACK, 0, 0);
    } else if (dlen > 0) {
        tcp_send_segment(c, TCP_ACK, 0, 0);
    }

    if (hdr.flags & TCP_FIN) {
        c->ack += 1;
        c->got_fin = 1;
        tcp_send_segment(c, TCP_ACK, 0, 0);
        if (c->state == TCPS_ESTABLISHED) c->state = TCPS_CLOSEWAIT;
    }
    if (hdr.flags & TCP_RST) {
        c->error = 1;
        c->state = TCPS_DONE;
    }
}

static void handle_ip(const u8* data, u32 len) {
    if (len < 20) return;
    ip_hdr_t hdr;
    memcpy(&hdr, data, 20);
    if ((hdr.ver_ihl >> 4) != 4) return;
    u32 ihl = (hdr.ver_ihl & 0xF) * 4;
    if (ihl < 20 || ihl > len) return;
    u32 total = hswap16(hdr.total_len);
    if (total > len) total = len;
    const u8* payload = data + ihl;
    u32 plen = total - ihl;

    if (hdr.proto == IP_PROTO_ICMP) handle_icmp(hdr.src, payload, plen);
    else if (hdr.proto == IP_PROTO_UDP) handle_udp(hdr.src, payload, plen);
    else if (hdr.proto == IP_PROTO_TCP) handle_tcp(hdr.src, payload, plen);
}

static void handle_arp(const u8* data, u32 len) {
    if (len < sizeof(arp_pkt_t)) return;
    arp_pkt_t pkt;
    memcpy(&pkt, data, sizeof(pkt));
    u16 oper = hswap16(pkt.oper);
    if (oper == 1) {
        if (pkt.tpa == my_ip) send_arp_reply(pkt.spa, pkt.sha);
    } else if (oper == 2) {
        arp_cache_put(pkt.spa, pkt.sha);
    }
}

void net_poll(void) {
    if (!nic_available()) return;
    for (int i = 0; i < 8; i++) {
        int n = nic_poll_recv(rx_buf, sizeof(rx_buf));
        if (n <= 0) break;
        if ((u32)n < sizeof(eth_hdr_t)) continue;
        eth_hdr_t* eh = (eth_hdr_t*)rx_buf;
        u16 et = hswap16(eh->ethertype);
        const u8* payload = rx_buf + sizeof(eth_hdr_t);
        u32 plen = (u32)n - sizeof(eth_hdr_t);
        if (et == ETH_TYPE_ARP) handle_arp(payload, plen);
        else if (et == ETH_TYPE_IPV4) handle_ip(payload, plen);
    }
}

static int udp_send(u32 dst_ip, u16 sport, u16 dport, const u8* data, u32 len) {
    u8 buf[1024];
    udp_hdr_t* uh = (udp_hdr_t*)buf;
    uh->sport = hswap16(sport);
    uh->dport = hswap16(dport);
    uh->len = hswap16((u16)(8 + len));
    uh->checksum = 0;
    if (len > sizeof(buf) - 8) len = sizeof(buf) - 8;
    memcpy(buf + 8, data, len);
    ip_send(dst_ip, IP_PROTO_UDP, buf, 8 + len);
    return 1;
}

static int udp_wait_response(u32 timeout_ms) {
    u32 start = ticks_get();
    u32 limit = (timeout_ms * ticks_per_sec()) / 1000;
    while (ticks_get() - start < limit) {
        net_poll();
        if (!udp_wait_active) return 1;
    }
    return 0;
}

static u16 next_ephemeral_port = 49152;
static u16 alloc_port(void) {
    u16 p = next_ephemeral_port++;
    if (next_ephemeral_port == 0) next_ephemeral_port = 49152;
    return p;
}

static int dhcp_run(u32 timeout_ms) {
    u16 my_port = 68;
    u8 pkt[300];
    memset(pkt, 0, sizeof(pkt));
    pkt[0] = 1; pkt[1] = 1; pkt[2] = 6; pkt[3] = 0;
    static u32 xid = 0x12345678;
    pkt[4] = (u8)(xid >> 24); pkt[5] = (u8)(xid >> 16); pkt[6] = (u8)(xid >> 8); pkt[7] = (u8)xid;
    pkt[10] = 0x80;
    memcpy(pkt + 28, my_mac, 6);
    pkt[236] = 99; pkt[237] = 130; pkt[238] = 83; pkt[239] = 99;
    u32 o = 240;
    pkt[o++] = 53; pkt[o++] = 1; pkt[o++] = 1;
    pkt[o++] = 55; pkt[o++] = 3; pkt[o++] = 1; pkt[o++] = 3; pkt[o++] = 6;
    pkt[o++] = 255;

    udp_wait_active = 1;
    udp_wait_local_port = my_port;
    u32 dst_bcast = 0xFFFFFFFFu;
    u8 bcast_mac[6] = {0xFF,0xFF,0xFF,0xFF,0xFF,0xFF};
    {
        u8 ubuf[400];
        udp_hdr_t* uh = (udp_hdr_t*)ubuf;
        uh->sport = hswap16(68); uh->dport = hswap16(67);
        uh->len = hswap16((u16)(8 + o)); uh->checksum = 0;
        memcpy(ubuf + 8, pkt, o);
        u8 ipbuf[440];
        ip_hdr_t* ih = (ip_hdr_t*)ipbuf;
        ih->ver_ihl = 0x45; ih->tos = 0;
        ih->total_len = hswap16((u16)(20 + 8 + o));
        ih->id = hswap16(1); ih->flags_frag = 0; ih->ttl = 64;
        ih->proto = IP_PROTO_UDP; ih->checksum = 0;
        ih->src = 0; ih->dst = dst_bcast;
        ih->checksum = hswap16(csum_fold(csum_acc(ih, 20, 0)));
        memcpy(ipbuf + 20, ubuf, 8 + o);
        eth_send(bcast_mac, ETH_TYPE_IPV4, ipbuf, 20 + 8 + o);
    }

    if (!udp_wait_response(timeout_ms)) return 0;

    u8* offer = udp_wait_buf;
    u32 offered_ip = ((u32)offer[16]) | ((u32)offer[17] << 8) | ((u32)offer[18] << 16) | ((u32)offer[19] << 24);
    u32 server_ip = 0;
    u32 oo = 240;
    while (oo < udp_wait_len) {
        u8 code = offer[oo];
        if (code == 255) break;
        if (code == 0) { oo++; continue; }
        u8 olen = offer[oo + 1];
        if (code == 54) server_ip = ((u32)offer[oo+2]) | ((u32)offer[oo+3]<<8) | ((u32)offer[oo+4]<<16) | ((u32)offer[oo+5]<<24);
        oo += 2 + olen;
    }
    if (server_ip == 0) server_ip = udp_wait_from_ip;

    memset(pkt, 0, sizeof(pkt));
    pkt[0] = 1; pkt[1] = 1; pkt[2] = 6; pkt[3] = 0;
    pkt[4] = (u8)(xid >> 24); pkt[5] = (u8)(xid >> 16); pkt[6] = (u8)(xid >> 8); pkt[7] = (u8)xid;
    pkt[10] = 0x80;
    memcpy(pkt + 28, my_mac, 6);
    pkt[236] = 99; pkt[237] = 130; pkt[238] = 83; pkt[239] = 99;
    o = 240;
    pkt[o++] = 53; pkt[o++] = 1; pkt[o++] = 3;
    pkt[o++] = 50; pkt[o++] = 4;
    pkt[o++] = (u8)(offered_ip); pkt[o++] = (u8)(offered_ip>>8); pkt[o++] = (u8)(offered_ip>>16); pkt[o++] = (u8)(offered_ip>>24);
    pkt[o++] = 54; pkt[o++] = 4;
    pkt[o++] = (u8)(server_ip); pkt[o++] = (u8)(server_ip>>8); pkt[o++] = (u8)(server_ip>>16); pkt[o++] = (u8)(server_ip>>24);
    pkt[o++] = 255;

    udp_wait_active = 1;
    udp_wait_local_port = my_port;
    {
        u8 ubuf[400];
        udp_hdr_t* uh = (udp_hdr_t*)ubuf;
        uh->sport = hswap16(68); uh->dport = hswap16(67);
        uh->len = hswap16((u16)(8 + o)); uh->checksum = 0;
        memcpy(ubuf + 8, pkt, o);
        u8 ipbuf[440];
        ip_hdr_t* ih = (ip_hdr_t*)ipbuf;
        ih->ver_ihl = 0x45; ih->tos = 0;
        ih->total_len = hswap16((u16)(20 + 8 + o));
        ih->id = hswap16(2); ih->flags_frag = 0; ih->ttl = 64;
        ih->proto = IP_PROTO_UDP; ih->checksum = 0;
        ih->src = 0; ih->dst = dst_bcast;
        ih->checksum = hswap16(csum_fold(csum_acc(ih, 20, 0)));
        memcpy(ipbuf + 20, ubuf, 8 + o);
        eth_send(bcast_mac, ETH_TYPE_IPV4, ipbuf, 20 + 8 + o);
    }
    if (!udp_wait_response(timeout_ms)) return 0;

    u8* ack = udp_wait_buf;
    u32 acked_ip = ((u32)ack[16]) | ((u32)ack[17] << 8) | ((u32)ack[18] << 16) | ((u32)ack[19] << 24);
    u32 mask = 0xFFFFFFu | 0xFF000000u;
    u32 gw = 0, dns = 0;
    oo = 240;
    while (oo < udp_wait_len) {
        u8 code = ack[oo];
        if (code == 255) break;
        if (code == 0) { oo++; continue; }
        u8 olen = ack[oo + 1];
        if (code == 1 && olen == 4) mask = ((u32)ack[oo+2]) | ((u32)ack[oo+3]<<8) | ((u32)ack[oo+4]<<16) | ((u32)ack[oo+5]<<24);
        if (code == 3 && olen >= 4) gw = ((u32)ack[oo+2]) | ((u32)ack[oo+3]<<8) | ((u32)ack[oo+4]<<16) | ((u32)ack[oo+5]<<24);
        if (code == 6 && olen >= 4) dns = ((u32)ack[oo+2]) | ((u32)ack[oo+3]<<8) | ((u32)ack[oo+4]<<16) | ((u32)ack[oo+5]<<24);
        oo += 2 + olen;
    }
    my_ip = acked_ip;
    my_netmask = mask;
    my_gw = gw;
    my_dns = dns;
    return 1;
}

void net_init(void) {
    memset(arp_cache, 0, sizeof(arp_cache));
    state = 0;
    if (!nic_init()) return;
    nic_get_mac(my_mac);
    state = 1;
    if (dhcp_run(2000)) state = 2;
}

int net_ping(u32 dst_ip, u32 timeout_ms, u32* out_ms) {
    if (!net_ready() && my_ip == 0) return 0;
    icmp_reply_pending = 0;
    u8 payload[40];
    icmp_hdr_t* ih = (icmp_hdr_t*)payload;
    ih->type = 8; ih->code = 0; ih->checksum = 0;
    static u16 pid = 1;
    ih->id = hswap16(pid);
    ih->seq = hswap16(1);
    for (u32 i = 8; i < sizeof(payload); i++) payload[i] = (u8)i;
    ih->checksum = hswap16(csum_fold(csum_acc(payload, sizeof(payload), 0)));

    u32 t0 = ticks_get();
    ip_send(dst_ip, IP_PROTO_ICMP, payload, sizeof(payload));

    u32 start = ticks_get();
    u32 limit = (timeout_ms * ticks_per_sec()) / 1000;
    while (ticks_get() - start < limit) {
        net_poll();
        if (icmp_reply_pending && icmp_reply_from == dst_ip && hswap16(ih->id) == icmp_reply_id) {
            u32 t1 = ticks_get();
            if (out_ms) *out_ms = ((t1 - t0) * 1000) / ticks_per_sec();
            pid++;
            return 1;
        }
    }
    pid++;
    return 0;
}

int net_dns_resolve(const char* hostname, u32* out_ip, u32 timeout_ms) {
    if (my_dns == 0) return 0;
    u8 q[300];
    memset(q, 0, sizeof(q));
    static u16 qid = 0x4242;
    q[0] = (u8)(qid >> 8); q[1] = (u8)qid;
    q[2] = 0x01; q[3] = 0x00;
    q[4] = 0; q[5] = 1;
    q[6] = 0; q[7] = 0;
    q[8] = 0; q[9] = 0;
    q[10] = 0; q[11] = 0;
    u32 p = 12;
    const char* s = hostname;
    while (*s) {
        u32 lenpos = p++;
        u32 l = 0;
        while (*s && *s != '.') { q[p++] = (u8)*s++; l++; if (p >= sizeof(q) - 6) break; }
        q[lenpos] = (u8)l;
        if (*s == '.') s++;
    }
    q[p++] = 0;
    q[p++] = 0; q[p++] = 1;
    q[p++] = 0; q[p++] = 1;

    u16 lport = alloc_port();
    udp_wait_active = 1;
    udp_wait_local_port = lport;
    udp_send(my_dns, lport, 53, q, p);

    if (!udp_wait_response(timeout_ms)) return 0;

    u8* r = udp_wait_buf;
    if (udp_wait_len < 12) return 0;
    u16 ancount = ((u16)r[6] << 8) | r[7];
    u16 qdcount = ((u16)r[4] << 8) | r[5];
    if (ancount == 0) return 0;
    u32 pos = 12;
    for (u16 i = 0; i < qdcount && pos < udp_wait_len; i++) {
        while (pos < udp_wait_len && r[pos] != 0) {
            if ((r[pos] & 0xC0) == 0xC0) { pos += 2; goto qdone; }
            pos += r[pos] + 1;
        }
        pos++;
        qdone:;
        pos += 4;
    }
    for (u16 i = 0; i < ancount; i++) {
        if (pos >= udp_wait_len) break;
        if ((r[pos] & 0xC0) == 0xC0) pos += 2;
        else { while (pos < udp_wait_len && r[pos] != 0) pos += r[pos] + 1; pos++; }
        if (pos + 10 > udp_wait_len) break;
        u16 rtype = ((u16)r[pos] << 8) | r[pos+1];
        u16 rdlen = ((u16)r[pos+8] << 8) | r[pos+9];
        pos += 10;
        if (rtype == 1 && rdlen == 4 && pos + 4 <= udp_wait_len) {
            *out_ip = ((u32)r[pos]) | ((u32)r[pos+1]<<8) | ((u32)r[pos+2]<<16) | ((u32)r[pos+3]<<24);
            qid++;
            return 1;
        }
        pos += rdlen;
    }
    qid++;
    return 0;
}

tcp_conn_t* tcp_connect(u32 dst_ip, u16 dst_port, u32 timeout_ms) {
    tcp_conn_t* c = &g_conn;
    memset(c, 0, sizeof(*c));
    c->active = 1;
    c->dst_ip = dst_ip;
    c->dst_port = dst_port;
    c->src_port = alloc_port();
    c->seq = 0x1000 + (u32)ticks_get();
    c->state = TCPS_SYN_SENT;

    tcp_send_segment(c, TCP_SYN, 0, 0);

    u32 start = ticks_get();
    u32 limit = (timeout_ms * ticks_per_sec()) / 1000;
    while (ticks_get() - start < limit) {
        net_poll();
        if (c->state == TCPS_ESTABLISHED) return c;
        if (c->state == TCPS_DONE) { c->active = 0; return 0; }
    }
    c->active = 0;
    return 0;
}

int tcp_send(tcp_conn_t* c, const u8* data, u32 len) {
    if (!c || !c->active) return 0;
    u32 sent = 0;
    while (sent < len) {
        u32 chunk = len - sent;
        if (chunk > 1300) chunk = 1300;
        tcp_send_segment(c, TCP_ACK | TCP_PSH, data + sent, chunk);
        sent += chunk;
        u32 start = ticks_get();
        while (ticks_get() - start < ticks_per_sec() / 20) net_poll();
    }
    return (int)sent;
}

int tcp_recv(tcp_conn_t* c, u8* buf, u32 bufsize, u32 timeout_ms) {
    if (!c) return -1;
    u32 start = ticks_get();
    u32 limit = (timeout_ms * ticks_per_sec()) / 1000;
    while (c->rxlen == 0 && !c->got_fin && ticks_get() - start < limit) {
        net_poll();
    }
    if (c->rxlen == 0) {
        return -1;
    }
    u32 before = c->rxlen;
    u32 n = c->rxlen; if (n > bufsize) n = bufsize;
    memcpy(buf, c->rxbuf, n);
    if (n < c->rxlen) memmove(c->rxbuf, c->rxbuf + n, c->rxlen - n);
    c->rxlen -= n;
    if (n > 0 && before >= sizeof(c->rxbuf) / 2 && c->state == TCPS_ESTABLISHED)
        tcp_send_segment(c, TCP_ACK, 0, 0);
    return (int)n;
}

int tcp_is_closed(tcp_conn_t* c) {
    if (!c) return 1;
    return c->got_fin && c->rxlen == 0;
}

void tcp_close(tcp_conn_t* c) {
    if (!c || !c->active) return;
    tcp_send_segment(c, TCP_FIN | TCP_ACK, 0, 0);
    c->active = 0;
}
