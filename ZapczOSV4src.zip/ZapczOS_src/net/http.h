#ifndef HTTP_H
#define HTTP_H
#include "io.h"

typedef struct {
    int  status_code;
    char content_type[64];
    u32  body_len;
    int  error;
    char error_msg[64];
    char location[256];
} http_response_t;

int http_get(const char* host, u16 port, const char* path, int use_tls, u8* body_buf, u32 body_buf_size, http_response_t* resp);

int  http_fetch_begin(const char* host, u16 port, const char* path, int use_tls,
                      u8* body_buf, u32 body_buf_size);
int  http_fetch_pump(void);
int  http_fetch_finish(http_response_t* resp);
void http_fetch_abort(void);
int  http_fetch_active(void);
u32  http_fetch_bytes(void);
int  http_fetch_state(void);

#endif
void http_set_privacy(int ua_mode, int dnt);
int  http_get_ua_mode(void);
int  http_get_dnt(void);
