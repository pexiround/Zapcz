#ifndef NET_H
#define NET_H
#include "io.h"

void net_init(void);
void net_poll(void);
int  net_ready(void);
int  net_state(void);
void net_get_mac(u8 out[6]);
u32  net_get_ip(void);
u32  net_get_gateway(void);
u32  net_get_netmask(void);
u32  net_get_dns(void);
const char* net_state_str(void);
void net_ip_to_str(u32 ip, char* out);
int  net_str_to_ip(const char* s, u32* out);

int  net_ping(u32 dst_ip, u32 timeout_ms, u32* out_ms);

int  net_dns_resolve(const char* hostname, u32* out_ip, u32 timeout_ms);

typedef struct tcp_conn tcp_conn_t;
tcp_conn_t* tcp_connect(u32 dst_ip, u16 dst_port, u32 timeout_ms);
int  tcp_send(tcp_conn_t* c, const u8* data, u32 len);
int  tcp_recv(tcp_conn_t* c, u8* buf, u32 bufsize, u32 timeout_ms);
void tcp_close(tcp_conn_t* c);
int  tcp_is_closed(tcp_conn_t* c);

#endif
