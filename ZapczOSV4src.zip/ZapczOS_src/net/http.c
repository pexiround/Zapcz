#include "http.h"
#include "net.h"
#include "tls.h"
#include "util.h"
#include "libc_shim.h"
#include "pit.h"

static int find_crlfcrlf(const u8* buf, u32 len) {
    for (u32 i = 0; i + 3 < len; i++) {
        if (buf[i] == '\r' && buf[i+1] == '\n' && buf[i+2] == '\r' && buf[i+3] == '\n') return (int)i;
    }
    return -1;
}

static void extract_header(const u8* headers, u32 hlen, const char* name, char* out, u32 outsize) {
    out[0] = 0;
    u32 nlen = str_len(name);
    for (u32 i = 0; i + nlen < hlen; i++) {
        int match = 1;
        for (u32 j = 0; j < nlen; j++) {
            char a = (char)headers[i + j], b = name[j];
            if (a >= 'A' && a <= 'Z') a = (char)(a - 'A' + 'a');
            if (b >= 'A' && b <= 'Z') b = (char)(b - 'A' + 'a');
            if (a != b) { match = 0; break; }
        }
        if (!match) continue;
        if (i > 0 && headers[i - 1] != '\n') continue;
        u32 p = i + nlen;
        while (p < hlen && (headers[p] == ' ' || headers[p] == ':')) p++;
        u32 o = 0;
        while (p < hlen && headers[p] != '\r' && headers[p] != '\n' && o + 1 < outsize) {
            out[o++] = (char)headers[p++];
        }
        out[o] = 0;
        return;
    }
}

static int g_priv_ua_mode = 0;
static int g_priv_dnt = 0;

void http_set_privacy(int ua_mode, int dnt) { g_priv_ua_mode = ua_mode; g_priv_dnt = dnt; }
int  http_get_ua_mode(void) { return g_priv_ua_mode; }
int  http_get_dnt(void)     { return g_priv_dnt; }

static const char* http_ua_string(void) {
    if (g_priv_ua_mode == 1) return "Mozilla/5.0 (Windows NT 10.0; Win64; x64) Gecko/20100101 Firefox/128.0";
    if (g_priv_ua_mode == 2) return 0;
    return "ZapczOS/1.0";
}

static void http_append_headers(char* req, u32 cap) {
    const char* ua = http_ua_string();
    if (ua) { str_cat(req, "\r\nUser-Agent: ", cap); str_cat(req, ua, cap); }
    str_cat(req, "\r\nAccept: */*\r\nAccept-Encoding: identity", cap);
    if (g_priv_dnt) str_cat(req, "\r\nDNT: 1\r\nSec-GPC: 1", cap);
    str_cat(req, "\r\nConnection: close\r\n\r\n", cap);
}

static void parse_url(const char* addr, int* use_tls, char* host, u32 host_size,
                       u16* port, char* path, u32 path_size) {
    *use_tls = starts_with(addr, "https://");
    const char* p = addr + (*use_tls ? 8 : 7);
    u32 hi = 0;
    while (*p && *p != '/' && *p != ':' && hi < host_size - 1) host[hi++] = *p++;
    host[hi] = 0;

    *port = (u16)(*use_tls ? 443 : 80);
    if (*p == ':') {
        p++;
        u32 pv = 0;
        while (*p >= '0' && *p <= '9') { pv = pv * 10 + (u32)(*p - '0'); p++; }
        if (pv > 0 && pv < 65536) *port = (u16)pv;
    }

    if (*p == '/') str_copy(path, p, path_size);
    else str_copy(path, "/", path_size);
}

/* Decode HTTP/1.1 chunked transfer-encoding in place.
   Format: <hex-size>\r\n<data>\r\n ... 0\r\n\r\n
   Returns the decoded length. */
static u32 dechunk_inplace(u8* buf, u32 len) {
    u32 rd = 0, wr = 0;
    while (rd < len) {
        /* parse hex chunk size */
        u32 sz = 0; int got = 0;
        while (rd < len) {
            u8 ch = buf[rd];
            int v = -1;
            if (ch >= '0' && ch <= '9') v = ch - '0';
            else if (ch >= 'a' && ch <= 'f') v = ch - 'a' + 10;
            else if (ch >= 'A' && ch <= 'F') v = ch - 'A' + 10;
            else break;
            sz = (sz << 4) | (u32)v; got = 1; rd++;
        }
        if (!got) break;
        /* skip any chunk extension up to CRLF */
        while (rd < len && buf[rd] != '\n') rd++;
        if (rd < len) rd++;
        if (sz == 0) break;                 /* final chunk */
        if (rd + sz > len) sz = len - rd;   /* truncated */
        for (u32 k = 0; k < sz; k++) buf[wr + k] = buf[rd + k];
        wr += sz; rd += sz;
        /* skip trailing CRLF after chunk data */
        while (rd < len && (buf[rd] == '\r' || buf[rd] == '\n')) rd++;
    }
    return wr;
}

static int http_get_once(const char* host, u16 port, const char* path, int use_tls,
                          u8* body_buf, u32 body_buf_size, http_response_t* resp,
                          char* location_out, u32 location_out_size) {
    memset(resp, 0, sizeof(*resp));
    location_out[0] = 0;
    watchdog_heartbeat("dns lookup");

    u32 ip;
    if (!net_str_to_ip(host, &ip)) {
        if (!net_dns_resolve(host, &ip, 3000)) {
            resp->error = 1;
            str_copy(resp->error_msg, "DNS lookup failed", sizeof(resp->error_msg));
            return 0;
        }
    }

    watchdog_heartbeat("connecting");
    tcp_conn_t* c = 0;
    tls_conn_t* tc = 0;
    if (use_tls) {
        tc = tls_connect(ip, port, host, 6000);
        if (!tc) {
            resp->error = 1;
            str_copy(resp->error_msg, "TLS handshake failed", sizeof(resp->error_msg));
            return 0;
        }
    } else {
        c = tcp_connect(ip, port, 4000);
        if (!c) {
            resp->error = 1;
            str_copy(resp->error_msg, "connection failed", sizeof(resp->error_msg));
            return 0;
        }
    }

    char req[768];
    str_copy(req, "GET ", sizeof(req));
    str_cat(req, path[0] ? path : "/", sizeof(req));
    str_cat(req, " HTTP/1.1\r\nHost: ", sizeof(req));
    str_cat(req, host, sizeof(req));
    http_append_headers(req, sizeof(req));

    if (use_tls) tls_send(tc, (const u8*)req, str_len(req));
    else tcp_send(c, (const u8*)req, str_len(req));


    u32 total = 0;
    int idle_rounds = 0;
    u32 recv_timeout = use_tls ? 2500 : 2000;
    while (total < body_buf_size) {
        watchdog_heartbeat("http fetch");
        int n = use_tls ? tls_recv(tc, body_buf + total, body_buf_size - total, recv_timeout)
                         : tcp_recv(c, body_buf + total, body_buf_size - total, recv_timeout);
        /* A large HTTPS page can take far longer than the watchdog's 20s
           patience, and no frames are drawn while we block here, so the
           watchdog would fire and look like a crash. Keep it fed. */
        watchdog_heartbeat("web: receiving");

        if (n > 0) {
            total += (u32)n;
            idle_rounds = 0;
            /* A complete HTML document ends with </html>; once we have that
               there is no reason to keep waiting on the socket. */
            if (total > 512) {
                const u8* tail = body_buf + total - 16;
                for (int q = 0; q < 9; q++) {
                    if ((tail[q] == '<') && (tail[q+1] == '/') &&
                        (tail[q+2] == 'h' || tail[q+2] == 'H') &&
                        (tail[q+3] == 't' || tail[q+3] == 'T') &&
                        (tail[q+4] == 'm' || tail[q+4] == 'M') &&
                        (tail[q+5] == 'l' || tail[q+5] == 'L')) { goto recv_done; }
                }
            }
        } else if (n == 0) {
            break;
        } else {
            idle_rounds++;
            if (idle_rounds >= 2) break;
        }
    }
recv_done:
    if (use_tls) tls_close(tc);
    else tcp_close(c);

    int sep = find_crlfcrlf(body_buf, total);
    if (sep < 0) {
        resp->error = 1;
        str_copy(resp->error_msg, "no response", sizeof(resp->error_msg));
        return 0;
    }

    int code = 0;
    u32 p = 0;
    while (p < (u32)sep && body_buf[p] != ' ') p++;
    p++;
    while (p < (u32)sep && body_buf[p] >= '0' && body_buf[p] <= '9') { code = code * 10 + (body_buf[p] - '0'); p++; }
    resp->status_code = code;

    char ctbuf[64];
    extract_header(body_buf, (u32)sep, "Content-Type", ctbuf, sizeof(ctbuf));
    str_copy(resp->content_type, ctbuf, sizeof(resp->content_type));

    if (code >= 300 && code < 400) {
        extract_header(body_buf, (u32)sep, "Location", location_out, location_out_size);
    }

    char tebuf[32];
    extract_header(body_buf, (u32)sep, "Transfer-Encoding", tebuf, sizeof(tebuf));
    int is_chunked = (tebuf[0] && (tebuf[0] == 'c' || tebuf[0] == 'C'));

    u32 body_start = (u32)sep + 4;
    u32 blen = (total > body_start) ? (total - body_start) : 0;
    if (blen > 0) memmove(body_buf, body_buf + body_start, blen);
    if (is_chunked && blen > 0) blen = dechunk_inplace(body_buf, blen);
    resp->body_len = blen;
    return 1;
}

int http_get(const char* host, u16 port, const char* path, int use_tls, u8* body_buf, u32 body_buf_size, http_response_t* resp) {
    char cur_host[64];
    char cur_path[192];
    u16 cur_port = port;
    int cur_tls = use_tls;
    str_copy(cur_host, host, sizeof(cur_host));
    str_copy(cur_path, path, sizeof(cur_path));

    for (int hop = 0; hop < 5; hop++) {
        char location[256];
        if (!http_get_once(cur_host, cur_port, cur_path, cur_tls, body_buf, body_buf_size, resp, location, sizeof(location))) {
            return 0;
        }
        if (resp->status_code < 300 || resp->status_code >= 400 || !location[0]) {
            return 1;
        }
        if (starts_with(location, "http://") || starts_with(location, "https://")) {
            parse_url(location, &cur_tls, cur_host, sizeof(cur_host), &cur_port, cur_path, sizeof(cur_path));
        } else {
            str_copy(cur_path, location, sizeof(cur_path));
        }
        watchdog_heartbeat("redirect");
        u32 pause = ticks_get() + ticks_per_sec() / 2;
        while (ticks_get() < pause) net_poll();
    }
    str_copy(resp->error_msg, "too many redirects", sizeof(resp->error_msg));
    resp->error = 1;
    return 0;
}


/* ================= incremental fetch =================
   A full page download can take tens of seconds over software TLS. Doing it
   in one blocking call meant the whole desktop stopped: no repaint, no input,
   no way to cancel. This state machine does a bounded slice of work per call
   so the UI keeps running while a page loads. */

static struct {
    int      active;
    int      use_tls;
    tcp_conn_t* c;
    tls_conn_t* tc;
    u8*      buf;
    u32      cap;
    u32      total;
    int      idle_rounds;
    int      state;         /* 0 idle, 1 receiving, 2 done, 3 error */
    char     err[64];
} F;

int http_fetch_active(void) { return F.active; }
u32 http_fetch_bytes(void)  { return F.total; }
int http_fetch_state(void)  { return F.state; }

void http_fetch_abort(void) {
    if (!F.active) return;
    if (F.use_tls) { if (F.tc) tls_close(F.tc); }
    else           { if (F.c)  tcp_close(F.c); }
    F.active = 0; F.state = 0; F.c = 0; F.tc = 0;
}

int http_fetch_begin(const char* host, u16 port, const char* path, int use_tls,
                     u8* body_buf, u32 body_buf_size) {
    http_fetch_abort();
    memset(&F, 0, sizeof(F));
    F.buf = body_buf; F.cap = body_buf_size; F.use_tls = use_tls;

    u32 ip = 0;
    if (!net_str_to_ip(host, &ip)) {
        if (!net_dns_resolve(host, &ip, 4000)) {
            str_copy(F.err, "DNS lookup failed", sizeof(F.err));
            F.state = 3; return 0;
        }
    }

    if (use_tls) {
        F.tc = tls_connect(ip, port, host, 6000);
        if (!F.tc) { str_copy(F.err, "TLS handshake failed", sizeof(F.err)); F.state = 3; return 0; }
    } else {
        F.c = tcp_connect(ip, port, 4000);
        if (!F.c) { str_copy(F.err, "TCP connect failed", sizeof(F.err)); F.state = 3; return 0; }
    }

    char req[768];
    str_copy(req, "GET ", sizeof(req));
    str_cat(req, path[0] ? path : "/", sizeof(req));
    str_cat(req, " HTTP/1.1\r\nHost: ", sizeof(req));
    str_cat(req, host, sizeof(req));
    http_append_headers(req, sizeof(req));

    if (use_tls) tls_send(F.tc, (const u8*)req, str_len(req));
    else         tcp_send(F.c, (const u8*)req, str_len(req));

    F.active = 1; F.state = 1; F.total = 0; F.idle_rounds = 0;
    return 1;
}

/* One slice of receiving. Returns the current state; call until it leaves 1. */
int http_fetch_pump(void) {
    if (!F.active || F.state != 1) return F.state;

    /* Bounded: at most this many reads per call, with a short per-read wait,
       so a slow server cannot stall the UI for more than a fraction of a second. */
    for (int slice = 0; slice < 4; slice++) {
        /* Buffer full: the page is larger than we can hold, so stop here and
           render what we have rather than spinning forever. */
        if (F.total >= F.cap) { F.state = 2; return F.state; }

        int n = F.use_tls ? tls_recv(F.tc, F.buf + F.total, F.cap - F.total, 120)
                          : tcp_recv(F.c,  F.buf + F.total, F.cap - F.total, 120);
        if (n > 0) {
            F.total += (u32)n;
            F.idle_rounds = 0;
            if (F.total > 512) {
                const u8* tail = F.buf + F.total - 16;
                for (int q = 0; q < 9; q++) {
                    if (tail[q] == '<' && tail[q+1] == '/' &&
                        (tail[q+2]|32) == 'h' && (tail[q+3]|32) == 't' &&
                        (tail[q+4]|32) == 'm' && (tail[q+5]|32) == 'l') {
                        F.state = 2; return F.state;
                    }
                }
            }
        } else if (n == 0) {
            F.state = 2; return F.state;      /* connection closed: complete */
        } else {
            F.idle_rounds++;
            if (F.idle_rounds >= 25) { F.state = 2; return F.state; }
            break;                            /* nothing waiting: yield to the UI */
        }
    }
    return F.state;
}

/* Turn the received bytes into a response. Safe to call once state == 2. */
int http_fetch_finish(http_response_t* resp) {
    memset(resp, 0, sizeof(*resp));
    if (F.state == 3) { str_copy(resp->error_msg, F.err, sizeof(resp->error_msg)); http_fetch_abort(); return 0; }

    u32 total = F.total;
    u8* body_buf = F.buf;
    http_fetch_abort();

    int sep = find_crlfcrlf(body_buf, total);
    if (sep < 0) { str_copy(resp->error_msg, "malformed response", sizeof(resp->error_msg)); return 0; }

    { int code = 0; u32 p = 0;
      while (p < (u32)sep && body_buf[p] != ' ') p++;
      p++;
      while (p < (u32)sep && body_buf[p] >= '0' && body_buf[p] <= '9') { code = code * 10 + (body_buf[p] - '0'); p++; }
      resp->status_code = code; }
    extract_header(body_buf, (u32)sep, "Content-Type", resp->content_type, sizeof(resp->content_type));

    /* A 3xx carries the next URL in Location. The browser drives the hop, so
       surface it here (the apex zapcz.com -> www.zapcz.com jump lands here). */
    if (resp->status_code >= 300 && resp->status_code < 400)
        extract_header(body_buf, (u32)sep, "Location", resp->location, sizeof(resp->location));

    char tebuf[32];
    extract_header(body_buf, (u32)sep, "Transfer-Encoding", tebuf, sizeof(tebuf));
    int is_chunked = (tebuf[0] && (tebuf[0] == 'c' || tebuf[0] == 'C'));

    u32 body_start = (u32)sep + 4;
    u32 blen = (total > body_start) ? (total - body_start) : 0;
    if (blen > 0) memmove(body_buf, body_buf + body_start, blen);
    if (is_chunked && blen > 0) blen = dechunk_inplace(body_buf, blen);
    resp->body_len = blen;
    return 1;
}
