#include "doomtype.h"
#include "i_sound.h"
#include "s_sound.h"

int sfxVolume = 8;
int musicVolume = 8;
int snd_channels = 8;

void I_BindSoundVariables(void) {
}

void I_InitMusic(void) {
}

void I_Endoom(byte* endoom_data) {
    (void)endoom_data;
}

void I_InitSound(boolean use_sfx_prefix) {
    (void)use_sfx_prefix;
}

void S_Init(int sfxVolume, int musicVolume) {
    (void)sfxVolume; (void)musicVolume;
}

void S_Shutdown(void) {
}

void S_Start(void) {
}

void S_StartSound(void* origin, int sound_id) {
    (void)origin; (void)sound_id;
}

void S_StopSound(mobj_t* origin) {
    (void)origin;
}

void S_StartMusic(int music_id) {
    (void)music_id;
}

void S_ChangeMusic(int music_id, int looping) {
    (void)music_id; (void)looping;
}

boolean S_MusicPlaying(void) {
    return false;
}

void S_StopMusic(void) {
}

void S_PauseSound(void) {
}

void S_ResumeSound(void) {
}

void S_UpdateSounds(mobj_t* listener) {
    (void)listener;
}

void S_SetMusicVolume(int volume) {
    (void)volume;
}

void S_SetSfxVolume(int volume) {
    (void)volume;
}
