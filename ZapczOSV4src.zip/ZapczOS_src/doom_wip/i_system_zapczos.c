#include "doomtype.h"
#include "i_system.h"
#include "i_timer.h"
#include "z_zone.h"
#include "mm.h"
#include "io.h"

#define ZAP_ZONE_SIZE (24 * 1024 * 1024)

byte* I_ZoneBase(int* size) {
    void* p = kmalloc(ZAP_ZONE_SIZE);
    *size = ZAP_ZONE_SIZE;
    return (byte*)p;
}

void I_Init(void) {
}

boolean I_ConsoleStdout(void) {
    return false;
}

void I_Quit(void) {
    serial_puts("DOOM: I_Quit\r\n");
    for (;;) { __asm__ volatile ("hlt"); }
}

extern void doom_term_print(const char* s);

void I_Error(char* error, ...) {
    char buf[256];
    __builtin_va_list args;
    __builtin_va_start(args, error);
    extern int vsnprintf(char* buf, unsigned long n, const char* fmt, __builtin_va_list ap);
    vsnprintf(buf, sizeof(buf), error, args);
    __builtin_va_end(args);
    serial_puts("DOOM I_Error: ");
    serial_puts(buf);
    serial_puts("\r\n");
    doom_term_print("DOOM I_Error:");
    doom_term_print(buf);
    for (;;) { __asm__ volatile ("hlt"); }
}

void I_Tactile(int on, int off, int total) {
    (void)on; (void)off; (void)total;
}

boolean I_GetMemoryValue(unsigned int offset, void* value, int size) {
    (void)offset; (void)value; (void)size;
    return false;
}

void I_AtExit(atexit_func_t func, boolean run_if_error) {
    (void)func; (void)run_if_error;
}

void I_BindVariables(void) {
}

void I_PrintStartupBanner(char* gamedescription) {
    serial_puts("DOOM banner: ");
    serial_puts(gamedescription);
    serial_puts("\r\n");
    doom_term_print(gamedescription);
}

void I_PrintBanner(char* text) {
    serial_puts("DOOM: ");
    serial_puts(text);
    serial_puts("\r\n");
    doom_term_print(text);
}

void I_PrintDivider(void) {
}

void I_InitJoystick(void) {
}

void I_BindJoystickVariables(void) {
}
