#include "doomtype.h"
#include "w_file.h"
#include "mm.h"

typedef struct {
    wad_file_t wad;
} zap_wad_file_t;

extern wad_file_class_t zap_wad_file;

static u8* g_wad_buf = 0;
static u32 g_wad_len = 0;

void doom_set_wad_buffer(u8* buf, u32 len) {
    g_wad_buf = buf;
    g_wad_len = len;
}

static wad_file_t* Zap_OpenFile(char* path) {
    (void)path;
    if (!g_wad_buf) return 0;
    zap_wad_file_t* result = (zap_wad_file_t*)kmalloc(sizeof(zap_wad_file_t));
    if (!result) return 0;
    result->wad.file_class = &zap_wad_file;
    result->wad.mapped = (byte*)g_wad_buf;
    result->wad.length = g_wad_len;
    return &result->wad;
}

static void Zap_CloseFile(wad_file_t* wad) {
    kfree(wad);
}

static unsigned long Zap_Read(wad_file_t* wad, unsigned int offset, void* buffer, unsigned long buffer_len) {
    (void)wad;
    if (offset >= g_wad_len) return 0;
    unsigned long remain = g_wad_len - offset;
    unsigned long n = buffer_len < remain ? buffer_len : remain;
    u8* src = g_wad_buf + offset;
    u8* dst = (u8*)buffer;
    for (unsigned long i = 0; i < n; i++) dst[i] = src[i];
    return n;
}

wad_file_class_t zap_wad_file = {
    Zap_OpenFile,
    Zap_CloseFile,
    Zap_Read,
};
