#include "m_config.h"
#include "doomtype.h"

char *configdir = "";

void M_LoadDefaults(void) {
}

void M_SaveDefaults(void) {
}

void M_SaveDefaultsAlternate(char *main, char *extra) {
    (void)main; (void)extra;
}

void M_SetConfigDir(char *dir) {
    (void)dir;
}

void M_BindVariable(char *name, void *variable) {
    (void)name; (void)variable;
}

boolean M_SetVariable(char *name, char *value) {
    (void)name; (void)value;
    return false;
}

int M_GetIntVariable(char *name) {
    (void)name;
    return 0;
}

const char *M_GetStrVariable(char *name) {
    (void)name;
    return (const char*)0;
}

void M_SetConfigFilenames(char *main_config, char *extra_config) {
    (void)main_config; (void)extra_config;
}

char *M_GetSaveGameDir(char *iwadname) {
    (void)iwadname;
    return "";
}
