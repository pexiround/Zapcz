#ifndef ZAP_SYS_STAT_H
#define ZAP_SYS_STAT_H
struct stat { unsigned long st_size; unsigned int st_mode; };
static inline int stat(const char* path, struct stat* buf) { (void)path; (void)buf; return -1; }
#define S_ISDIR(m) 0
int mkdir(const char* path, int mode);
#endif
