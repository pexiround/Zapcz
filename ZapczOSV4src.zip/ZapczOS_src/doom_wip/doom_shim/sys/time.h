#ifndef ZAP_SYS_TIME_H
#define ZAP_SYS_TIME_H
struct timeval { long tv_sec; long tv_usec; };
#endif
