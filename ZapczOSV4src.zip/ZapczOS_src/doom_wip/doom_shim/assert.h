#ifndef ZAP_ASSERT_H
#define ZAP_ASSERT_H
#define assert(x) ((void)0)
#endif
