#ifndef ZAP_STDLIB_H
#define ZAP_STDLIB_H
#include <stddef.h>
void* malloc(size_t size);
void free(void* ptr);
void* calloc(size_t n, size_t size);
void* realloc(void* ptr, size_t size);
int atoi(const char* s);
long atol(const char* s);
double atof(const char* s);
int abs(int x);
long labs(long x);
void exit(int code);
int rand(void);
void srand(unsigned int seed);
void qsort(void* base, size_t n, size_t size, int (*cmp)(const void*, const void*));
char* getenv(const char* name);
#define RAND_MAX 32767
#endif
