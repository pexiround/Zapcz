#ifndef ZAP_STRING_H
#define ZAP_STRING_H
#include <stddef.h>
void* memcpy(void* dst, const void* src, unsigned long n);
void* memmove(void* dst, const void* src, unsigned long n);
void* memset(void* dst, int val, unsigned long n);
int memcmp(const void* a, const void* b, unsigned long n);
unsigned long strlen(const char* s);
char* strcpy(char* dst, const char* src);
char* strncpy(char* dst, const char* src, unsigned long n);
char* strcat(char* dst, const char* src);
char* strncat(char* dst, const char* src, unsigned long n);
int strcmp(const char* a, const char* b);
int strncmp(const char* a, const char* b, unsigned long n);
char* strchr(const char* s, int c);
char* strrchr(const char* s, int c);
char* strstr(const char* hay, const char* needle);
char* strdup(const char* s);
char* strtok(char* str, const char* delim);

#endif
