#ifndef ZAP_STRINGS_H
#define ZAP_STRINGS_H
int strcasecmp(const char* a, const char* b);
int strncasecmp(const char* a, const char* b, unsigned long n);
#endif
