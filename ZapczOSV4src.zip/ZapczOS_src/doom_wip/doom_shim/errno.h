#ifndef ZAP_ERRNO_H
#define ZAP_ERRNO_H
extern int zap_errno;
#define errno zap_errno
#define ENOENT 2
#define EBADF 9
#define ENOMEM 12
#define EISDIR 21
#endif
