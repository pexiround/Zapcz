#ifndef ZAP_CTYPE_H
#define ZAP_CTYPE_H
int isspace(int c);
int isdigit(int c);
int isalpha(int c);
int isalnum(int c);
int isupper(int c);
int islower(int c);
int isxdigit(int c);
int isprint(int c);
int iscntrl(int c);
int ispunct(int c);
int toupper(int c);
int tolower(int c);
#endif
