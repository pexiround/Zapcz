#ifndef ZAP_STDDEF_H
#define ZAP_STDDEF_H
typedef unsigned long size_t;
typedef long ptrdiff_t;
#ifndef NULL
#define NULL ((void*)0)
#endif
#define offsetof(t,m) __builtin_offsetof(t,m)
#endif
