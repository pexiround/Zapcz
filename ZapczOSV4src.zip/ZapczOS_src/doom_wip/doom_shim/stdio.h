#ifndef ZAP_STDIO_H
#define ZAP_STDIO_H
#include <stdarg.h>
#include <stddef.h>
typedef struct FILE FILE;
extern FILE* zap_stdout;
extern FILE* zap_stderr;
#define stdout zap_stdout
#define stderr zap_stderr
#define EOF (-1)
#define SEEK_SET 0
#define SEEK_CUR 1
#define SEEK_END 2
int printf(const char* fmt, ...);
int fprintf(FILE* f, const char* fmt, ...);
int sprintf(char* buf, const char* fmt, ...);
int snprintf(char* buf, size_t n, const char* fmt, ...);
int vprintf(const char* fmt, va_list ap);
int vfprintf(FILE* f, const char* fmt, va_list ap);
int vsprintf(char* buf, const char* fmt, va_list ap);
int vsnprintf(char* buf, size_t n, const char* fmt, va_list ap);
FILE* fopen(const char* path, const char* mode);
int fclose(FILE* f);
size_t fread(void* buf, size_t size, size_t n, FILE* f);
size_t fwrite(const void* buf, size_t size, size_t n, FILE* f);
int fseek(FILE* f, long offset, int whence);
long ftell(FILE* f);
int fputc(int c, FILE* f);
int fputs(const char* s, FILE* f);
int fgetc(FILE* f);
char* fgets(char* buf, int n, FILE* f);
int feof(FILE* f);
int remove(const char* path);
int rename(const char* old, const char* newp);
int fflush(FILE* f);
int puts(const char* s);
int sscanf(const char* str, const char* fmt, void* out);
#endif
