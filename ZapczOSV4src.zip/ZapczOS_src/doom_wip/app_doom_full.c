#include "desktop.h"
#include "graphics.h"
#include "theme.h"
#include "fat32.h"
#include "mm.h"
#include "util.h"
#include "kernel.h"

extern void doom_set_wad_buffer(u8* buf, u32 len);
extern void doom_set_window_origin(i32 x, i32 y);
extern void doomgeneric_Create(int argc, char** argv);
extern void doomgeneric_Tick(void);

static int doom_state = 0;
static char doom_status[64] = "";
static int doom_using_real_wad = 0;
static char wad_name_used[16] = "freedoom1.wad";

#define DOOM_STATE_NONE 0
#define DOOM_STATE_RUNNING 1
#define DOOM_STATE_NO_DISK 2
#define DOOM_STATE_NO_WAD 3

static const fat_dirent_t* find_entry(const fat_dirent_t* ents, int n, const char* name) {
    for (int i = 0; i < n; i++) {
        if (str_eq_ci(ents[i].display_name, name)) return &ents[i];
    }
    return 0;
}

static int load_fat32_file(const fat_dirent_t* found) {
    u8* buf = (u8*)kmalloc(found->size + 16);
    if (!buf) {
        str_copy(doom_status, "Out of memory loading WAD.", 64);
        return 0;
    }
    int got = fat32_read_file(found, buf, found->size + 16);
    if (got <= 0) {
        kfree(buf);
        return 0;
    }
    doom_set_wad_buffer(buf, (u32)got);
    return 1;
}

static int doom_start_from_fat32(void) {
    if (!fat32_available()) return 0;
    fat_dirent_t ents[64];
    int n = fat32_list_root(ents, 64);

    const fat_dirent_t* real_wad = find_entry(ents, n, "DOOM.WAD");
    if (!real_wad) real_wad = find_entry(ents, n, "DOOM1.WAD");
    if (!real_wad) real_wad = find_entry(ents, n, "DOOM2.WAD");
    if (!real_wad) real_wad = find_entry(ents, n, "PLUTONIA.WAD");
    if (!real_wad) real_wad = find_entry(ents, n, "TNT.WAD");
    if (real_wad && load_fat32_file(real_wad)) {
        doom_using_real_wad = 1;
        str_copy(wad_name_used, real_wad->display_name, sizeof(wad_name_used));
        return 1;
    }

    const fat_dirent_t* free_wad = find_entry(ents, n, "FREEDOOM.WAD");
    if (!free_wad) free_wad = find_entry(ents, n, "FREEDOOM1.WAD");
    if (free_wad && load_fat32_file(free_wad)) {
        doom_using_real_wad = 0;
        str_copy(wad_name_used, free_wad->display_name, sizeof(wad_name_used));
        return 1;
    }

    return 0;
}

static int doom_start_from_module(void) {
    u8* buf = kernel_get_mod_buf();
    u32 size = kernel_get_mod_size();
    if (!buf || size < 1024) return 0;
    doom_set_wad_buffer(buf, size);
    doom_using_real_wad = 0;
    str_copy(wad_name_used, "freedoom1.wad", sizeof(wad_name_used));
    return 1;
}

extern void serial_puts(const char*);
static void doom_try_start(void) {
    int got_wad = doom_start_from_fat32();
    if (!got_wad) got_wad = doom_start_from_module();

    if (!got_wad) {
        doom_state = fat32_available() ? DOOM_STATE_NO_WAD : DOOM_STATE_NO_DISK;
        return;
    }

    static char* argv[3];
    static char arg0[] = "doomgeneric";
    static char arg1[] = "-iwad";
    argv[0] = arg0; argv[1] = arg1; argv[2] = wad_name_used;
    doomgeneric_Create(3, argv);
    doom_state = DOOM_STATE_RUNNING;
}

void app_doom_draw(i32 x, i32 y, i32 w, i32 h) {
    (void)w; (void)h;
    if (doom_state == DOOM_STATE_NONE) {
        doom_try_start();
    }
    if (doom_state == DOOM_STATE_RUNNING) {
        doom_set_window_origin(x, y);
        doomgeneric_Tick();
        return;
    }

    gfx_rect(x, y, 640, 400, RGB(10, 10, 14));
    if (doom_state == DOOM_STATE_NO_DISK) {
        gfx_string(x + 16, y + 16, "DOOM needs a disk to load the game data from.",
                   THEME_WARNING, RGB(10,10,14), 0);
    } else if (doom_state == DOOM_STATE_NO_WAD) {
        gfx_string(x + 16, y + 16, "No DOOM game data found on disk.",
                   THEME_WARNING, RGB(10,10,14), 0);
        gfx_string(x + 16, y + 38, "Own a copy of DOOM? Copy your DOOM.WAD / DOOM1.WAD /",
                   THEME_TEXT_DIM, RGB(10,10,14), 0);
        gfx_string(x + 16, y + 56, "DOOM2.WAD to the root of this OS's disk to play the real",
                   THEME_TEXT_DIM, RGB(10,10,14), 0);
        gfx_string(x + 16, y + 74, "thing -- otherwise copy FREEDOOM.WAD for the free version.",
                   THEME_TEXT_DIM, RGB(10,10,14), 0);
        if (doom_status[0]) {
            gfx_string(x + 16, y + 102, doom_status, THEME_DANGER, RGB(10,10,14), 0);
        }
    }
}

int app_doom_using_real_wad(void) { return doom_using_real_wad; }
