#include "doomgeneric.h"
#include "doomkeys.h"
#include "graphics.h"
#include "pit.h"
#include "keyboard.h"
#include "mm.h"

static const unsigned char zap_scancode_to_doom[88] = {
    0x00, KEY_ESCAPE, '1', '2', '3', '4', '5', '6', '7', '8',
    '9', '0', '-', '=', KEY_BACKSPACE, KEY_TAB, 'q', 'w', 'e', 'r',
    't', 'y', 'u', 'i', 'o', 'p', '[', ']', KEY_ENTER, KEY_FIRE,
    'a', 's', 'd', 'f', 'g', 'h', 'j', 'k', 'l', ';',
    '\'', '`', KEY_RSHIFT, '\\', 'z', 'x', 'c', 'v', 'b', 'n',
    'm', ',', '.', '/', KEY_RSHIFT, 0, KEY_LALT, KEY_USE, KEY_CAPSLOCK, KEY_F1,
    KEY_F2, KEY_F3, KEY_F4, KEY_F5, KEY_F6, KEY_F7, KEY_F8, KEY_F9, KEY_F10, KEY_NUMLOCK,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
};

static int wheel_key_pending = 0;

void DG_Init(void) {
}

static i32 doom_win_x = 0, doom_win_y = 0;

void doom_set_window_origin(i32 x, i32 y) {
    doom_win_x = x;
    doom_win_y = y;
}

void DG_DrawFrame(void) {
    if (!DG_ScreenBuffer) return;
    for (i32 row = 0; row < DOOMGENERIC_RESY; row++) {
        u8* src = (u8*)DG_ScreenBuffer + (u32)row * DOOMGENERIC_RESX * 4;
        u32 dst_off = (u32)(doom_win_y + row) * gfx.width * gfx.bypp + (u32)doom_win_x * gfx.bypp;
        if ((u32)(doom_win_y + row) >= gfx.height) continue;
        u8* dst = gfx.back + dst_off;
        u32 nbytes = DOOMGENERIC_RESX * 4;
        if ((u32)doom_win_x + DOOMGENERIC_RESX > gfx.width) {
            i32 visible = (i32)gfx.width - doom_win_x;
            if (visible < 0) visible = 0;
            nbytes = (u32)visible * 4;
        }
        for (u32 i = 0; i < nbytes; i++) dst[i] = src[i];
    }
}

void DG_SleepMs(uint32_t ms) {
    sleep_ms(ms);
}

uint32_t DG_GetTicksMs(void) {
    u32 tps = ticks_per_sec();
    if (tps == 0) tps = 1;
    return (uint32_t)(((u64)ticks_get() * 1000u) / tps);
}

int DG_GetKey(int* pressed, unsigned char* doomKey) {
    if (wheel_key_pending) {
        wheel_key_pending = 0;
        *pressed = 0;
        *doomKey = KEY_ENTER;
        return 1;
    }
    int p, ext;
    u8 sc;
    if (!kbd_get_raw_event(&p, &ext, &sc)) return 0;
    unsigned char dk = 0;
    if (ext) {
        switch (sc) {
            case 0x48: dk = KEY_UPARROW; break;
            case 0x50: dk = KEY_DOWNARROW; break;
            case 0x4B: dk = KEY_LEFTARROW; break;
            case 0x4D: dk = KEY_RIGHTARROW; break;
            case 0x1D: dk = KEY_FIRE; break;
            case 0x38: dk = KEY_LALT; break;
            default: dk = 0; break;
        }
    } else if (sc < sizeof(zap_scancode_to_doom)) {
        dk = zap_scancode_to_doom[sc];
    }
    if (!dk) return 0;
    *pressed = p;
    *doomKey = dk;
    return 1;
}

void DG_SetWindowTitle(const char* title) {
    (void)title;
}
