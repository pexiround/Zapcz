#include "mm.h"
#include "apps.h"
#include <stdio.h>

typedef unsigned long size_t_;

void doom_term_print(const char* s) {
    term_print(s);
}

void* malloc(unsigned long size) {
    return kmalloc((u32)size);
}

void free(void* ptr) {
    kfree(ptr);
}

void* calloc(unsigned long n, unsigned long size) {
    u32 total = (u32)(n * size);
    void* p = kmalloc(total);
    if (p) {
        u8* b = (u8*)p;
        for (u32 i = 0; i < total; i++) b[i] = 0;
    }
    return p;
}

void* realloc(void* ptr, unsigned long size) {
    void* np = kmalloc((u32)size);
    if (np && ptr) {
        u8* d = (u8*)np;
        u8* s = (u8*)ptr;
        for (unsigned long i = 0; i < size; i++) d[i] = s[i];
        kfree(ptr);
    }
    return np;
}

int strcasecmp(const char* a, const char* b) {
    while (*a && *b) {
        char ca = *a, cb = *b;
        if (ca >= 'A' && ca <= 'Z') ca += 32;
        if (cb >= 'A' && cb <= 'Z') cb += 32;
        if (ca != cb) return (int)ca - (int)cb;
        a++; b++;
    }
    return (int)*a - (int)*b;
}

int strncasecmp(const char* a, const char* b, unsigned long n) {
    while (n-- && *a && *b) {
        char ca = *a, cb = *b;
        if (ca >= 'A' && ca <= 'Z') ca += 32;
        if (cb >= 'A' && cb <= 'Z') cb += 32;
        if (ca != cb) return (int)ca - (int)cb;
        a++; b++;
    }
    if (n == (unsigned long)-1) return 0;
    return (int)*a - (int)*b;
}

char* strcpy(char* dst, const char* src) {
    char* d = dst;
    while ((*d++ = *src++)) { }
    return dst;
}

char* strncpy(char* dst, const char* src, unsigned long n) {
    unsigned long i = 0;
    for (; i < n && src[i]; i++) dst[i] = src[i];
    for (; i < n; i++) dst[i] = 0;
    return dst;
}

char* strcat(char* dst, const char* src) {
    char* d = dst;
    while (*d) d++;
    while ((*d++ = *src++)) { }
    return dst;
}

char* strncat(char* dst, const char* src, unsigned long n) {
    char* d = dst;
    while (*d) d++;
    unsigned long i = 0;
    for (; i < n && src[i]; i++) d[i] = src[i];
    d[i] = 0;
    return dst;
}

int strcmp(const char* a, const char* b) {
    while (*a && *a == *b) { a++; b++; }
    return (int)(unsigned char)*a - (int)(unsigned char)*b;
}

int strncmp(const char* a, const char* b, unsigned long n) {
    while (n-- && *a && *a == *b) { a++; b++; }
    if (n == (unsigned long)-1) return 0;
    return (int)(unsigned char)*a - (int)(unsigned char)*b;
}

char* strchr(const char* s, int c) {
    while (*s) {
        if (*s == (char)c) return (char*)s;
        s++;
    }
    return (c == 0) ? (char*)s : 0;
}

char* strrchr(const char* s, int c) {
    const char* last = 0;
    while (*s) {
        if (*s == (char)c) last = s;
        s++;
    }
    if (c == 0) return (char*)s;
    return (char*)last;
}

char* strstr(const char* hay, const char* needle) {
    if (!*needle) return (char*)hay;
    for (; *hay; hay++) {
        const char* h = hay;
        const char* n = needle;
        while (*h && *n && *h == *n) { h++; n++; }
        if (!*n) return (char*)hay;
    }
    return 0;
}

char* strdup(const char* s) {
    unsigned long n = 0;
    while (s[n]) n++;
    char* p = (char*)kmalloc((u32)n + 1);
    if (p) {
        for (unsigned long i = 0; i <= n; i++) p[i] = s[i];
    }
    return p;
}

static char* strtok_save = 0;
char* strtok(char* str, const char* delim) {
    if (str) strtok_save = str;
    if (!strtok_save) return 0;
    char* s = strtok_save;
    while (*s) {
        int is_delim = 0;
        for (const char* d = delim; *d; d++) if (*s == *d) { is_delim = 1; break; }
        if (!is_delim) break;
        s++;
    }
    if (!*s) { strtok_save = 0; return 0; }
    char* start = s;
    while (*s) {
        int is_delim = 0;
        for (const char* d = delim; *d; d++) if (*s == *d) { is_delim = 1; break; }
        if (is_delim) { *s = 0; strtok_save = s + 1; return start; }
        s++;
    }
    strtok_save = 0;
    return start;
}

int isspace(int c) { return c == ' ' || c == '\t' || c == '\n' || c == '\r' || c == '\f' || c == '\v'; }
int isdigit(int c) { return c >= '0' && c <= '9'; }
int isalpha(int c) { return (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z'); }
int isalnum(int c) { return isalpha(c) || isdigit(c); }
int isupper(int c) { return c >= 'A' && c <= 'Z'; }
int islower(int c) { return c >= 'a' && c <= 'z'; }
int isxdigit(int c) { return isdigit(c) || (c >= 'a' && c <= 'f') || (c >= 'A' && c <= 'F'); }
int isprint(int c) { return c >= 32 && c < 127; }
int iscntrl(int c) { return c < 32 || c == 127; }
int ispunct(int c) { return isprint(c) && !isalnum(c) && c != ' '; }
int toupper(int c) { return (c >= 'a' && c <= 'z') ? c - 32 : c; }
int tolower(int c) { return (c >= 'A' && c <= 'Z') ? c + 32 : c; }

int atoi(const char* s) {
    int neg = 0;
    int v = 0;
    while (*s == ' ' || *s == '\t') s++;
    if (*s == '-') { neg = 1; s++; }
    else if (*s == '+') s++;
    while (*s >= '0' && *s <= '9') { v = v * 10 + (*s - '0'); s++; }
    return neg ? -v : v;
}

long atol(const char* s) {
    return (long)atoi(s);
}

double atof(const char* s) {
    (void)s;
    return 0;
}

int abs(int x) { return x < 0 ? -x : x; }
long labs(long x) { return x < 0 ? -x : x; }

void exit(int code) {
    (void)code;
    for (;;) { __asm__ volatile ("hlt"); }
}

static unsigned int rng_state = 12345;
int rand(void) {
    rng_state = rng_state * 1103515245u + 12345u;
    return (int)((rng_state >> 16) & 0x7FFF);
}
void srand(unsigned int seed) {
    rng_state = seed;
}

void qsort(void* base, unsigned long n, unsigned long size, int (*cmp)(const void*, const void*)) {
    u8* arr = (u8*)base;
    for (unsigned long i = 1; i < n; i++) {
        unsigned long j = i;
        while (j > 0) {
            u8* a = arr + (j - 1) * size;
            u8* b = arr + j * size;
            if (cmp(a, b) <= 0) break;
            for (unsigned long k = 0; k < size; k++) {
                u8 tmp = a[k]; a[k] = b[k]; b[k] = tmp;
            }
            j--;
        }
    }
}

char* getenv(const char* name) {
    (void)name;
    return 0;
}

static void out_char(char* buf, unsigned long n, unsigned long* pos, char c) {
    if (*pos < n) buf[*pos] = c;
    (*pos)++;
}

static void out_str(char* buf, unsigned long n, unsigned long* pos, const char* s) {
    while (*s) out_char(buf, n, pos, *s++);
}

static void out_uint_pad(char* buf, unsigned long n, unsigned long* pos, unsigned long v, int base, int upper, int min_digits) {
    char tmp[32];
    int t = 0;
    if (v == 0) { tmp[t++] = '0'; }
    while (v > 0) {
        int d = (int)(v % (unsigned long)base);
        tmp[t++] = (d < 10) ? (char)('0' + d) : (char)((upper ? 'A' : 'a') + d - 10);
        v /= (unsigned long)base;
    }
    while (t < min_digits && t < 31) tmp[t++] = '0';
    while (t > 0) out_char(buf, n, pos, tmp[--t]);
}

static void out_uint(char* buf, unsigned long n, unsigned long* pos, unsigned long v, int base, int upper) {
    out_uint_pad(buf, n, pos, v, base, upper, 0);
}

static void out_int_pad(char* buf, unsigned long n, unsigned long* pos, long v, int min_digits) {
    if (v < 0) {
        out_char(buf, n, pos, '-');
        out_uint_pad(buf, n, pos, (unsigned long)(-v), 10, 0, min_digits);
    } else {
        out_uint_pad(buf, n, pos, (unsigned long)v, 10, 0, min_digits);
    }
}

int vsnprintf(char* buf, unsigned long n, const char* fmt, __builtin_va_list ap) {
    unsigned long pos = 0;
    while (*fmt) {
        if (*fmt != '%') { out_char(buf, n, &pos, *fmt++); continue; }
        fmt++;
        int longflag = 0;
        while (*fmt == 'l') { longflag++; fmt++; }
        (void)longflag;
        int zero_pad = 0;
        int width = 0;
        if (*fmt == '0') { zero_pad = 1; fmt++; }
        while (*fmt >= '0' && *fmt <= '9') { width = width * 10 + (*fmt - '0'); fmt++; }
        int precision = -1;
        if (*fmt == '.') {
            fmt++;
            precision = 0;
            while (*fmt >= '0' && *fmt <= '9') { precision = precision * 10 + (*fmt - '0'); fmt++; }
        }
        int min_digits = (precision >= 0) ? precision : (zero_pad ? width : 0);
        switch (*fmt) {
            case 'd': case 'i': {
                long v = __builtin_va_arg(ap, int);
                out_int_pad(buf, n, &pos, v, min_digits);
                break;
            }
            case 'u': {
                unsigned long v = __builtin_va_arg(ap, unsigned int);
                out_uint_pad(buf, n, &pos, v, 10, 0, min_digits);
                break;
            }
            case 'x': {
                unsigned long v = __builtin_va_arg(ap, unsigned int);
                out_uint_pad(buf, n, &pos, v, 16, 0, min_digits);
                break;
            }
            case 'X': {
                unsigned long v = __builtin_va_arg(ap, unsigned int);
                out_uint_pad(buf, n, &pos, v, 16, 1, min_digits);
                break;
            }
            case 'o': {
                unsigned long v = __builtin_va_arg(ap, unsigned int);
                out_uint_pad(buf, n, &pos, v, 8, 0, min_digits);
                break;
            }
            case 'c': {
                int v = __builtin_va_arg(ap, int);
                out_char(buf, n, &pos, (char)v);
                break;
            }
            case 's': {
                const char* s = __builtin_va_arg(ap, const char*);
                if (!s) s = "(null)";
                out_str(buf, n, &pos, s);
                break;
            }
            case 'p': {
                unsigned long v = (unsigned long)__builtin_va_arg(ap, void*);
                out_str(buf, n, &pos, "0x");
                out_uint(buf, n, &pos, v, 16, 0);
                break;
            }
            case 'f': {
                __builtin_va_arg(ap, double);
                out_str(buf, n, &pos, "0.000000");
                break;
            }
            case '%':
                out_char(buf, n, &pos, '%');
                break;
            default:
                out_char(buf, n, &pos, '%');
                if (*fmt) out_char(buf, n, &pos, *fmt);
                break;
        }
        if (*fmt) fmt++;
    }
    if (n > 0) buf[pos < n ? pos : n - 1] = 0;
    return (int)pos;
}

int vsprintf(char* buf, const char* fmt, __builtin_va_list ap) {
    return vsnprintf(buf, 0x7FFFFFFF, fmt, ap);
}

int sprintf(char* buf, const char* fmt, ...) {
    __builtin_va_list ap;
    __builtin_va_start(ap, fmt);
    int r = vsnprintf(buf, 0x7FFFFFFF, fmt, ap);
    __builtin_va_end(ap);
    return r;
}

int snprintf(char* buf, unsigned long n, const char* fmt, ...) {
    __builtin_va_list ap;
    __builtin_va_start(ap, fmt);
    int r = vsnprintf(buf, n, fmt, ap);
    __builtin_va_end(ap);
    return r;
}

int vprintf(const char* fmt, __builtin_va_list ap) {
    char buf[256];
    int r = vsnprintf(buf, sizeof(buf), fmt, ap);
    extern void serial_puts(const char* s);
    serial_puts(buf);
    serial_puts("\r\n");
    doom_term_print(buf);
    return r;
}

int printf(const char* fmt, ...) {
    __builtin_va_list ap;
    __builtin_va_start(ap, fmt);
    int r = vprintf(fmt, ap);
    __builtin_va_end(ap);
    return r;
}

struct FILE { int dummy; };
FILE* zap_stdout = 0;
FILE* zap_stderr = 0;

int vfprintf(FILE* f, const char* fmt, __builtin_va_list ap) {
    (void)f;
    return vprintf(fmt, ap);
}

int fprintf(FILE* f, const char* fmt, ...) {
    __builtin_va_list ap;
    __builtin_va_start(ap, fmt);
    int r = vfprintf(f, fmt, ap);
    __builtin_va_end(ap);
    return r;
}

FILE* fopen(const char* path, const char* mode) {
    (void)path; (void)mode;
    return 0;
}

int fclose(FILE* f) {
    (void)f;
    return 0;
}

unsigned long fread(void* buf, unsigned long size, unsigned long n, FILE* f) {
    (void)buf; (void)size; (void)n; (void)f;
    return 0;
}

unsigned long fwrite(const void* buf, unsigned long size, unsigned long n, FILE* f) {
    (void)buf; (void)size; (void)n; (void)f;
    return 0;
}

int fseek(FILE* f, long offset, int whence) {
    (void)f; (void)offset; (void)whence;
    return -1;
}

long ftell(FILE* f) {
    (void)f;
    return -1;
}

int fputc(int c, FILE* f) {
    (void)f;
    return c;
}

int fputs(const char* s, FILE* f) {
    (void)f;
    doom_term_print(s);
    return 0;
}

int fgetc(FILE* f) {
    (void)f;
    return -1;
}

char* fgets(char* buf, int n, FILE* f) {
    (void)buf; (void)n; (void)f;
    return 0;
}

int feof(FILE* f) {
    (void)f;
    return 1;
}

int remove(const char* path) {
    (void)path;
    return -1;
}

int rename(const char* oldp, const char* newp) {
    (void)oldp; (void)newp;
    return -1;
}

int zap_errno = 0;

int mkdir(const char* path, int mode) {
    (void)path; (void)mode;
    return -1;
}

int fflush(FILE* f) {
    (void)f;
    return 0;
}

int puts(const char* s) {
    doom_term_print(s);
    return 0;
}

static int hexval(char c) {
    if (c >= '0' && c <= '9') return c - '0';
    if (c >= 'a' && c <= 'f') return c - 'a' + 10;
    if (c >= 'A' && c <= 'F') return c - 'A' + 10;
    return -1;
}

int sscanf(const char* str, const char* fmt, void* out) {
    int matched = 0;
    while (*fmt) {
        if (*fmt == ' ') {
            while (*str == ' ' || *str == '\t') str++;
            fmt++;
            continue;
        }
        if (*fmt == '%') {
            fmt++;
            if (*fmt == 'd') {
                int neg = 0;
                int v = 0;
                int any = 0;
                if (*str == '-') { neg = 1; str++; }
                while (*str >= '0' && *str <= '9') { v = v * 10 + (*str - '0'); str++; any = 1; }
                if (!any) return matched;
                *(int*)out = neg ? -v : v;
                matched++;
                fmt++;
                continue;
            } else if (*fmt == 'x') {
                unsigned int v = 0;
                int any = 0;
                int hv;
                while ((hv = hexval(*str)) >= 0) { v = v * 16 + (unsigned int)hv; str++; any = 1; }
                if (!any) return matched;
                *(int*)out = (int)v;
                matched++;
                fmt++;
                continue;
            } else if (*fmt == 'o') {
                unsigned int v = 0;
                int any = 0;
                while (*str >= '0' && *str <= '7') { v = v * 8 + (unsigned int)(*str - '0'); str++; any = 1; }
                if (!any) return matched;
                *(int*)out = (int)v;
                matched++;
                fmt++;
                continue;
            } else {
                return matched;
            }
        }
        if (*str != *fmt) return matched;
        str++; fmt++;
    }
    return matched;
}
