#ifndef KERNEL_H
#define KERNEL_H

#include "io.h"

typedef struct __attribute__((packed)) {
    u32 fb_addr;
    u16 width;
    u16 height;
    u8  bpp;
    u8  _reserved0;
    u16 pitch;
    u8  vbe_ok;
    u8  disk_safe;
    u8  _reserved1[2];
    u32 mmap_addr;
    u32 mmap_count;
    u32 mod_addr;
    u32 mod_size;
    u32 instimg_addr;
    u32 instimg_size;
    u32 mod2_addr;
    u32 mod2_size;
    u32 mod3_addr;
    u32 mod4_addr;
    u32 mod4_size;
    u32 mod5_addr;
    u32 mod5_size;
    u32 mod3_size;
    u32 tui_install;
    u32 cc_selftest;
    u32 demo_mode;
} boot_info_t;

typedef struct __attribute__((packed)) {
    u64 base;
    u64 length;
    u32 type;
    u32 acpi_ext;
} mmap_entry_t;

u32 kernel_total_ram_kb(void);
u8* kernel_get_mod_buf(void);
u32 kernel_get_mod_size(void);
u8* kernel_get_install_img_buf(void);
u32 kernel_get_install_img_size(void);
int  kernel_disk_safe(void);

#endif
