#include "kernel.h"
#include "io.h"
#include "util.h"

typedef struct __attribute__((packed)) {
    u32 type;
    u32 size;
} mb2_tag_t;

typedef struct __attribute__((packed)) {
    u32 type;
    u32 size;
    u32 entry_size;
    u32 entry_version;
} mb2_mmap_tag_t;

typedef struct __attribute__((packed)) {
    u64 base;
    u64 length;
    u32 type;
    u32 reserved;
} mb2_mmap_entry_t;

typedef struct __attribute__((packed)) {
    u32 type;
    u32 size;
    u64 fb_addr;
    u32 fb_pitch;
    u32 fb_width;
    u32 fb_height;
    u8  fb_bpp;
    u8  fb_type;
    u16 reserved;
} mb2_fb_tag_t;

typedef struct __attribute__((packed)) {
    u32 type;
    u32 size;
    u32 mod_start;
    u32 mod_end;
} mb2_module_tag_t;

static boot_info_t g_boot_info;
static mmap_entry_t g_mmap_storage[64];

boot_info_t* multiboot2_entry(u32 magic, u32 mb_info_addr) {
    g_boot_info.vbe_ok = 0;
    g_boot_info.disk_safe = 0;
    g_boot_info.mmap_count = 0;
    g_boot_info.mmap_addr = (u32)(void*)g_mmap_storage;
    g_boot_info.mod_addr = 0;
    g_boot_info.mod_size = 0;
    g_boot_info.instimg_addr = 0;
    g_boot_info.instimg_size = 0;
    g_boot_info.mod2_addr = 0;
    g_boot_info.mod2_size = 0;
    g_boot_info.mod3_addr = 0;
    g_boot_info.mod4_addr = 0;
    g_boot_info.mod5_addr = 0;
    g_boot_info.mod3_size = 0;
    g_boot_info.tui_install = 0;

    if (magic != 0x36D76289u) {
        return &g_boot_info;
    }

    u8* base_ptr = (u8*)(void*)(u32)mb_info_addr;
    u32 total_size = *(u32*)base_ptr;
    u8* end = base_ptr + total_size;
    u8* cur = base_ptr + 8;

    while (cur + 8 <= end) {
        mb2_tag_t* tag = (mb2_tag_t*)cur;
        if (tag->type == 0) break;

        if (tag->type == 8) {
            mb2_fb_tag_t* fb = (mb2_fb_tag_t*)cur;
            g_boot_info.fb_addr = (u32)fb->fb_addr;
            g_boot_info.width  = (u16)fb->fb_width;
            g_boot_info.height = (u16)fb->fb_height;
            g_boot_info.bpp    = fb->fb_bpp;
            g_boot_info.pitch  = (u16)fb->fb_pitch;
            if (fb->fb_type == 1 && fb->fb_bpp >= 24) g_boot_info.vbe_ok = 1;
        } else if (tag->type == 6) {
            mb2_mmap_tag_t* mm = (mb2_mmap_tag_t*)cur;
            u8* entry_ptr = cur + 16;
            u8* mmap_end = cur + tag->size;
            u32 count = 0;
            u32 stride = mm->entry_size ? mm->entry_size : sizeof(mb2_mmap_entry_t);
            while (entry_ptr + sizeof(mb2_mmap_entry_t) <= mmap_end && count < 64) {
                mb2_mmap_entry_t* e = (mb2_mmap_entry_t*)entry_ptr;
                g_mmap_storage[count].base = e->base;
                g_mmap_storage[count].length = e->length;
                g_mmap_storage[count].type = e->type;
                g_mmap_storage[count].acpi_ext = 0;
                count++;
                entry_ptr += stride;
            }
            g_boot_info.mmap_count = count;
        } else if (tag->type == 3) {
            mb2_module_tag_t* mod = (mb2_module_tag_t*)cur;
            const char* ident = (const char*)cur + sizeof(mb2_module_tag_t);
            if (str_eq(ident, "instimg")) {
                g_boot_info.instimg_addr = mod->mod_start;
                g_boot_info.instimg_size = mod->mod_end - mod->mod_start;
            } else if (str_eq(ident, "iwl8265fw")) {
                g_boot_info.mod2_addr = mod->mod_start;
                g_boot_info.mod2_size = mod->mod_end - mod->mod_start;
            } else if (str_eq(ident, "iwl3160fw")) {
                g_boot_info.mod3_addr = mod->mod_start;
                g_boot_info.mod3_size = mod->mod_end - mod->mod_start;
            } else if (str_eq(ident, "iwl7265fw")) {
                g_boot_info.mod4_addr = mod->mod_start;
                g_boot_info.mod4_size = mod->mod_end - mod->mod_start;
            } else if (str_eq(ident, "iwl9260fw")) {
                g_boot_info.mod5_addr = mod->mod_start;
                g_boot_info.mod5_size = mod->mod_end - mod->mod_start;
            } else {
                g_boot_info.mod_addr = mod->mod_start;
                g_boot_info.mod_size = mod->mod_end - mod->mod_start;
            }
        } else if (tag->type == 1) {
            /* boot command line: look for the text-installer keyword so a GRUB
               menu entry can request the console installer instead of the GUI */
            const char* s = (const char*)cur + 8;
            const char* key = "textinstall";
            for (const char* p = s; *p; p++) {
                int m = 1;
                for (int k = 0; key[k]; k++) { if (p[k] != key[k]) { m = 0; break; } }
                if (m) { g_boot_info.tui_install = 1; break; }
            }
            const char* key3 = "zapczdemo";
            for (const char* p = s; *p; p++) {
                int m = 1;
                for (int k = 0; key3[k]; k++) { if (p[k] != key3[k]) { m = 0; break; } }
                if (m) { g_boot_info.demo_mode = 1; break; }
            }
            const char* key2 = "zapcctest";
            for (const char* p = s; *p; p++) {
                int m = 1;
                for (int k = 0; key2[k]; k++) { if (p[k] != key2[k]) { m = 0; break; } }
                if (m) { g_boot_info.cc_selftest = 1; break; }
            }
        }

        u32 sz = (tag->size + 7u) & ~7u;
        cur += sz;
    }

    return &g_boot_info;
}
