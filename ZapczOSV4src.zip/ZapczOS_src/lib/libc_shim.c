#include "io.h"

void* memcpy(void* dst, const void* src, u32 n) {
    u8* d = (u8*)dst; const u8* s = (const u8*)src;

    if (((u32)d & 3) == 0 && ((u32)s & 3) == 0) {
        u32 words = n >> 2;
        u32* dw = (u32*)d;
        const u32* sw = (const u32*)s;
        for (u32 i = 0; i < words; i++) dw[i] = sw[i];
        d += words * 4;
        s += words * 4;
        n &= 3;
    }
    while (n--) *d++ = *s++;
    return dst;
}

void* memset(void* dst, int val, u32 n) {
    u8* d = (u8*)dst;
    u8 v = (u8)val;
    if (((u32)d & 3) == 0) {
        u32 vw = (u32)v | ((u32)v << 8) | ((u32)v << 16) | ((u32)v << 24);
        u32 words = n >> 2;
        u32* dw = (u32*)d;
        for (u32 i = 0; i < words; i++) dw[i] = vw;
        d += words * 4;
        n &= 3;
    }
    while (n--) *d++ = v;
    return dst;
}

void* memmove(void* dst, const void* src, u32 n) {
    u8* d = (u8*)dst; const u8* s = (const u8*)src;
    if (d < s) { while (n--) *d++ = *s++; }
    else { d += n; s += n; while (n--) *--d = *--s; }
    return dst;
}

int memcmp(const void* a, const void* b, u32 n) {
    const u8* pa = (const u8*)a; const u8* pb = (const u8*)b;
    while (n--) {
        if (*pa != *pb) return (int)*pa - (int)*pb;
        pa++; pb++;
    }
    return 0;
}

u32 strlen(const char* s) {
    u32 n = 0;
    while (s[n]) n++;
    return n;
}
