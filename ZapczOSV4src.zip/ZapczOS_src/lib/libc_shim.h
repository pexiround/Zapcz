#ifndef LIBC_SHIM_H
#define LIBC_SHIM_H
#include "io.h"

void* memcpy(void* dst, const void* src, u32 n);
void* memset(void* dst, int val, u32 n);
void* memmove(void* dst, const void* src, u32 n);
int   memcmp(const void* a, const void* b, u32 n);
u32   strlen(const char* s);

#endif
