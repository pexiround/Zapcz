#ifndef MM_H
#define MM_H

#include "io.h"

extern u8 bss_end;

#define PAGE_ROUND_UP(addr, align) (((u32)(addr) + ((align) - 1)) & ~((align) - 1))

#define BACKBUFFER_SAFETY_MARGIN 0x100000u

/* Boot modules (firmware blobs, install image, WAD) are loaded by GRUB into
   memory just above the kernel -- exactly where the backbuffer used to land,
   so drawing a frame would overwrite them. mm_set_safe_base() is called at
   boot with the highest module end address, and everything dynamic is placed
   above it. */
extern u32 g_dyn_base;
void mm_set_safe_base(u32 modules_end);

#define BACKBUFFER_ADDR   (g_dyn_base)
#define BACKBUFFER_MAXLEN 0x2400000u   /* 36 MB: enough for 3840x2160x4 */

#define HEAP_ADDR  (g_dyn_base + BACKBUFFER_MAXLEN)
#define HEAP_SIZE_MIN  0x4000000u
#define HEAP_SIZE_MAX  0x40000000u

void  heap_init(u32 size);
void* kmalloc(u32 size);
void  kfree(void* ptr);
void  heap_stats(u32* used_bytes, u32* free_bytes);

#endif
