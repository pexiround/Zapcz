#include "mm.h"

/* Placed above the kernel image and above every module GRUB loaded. */
u32 g_dyn_base = 0;

void mm_set_safe_base(u32 modules_end) {
    u32 after_bss = PAGE_ROUND_UP(&bss_end, 0x1000u) + BACKBUFFER_SAFETY_MARGIN;
    u32 base = after_bss;
    if (modules_end + BACKBUFFER_SAFETY_MARGIN > base)
        base = PAGE_ROUND_UP(modules_end + BACKBUFFER_SAFETY_MARGIN, 0x1000u);
    g_dyn_base = base;
}


typedef struct block_header {
    u32 size;
    u8  free;
    struct block_header* next;
} block_header_t;

static block_header_t* heap_head = 0;

void heap_init(u32 size) {
    heap_head = (block_header_t*)HEAP_ADDR;
    heap_head->size = size - sizeof(block_header_t);
    heap_head->free = 1;
    heap_head->next = 0;
}

void* kmalloc(u32 size) {
    if (size == 0) return 0;

    size = (size + 15) & ~15u;

    block_header_t* cur = heap_head;
    while (cur) {
        if (cur->free && cur->size >= size) {

            if (cur->size > size + sizeof(block_header_t) + 16) {
                block_header_t* rest = (block_header_t*)((u8*)(cur + 1) + size);
                rest->size = cur->size - size - sizeof(block_header_t);
                rest->free = 1;
                rest->next = cur->next;
                cur->next = rest;
                cur->size = size;
            }
            cur->free = 0;
            return (void*)(cur + 1);
        }
        cur = cur->next;
    }
    return 0;
}

void kfree(void* ptr) {
    if (!ptr) return;
    block_header_t* blk = ((block_header_t*)ptr) - 1;
    blk->free = 1;

    block_header_t* cur = heap_head;
    while (cur && cur->next) {
        if (cur->free && cur->next->free &&
            (u8*)(cur + 1) + cur->size == (u8*)cur->next) {
            cur->size += sizeof(block_header_t) + cur->next->size;
            cur->next = cur->next->next;
        } else {
            cur = cur->next;
        }
    }
}

void heap_stats(u32* used_bytes, u32* free_bytes) {
    u32 used = 0, free = 0;
    block_header_t* cur = heap_head;
    while (cur) {
        if (cur->free) free += cur->size;
        else used += cur->size;
        cur = cur->next;
    }
    if (used_bytes) *used_bytes = used;
    if (free_bytes) *free_bytes = free;
}
