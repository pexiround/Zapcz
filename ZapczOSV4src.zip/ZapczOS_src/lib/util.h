#ifndef UTIL_H
#define UTIL_H
#include "io.h"

u32  str_len(const char* s);
int  str_eq(const char* a, const char* b);
int  str_eq_ci(const char* a, const char* b);
void str_copy(char* dst, const char* src, u32 maxlen);
void str_cat(char* dst, const char* src, u32 maxlen);
int  starts_with(const char* s, const char* prefix);
void u32_to_str(u32 v, char* out);
void i32_to_str(i32 v, char* out);
void u32_to_kb_str(u32 bytes, char* out);

#endif
