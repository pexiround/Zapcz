#include "util.h"

u32 str_len(const char* s) {
    u32 n = 0;
    while (s[n]) n++;
    return n;
}

int str_eq(const char* a, const char* b) {
    while (*a && *b) {
        if (*a != *b) return 0;
        a++; b++;
    }
    return *a == *b;
}

static char to_upper_ch(char c) {
    if (c >= 'a' && c <= 'z') return (char)(c - 'a' + 'A');
    return c;
}

int str_eq_ci(const char* a, const char* b) {
    while (*a && *b) {
        if (to_upper_ch(*a) != to_upper_ch(*b)) return 0;
        a++; b++;
    }
    return *a == *b;
}

void str_copy(char* dst, const char* src, u32 maxlen) {
    u32 i = 0;
    while (src[i] && i + 1 < maxlen) { dst[i] = src[i]; i++; }
    dst[i] = 0;
}

void str_cat(char* dst, const char* src, u32 maxlen) {
    u32 dl = str_len(dst);
    u32 i = 0;
    while (src[i] && dl + 1 < maxlen) { dst[dl] = src[i]; dl++; i++; }
    dst[dl] = 0;
}

int starts_with(const char* s, const char* prefix) {
    while (*prefix) {
        if (*s != *prefix) return 0;
        s++; prefix++;
    }
    return 1;
}

void u32_to_str(u32 v, char* out) {
    char tmp[12];
    int n = 0;
    if (v == 0) { out[0] = '0'; out[1] = 0; return; }
    while (v > 0) { tmp[n++] = (char)('0' + v % 10); v /= 10; }
    for (int i = 0; i < n; i++) out[i] = tmp[n - 1 - i];
    out[n] = 0;
}

void i32_to_str(i32 v, char* out) {
    if (v < 0) { out[0] = '-'; u32_to_str((u32)(-v), out+1); }
    else u32_to_str((u32)v, out);
}

void u32_to_kb_str(u32 bytes, char* out) {
    u32 kb = bytes / 1024;
    if (kb < 1024) {
        u32_to_str(kb, out);
        str_cat(out, " KB", 32);
    } else {
        u32 mb = kb / 1024;
        u32 frac = (kb % 1024) * 10 / 1024;
        char a[12], b[4];
        u32_to_str(mb, a);
        u32_to_str(frac, b);
        out[0] = 0;
        str_cat(out, a, 32);
        str_cat(out, ".", 32);
        str_cat(out, b, 32);
        str_cat(out, " MB", 32);
    }
}
