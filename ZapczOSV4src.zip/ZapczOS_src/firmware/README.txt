Intel wireless firmware
=======================

These are Intel's iwlwifi microcode images, taken from linux-firmware.
They are redistributable under Intel's firmware licence (see LICENCE.iwlwifi
in the linux-firmware tree). They are not part of ZapczOS and are not
covered by its licence.

  iwlwifi-3160-17.ucode                 3160            (Lenovo E31-70)
  iwlwifi-7260-17.ucode                 7260
  iwlwifi-7265D-29.ucode                7265D
  iwlwifi-3168-29.ucode                 3168
  iwlwifi-8265-36.ucode                 8265           (ThinkPad T480)
  iwlwifi-9260-th-b0-jf-b0-46.ucode     9260
  iwlwifi-9000-pu-b0-jf-b0-46.ucode     9560 / 9000 series

`make iso` copies whichever of these exist into the image and grub.cfg
passes them as multiboot modules. At boot the driver reads PCI config space
to work out which radio is fitted and loads only the matching image.

All seven were checked with the same TLV walk the kernel uses; each has a
valid IWL header and a sane section layout. The 3160/7260/7265D/3168 images
are single-CPU (7000-family, non-secure load); the 8265/9260/9000 images are
dual-CPU with paging and need the secure-boot load path.
