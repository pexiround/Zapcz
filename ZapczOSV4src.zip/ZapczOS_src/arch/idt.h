#ifndef IDT_H
#define IDT_H

#include "io.h"

struct interrupt_frame;

void idt_init(void);
void idt_set_gate(u8 num, void* handler, u8 flags);
void panic(const char* msg);

#endif
