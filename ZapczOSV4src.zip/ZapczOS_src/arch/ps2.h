#ifndef PS2_H
#define PS2_H
#include "io.h"

int ps2_controller_init(void);

void ps2_wait_input_clear(void);
void ps2_wait_output_full(void);
int  ps2_try_read(u8* out, u32 timeout_ms);

#endif
