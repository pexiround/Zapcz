#ifndef CRASH_H
#define CRASH_H
#include "io.h"

int  kj_setjmp(u32* env);
void kj_longjmp(u32* env, int val);

extern u32 g_kj_env[6];
extern volatile int g_guard_active;
extern volatile int g_crash_app;
extern volatile int g_crash_vec;
extern volatile u32 g_crash_eip;
extern volatile u32 g_crash_addr;
extern volatile u32 g_crash_err;

const char* crash_vec_name(int vec);

#endif
