#ifndef KEYBOARD_H
#define KEYBOARD_H
#include "io.h"

#define KEY_NONE      0
#define KEY_BACKSPACE 8
#define KEY_TAB       9
#define KEY_ENTER     10
#define KEY_ESC       27
#define KEY_UP        200
#define KEY_DOWN      201
#define KEY_LEFT      202
#define KEY_RIGHT     203
#define KEY_DEL       204

#define KEY_F1        205
#define KEY_F2        206
#define KEY_F3        207
#define KEY_F4        208
#define KEY_F5        209
#define KEY_F6        210
#define KEY_F7        211
#define KEY_F8        212
#define KEY_F9        213
#define KEY_F10       214
#define KEY_F11       215
#define KEY_F12       216

#define KEY_EXT_FIRST 128
#define KEY_EXT_LAST  154

static inline int kbd_is_printable(int key) {
    return (key >= 32 && key < 127) || (key >= KEY_EXT_FIRST && key <= KEY_EXT_LAST);
}

#define KBD_LAYOUT_US 0
#define KBD_LAYOUT_UK 1
#define KBD_LAYOUT_SE 2
#define KBD_LAYOUT_NO 3
#define KBD_LAYOUT_DK 4
#define KBD_LAYOUT_FI 5
#define KBD_LAYOUT_DE 6
#define KBD_LAYOUT_FR 7
#define KBD_LAYOUT_ES 8
#define KBD_LAYOUT_COUNT 9

const char* kbd_layout_name(int layout);
const char* kbd_layout_label(int layout);

void kbd_init(void);
int  kbd_getchar(void);
int  kbd_shift_down(void);
int  kbd_ctrl_down(void);
int  kbd_get_raw_event(int* pressed, int* extended_flag, unsigned char* scancode);

void kbd_set_layout(int layout);
int  kbd_get_layout(void);

#endif
