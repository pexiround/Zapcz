#include "apprecover.h"
#include "pit.h"

/* ebx, esi, edi, ebp, esp, eip */
__asm__(
".globl app_ctx_save\n"
"app_ctx_save:\n"
"    mov 4(%esp), %ecx\n"      /* ctx pointer */
"    mov %ebx, 0(%ecx)\n"
"    mov %esi, 4(%ecx)\n"
"    mov %edi, 8(%ecx)\n"
"    mov %ebp, 12(%ecx)\n"
"    lea 4(%esp), %eax\n"      /* esp as it will be after ret */
"    mov %eax, 16(%ecx)\n"
"    mov (%esp), %eax\n"       /* return address */
"    mov %eax, 20(%ecx)\n"
"    xor %eax, %eax\n"
"    ret\n"
);

__asm__(
".globl app_ctx_restore\n"
"app_ctx_restore:\n"
"    mov 4(%esp), %ecx\n"      /* ctx */
"    mov 8(%esp), %eax\n"      /* value to return */
"    mov 0(%ecx), %ebx\n"
"    mov 4(%ecx), %esi\n"
"    mov 8(%ecx), %edi\n"
"    mov 12(%ecx), %ebp\n"
"    mov 16(%ecx), %esp\n"
"    mov 20(%ecx), %edx\n"
"    sti\n"
"    jmp *%edx\n"
);

static app_ctx_t* g_ctx = 0;
static int   g_app = -1;
static int   g_armed = 0;
static u32   g_arm_tick = 0;
static int   g_hung_app = -1;

/* An app gets a much shorter leash than the kernel watchdog: if a single
   draw/click/key call takes this long it is wedged, not busy. */
#define APP_TIMEOUT_SEC 6

void app_guard_arm(app_ctx_t ctx, int app_id) {
    g_ctx = (app_ctx_t*)ctx;
    g_app = app_id;
    g_arm_tick = ticks_get();
    g_armed = 1;
}

void app_guard_disarm(void) {
    g_armed = 0;
    g_ctx = 0;
    g_app = -1;
}

int app_guard_hung_app(void) { return g_hung_app; }

int app_guard_check(void) {
    if (!g_armed || !g_ctx) return 0;
    u32 hz = ticks_per_sec();
    if (!hz) hz = 100;
    if ((ticks_get() - g_arm_tick) < hz * APP_TIMEOUT_SEC) return 0;

    /* Time is up. Remember who hung, disarm, and unwind back to the desktop
       loop. We are inside the timer interrupt, so the PIC has to be told we
       are done before we abandon the interrupt frame. */
    g_hung_app = g_app;
    app_ctx_t* ctx = g_ctx;
    app_guard_disarm();
    extern void pic_send_eoi(u8 irq);
    pic_send_eoi(0);
    app_ctx_restore(*ctx, 1);
    return 1;   /* unreachable */
}
