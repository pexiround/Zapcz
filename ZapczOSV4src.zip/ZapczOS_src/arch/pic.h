#ifndef PIC_H
#define PIC_H
#include "io.h"

void pic_remap(void);
void pic_send_eoi(u8 irq);
void pic_mask_irq(u8 irq);
void pic_unmask_irq(u8 irq);

#endif
