#ifndef PIT_H
#define PIT_H
#include "io.h"
void pit_init(u32 hz);
u32  ticks_get(void);
u32  ticks_per_sec(void);
void sleep_ms(u32 ms);
void watchdog_arm(void);
void watchdog_heartbeat(const char* label);
#endif
