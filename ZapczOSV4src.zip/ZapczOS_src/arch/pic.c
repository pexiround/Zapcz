#include "io.h"
#include "pic.h"

#define PIC1 0x20
#define PIC2 0xA0
#define PIC1_DATA 0x21
#define PIC2_DATA 0xA1

void pic_remap(void) {
    u8 mask1 = inb(PIC1_DATA);
    u8 mask2 = inb(PIC2_DATA);

    outb(PIC1, 0x11); io_wait();
    outb(PIC2, 0x11); io_wait();
    outb(PIC1_DATA, 0x20); io_wait();
    outb(PIC2_DATA, 0x28); io_wait();
    outb(PIC1_DATA, 0x04); io_wait();
    outb(PIC2_DATA, 0x02); io_wait();
    outb(PIC1_DATA, 0x01); io_wait();
    outb(PIC2_DATA, 0x01); io_wait();

    (void)mask1; (void)mask2;

    outb(PIC1_DATA, 0xFE);
    outb(PIC2_DATA, 0xFF);
}

void pic_mask_irq(u8 irq) {
    u16 port = irq < 8 ? PIC1_DATA : PIC2_DATA;
    u8 bit = (u8)(1u << (irq < 8 ? irq : irq - 8));
    u8 cur = inb(port);
    outb(port, (u8)(cur | bit));
}

void pic_unmask_irq(u8 irq) {
    u16 port = irq < 8 ? PIC1_DATA : PIC2_DATA;
    u8 bit = (u8)(1u << (irq < 8 ? irq : irq - 8));
    u8 cur = inb(port);
    outb(port, (u8)(cur & ~bit));
    if (irq >= 8) {

        u8 m1 = inb(PIC1_DATA);
        outb(PIC1_DATA, (u8)(m1 & ~(1u << 2)));
    }
}

void pic_send_eoi(u8 irq) {
    if (irq >= 8) outb(PIC2, 0x20);
    outb(PIC1, 0x20);
}
