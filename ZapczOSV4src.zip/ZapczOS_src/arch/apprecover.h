#ifndef APPRECOVER_H
#define APPRECOVER_H
#include "io.h"

/* Minimal setjmp/longjmp so a hung application can be abandoned without
   taking the kernel down with it. Only callee-saved state is preserved,
   which is all we need: we are unwinding, not resuming. */
typedef u32 app_ctx_t[6];   /* ebx, esi, edi, ebp, esp, eip */

int  app_ctx_save(app_ctx_t ctx);              /* 0 first time, 1 when unwound */
void app_ctx_restore(app_ctx_t ctx, int val);  /* never returns */

/* Arm/disarm the per-app timeout. label is shown on the crash overlay. */
void app_guard_arm(app_ctx_t ctx, int app_id);
void app_guard_disarm(void);

/* Called from the timer interrupt. Returns 1 if it unwound (never returns
   in practice), 0 if nothing to do. */
int  app_guard_check(void);

int  app_guard_hung_app(void);

#endif
