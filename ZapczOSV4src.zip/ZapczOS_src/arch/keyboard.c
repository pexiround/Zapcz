#include "keyboard.h"
#include "idt.h"
#include "pic.h"

#define KBD_DATA 0x60
#define KBD_BUF_SIZE 256

static volatile u8 kbuf[KBD_BUF_SIZE];
static volatile u32 kbuf_head = 0, kbuf_tail = 0;
static int shift_down = 0;
static int ctrl_down = 0;
static int altgr_down = 0;
static int extended = 0;

#define RAW_BUF_SIZE 256
static volatile u16 raw_buf[RAW_BUF_SIZE];
static volatile u32 raw_head = 0, raw_tail = 0;

static void raw_push(u8 scancode, int extended_flag, int pressed) {
    u32 next = (raw_head + 1) % RAW_BUF_SIZE;
    if (next == raw_tail) return;
    raw_buf[raw_head] = (u16)((extended_flag ? 0x100 : 0) | (pressed ? 0x200 : 0) | scancode);
    raw_head = next;
}

int kbd_get_raw_event(int* pressed, int* extended_flag, u8* scancode) {
    if (raw_tail == raw_head) return 0;
    u16 e = raw_buf[raw_tail];
    raw_tail = (raw_tail + 1) % RAW_BUF_SIZE;
    *scancode = (u8)(e & 0xFF);
    *extended_flag = (e & 0x100) ? 1 : 0;
    *pressed = (e & 0x200) ? 1 : 0;
    return 1;
}

#define KBD_TABLE_LEN 87

static const u8 kbd_unshifted_US[KBD_TABLE_LEN] = {0,27,49,50,51,52,53,54,55,56,57,48,45,61,8,9,113,119,101,114,116,121,117,105,111,112,91,93,10,0,97,115,100,102,103,104,106,107,108,59,39,96,0,92,122,120,99,118,98,110,109,44,46,47,0,42,0,32,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
static const u8 kbd_shifted_US[KBD_TABLE_LEN]   = {0,27,33,64,35,36,37,94,38,42,40,41,95,43,8,9,81,87,69,82,84,89,85,73,79,80,123,125,10,0,65,83,68,70,71,72,74,75,76,58,34,126,0,124,90,88,67,86,66,78,77,60,62,63,0,42,0,32,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
static const u8 kbd_altgr_US[KBD_TABLE_LEN]     = {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};

static const u8 kbd_unshifted_UK[KBD_TABLE_LEN] = {0,27,49,50,51,52,53,54,55,56,57,48,45,61,8,9,113,119,101,114,116,121,117,105,111,112,91,93,10,0,97,115,100,102,103,104,106,107,108,59,39,96,0,35,122,120,99,118,98,110,109,44,46,47,0,42,0,32,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,92};
static const u8 kbd_shifted_UK[KBD_TABLE_LEN]   = {0,27,33,34,152,36,37,94,38,42,40,41,95,43,8,9,81,87,69,82,84,89,85,73,79,80,123,125,10,0,65,83,68,70,71,72,74,75,76,58,64,126,0,126,90,88,67,86,66,78,77,60,62,63,0,42,0,32,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,124};
static const u8 kbd_altgr_UK[KBD_TABLE_LEN]     = {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};

static const u8 kbd_unshifted_SE[KBD_TABLE_LEN] = {0,27,49,50,51,52,53,54,55,56,57,48,43,39,8,9,113,119,101,114,116,121,117,105,111,112,131,34,10,0,97,115,100,102,103,104,106,107,108,133,132,151,0,39,122,120,99,118,98,110,109,44,46,45,0,42,0,32,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,60};
static const u8 kbd_shifted_SE[KBD_TABLE_LEN]   = {0,27,33,34,35,36,37,38,47,40,41,61,63,96,8,9,81,87,69,82,84,89,85,73,79,80,128,94,10,0,65,83,68,70,71,72,74,75,76,130,129,35,0,42,90,88,67,86,66,78,77,59,58,95,0,42,0,32,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,62};
static const u8 kbd_altgr_SE[KBD_TABLE_LEN]     = {0,0,0,64,0,36,0,0,123,91,93,125,92,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,124};

static const u8 kbd_unshifted_NO[KBD_TABLE_LEN] = {0,27,49,50,51,52,53,54,55,56,57,48,43,39,8,9,113,119,101,114,116,121,117,105,111,112,131,34,10,0,97,115,100,102,103,104,106,107,108,137,135,151,0,39,122,120,99,118,98,110,109,44,46,45,0,42,0,32,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,60};
static const u8 kbd_shifted_NO[KBD_TABLE_LEN]   = {0,27,33,34,35,36,37,38,47,40,41,61,63,96,8,9,81,87,69,82,84,89,85,73,79,80,128,94,10,0,65,83,68,70,71,72,74,75,76,136,134,35,0,42,90,88,67,86,66,78,77,59,58,95,0,42,0,32,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,62};
static const u8 kbd_altgr_NO[KBD_TABLE_LEN]     = {0,0,0,64,0,36,0,0,123,91,93,125,92,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,124};

static const u8 kbd_unshifted_DK[KBD_TABLE_LEN] = {0,27,49,50,51,52,53,54,55,56,57,48,43,39,8,9,113,119,101,114,116,121,117,105,111,112,131,34,10,0,97,115,100,102,103,104,106,107,108,137,135,151,0,39,122,120,99,118,98,110,109,44,46,45,0,42,0,32,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,60};
static const u8 kbd_shifted_DK[KBD_TABLE_LEN]   = {0,27,33,34,35,36,37,38,47,40,41,61,63,96,8,9,81,87,69,82,84,89,85,73,79,80,128,94,10,0,65,83,68,70,71,72,74,75,76,136,134,35,0,42,90,88,67,86,66,78,77,59,58,95,0,42,0,32,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,62};
static const u8 kbd_altgr_DK[KBD_TABLE_LEN]     = {0,0,0,64,0,36,0,0,123,91,93,125,92,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,124};

static const u8 kbd_unshifted_FI[KBD_TABLE_LEN] = {0,27,49,50,51,52,53,54,55,56,57,48,43,39,8,9,113,119,101,114,116,121,117,105,111,112,131,34,10,0,97,115,100,102,103,104,106,107,108,133,132,151,0,39,122,120,99,118,98,110,109,44,46,45,0,42,0,32,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,60};
static const u8 kbd_shifted_FI[KBD_TABLE_LEN]   = {0,27,33,34,35,36,37,38,47,40,41,61,63,96,8,9,81,87,69,82,84,89,85,73,79,80,128,94,10,0,65,83,68,70,71,72,74,75,76,130,129,35,0,42,90,88,67,86,66,78,77,59,58,95,0,42,0,32,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,62};
static const u8 kbd_altgr_FI[KBD_TABLE_LEN]     = {0,0,0,64,0,36,0,0,123,91,93,125,92,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,124};

static const u8 kbd_unshifted_DE[KBD_TABLE_LEN] = {0,27,49,50,51,52,53,54,55,56,57,48,140,39,8,9,113,119,101,114,116,122,117,105,111,112,139,43,10,0,97,115,100,102,103,104,106,107,108,133,132,94,0,35,121,120,99,118,98,110,109,44,46,45,0,42,0,32,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,60};
static const u8 kbd_shifted_DE[KBD_TABLE_LEN]   = {0,27,33,34,151,36,37,38,47,40,41,61,63,96,8,9,81,87,69,82,84,90,85,73,79,80,138,42,10,0,65,83,68,70,71,72,74,75,76,130,129,111,0,39,89,88,67,86,66,78,77,59,58,95,0,42,0,32,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,62};
static const u8 kbd_altgr_DE[KBD_TABLE_LEN]     = {0,0,0,0,64,0,0,0,123,91,93,125,92,0,0,0,0,0,0,0,0,0,0,0,0,0,0,124,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};

static const u8 kbd_unshifted_FR[KBD_TABLE_LEN] = {0,27,38,142,34,39,40,45,144,95,146,153,41,61,8,9,97,122,101,114,116,121,117,105,111,112,94,36,10,0,113,115,100,102,103,104,106,107,108,109,154,50,0,42,119,120,99,118,98,110,44,59,58,33,0,42,0,32,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,60};
static const u8 kbd_shifted_FR[KBD_TABLE_LEN]   = {0,27,49,50,51,52,53,54,55,56,57,48,111,43,8,9,65,90,69,82,84,89,85,73,79,80,34,152,10,0,81,83,68,70,71,72,74,75,76,77,37,126,0,117,87,88,67,86,66,78,63,46,47,151,0,42,0,32,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,62};
static const u8 kbd_altgr_FR[KBD_TABLE_LEN]     = {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,123,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};

static const u8 kbd_unshifted_ES[KBD_TABLE_LEN] = {0,27,49,50,51,52,53,54,55,56,57,48,39,150,8,9,113,119,101,114,116,121,117,105,111,112,96,43,10,0,97,115,100,102,103,104,106,107,108,148,39,111,0,146,122,120,99,118,98,110,109,44,46,45,0,42,0,32,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,60};
static const u8 kbd_shifted_ES[KBD_TABLE_LEN]   = {0,27,33,34,35,36,37,38,47,40,41,61,63,149,8,9,81,87,69,82,84,89,85,73,79,80,94,42,10,0,65,83,68,70,71,72,74,75,76,147,34,111,0,145,90,88,67,86,66,78,77,59,58,95,0,42,0,32,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,62};
static const u8 kbd_altgr_ES[KBD_TABLE_LEN]     = {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};


typedef struct {
    const u8* unshifted;
    const u8* shifted;
    const u8* altgr;
    const char* name;
    const char* label;
} kbd_layout_t;

static const kbd_layout_t LAYOUTS[KBD_LAYOUT_COUNT] = {
    { kbd_unshifted_US, kbd_shifted_US, kbd_altgr_US, "US", "United States (QWERTY)" },
    { kbd_unshifted_UK, kbd_shifted_UK, kbd_altgr_UK, "UK", "United Kingdom" },
    { kbd_unshifted_SE, kbd_shifted_SE, kbd_altgr_SE, "SE", "Svenska (Swedish)" },
    { kbd_unshifted_NO, kbd_shifted_NO, kbd_altgr_NO, "NO", "Norsk (Norwegian)" },
    { kbd_unshifted_DK, kbd_shifted_DK, kbd_altgr_DK, "DK", "Dansk (Danish)" },
    { kbd_unshifted_FI, kbd_shifted_FI, kbd_altgr_FI, "FI", "Suomi (Finnish)" },
    { kbd_unshifted_DE, kbd_shifted_DE, kbd_altgr_DE, "DE", "Deutsch (German, QWERTZ)" },
    { kbd_unshifted_FR, kbd_shifted_FR, kbd_altgr_FR, "FR", "Francais (French, AZERTY)" },
    { kbd_unshifted_ES, kbd_shifted_ES, kbd_altgr_ES, "ES", "Espanol (Spanish)" },
};

static int cur_layout = KBD_LAYOUT_US;

const char* kbd_layout_name(int layout) {
    if (layout < 0 || layout >= KBD_LAYOUT_COUNT) layout = KBD_LAYOUT_US;
    return LAYOUTS[layout].name;
}
const char* kbd_layout_label(int layout) {
    if (layout < 0 || layout >= KBD_LAYOUT_COUNT) layout = KBD_LAYOUT_US;
    return LAYOUTS[layout].label;
}

void kbd_set_layout(int layout) {
    if (layout < 0 || layout >= KBD_LAYOUT_COUNT) layout = KBD_LAYOUT_US;
    cur_layout = layout;
}
int kbd_get_layout(void) { return cur_layout; }

void kbd_init(void) {
    kbuf_head = kbuf_tail = 0;
    shift_down = ctrl_down = altgr_down = extended = 0;
}

int kbd_shift_down(void) { return shift_down; }
int kbd_ctrl_down(void) { return ctrl_down; }

static void kbuf_push(u8 c) {
    u32 next = (kbuf_head + 1) % KBD_BUF_SIZE;
    if (next == kbuf_tail) return;
    kbuf[kbuf_head] = c;
    kbuf_head = next;
}

int kbd_getchar(void) {
    if (kbuf_tail == kbuf_head) return KEY_NONE;
    u8 c = kbuf[kbuf_tail];
    kbuf_tail = (kbuf_tail + 1) % KBD_BUF_SIZE;
    return c;
}

__attribute__((interrupt)) void kbd_irq_handler(struct interrupt_frame* f) {
    (void)f;
    u8 sc = inb(KBD_DATA);

    if (sc == 0xE0) { extended = 1; goto eoi; }

    if (extended) {
        extended = 0;
        u8 make = sc & 0x7F;
        int release = sc & 0x80;
        raw_push(make, 1, !release);
        if (make == 0x38) { altgr_down = !release; goto eoi; }
        if (!release) {
            switch (make) {
                case 0x48: kbuf_push(KEY_UP); break;
                case 0x50: kbuf_push(KEY_DOWN); break;
                case 0x4B: kbuf_push(KEY_LEFT); break;
                case 0x4D: kbuf_push(KEY_RIGHT); break;
                case 0x53: kbuf_push(KEY_DEL); break;
                default: break;
            }
        }
        goto eoi;
    }

    {
        u8 make = sc & 0x7F;
        int release = sc & 0x80;
        raw_push(make, 0, !release);
    }

    if (sc == 0x2A || sc == 0x36) { shift_down = 1; goto eoi; }
    if (sc == 0xAA || sc == 0xB6) { shift_down = 0; goto eoi; }
    if (sc == 0x1D) { ctrl_down = 1; goto eoi; }
    if (sc == 0x9D) { ctrl_down = 0; goto eoi; }

    if (sc & 0x80) goto eoi;

    if (sc >= 0x3B && sc <= 0x44) { kbuf_push(KEY_F1 + (sc - 0x3B)); goto eoi; }
    if (sc == 0x57) { kbuf_push(KEY_F11); goto eoi; }
    if (sc == 0x58) { kbuf_push(KEY_F12); goto eoi; }

    if (sc < KBD_TABLE_LEN) {
        const kbd_layout_t* L = &LAYOUTS[cur_layout];
        u8 ch = 0;
        if (altgr_down) ch = L->altgr[sc];
        if (!ch) ch = shift_down ? L->shifted[sc] : L->unshifted[sc];
        if (ch) kbuf_push(ch);
    }

eoi:
    {
        pic_send_eoi(1);
    }
}
