#include "rtc.h"

#define CMOS_ADDR 0x70
#define CMOS_DATA 0x71

static u8 cmos_read(u8 reg) {
    outb(CMOS_ADDR, reg);
    return inb(CMOS_DATA);
}

static int updating(void) {
    outb(CMOS_ADDR, 0x0A);
    return inb(CMOS_DATA) & 0x80;
}

static u8 bcd2bin(u8 v) { return (u8)((v & 0x0F) + ((v >> 4) * 10)); }

void rtc_read(rtc_time_t* t) {
    u8 sec, min, hour, day, month, year, regB;
    int tries = 0;
    do {
        while (updating() && tries < 100000) tries++;
        sec   = cmos_read(0x00);
        min   = cmos_read(0x02);
        hour  = cmos_read(0x04);
        day   = cmos_read(0x07);
        month = cmos_read(0x08);
        year  = cmos_read(0x09);
    } while (updating() && tries < 100000);

    regB = cmos_read(0x0B);

    if (!(regB & 0x04)) {
        sec   = bcd2bin(sec);
        min   = bcd2bin(min);
        hour  = (u8)(bcd2bin(hour & 0x7F) | (hour & 0x80));
        day   = bcd2bin(day);
        month = bcd2bin(month);
        year  = bcd2bin(year);
    }

    if (!(regB & 0x02) && (hour & 0x80)) {
        hour = (u8)(((hour & 0x7F) + 12) % 24);
    }

    t->second = sec;
    t->minute = min;
    t->hour = hour;
    t->day = day;
    t->month = month;
    t->year = (u16)(2000 + year);
}
