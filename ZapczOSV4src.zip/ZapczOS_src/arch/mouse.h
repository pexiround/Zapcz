#ifndef MOUSE_H
#define MOUSE_H
#include "io.h"

int  mouse_init(void);
void mouse_poll_frame(void);
void mouse_set_bounds(i32 w, i32 h);
i32  mouse_x(void);
i32  mouse_y(void);
int  mouse_left(void);
int  mouse_right(void);

int  mouse_left_pressed(void);
int  mouse_left_released(void);
int  mouse_right_pressed(void);
i32  mouse_wheel_delta(void);
int  mouse_has_wheel(void);

void mouse_set_sensitivity(int pct);
int  mouse_get_sensitivity(void);

#endif
