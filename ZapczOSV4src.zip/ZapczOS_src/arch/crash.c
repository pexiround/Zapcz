#include "crash.h"

u32 g_kj_env[6];
volatile int g_guard_active = 0;
volatile int g_crash_app = -1;
volatile int g_crash_vec = 0;
volatile u32 g_crash_eip = 0;
volatile u32 g_crash_addr = 0;
volatile u32 g_crash_err = 0;

__attribute__((naked)) int kj_setjmp(u32* env) {
    __asm__ volatile(
        "movl 4(%esp), %eax\n\t"
        "movl %ebx, (%eax)\n\t"
        "movl %esi, 4(%eax)\n\t"
        "movl %edi, 8(%eax)\n\t"
        "movl %ebp, 12(%eax)\n\t"
        "leal 4(%esp), %ecx\n\t"
        "movl %ecx, 16(%eax)\n\t"
        "movl (%esp), %ecx\n\t"
        "movl %ecx, 20(%eax)\n\t"
        "xorl %eax, %eax\n\t"
        "ret\n\t"
    );
}

__attribute__((naked)) void kj_longjmp(u32* env, int val) {
    __asm__ volatile(
        "movl 4(%esp), %edx\n\t"
        "movl 8(%esp), %eax\n\t"
        "testl %eax, %eax\n\t"
        "jnz 1f\n\t"
        "movl $1, %eax\n\t"
        "1:\n\t"
        "movl (%edx), %ebx\n\t"
        "movl 4(%edx), %esi\n\t"
        "movl 8(%edx), %edi\n\t"
        "movl 12(%edx), %ebp\n\t"
        "movl 16(%edx), %esp\n\t"
        "movl 20(%edx), %ecx\n\t"
        "jmp *%ecx\n\t"
    );
}

const char* crash_vec_name(int vec) {
    switch (vec) {
        case 0:  return "Divide by zero";
        case 6:  return "Illegal instruction";
        case 13: return "Protection fault (bad access)";
        case 14: return "Memory fault (invalid address)";
        default: return "Fault";
    }
}
