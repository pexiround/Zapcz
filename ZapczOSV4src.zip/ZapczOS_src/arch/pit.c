#include "io.h"
#include "idt.h"
#include "pic.h"
static volatile u32 ticks = 0;
static u32 tick_hz = 100;
static volatile u32 last_heartbeat_tick = 0;
static volatile int watchdog_armed = 0;
static char watchdog_label[48] = "";

void pit_init(u32 hz) {
    tick_hz = hz;
    u32 divisor = 1193182 / hz;
    outb(0x43, 0x36);
    outb(0x40, (u8)(divisor & 0xFF));
    outb(0x40, (u8)((divisor >> 8) & 0xFF));
}

u32 ticks_get(void) { return ticks; }
u32 ticks_per_sec(void) { return tick_hz; }

void sleep_ms(u32 ms) {
    u32 target = ticks + (ms * tick_hz) / 1000 + 1;
    while (ticks < target) { __asm__ volatile ("hlt"); }
}

void watchdog_arm(void) {
    last_heartbeat_tick = ticks;
    watchdog_armed = 1;
}

void watchdog_heartbeat(const char* label) {
    last_heartbeat_tick = ticks;
    int i = 0;
    while (label[i] && i < 47) { watchdog_label[i] = label[i]; i++; }
    watchdog_label[i] = 0;
}

__attribute__((interrupt)) void timer_irq_handler(struct interrupt_frame* f) {
    (void)f;
    ticks++;
    /* Give a wedged application a chance to be abandoned on its own before
       we escalate to taking the whole kernel down. */
    { extern int app_guard_check(void); app_guard_check(); }

    if (watchdog_armed && (ticks - last_heartbeat_tick) > tick_hz * 20) {
        char msg[80] = "Watchdog timeout (stuck in: ";
        int i = 0;
        while (msg[i]) i++;
        int j = 0;
        while (watchdog_label[j] && i < 78) msg[i++] = watchdog_label[j++];
        msg[i++] = ')';
        msg[i] = 0;
        panic(msg);
    }
    pic_send_eoi(0);
}
