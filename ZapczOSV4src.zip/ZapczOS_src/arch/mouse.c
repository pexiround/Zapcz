#include "mouse.h"
#include "idt.h"
#include "ps2.h"
#include "pic.h"

#define PS2_DATA 0x60
#define PS2_CMD  0x64

static i32 mx = 100, my = 100;
static i32 bound_w = 1024, bound_h = 768;
static u8 buttons = 0, prev_buttons = 0;

static u8 packet[4];
static int packet_idx = 0;
static int packet_size = 3;
static int wheel_enabled = 0;

static int sens_pct = 100;
void mouse_set_sensitivity(int pct) {
    if (pct < 25) pct = 25;
    if (pct > 200) pct = 200;
    sens_pct = pct;
}
int mouse_get_sensitivity(void) { return sens_pct; }

static volatile int raw_press_event = 0, raw_release_event = 0;
static volatile int raw_right_press_event = 0;
static volatile i32 raw_wheel_accum = 0;

static int frame_press = 0, frame_release = 0;
static int frame_right_press = 0;
static i32 frame_wheel = 0;

extern void serial_puts(const char*);
static void mouse_dbg(const char* msg) { serial_puts("[mouse] "); serial_puts(msg); serial_puts("\r\n"); }

static void mouse_send(u8 b) {
    ps2_wait_input_clear();
    outb(PS2_CMD, 0xD4);
    ps2_wait_input_clear();
    outb(PS2_DATA, b);
}

static int mouse_cmd_ack(u8 b) {
    mouse_send(b);
    u8 resp = 0;
    if (!ps2_try_read(&resp, 100)) return 0;
    return resp == 0xFA;
}

static int mouse_get_id(u8* id_out) {
    mouse_send(0xF2);
    u8 ack = 0;
    if (!ps2_try_read(&ack, 100) || ack != 0xFA) return 0;
    return ps2_try_read(id_out, 100);
}

void mouse_set_bounds(i32 w, i32 h) { bound_w = w; bound_h = h; mx = w/2; my = h/2; }
i32 mouse_x(void) { return mx; }
i32 mouse_y(void) { return my; }
int mouse_left(void) { return buttons & 1; }
int mouse_right(void) { return buttons & 2; }

void mouse_poll_frame(void) {
    frame_press = raw_press_event;   raw_press_event = 0;
    frame_release = raw_release_event; raw_release_event = 0;
    frame_wheel = raw_wheel_accum;    raw_wheel_accum = 0;
    frame_right_press = raw_right_press_event; raw_right_press_event = 0;
}
int mouse_left_pressed(void) { return frame_press; }
int mouse_left_released(void) { return frame_release; }
int mouse_right_pressed(void) { return frame_right_press; }
i32  mouse_wheel_delta(void) { return frame_wheel; }
int  mouse_has_wheel(void) { return wheel_enabled; }

int mouse_init(void) {
    packet_idx = 0;
    packet_size = 3;
    wheel_enabled = 0;
    buttons = 0;
    prev_buttons = 0;

    ps2_wait_input_clear();
    outb(PS2_CMD, 0xD4);
    ps2_wait_input_clear();
    outb(PS2_DATA, 0xFF);

    u8 ack = 0, bat = 0, devid = 0;
    int got_ack = ps2_try_read(&ack, 100);
    int got_bat = ps2_try_read(&bat, 1000);
    ps2_try_read(&devid, 100);

    int reset_ok = (got_ack && ack == 0xFA && got_bat && bat == 0xAA);
    mouse_dbg(reset_ok ? "reset OK (ACK+BAT)"
                       : "reset handshake imperfect - continuing anyway (trackpoint/touchpad)");

    mouse_cmd_ack(0xF6);

    if (mouse_cmd_ack(0xF3) && mouse_cmd_ack(200) &&
        mouse_cmd_ack(0xF3) && mouse_cmd_ack(100) &&
        mouse_cmd_ack(0xF3) && mouse_cmd_ack(80)) {
        u8 id = 0xFF;
        if (mouse_get_id(&id) && id == 3) {
            wheel_enabled = 1;
            packet_size = 4;
        }
    }

    /* The wheel-detect knock above leaves the device at 80 samples/sec, which
       feels sluggish on real hardware. Restore a fast rate and ask for the
       finest resolution (8 counts/mm) so movement is responsive. */
    mouse_cmd_ack(0xF3); mouse_cmd_ack(200);      /* sample rate 200 Hz */
    mouse_cmd_ack(0xE8); mouse_cmd_ack(0x03);     /* resolution 8 counts/mm */
    mouse_cmd_ack(0xE6);                          /* linear 1:1 scaling (we accelerate ourselves) */

    int report_ok = mouse_cmd_ack(0xF4);
    mouse_dbg(report_ok ? "data reporting enabled (0xF4 ACKed)"
                        : "0xF4 not ACKed - unmasking IRQ12 anyway");

    {
        int guard = 0;
        while ((inb(PS2_CMD) & 0x01) && guard++ < 64) inb(PS2_DATA);
    }
    packet_idx = 0;

    pic_unmask_irq(12);
    return reset_ok || report_ok;
}

__attribute__((interrupt)) void mouse_irq_handler(struct interrupt_frame* f) {
    (void)f;
    u8 data = inb(PS2_DATA);

    if (packet_idx == 0 && !(data & 0x08)) {

        goto eoi;
    }

    packet[packet_idx++] = data;
    if (packet_idx == packet_size) {
        packet_idx = 0;
        u8 b0 = packet[0];

        {
            i32 dx = (i32)(i8)packet[1];
            i32 dy = (i32)(i8)packet[2];
            if (b0 & 0x40) dx = 0;
            if (b0 & 0x80) dy = 0;

            dx = dx * sens_pct / 100;
            dy = dy * sens_pct / 100;

            /* mild acceleration: |d| > 5 counts in one packet means a fast
               flick, so scale it up; small movements stay 1:1 for precision */
            {
                i32 adx = dx < 0 ? -dx : dx;
                i32 ady = dy < 0 ? -dy : dy;
                i32 mag = adx > ady ? adx : ady;
                if (mag > 5) {
                    i32 boost = 100 + (mag - 5) * 12;
                    if (boost > 260) boost = 260;
                    dx = dx * boost / 100;
                    dy = dy * boost / 100;
                }
            }

            mx += dx;
            my -= dy;
            if (mx < 0) mx = 0;
            if (my < 0) my = 0;
            if (mx >= bound_w) mx = bound_w - 1;
            if (my >= bound_h) my = bound_h - 1;

            prev_buttons = buttons;
            buttons = b0 & 0x07;
            if ((buttons & 1) && !(prev_buttons & 1)) raw_press_event = 1;
            if (!(buttons & 1) && (prev_buttons & 1)) raw_release_event = 1;
            if ((buttons & 2) && !(prev_buttons & 2)) raw_right_press_event = 1;

            if (wheel_enabled) {
                i32 wz = (i32)(i8)packet[3];
                if (wz != 0) raw_wheel_accum -= wz;
            }
        }
    }

eoi:
    pic_send_eoi(12);
}
