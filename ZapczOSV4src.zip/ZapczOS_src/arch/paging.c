#include "io.h"

static u32 page_dir[1024]  __attribute__((aligned(4096)));
static u32 first_pt[1024]  __attribute__((aligned(4096)));

void paging_init(void) {
    for (int i = 0; i < 1024; i++) {
        if (i == 0) first_pt[i] = 0;
        else first_pt[i] = ((u32)i * 0x1000u) | 3u;
    }
    page_dir[0] = (u32)first_pt | 3;
    for (int i = 1; i < 1024; i++) {
        page_dir[i] = ((u32)i * 0x400000u) | 0x83u;
    }
    __asm__ volatile(
        "mov %0, %%cr3\n\t"
        "mov %%cr4, %%eax\n\t"
        "or $0x00000010, %%eax\n\t"
        "mov %%eax, %%cr4\n\t"
        "mov %%cr0, %%eax\n\t"
        "or $0x80000000, %%eax\n\t"
        "mov %%eax, %%cr0\n\t"
        : : "r"(page_dir) : "eax"
    );
}
