#include "ps2.h"
#include "pic.h"
#include "pit.h"

#define PS2_DATA 0x60
#define PS2_CMD  0x64

static u32 ms_to_ticks(u32 ms) {
    u32 t = (ms * ticks_per_sec()) / 1000;
    return t ? t : 1;
}

void ps2_wait_input_clear(void) {
    u32 start = ticks_get();
    u32 limit = ms_to_ticks(50);
    while (ticks_get() - start <= limit) {
        if (!(inb(PS2_CMD) & 0x02)) return;
    }
}
void ps2_wait_output_full(void) {
    u32 start = ticks_get();
    u32 limit = ms_to_ticks(50);
    while (ticks_get() - start <= limit) {
        if (inb(PS2_CMD) & 0x01) return;
    }
}
int ps2_try_read(u8* out, u32 timeout_ms) {
    u32 start = ticks_get();
    u32 limit = ms_to_ticks(timeout_ms);
    while (ticks_get() - start <= limit) {
        if (inb(PS2_CMD) & 0x01) { *out = inb(PS2_DATA); return 1; }
    }
    return 0;
}

static void ps2_flush_output(void) {
    int guard = 0;
    while ((inb(PS2_CMD) & 0x01) && guard++ < 256) {
        inb(PS2_DATA);
    }
}

static void cmd(u8 c) { ps2_wait_input_clear(); outb(PS2_CMD, c); }
static void data(u8 d) { ps2_wait_input_clear(); outb(PS2_DATA, d); }

extern void serial_puts(const char*);
static void ps2_dbg_hex(const char* s, u8 v) {
    char b[8]; const char* hx = "0123456789ABCDEF";
    b[0]='0'; b[1]='x'; b[2]=hx[(v>>4)&0xF]; b[3]=hx[v&0xF]; b[4]=0;
    serial_puts("[ps2] "); serial_puts(s); serial_puts(b); serial_puts("\r\n");
}

int ps2_controller_init(void) {

    pic_mask_irq(1);
    pic_mask_irq(12);

    cmd(0xAD);
    cmd(0xA7);
    ps2_flush_output();

    cmd(0xAA);
    u8 self_test_result = 0;
    ps2_try_read(&self_test_result, 100);
    ps2_flush_output();
    ps2_dbg_hex("8042 self-test (want 0x55)=", self_test_result);

    cmd(0xA9);
    u8 port2_result = 0xFF;
    ps2_try_read(&port2_result, 100);
    ps2_dbg_hex("port2 test (0x00=present)=", port2_result);

    cmd(0x20);
    u8 config = 0;
    ps2_try_read(&config, 100);
    config |= 0x01;
    config &= (u8)~0x10;
    config |= 0x02;
    config &= (u8)~0x20;
    cmd(0x60);
    data(config);
    ps2_dbg_hex("config byte written=", config);

    cmd(0xAE);
    cmd(0xA8);

    pic_unmask_irq(1);

    return 1;
}
