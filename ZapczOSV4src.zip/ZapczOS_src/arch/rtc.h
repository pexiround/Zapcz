#ifndef RTC_H
#define RTC_H
#include "io.h"

typedef struct {
    u8 hour, minute, second;
    u8 day, month;
    u16 year;
} rtc_time_t;

void rtc_read(rtc_time_t* t);

#endif
