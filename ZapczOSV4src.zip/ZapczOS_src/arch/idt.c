#include "idt.h"
#include "graphics.h"
#include "pic.h"
#include "crash.h"

struct interrupt_frame { u32 eip; u32 cs; u32 eflags; };

typedef struct __attribute__((packed)) {
    u16 offset_low;
    u16 selector;
    u8  zero;
    u8  type_attr;
    u16 offset_high;
} idt_entry_t;

typedef struct __attribute__((packed)) {
    u16 limit;
    u32 base;
} idt_ptr_t;

static idt_entry_t idt[256];
static idt_ptr_t idt_ptr;

extern void pit_init(u32 hz);
extern void kbd_irq_handler(struct interrupt_frame* f);
extern void mouse_irq_handler(struct interrupt_frame* f);
extern void timer_irq_handler(struct interrupt_frame* f);

void idt_set_gate(u8 num, void* handler, u8 flags) {
    u32 addr = (u32)handler;
    idt[num].offset_low  = addr & 0xFFFF;
    idt[num].offset_high = (addr >> 16) & 0xFFFF;
    idt[num].selector = 0x08;
    idt[num].zero = 0;
    idt[num].type_attr = flags;
}

void panic(const char* msg) {
    serial_puts("\r\n*** KERNEL PANIC: ");
    serial_puts(msg);
    serial_puts(" ***\r\n");

    if (gfx.fb_addr) {
        gfx_rect(0, 0, (i32)gfx.width, (i32)gfx.height, RGB(0x10, 0x10, 0x60));
        gfx_string(20, 20, "*** ZapczOS V4 PANIC ***", RGB(255, 255, 255), RGB(0,0,0), 0);
        gfx_string(20, 50, msg, RGB(255, 220, 120), RGB(0,0,0), 0);
        gfx_string(20, 80, "The system has halted.", RGB(200, 200, 200), RGB(0,0,0), 0);
        gfx_present();
    }
    __asm__ volatile ("cli");
    for (;;) { __asm__ volatile ("hlt"); }
}

static void exception_panic(int vec) {
    static const char* names[32] = {
        "Divide by zero", "Debug", "NMI", "Breakpoint", "Overflow",
        "Bound range", "Invalid opcode", "Device unavailable",
        "Double fault", "Coprocessor overrun", "Invalid TSS",
        "Segment not present", "Stack fault", "General protection fault",
        "Page fault", "Reserved", "x87 FP exception", "Alignment check",
        "Machine check", "SIMD FP exception", "Virtualization",
        "Control protection", "Reserved", "Reserved", "Reserved",
        "Reserved", "Reserved", "Reserved", "Reserved", "Reserved",
        "Security exception", "Reserved"
    };
    panic(names[vec & 31]);
}

#define EXC(n) \
    __attribute__((interrupt)) static void exc##n(struct interrupt_frame* f) { \
        (void)f; exception_panic(n); \
    }
        EXC(1)  EXC(2)  EXC(3)  EXC(4)  EXC(5)          EXC(7)
EXC(8)  EXC(9)  EXC(10) EXC(11) EXC(12)                 EXC(15)
EXC(16) EXC(17) EXC(18) EXC(19) EXC(20) EXC(21) EXC(22) EXC(23)
EXC(24) EXC(25) EXC(26) EXC(27) EXC(28) EXC(29) EXC(30) EXC(31)

static void try_recover(int vec, u32 eip, u32 addr, u32 err) {
    if (g_guard_active) {
        g_crash_vec = vec;
        g_crash_eip = eip;
        g_crash_addr = addr;
        g_crash_err = err;
        g_guard_active = 0;
        kj_longjmp(g_kj_env, 1);
    }
    exception_panic(vec);
}
__attribute__((interrupt)) static void exc0(struct interrupt_frame* f) { try_recover(0, f->eip, f->eip, 0); }
__attribute__((interrupt)) static void exc6(struct interrupt_frame* f) { try_recover(6, f->eip, f->eip, 0); }
__attribute__((interrupt)) static void exc13(struct interrupt_frame* f, u32 err) { try_recover(13, f->eip, f->eip, err); }
__attribute__((interrupt)) static void exc14(struct interrupt_frame* f, u32 err) {
    u32 cr2; __asm__ volatile("mov %%cr2, %0" : "=r"(cr2));
    try_recover(14, f->eip, cr2, err);
}

void idt_init(void) {
    for (int i = 0; i < 256; i++) idt_set_gate((u8)i, 0, 0);

    void* exc_table[32] = {
        exc0,exc1,exc2,exc3,exc4,exc5,exc6,exc7,exc8,exc9,exc10,exc11,
        exc12,exc13,exc14,exc15,exc16,exc17,exc18,exc19,exc20,exc21,
        exc22,exc23,exc24,exc25,exc26,exc27,exc28,exc29,exc30,exc31
    };
    for (int i = 0; i < 32; i++) idt_set_gate((u8)i, exc_table[i], 0x8E);

    pic_remap();

    idt_set_gate(0x20, timer_irq_handler, 0x8E);
    idt_set_gate(0x21, kbd_irq_handler, 0x8E);
    idt_set_gate(0x2C, mouse_irq_handler, 0x8E);

    idt_ptr.limit = sizeof(idt) - 1;
    idt_ptr.base = (u32)&idt;
    __asm__ volatile ("lidt %0" : : "m"(idt_ptr));

    pit_init(100);

    __asm__ volatile ("sti");
}
