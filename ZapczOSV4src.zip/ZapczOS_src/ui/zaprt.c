#include "zapcc.h"
#include "util.h"
#include "libc_shim.h"
#include "pit.h"
#include "rtc.h"

#define ZRT_LINES   220
#define ZRT_COLS    100
#define ZRT_CANVAS_W 200
#define ZRT_CANVAS_H 120

static char zrt_out[ZRT_LINES][ZRT_COLS];
static int  zrt_nlines;
static int  zrt_col;
static u8   zrt_cv[ZRT_CANVAS_H][ZRT_CANVAS_W][3];
static int  zrt_cv_used;
static u32  zrt_seed = 2463534242u;
static u32  zrt_calls;

static u8   exec_image[ZAP_IMAGE_MAX + 8192];
static char run_err[96];

void zrt_reset(void) {
    zrt_nlines = 0;
    zrt_col = 0;
    zrt_out[0][0] = 0;
    zrt_cv_used = 0;
    zrt_calls = 0;
    for (int y = 0; y < ZRT_CANVAS_H; y++)
        for (int x = 0; x < ZRT_CANVAS_W; x++) {
            zrt_cv[y][x][0] = 16; zrt_cv[y][x][1] = 16; zrt_cv[y][x][2] = 24;
        }
}

int zrt_line_count(void) { return zrt_nlines + (zrt_col > 0 ? 1 : 0); }
const char* zrt_line(int i) {
    if (i < 0 || i >= ZRT_LINES) return "";
    return zrt_out[i];
}
const u8* zrt_canvas(void) { return &zrt_cv[0][0][0]; }
int zrt_canvas_used(void) { return zrt_cv_used; }
int zrt_canvas_w(void) { return ZRT_CANVAS_W; }
int zrt_canvas_h(void) { return ZRT_CANVAS_H; }

static void zrt_newline(void) {
    if (zrt_nlines < ZRT_LINES - 1) {
        zrt_out[zrt_nlines][zrt_col] = 0;
        zrt_nlines++;
        zrt_col = 0;
        zrt_out[zrt_nlines][0] = 0;
    } else {
        zrt_col = 0;
        zrt_out[zrt_nlines][0] = 0;
    }
}

static void zrt_putc(char c) {
    if (c == '\n') { zrt_newline(); return; }
    if (c == '\r') return;
    if (c == '\t') {
        int target = (zrt_col + 4) & ~3;
        while (zrt_col < target && zrt_col < ZRT_COLS - 1) zrt_out[zrt_nlines][zrt_col++] = ' ';
        zrt_out[zrt_nlines][zrt_col] = 0;
        return;
    }
    if (zrt_col >= ZRT_COLS - 1) zrt_newline();
    if (zrt_nlines >= ZRT_LINES - 1) return;
    zrt_out[zrt_nlines][zrt_col++] = c;
    zrt_out[zrt_nlines][zrt_col] = 0;
}

static int zrt_budget(void) {
    zrt_calls++;
    if ((zrt_calls & 0x3FF) == 0) watchdog_heartbeat("zap program");
    return zrt_calls < 4000000u;
}

static void zb_print(const char* s) {
    if (!s || !zrt_budget()) return;
    for (u32 i = 0; i < 4096 && s[i]; i++) zrt_putc(s[i]);
}
static void zb_print_int(int n) {
    if (!zrt_budget()) return;
    char b[16];
    i32_to_str(n, b);
    zb_print(b);
}
static void zb_put_char(int c) { if (zrt_budget()) zrt_putc((char)c); }
static void zb_print_line(const char* s) { zb_print(s); zrt_putc('\n'); }
static void zb_clear(void) { zrt_nlines = 0; zrt_col = 0; zrt_out[0][0] = 0; }
static int  zb_rand(void) {
    zrt_seed ^= zrt_seed << 13;
    zrt_seed ^= zrt_seed >> 17;
    zrt_seed ^= zrt_seed << 5;
    return (int)(zrt_seed & 0x7FFFFFFF);
}
static void zb_srand(int s) { zrt_seed = (u32)s ? (u32)s : 1u; }
static int  zb_ticks(void) { return (int)ticks_get(); }
static void zb_sleep(int ms) {
    if (ms <= 0 || ms > 3000) return;
    u32 start = ticks_get();
    u32 want = (u32)ms / 10;
    while (ticks_get() - start < want) watchdog_heartbeat("zap sleep");
}
static int  zb_strlen(const char* s) { return s ? (int)str_len(s) : 0; }
static int  zb_strcmp(const char* a, const char* b) {
    if (!a || !b) return 0;
    u32 i = 0;
    while (a[i] && a[i] == b[i] && i < 4096) i++;
    return (int)((unsigned char)a[i]) - (int)((unsigned char)b[i]);
}
static void zb_strcpy(char* d, const char* s) {
    if (!d || !s) return;
    u32 i = 0;
    while (s[i] && i < 4095) { d[i] = s[i]; i++; }
    d[i] = 0;
}
static void zb_strcat(char* d, const char* s) {
    if (!d || !s) return;
    u32 dl = str_len(d), i = 0;
    while (s[i] && dl + i < 4095) { d[dl + i] = s[i]; i++; }
    d[dl + i] = 0;
}
static void* zb_memset(void* d, int v, int n) {
    if (!d || n <= 0 || n > 1048576) return d;
    return memset(d, v, (u32)n);
}
static void* zb_memcpy(void* d, const void* s, int n) {
    if (!d || !s || n <= 0 || n > 1048576) return d;
    return memcpy(d, s, (u32)n);
}
static void zb_plot(int x, int y, int r, int g, int b) {
    if (!zrt_budget()) return;
    if (x < 0 || y < 0 || x >= ZRT_CANVAS_W || y >= ZRT_CANVAS_H) return;
    zrt_cv[y][x][0] = (u8)(r < 0 ? 0 : (r > 255 ? 255 : r));
    zrt_cv[y][x][1] = (u8)(g < 0 ? 0 : (g > 255 ? 255 : g));
    zrt_cv[y][x][2] = (u8)(b < 0 ? 0 : (b > 255 ? 255 : b));
    zrt_cv_used = 1;
}
static void zb_canvas_clear(int r, int g, int b) {
    for (int y = 0; y < ZRT_CANVAS_H; y++)
        for (int x = 0; x < ZRT_CANVAS_W; x++) {
            zrt_cv[y][x][0] = (u8)(r & 0xFF);
            zrt_cv[y][x][1] = (u8)(g & 0xFF);
            zrt_cv[y][x][2] = (u8)(b & 0xFF);
        }
    zrt_cv_used = 1;
}
static void zb_canvas_rect(int x, int y, int w, int h, int r, int g, int b) {
    if (w <= 0 || h <= 0 || w > 4096 || h > 4096) return;
    for (int yy = y; yy < y + h; yy++)
        for (int xx = x; xx < x + w; xx++) zb_plot(xx, yy, r, g, b);
}
static int zb_canvas_on(void) { zrt_cv_used = 1; return 1; }
static int zb_abs(int v) { return v < 0 ? -v : v; }
static int zb_min(int a, int b) { return a < b ? a : b; }
static int zb_max(int a, int b) { return a > b ? a : b; }
static int zb_sqrt(int v) {
    if (v <= 0) return 0;
    int x = v, y = (x + 1) / 2;
    while (y < x) { x = y; y = (x + v / x) / 2; }
    return x;
}
static int zb_pow(int b, int e) {
    int r = 1;
    while (e-- > 0) { r *= b; if (r > 1000000000 || r < -1000000000) break; }
    return r;
}

typedef struct { const char* name; void* fn; } zbind_t;

static const zbind_t BINDINGS[] = {
    { "print",        (void*)zb_print },
    { "print_int",    (void*)zb_print_int },
    { "put_char",     (void*)zb_put_char },
    { "print_line",   (void*)zb_print_line },
    { "clear",        (void*)zb_clear },
    { "rand",         (void*)zb_rand },
    { "srand",        (void*)zb_srand },
    { "ticks",        (void*)zb_ticks },
    { "sleep",        (void*)zb_sleep },
    { "strlen",       (void*)zb_strlen },
    { "strcmp",       (void*)zb_strcmp },
    { "strcpy",       (void*)zb_strcpy },
    { "strcat",       (void*)zb_strcat },
    { "memset",       (void*)zb_memset },
    { "memcpy",       (void*)zb_memcpy },
    { "plot",         (void*)zb_plot },
    { "canvas_clear", (void*)zb_canvas_clear },
    { "canvas_rect",  (void*)zb_canvas_rect },
    { "canvas_on",    (void*)zb_canvas_on },
    { "abs",          (void*)zb_abs },
    { "min",          (void*)zb_min },
    { "max",          (void*)zb_max },
    { "sqrt",         (void*)zb_sqrt },
    { "pow",          (void*)zb_pow },
    { 0, 0 }
};

const char* zap_run_error(void) { return run_err; }

int zap_run(const u8* image, u32 size, int* exit_code) {
    run_err[0] = 0;
    if (!image || size < sizeof(zap_header_t)) { str_copy(run_err, "not a .zap file", sizeof(run_err)); return 0; }

    zap_header_t h;
    memcpy(&h, image, sizeof(h));
    if (h.magic != ZAP_MAGIC) { str_copy(run_err, "bad .zap signature", sizeof(run_err)); return 0; }
    if (h.version != ZAP_VERSION) { str_copy(run_err, "unsupported .zap version", sizeof(run_err)); return 0; }

    u32 img_size = h.code_size + h.data_size;
    u32 need = sizeof(h) + img_size + h.nreloc * 4 + h.nimport * sizeof(zap_import_t);
    if (need > size) { str_copy(run_err, "truncated .zap file", sizeof(run_err)); return 0; }
    if (img_size + h.bss_size > ZAP_IMAGE_MAX) { str_copy(run_err, "program image too large", sizeof(run_err)); return 0; }
    if (h.entry >= h.code_size) { str_copy(run_err, "bad entry point", sizeof(run_err)); return 0; }

    for (u32 i = 0; i < ZAP_IMAGE_MAX + 8192; i++) exec_image[i] = 0;
    memcpy(exec_image, image + sizeof(h), img_size);

    u32 base = (u32)(u32*)exec_image;
    const u8* rp = image + sizeof(h) + img_size;

    for (u32 i = 0; i < h.nreloc; i++) {
        u32 off;
        memcpy(&off, rp + i * 4, 4);
        if (off + 4 > img_size) { str_copy(run_err, "bad relocation in .zap", sizeof(run_err)); return 0; }
        u32 v;
        memcpy(&v, exec_image + off, 4);
        v += base;
        memcpy(exec_image + off, &v, 4);
    }

    const u8* ip = rp + h.nreloc * 4;
    for (u32 i = 0; i < h.nimport; i++) {
        zap_import_t im;
        memcpy(&im, ip + i * sizeof(zap_import_t), sizeof(im));
        im.name[19] = 0;
        if (im.slot_off + 4 > h.code_size) { str_copy(run_err, "bad import slot in .zap", sizeof(run_err)); return 0; }
        void* fn = 0;
        for (int k = 0; BINDINGS[k].name; k++) {
            if (str_eq(BINDINGS[k].name, im.name)) { fn = BINDINGS[k].fn; break; }
        }
        if (!fn) {
            str_copy(run_err, "unknown library call: ", sizeof(run_err));
            str_cat(run_err, im.name, sizeof(run_err));
            return 0;
        }
        u32 rel = (u32)fn - (base + im.slot_off + 4);
        memcpy(exec_image + im.slot_off, &rel, 4);
    }

    zrt_calls = 0;
    typedef int (*entry_fn)(void);
    entry_fn e = (entry_fn)(void*)(exec_image + h.entry);
    int rc = e();
    if (exit_code) *exit_code = rc;
    return 1;
}
