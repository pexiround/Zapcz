#ifndef TTT_H
#define TTT_H
#include "io.h"

void ttt_init(void);
void app_ttt_draw(i32 x, i32 y, i32 w, i32 h);
void app_ttt_click(i32 rx, i32 ry);
void app_ttt_key(int key);

#endif
