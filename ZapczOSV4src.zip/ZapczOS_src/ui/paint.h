#ifndef PAINT_H
#define PAINT_H
#include "io.h"

void paint_init(void);
void app_paint_draw(i32 x, i32 y, i32 w, i32 h);
void app_paint_click(i32 rx, i32 ry);
void app_paint_drag(i32 rx, i32 ry);

#endif
