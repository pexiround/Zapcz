#ifndef ZAPCC_H
#define ZAPCC_H
#include "io.h"

#define ZAP_MAGIC   0x5850415Au
#define ZAP_VERSION 1

#define ZAP_CODE_MAX 65536
#define ZAP_DATA_MAX 16384
#define ZAP_IMAGE_MAX (ZAP_CODE_MAX + ZAP_DATA_MAX)

typedef struct {
    u32 magic;
    u32 version;
    u32 code_size;
    u32 data_size;
    u32 bss_size;
    u32 entry;
    u32 nreloc;
    u32 nimport;
} zap_header_t;

typedef struct {
    u32  slot_off;
    char name[20];
} zap_import_t;

int         zapcc_compile(const char* src, u32 len, u8* out, u32 out_max, u32* out_size);
const char* zapcc_error(void);
int         zapcc_error_line(void);
int         zapcc_stat_funcs(void);
int         zapcc_stat_globals(void);
u32         zapcc_stat_code(void);

int         zap_run(const u8* image, u32 size, int* exit_code);
const char* zap_run_error(void);

void        zrt_reset(void);
int         zrt_line_count(void);
const char* zrt_line(int i);
const u8*   zrt_canvas(void);
int         zrt_canvas_used(void);
int         zrt_canvas_w(void);
int         zrt_canvas_h(void);

#endif
