#include "browser.h"
#include "icons.h"
#include "graphics.h"
#include "desktop.h"
#include "theme.h"
#include "util.h"
#include "mouse.h"
#include "pit.h"
#include "logo.h"
#include "keyboard.h"
#include "fat32.h"
#include "png.h"
#include "jpeg.h"
#include "html.h"
#include "libc_shim.h"
#include "scroll.h"
#include "net.h"
#include "http.h"

typedef enum { EL_LOGO, EL_HEADING, EL_TEXT, EL_LINK, EL_SPACE } el_type_t;
typedef struct { el_type_t type; const char* text; const char* dest; } page_el_t;
typedef struct { const char* address; const page_el_t* els; int count; } page_t;

static const page_el_t home_els[] = {
    { EL_LOGO, 0, 0 },
    { EL_HEADING, "Welcome to ZapczNet", 0 },
    { EL_TEXT, "The browser built into ZapczOS, written from scratch.", 0 },
    { EL_TEXT, "No Chromium, no WebKit: the HTML parser, layout, HTTP", 0 },
    { EL_TEXT, "and TLS 1.2 clients are all hand-rolled. Type a domain", 0 },
    { EL_TEXT, "like zapcz.com (no http:// needed) and press Enter.", 0 },
    { EL_SPACE, 0, 0 },
    { EL_HEADING, "zapcz.com -- the project home", 0 },
    { EL_LINK, "zapcz.com (apex, redirects to www)", "https://zapcz.com" },
    { EL_LINK, "www.zapcz.com (Systems Archive)", "https://www.zapcz.com" },
    { EL_LINK, "ZapczOS V2.1 web demo", "https://www.zapcz.com/zapczv2.1.html" },
    { EL_TEXT, "This is the real site, fetched live over Ethernet with", 0 },
    { EL_TEXT, "the from-scratch TLS stack. The apex link exercises", 0 },
    { EL_TEXT, "HTTP redirect following (301 -> www).", 0 },
    { EL_SPACE, 0, 0 },
    { EL_HEADING, "Other real websites", 0 },
    { EL_LINK, "Wikipedia (mobile)", "https://en.m.wikipedia.org/wiki/Operating_system" },
    { EL_LINK, "example.com", "http://example.com" },
    { EL_LINK, "info.cern.ch (first website)", "http://info.cern.ch" },
    { EL_TEXT, "Lighter, text-first pages render best. Heavy or", 0 },
    { EL_TEXT, "video sites (YouTube) won't work -- there's no JS engine.", 0 },
    { EL_SPACE, 0, 0 },
    { EL_LINK, "About this OS", "zapcz://about" },
    { EL_LINK, "Open the App Store", "app:store" },
    { EL_LINK, "Open Settings", "app:settings" },
    { EL_LINK, "Browser help", "zapcz://help" },
};

static const page_el_t about_els[] = {
    { EL_HEADING, "About ZapczOS", 0 },
    { EL_TEXT, "A hobby x86 operating system, written from scratch in C", 0 },
    { EL_TEXT, "and NASM assembly -- bootloader, kernel, drivers, a real", 0 },
    { EL_TEXT, "on-disk FAT32 filesystem, and this whole desktop, apps", 0 },
    { EL_TEXT, "and all.", 0 },
    { EL_SPACE, 0, 0 },
    { EL_TEXT, "Real networking now exists too: a from-scratch Intel", 0 },
    { EL_TEXT, "e1000 Ethernet driver, ARP, IPv4, ICMP, UDP, DHCP, DNS,", 0 },
    { EL_TEXT, "and TCP, with a from-scratch TLS 1.2 client (RSA, AES-128,", 0 },
    { EL_TEXT, "SHA-256, a hand-rolled bignum/X.509 parser) wired into a", 0 },
    { EL_TEXT, "plain-HTTP-and-HTTPS client in this browser.", 0 },
    { EL_SPACE, 0, 0 },
    { EL_LINK, "Back to home", "zapcz://home" },
};

static const page_el_t help_els[] = {
    { EL_HEADING, "Browser Help", 0 },
    { EL_TEXT, "Type an address into the bar above and press Enter, or", 0 },
    { EL_TEXT, "just click any link on a page.", 0 },
    { EL_SPACE, 0, 0 },
    { EL_TEXT, "Known addresses:", 0 },
    { EL_TEXT, "  zapcz://home   -- this browser's start page", 0 },
    { EL_TEXT, "  zapcz://about  -- about ZapczOS", 0 },
    { EL_TEXT, "  zapcz://help   -- this page", 0 },
    { EL_SPACE, 0, 0 },
    { EL_TEXT, "Real sites: type a plain http:// or https:// address", 0 },
    { EL_TEXT, "and press Enter. Needs a network --", 0 },
    { EL_TEXT, "check ifconfig in Terminal if it won't load.", 0 },
    { EL_SPACE, 0, 0 },
    { EL_TEXT, "You can also type a real filename, e.g. PAGE.HTM or", 0 },
    { EL_TEXT, "LOGO.PNG, to open a file you made in Editor or Paint.", 0 },
    { EL_TEXT, "Saving as .html actually lands on disk as .htm (8.3", 0 },
    { EL_TEXT, "filenames can't hold a 4-letter extension) -- typing", 0 },
    { EL_TEXT, "either one here works.", 0 },
    { EL_SPACE, 0, 0 },
    { EL_TEXT, "Three content types are understood, by extension:", 0 },
    { EL_TEXT, "  .htm/.html -- real (small) HTML: headings, links,", 0 },
    { EL_TEXT, "                paragraphs, images, line breaks", 0 },
    { EL_TEXT, "  .md        -- markdown: # headings, - bullet lists,", 0 },
    { EL_TEXT, "                [text](url) links, --- dividers", 0 },
    { EL_TEXT, "  anything else (.txt, etc.) -- shown as plain text,", 0 },
    { EL_TEXT, "                no markup interpreted at all", 0 },
    { EL_SPACE, 0, 0 },
    { EL_LINK, "Back to home", "zapcz://home" },
};

static const page_t pages[] = {
    { "zapcz://home",  home_els,  sizeof(home_els)/sizeof(home_els[0]) },
    { "zapcz://about", about_els, sizeof(about_els)/sizeof(about_els[0]) },
    { "zapcz://help",  help_els,  sizeof(help_els)/sizeof(help_els[0]) },
};
#define PAGE_COUNT (sizeof(pages)/sizeof(pages[0]))

#define HIST_MAX 16
static char hist[HIST_MAX][96];
static int hist_count = 0;
static int hist_pos = -1;
static char addr_buf[96];
static u32 addr_len = 0;

static const page_t* find_page(const char* addr) {
    for (u32 i = 0; i < PAGE_COUNT; i++) if (str_eq_ci(pages[i].address, addr)) return &pages[i];
    return 0;
}

#define LOCAL_BUF_SIZE 262144
#define LOCAL_IMG_MAX 512

static char local_buf[LOCAL_BUF_SIZE];
static int g_loading = 0;
static char g_fetch_host[64];        /* host of the in-flight request, for resolving relative redirects */
static int  g_fetch_tls = 0;
static u16  g_fetch_port = 0;
static int  g_redirects = 0;
#define BROWSER_MAX_REDIRECTS 6
static u32 local_doc_gen = 0;   /* bumped on every new parsed document */
static i32 g_view_top_px = 0, g_view_bot_px = 0;   /* visible band, for culling */
static html_doc_t local_doc;
static int local_kind = 0;
static char local_status[64] = "";
static i32 browser_scroll = 0;
static i32 browser_content_h = 0;
#define WEB_IMG_SLOTS 4
static u8 local_img[WEB_IMG_SLOTS][LOCAL_IMG_MAX][LOCAL_IMG_MAX][3];
static u32 web_img_w[WEB_IMG_SLOTS], web_img_h[WEB_IMG_SLOTS];
static int web_img_el[WEB_IMG_SLOTS];
static int web_img_n = 0;
static int img_hit_el[16], img_hit_n = 0;
static i32 img_hit_x[16], img_hit_y[16], img_hit_w[16], img_hit_h[16];
static char web_img_src[WEB_IMG_SLOTS][128];

static int web_img_slot_for(int el) {
    for (int i = 0; i < web_img_n; i++) if (web_img_el[i] == el) return i;
    return -1;
}
static u8 img_dl_buf[2 * 1024 * 1024];
static int resolve_img_url(const char* src, char* host, u32 hostsz, char* path, u32 pathsz, int* tls, u16* port){
    if(starts_with(src,"http://")||starts_with(src,"https://")){
        int t=starts_with(src,"https://"); const char* p=src+(t?8:7);
        u32 hi=0; while(*p&&*p!='/'&&*p!=':'&&hi<hostsz-1) host[hi++]=*p++; host[hi]=0;
        u16 pt=t?443:80;
        if(*p==':'){p++;u32 pv=0;while(*p>='0'&&*p<='9')pv=pv*10+(u32)(*p++-'0');if(pv>0&&pv<65536)pt=(u16)pv;}
        if(*p=='/') str_copy(path,p,pathsz); else str_copy(path,"/",pathsz);
        *tls=t;*port=pt; return host[0]!=0;
    }
    if(starts_with(src,"//")){
        int t=g_fetch_tls; const char* p=src+2;
        u32 hi=0; while(*p&&*p!='/'&&*p!=':'&&hi<hostsz-1) host[hi++]=*p++; host[hi]=0;
        u16 pt=t?443:80;
        if(*p==':'){p++;u32 pv=0;while(*p>='0'&&*p<='9')pv=pv*10+(u32)(*p++-'0');if(pv>0&&pv<65536)pt=(u16)pv;}
        if(*p=='/') str_copy(path,p,pathsz); else str_copy(path,"/",pathsz);
        *tls=t;*port=pt; return host[0]!=0;
    }
    str_copy(host,g_fetch_host,hostsz); *tls=g_fetch_tls; *port=g_fetch_port;
    if(src[0]=='/') str_copy(path,src,pathsz);
    else { str_copy(path,"/",pathsz); str_cat(path,src,pathsz); }
    return host[0]!=0;
}
static u32 local_img_w = 0, local_img_h = 0;
static int local_img_el = -1;

static int fat32_find_exact(const char* name, fat_dirent_t* out) {
    if (!fat32_available()) return 0;
    fat_dirent_t ents[32];
    int n = fat32_list_root(ents, 32);
    for (int i = 0; i < n; i++) {
        if (str_eq_ci(ents[i].display_name, name)) { *out = ents[i]; return 1; }
    }
    return 0;
}

static int name_ends_with_ci(const char* name, const char* suffix) {
    u32 nlen = str_len(name), slen = str_len(suffix);
    if (nlen < slen) return 0;
    return str_eq_ci(name + (nlen - slen), suffix);
}

static int resolve_local_file(const char* addr, fat_dirent_t* out) {
    if (fat32_find_exact(addr, out)) return 1;
    if (name_ends_with_ci(addr, ".html")) {
        char alt[32];
        u32 base_len = str_len(addr) - 5;
        if (base_len < sizeof(alt) - 4) {
            memcpy(alt, addr, base_len);
            alt[base_len] = 0;
            str_cat(alt, ".htm", 32);
            if (fat32_find_exact(alt, out)) return 1;
        }
    }
    return 0;
}

static i32 content_chars_per_line(void) {
    i32 w = windows[APP_BROWSER].w;
    return (w - 32) / 8;
}

static void load_local(const char* addr) {
    local_kind = 0;
    local_img_el = -1; web_img_n = 0;
    fat_dirent_t ent;
    if (!resolve_local_file(addr, &ent)) {
        str_copy(local_status, "", 64);
        return;
    }

    if (name_ends_with_ci(ent.display_name, ".PNG")) {
        u32 w = 0, h = 0;
        int rc = png_decode_file(ent.display_name, &local_img[0][0][0][0], LOCAL_IMG_MAX, LOCAL_IMG_MAX, &w, &h);
        if (rc == PNG_OK) {
            local_img_w = w; local_img_h = h;
            local_kind = 'I';
        } else {
            str_copy(local_status, png_error_string(rc), 64);
        }
        return;
    }

    int len = fat32_read_file(&ent, (u8*)local_buf, LOCAL_BUF_SIZE - 1);
    if (len < 0) len = 0;
    if (name_ends_with_ci(ent.display_name, ".MD")) {
        md_parse(local_buf, (u32)len, (u32)content_chars_per_line(), &local_doc);
    } else if (name_ends_with_ci(ent.display_name, ".HTM") || name_ends_with_ci(ent.display_name, ".HTML")) {
        html_parse(local_buf, (u32)len, (u32)content_chars_per_line(), &local_doc); local_doc_gen++;
    } else {
        txt_parse(local_buf, (u32)len, (u32)content_chars_per_line(), &local_doc);
    }
    local_kind = 'H';

    for (int i = 0; i < local_doc.count; i++) {
        if (local_doc.els[i].type == HEL_IMG) {
            char src[40];
            html_text(&local_doc, local_doc.els[i].href_off, local_doc.els[i].href_len, src, sizeof(src));
            fat_dirent_t img_ent;
            if (resolve_local_file(src, &img_ent)) {
                u32 w = 0, h = 0;
                if (png_decode_file(img_ent.display_name, &local_img[0][0][0][0],
                                     LOCAL_IMG_MAX, LOCAL_IMG_MAX, &w, &h) == PNG_OK) {
                    local_img_w = w; local_img_h = h;
                    local_img_el = i;
                }
            }
            break;
        }
    }
}

static void load_http(const char* addr) {
    local_kind = 0;
    local_img_el = -1; web_img_n = 0;

    int use_tls = starts_with(addr, "https://");
    const char* p = addr + (use_tls ? 8 : 7);
    char host[64];
    u32 hi = 0;
    while (*p && *p != '/' && *p != ':' && hi < sizeof(host) - 1) host[hi++] = *p++;
    host[hi] = 0;

    u16 port = use_tls ? 443 : 80;
    if (*p == ':') {
        p++;
        u32 pv = 0;
        while (*p >= '0' && *p <= '9') { pv = pv * 10 + (u32)(*p - '0'); p++; }
        if (pv > 0 && pv < 65536) port = (u16)pv;
    }

    char path[64];
    if (*p == '/') str_copy(path, p, sizeof(path));
    else str_copy(path, "/", sizeof(path));
    for (u32 k = 0; path[k]; k++) if (path[k] == '#') { path[k] = 0; break; }

    str_copy(g_fetch_host, host, sizeof(g_fetch_host));
    g_fetch_port = port;
    g_fetch_tls = use_tls;

    if (!net_ready()) {
        str_copy(local_status, "No network connection (check 'ifconfig' in Terminal).", 64);
        return;
    }

    str_copy(local_status, use_tls ? "Connecting (HTTPS)..." : "Connecting...", 64);

    /* Start the transfer and return immediately. browser_tick() drives it a
       slice at a time so the desktop keeps repainting and stays clickable. */
    if (!http_fetch_begin(host, port, path, use_tls, (u8*)local_buf, LOCAL_BUF_SIZE - 1)) {
        http_response_t r;
        http_fetch_finish(&r);
        str_copy(local_status, "Could not load page: ", 64);
        str_cat(local_status, r.error_msg, 64);
        return;
    }
    g_loading = 1;
    str_copy(local_status, "Loading...", 64);
}

/* Follow a Location header. Resolves absolute URLs as-is and host-relative or
   path-relative targets against the host of the request that returned the 3xx,
   so the apex zapcz.com -> www.zapcz.com hop (and any http->https upgrade) is
   transparent. Bounded by BROWSER_MAX_REDIRECTS. */
static void browser_redirect(const char* loc) {
    if (!loc || !loc[0]) { str_copy(local_status, "Redirect had no target", 64); return; }
    if (g_redirects >= BROWSER_MAX_REDIRECTS) { str_copy(local_status, "Too many redirects", 64); return; }
    g_redirects++;

    char url[160];
    if (starts_with(loc, "http://") || starts_with(loc, "https://")) {
        str_copy(url, loc, sizeof(url));
    } else if (loc[0] == '/') {
        str_copy(url, g_fetch_tls ? "https://" : "http://", sizeof(url));
        str_cat(url, g_fetch_host, sizeof(url));
        str_cat(url, loc, sizeof(url));
    } else {
        str_copy(url, g_fetch_tls ? "https://" : "http://", sizeof(url));
        str_cat(url, g_fetch_host, sizeof(url));
        str_cat(url, "/", sizeof(url));
        str_cat(url, loc, sizeof(url));
    }
    str_copy(addr_buf, url, sizeof(addr_buf));
    addr_len = str_len(addr_buf);
    load_http(addr_buf);
}

/* Decide whether a scheme-less address the user typed is a website (fetch over
   https) or a local filename. A '/' or a non-file-extension dotted name means a
   URL; a bare NAME.HTM / NAME.PNG etc. stays a local-file lookup. */
static int looks_like_url(const char* a) {
    int has_dot = 0, has_space = 0, has_slash = 0;
    for (const char* p = a; *p; p++) {
        if (*p == '.') has_dot = 1;
        if (*p == ' ') has_space = 1;
        if (*p == '/') has_slash = 1;
    }
    if (!has_dot || has_space) return 0;
    if (has_slash) return 1;
    if (name_ends_with_ci(a, ".htm") || name_ends_with_ci(a, ".html") ||
        name_ends_with_ci(a, ".md")  || name_ends_with_ci(a, ".png")  ||
        name_ends_with_ci(a, ".txt")) return 0;
    return 1;
}

/* Called once per frame from the desktop loop. */
int browser_doc_count(void) { return local_doc.count; }

void browser_tick(void) {
    if (!g_loading) return;

    int st = http_fetch_pump();

    /* progress line, so a long download visibly moves */
    {
        u32 got = http_fetch_bytes();
        char nb[12];
        str_copy(local_status, "Loading... ", 64);
        u32_to_str(got / 1024, nb);
        str_cat(local_status, nb, 64);
        str_cat(local_status, " KB", 64);
    }

    if (st == 1) return;              /* still receiving */

    g_loading = 0;
    http_response_t resp;
    if (!http_fetch_finish(&resp)) {
        str_copy(local_status, "Could not load page: ", 64);
        str_cat(local_status, resp.error_msg, 64);
        return;
    }
    if (resp.status_code >= 300 && resp.status_code < 400 && resp.location[0]) {
        browser_redirect(resp.location);
        return;
    }
    if (resp.status_code != 200) {
        char nbuf[12];
        str_copy(local_status, "Server responded with status ", 64);
        u32_to_str((u32)resp.status_code, nbuf);
        str_cat(local_status, nbuf, 64);
        return;
    }

    u32 len = resp.body_len;
    if (len >= LOCAL_BUF_SIZE) len = LOCAL_BUF_SIZE - 1;
    local_buf[len] = 0;

    int is_html = 0;
    for (u32 i = 0; resp.content_type[i]; i++) {
        if (resp.content_type[i] == 'h' && starts_with(resp.content_type + i, "html")) { is_html = 1; break; }
    }
    if (is_html) { html_parse(local_buf, len, (u32)content_chars_per_line(), &local_doc); local_doc_gen++; }
    else { txt_parse(local_buf, len, (u32)content_chars_per_line(), &local_doc); local_doc_gen++; }
    local_kind = 'H';
    local_img_el = -1; web_img_n = 0;
    for (int ii = 0; ii < local_doc.count; ii++) {
        if (local_doc.els[ii].type == HEL_IMG) {
            char isrc[128];
            html_text(&local_doc, local_doc.els[ii].href_off, local_doc.els[ii].href_len, isrc, sizeof(isrc));
            char ihost[64], ipath[96]; int itls; u16 iport;
            if (resolve_img_url(isrc, ihost, sizeof(ihost), ipath, sizeof(ipath), &itls, &iport)) {
                http_response_t ir;
                int got = 0;
                for (int hop = 0; hop < 3 && !got; hop++) {
                    if (http_get(ihost, iport, ipath, itls, img_dl_buf, sizeof(img_dl_buf), &ir) <= 0) break;
                    if (ir.status_code >= 300 && ir.status_code < 400 && ir.location[0]) {
                        char nh[64], np[96]; int nt; u16 npo;
                        if (!resolve_img_url(ir.location, nh, sizeof(nh), np, sizeof(np), &nt, &npo)) break;
                        str_copy(ihost, nh, sizeof(ihost));
                        str_copy(ipath, np, sizeof(ipath));
                        itls = nt; iport = npo;
                        continue;
                    }
                    if (ir.status_code != 200) break;
                    got = 1;
                }
                if (got && web_img_n < WEB_IMG_SLOTS) {
                    u32 iw = 0, ih = 0;
                    int slot = web_img_n;
                    u8* dst = &local_img[slot][0][0][0];
                    int ok = 0;
                    if (png_decode_mem(img_dl_buf, ir.body_len, dst, LOCAL_IMG_MAX, LOCAL_IMG_MAX, &iw, &ih) == PNG_OK) ok = 1;
                    else if (jpeg_decode_mem(img_dl_buf, ir.body_len, dst, LOCAL_IMG_MAX, LOCAL_IMG_MAX, &iw, &ih) == JPEG_OK) ok = 1;
                    if (ok) {
                        web_img_w[slot] = iw; web_img_h[slot] = ih; web_img_el[slot] = ii;
                        str_copy(web_img_src[slot], isrc, 128);
                        web_img_n++;
                        if (local_img_el < 0) { local_img_w = iw; local_img_h = ih; local_img_el = ii; }
                    }
                }
            }
            if (web_img_n >= WEB_IMG_SLOTS) break;
        }
    }
    str_copy(local_status, "", 64);
}

void browser_cancel_load(void) {
    if (!g_loading) return;
    http_fetch_abort();
    g_loading = 0;
    str_copy(local_status, "Load cancelled.", 64);
}
int browser_is_loading(void) { return g_loading; }

static void push_history(const char* addr) {
    hist_count = hist_pos + 1;
    if (hist_count >= HIST_MAX) {
        for (int i = 1; i < HIST_MAX; i++) str_copy(hist[i - 1], hist[i], 96);
        hist_count = HIST_MAX - 1;
        hist_pos = HIST_MAX - 2;
    }
    str_copy(hist[hist_count], addr, 96);
    hist_count++;
    hist_pos = hist_count - 1;
}

static void resolve_current_address(void) {
    browser_scroll = 0;
    g_redirects = 0;
    if (find_page(addr_buf)) {
        local_kind = 0;
    } else if (starts_with(addr_buf, "http://") || starts_with(addr_buf, "https://")) {
        load_http(addr_buf);
    } else if (looks_like_url(addr_buf)) {
        /* Bare domain, e.g. "zapcz.com" -- fetch it over https. */
        char url[128];
        str_copy(url, "https://", sizeof(url));
        str_cat(url, addr_buf, sizeof(url));
        str_copy(addr_buf, url, sizeof(addr_buf));
        addr_len = str_len(addr_buf);
        load_http(addr_buf);
    } else {
        load_local(addr_buf);
    }
}

static int g_anchor_el = -1;
static i32 g_anchor_y = -1;
static i32 scroll_to_anchor(const char* url);
static int url_has_scheme(const char* s) {
    for (u32 i = 0; s[i]; i++) {
        if (s[i] == ':') return 1;
        if (s[i] == '/' || s[i] == '#' || s[i] == '?') return 0;
    }
    return 0;
}
static u32 url_after_scheme(const char* u) {
    for (u32 i = 0; u[i]; i++) {
        if (u[i] == ':' && u[i+1] == '/' && u[i+2] == '/') return i + 3;
        if (u[i] == '/' || u[i] == '#' || u[i] == '?') return 0;
    }
    return 0;
}
static void resolve_link(const char* href, const char* base, char* out, u32 outsz) {
    if (!href[0]) { str_copy(out, base, outsz); return; }
    if (url_has_scheme(href)) { str_copy(out, href, outsz); return; }
    u32 bscheme = url_after_scheme(base);
    if (bscheme == 0) { str_copy(out, href, outsz); return; }
    u32 bhostend = bscheme;
    while (base[bhostend] && base[bhostend] != '/' && base[bhostend] != '#' && base[bhostend] != '?') bhostend++;
    u32 o = 0;
    if (href[0] == '/' && href[1] == '/') {
        for (u32 i = 0; i + 1 < bscheme && o + 1 < outsz; i++) out[o++] = base[i];
        out[o] = 0; str_cat(out, href, outsz); return;
    }
    if (href[0] == '#') {
        for (u32 i = 0; base[i] && base[i] != '#' && o + 1 < outsz; i++) out[o++] = base[i];
        out[o] = 0; str_cat(out, href, outsz); return;
    }
    if (href[0] == '/') {
        for (u32 i = 0; i < bhostend && o + 1 < outsz; i++) out[o++] = base[i];
        out[o] = 0; str_cat(out, href, outsz); return;
    }
    u32 cut = bhostend;
    for (u32 i = bhostend; base[i] && base[i] != '#' && base[i] != '?'; i++) if (base[i] == '/') cut = i + 1;
    if (cut == bhostend) {
        for (u32 i = 0; i < bhostend && o + 1 < outsz; i++) out[o++] = base[i];
        if (o + 1 < outsz) out[o++] = '/';
    } else {
        for (u32 i = 0; i < cut && o + 1 < outsz; i++) out[o++] = base[i];
    }
    out[o] = 0; str_cat(out, href, outsz);
}
static int same_page_frag(const char* a, const char* b) {
    u32 i = 0;
    while (a[i] && a[i] != '#' && b[i] && b[i] != '#') { if (a[i] != b[i]) return 0; i++; }
    int aend = (a[i] == 0 || a[i] == '#');
    int bend = (b[i] == 0 || b[i] == '#');
    return aend && bend;
}
static void navigate(const char* addr) {
    push_history(addr);
    str_copy(addr_buf, addr, 96);
    addr_len = str_len(addr_buf);
    resolve_current_address();
}

static void go_back(void) {
    if (hist_pos <= 0) return;
    hist_pos--;
    str_copy(addr_buf, hist[hist_pos], 96);
    addr_len = str_len(addr_buf);
    resolve_current_address();
}
static void go_forward(void) {
    if (hist_pos >= hist_count - 1) return;
    hist_pos++;
    str_copy(addr_buf, hist[hist_pos], 96);
    addr_len = str_len(addr_buf);
    resolve_current_address();
}

static void browser_download(const char* src);

static int url_is_download(const char* u) {
    static const char* exts[] = { ".zip", ".iso", ".img", ".exe", ".tar", ".gz", ".bin", ".pdf", 0 };
    u32 n = str_len(u);
    for (int i = 0; exts[i]; i++) {
        u32 e = str_len(exts[i]);
        if (n <= e) continue;
        const char* tail = u + (n - e);
        int same = 1;
        for (u32 k = 0; k < e; k++) {
            char a = tail[k], b = exts[i][k];
            if (a >= 'A' && a <= 'Z') a = (char)(a - 'A' + 'a');
            if (a != b) { same = 0; break; }
        }
        if (same) return 1;
    }
    return 0;
}

static void browser_follow(const char* dest) {
    if (starts_with(dest, "app:")) {
        if (str_eq_ci(dest + 4, "store")) desktop_open_app(APP_STORE);
        else if (str_eq_ci(dest + 4, "settings")) desktop_open_app(APP_SETTINGS);
        return;
    }
    if (url_is_download(dest)) { browser_download(dest); return; }
    navigate(dest);
}
static void follow_link(const char* href) {
    char resolved[96];
    resolve_link(href, addr_buf, resolved, sizeof(resolved));
    if (url_after_scheme(resolved) && same_page_frag(resolved, addr_buf)) {
        push_history(resolved);
        str_copy(addr_buf, resolved, 96);
        addr_len = str_len(addr_buf);
        browser_scroll = scroll_to_anchor(resolved);
        return;
    }
    browser_follow(resolved);
}

void browser_init(void) {
    hist_count = 0;
    hist_pos = -1;
    navigate("zapcz://home");
}

#define CONTENT_X 16
#define CONTENT_TOP 60

static const char* layout_page(i32 x, i32 y, const page_t* p, int do_draw, i32 hit_rx, i32 hit_ry,
                                i32 scroll_off, i32* out_h) {
    i32 cx = x + CONTENT_X;
    i32 cy = y + CONTENT_TOP;
    const char* hit = 0;
    for (int i = 0; i < p->count; i++) {
        const page_el_t* e = &p->els[i];
        i32 dy = cy - scroll_off;
        switch (e->type) {
            case EL_LOGO: {
                i32 scale = 2;
                if (do_draw) {
                    logo_draw_ex(cx, dy, LOGO_W * scale, LOGO_H_ * scale, THEME_PANEL, 1);
                }
                cy += LOGO_H_ * scale + 12;
                break;
            }
            case EL_HEADING:
                if (do_draw) gfx_string(cx, dy, e->text, THEME_TEXT, THEME_PANEL, 0);
                cy += 28;
                break;
            case EL_TEXT:
                if (do_draw) gfx_string(cx, dy, e->text, THEME_TEXT_DIM, THEME_PANEL, 0);
                cy += 18;
                break;
            case EL_LINK: {
                char buf[80] = "-> ";
                str_cat(buf, e->text, 80);
                i32 tw = gfx_string_width(buf);
                if (do_draw) {

                    int hot = ui_point_in(mouse_x(), mouse_y(), cx, dy, tw, 18);
                    gfx_string(cx, dy, buf, THEME_ACCENT, THEME_PANEL, 0);
                    if (hot) gfx_hline(cx, dy + 17, tw, THEME_ACCENT);
                }
                if (hit_rx >= 0 && hit_ry >= dy && hit_ry < dy + 18 &&
                    hit_rx >= cx && hit_rx < cx + tw) {
                    hit = e->dest;
                }
                cy += 22;
                break;
            }
            case EL_SPACE:
                cy += 12;
                break;
        }
    }
    if (out_h) *out_h = cy - (y + CONTENT_TOP);
    return hit;
}

static char link_dest_buf[128];

static int el_scale(const html_el_t* e) {
    if (e->fsize == HFS_XLARGE) return 3;
    if (e->fsize == HFS_LARGE) return 2;
    return 1;
}
static i32 el_line_h(const html_el_t* e) {
    int sc = el_scale(e);
    if (sc == 3) return 44;
    if (sc == 2) return 30;
    return (e->fsize == HFS_SMALL) ? 16 : 18;
}
static i32 el_text_w(const html_el_t* e, const char* txt) {
    int sc = el_scale(e);
    return (sc > 1) ? gfx_string_width_scaled(txt, sc) : gfx_string_width(txt);
}
static void el_draw_text(const html_el_t* e, i32 x, i32 y, const char* txt, color_t col) {
    int sc = el_scale(e);
    if (sc > 1) gfx_string_scaled(x, y, txt, col, sc);
    else gfx_string(x, y, txt, col, RGB(0,0,0), 0);
    i32 tw = el_text_w(e, txt);
    i32 base = y + (sc > 1 ? (sc == 3 ? 34 : 24) : 15);
    if (e->underline) gfx_hline(x, base, tw, col);
    if (e->strike) gfx_hline(x, y + (sc > 1 ? (sc == 3 ? 18 : 13) : 8), tw, col);
}
static i32 el_start_x(const html_el_t* e, i32 cx, i32 x, i32 w, i32 tw) {
    i32 ix = cx + (i32)e->indent * 18;
    if (e->align == HAL_CENTER) {
        i32 c = x + (w - tw) / 2;
        return c > ix ? c : ix;
    }
    if (e->align == HAL_RIGHT) {
        i32 r = x + w - CONTENT_X - tw;
        return r > ix ? r : ix;
    }
    return ix;
}

static const char* html_layout(i32 x, i32 y, i32 w, int do_draw, i32 hit_rx, i32 hit_ry,
                                i32 scroll_off, i32* out_h) {
    i32 cx = x + CONTENT_X;
    i32 cy = y + CONTENT_TOP;
    const char* hit = 0;
    char buf[220];
    if (do_draw) img_hit_n = 0;
    for (int i = 0; i < local_doc.count; i++) {
        const html_el_t* e = &local_doc.els[i];
        if (i == g_anchor_el) g_anchor_y = cy;
        if (e->hidden) continue;
        i32 dy = cy - scroll_off;

        /* Large pages have thousands of elements. When drawing, everything
           below the viewport is unreachable, so stop; anything above it still
           has to advance cy but needs no text extraction or drawing. */
        int vis = (dy > g_view_top_px - 80) && (dy < g_view_bot_px + 40);
        if (do_draw && dy > g_view_bot_px + 40) break;
        int want_text = vis || (hit_rx >= 0);
        int draw_now = do_draw && vis;

        if (draw_now && (e->bg_r || e->bg_g || e->bg_b)) {
            i32 eh = (e->type == HEL_HEADING) ? ((e->heading <= 2) ? 42 : 22)
                   : (e->type == HEL_GAP) ? ((e->text_len > 1) ? (i32)(e->text_len * 10) : 10)
                   : 20;
            gfx_rect(x, dy - 2, w, eh, RGB(e->bg_r, e->bg_g, e->bg_b));
        }

        switch (e->type) {
            case HEL_HEADING: {
                if (want_text) html_text(&local_doc, e->text_off, e->text_len, buf, sizeof(buf));
                else buf[0] = 0;
                color_t hcol = RGB(e->fg_r ? e->fg_r : 22, e->fg_g ? e->fg_g : 32, e->fg_b ? e->fg_b : 78);
                int hs = el_scale(e);
                if (hs == 1 && e->heading <= 2) hs = 2;
                i32 tw = (hs > 1) ? gfx_string_width_scaled(buf, hs) : gfx_string_width(buf);
                i32 tx = el_start_x(e, cx, x, w, tw);
                if (draw_now) {
                    if (hs > 1) {
                        gfx_string_scaled(tx, dy, buf, hcol, hs);
                        gfx_hline(tx, dy + (hs == 3 ? 46 : 34), tw + 4, RGB(206,211,224));
                    } else {
                        gfx_string(tx, dy, buf, hcol, RGB(0,0,0), 0);
                    }
                    if (e->underline) gfx_hline(tx, dy + (hs > 1 ? (hs == 3 ? 40 : 28) : 15), tw, hcol);
                }
                cy += (hs == 3) ? 56 : (hs == 2) ? 44 : 22;
                break;
            }
            case HEL_TEXT: {
                if (want_text) html_text(&local_doc, e->text_off, e->text_len, buf, sizeof(buf));
                else buf[0] = 0;
                color_t tcol = e->fg_r || e->fg_g || e->fg_b ?
                    RGB(e->fg_r, e->fg_g, e->fg_b) : RGB(38,40,48);
                i32 tw = el_text_w(e, buf);
                i32 tx = el_start_x(e, cx, x, w, tw);
                if (draw_now) {
                    if (e->is_pre) {
                        gfx_rect(cx - 4, dy - 2, w - CONTENT_X * 2 + 8, 20, RGB(14,12,28));
                        gfx_string(cx, dy, buf, RGB(160, 220, 150), RGB(0,0,0), 0);
                    } else {
                        if (e->bullet) {
                            i32 bx = tx - 12;
                            if (bx < x + 4) bx = x + 4;
                            gfx_circle_fill(bx, dy + 8, 2, tcol);
                        }
                        el_draw_text(e, tx, dy, buf, tcol);
                    }
                }
                cy += e->is_pre ? 18 : el_line_h(e);
                break;
            }
            case HEL_LINK: {
                if (want_text) html_text(&local_doc, e->text_off, e->text_len, buf, sizeof(buf));
                else buf[0] = 0;
                color_t lcol = e->fg_r || e->fg_g || e->fg_b ?
                    RGB(e->fg_r, e->fg_g, e->fg_b) : RGB(29,78,216);
                i32 tw = el_text_w(e, buf);
                i32 tx = el_start_x(e, cx, x, w, tw);
                if (draw_now) {
                    int hot = ui_point_in(mouse_x(), mouse_y(), tx, dy, tw, el_line_h(e));
                    color_t lc2 = hot ? RGB(90,140,240) : lcol;
                    int sc = el_scale(e);
                    if (sc > 1) gfx_string_scaled(tx, dy, buf, lc2, sc);
                    else gfx_string(tx, dy, buf, lc2, RGB(0,0,0), 0);
                    if (!e->strike) gfx_hline(tx, dy + (sc > 1 ? (sc == 3 ? 40 : 28) : 17), tw, lc2);
                    else gfx_hline(tx, dy + 8, tw, lc2);
                }
                if (hit_rx >= 0 && hit_ry >= dy && hit_ry < dy + el_line_h(e) &&
                    hit_rx >= tx && hit_rx < tx + tw) {
                    html_text(&local_doc, e->href_off, e->href_len, link_dest_buf, sizeof(link_dest_buf));
                    hit = link_dest_buf;
                }
                cy += el_line_h(e) + 2;
                break;
            }
            case HEL_HR:
                if (draw_now) {
                    gfx_glass_rect(cx, dy + 4, w - CONTENT_X * 2, 1, RGB(120,100,200), 60);
                    gfx_hline(cx, dy + 4, w - CONTENT_X * 2, RGB(60,50,100));
                }
                cy += 16;
                break;
            case HEL_GAP:
                cy += (e->text_len > 1) ? (i32)(e->text_len * 10) : 10;
                break;
            case HEL_IMG: {
                int slot = web_img_slot_for(i);
                if (slot < 0 && i == local_img_el && local_img_w > 0) slot = 0;
                u32 iw = (slot >= 0) ? (web_img_n ? web_img_w[slot] : local_img_w) : 0;
                u32 ih = (slot >= 0) ? (web_img_n ? web_img_h[slot] : local_img_h) : 0;
                if (slot >= 0 && iw > 0 && ih > 0) {
                    i32 max_w = w - CONTENT_X * 2;
                    if (max_w > LOCAL_IMG_MAX) max_w = LOCAL_IMG_MAX;
                    i32 dw = (i32)iw, dh = (i32)ih;
                    if (dw > max_w) { dh = dh * max_w / dw; dw = max_w; }
                    if (do_draw) {
                        for (i32 py = 0; py < dh; py++) {
                            u32 sy = (u32)py * ih / (u32)dh;
                            for (i32 px = 0; px < dw; px++) {
                                u32 sx = (u32)px * iw / (u32)dw;
                                color_t c = RGB(local_img[slot][sy][sx][0], local_img[slot][sy][sx][1], local_img[slot][sy][sx][2]);
                                gfx_pixel(cx + px, dy + py, c);
                            }
                        }
                    }
                    if (do_draw && img_hit_n < 15) {
                        img_hit_el[img_hit_n] = i;
                        img_hit_x[img_hit_n] = cx; img_hit_y[img_hit_n] = dy;
                        img_hit_w[img_hit_n] = dw; img_hit_h[img_hit_n] = dh;
                        img_hit_n++;
                    }
                    cy += dh + 12;
                } else {
                    if (do_draw) gfx_string(cx, dy, "[image]", THEME_TEXT_FAINT, THEME_PANEL, 0);
                    cy += 18;
                }
            }
                break;
        }
    }
    if (out_h) *out_h = cy - (y + CONTENT_TOP);
    return hit;
}

static i32 scroll_to_anchor(const char* url) {
    const char* frag = 0;
    for (u32 i = 0; url[i]; i++) if (url[i] == '#') { frag = url + i + 1; break; }
    if (!frag || !frag[0] || local_kind != 'H') return 0;
    int el = html_anchor_el(&local_doc, frag);
    if (el < 0) return 0;
    i32 wx = windows[APP_BROWSER].x, wy = windows[APP_BROWSER].y, ww = windows[APP_BROWSER].w;
    i32 dummy = 0;
    g_anchor_el = el; g_anchor_y = -1;
    html_layout(wx, wy, ww, 0, -1, -1, 0, &dummy);
    g_anchor_el = -1;
    if (g_anchor_y < 0) return 0;
    i32 target = g_anchor_y - (wy + CONTENT_TOP);
    return target < 0 ? 0 : target;
}

#define BACK_X 12
#define FWD_X  48
#define HOME_X 84
#define HOME_W 56
#define NAV_BTN_W 32
#define NAV_BTN_H 28
#define GO_W 50
#define ADDR_X 148
#define BAR_Y 10


static int priv_panel_open = 0;

static void priv_panel_geom(i32 x, i32 y, i32 w, i32 h, i32* px, i32* py, i32* pw, i32* ph) {
    *pw = 340; *ph = 186;
    *px = x + w - *pw - 16;
    *py = y + BAR_Y + 34;
    (void)h;
}

static void priv_toggle_row(i32 tx, i32 ty, int on, const char* label, const char* sub) {
    gfx_rounded_rect(tx, ty, 34, 18, 9, on ? THEME_ACCENT : THEME_INPUT);
    gfx_rounded_rect_outline(tx, ty, 34, 18, 9, on ? THEME_ACCENT : THEME_BORDER);
    gfx_circle_fill(on ? tx + 25 : tx + 9, ty + 9, 6, RGB(255,255,255));
    gfx_string(tx + 44, ty + 1, label, THEME_TEXT, THEME_PANEL, 0);
    if (sub) gfx_string(tx + 44, ty + 17, sub, THEME_TEXT_FAINT, THEME_PANEL, 0);
}

static void priv_panel_draw(i32 x, i32 y, i32 w, i32 h) {
    if (!priv_panel_open) return;
    i32 px, py, pw, ph;
    priv_panel_geom(x, y, w, h, &px, &py, &pw, &ph);
    gfx_rect(px + 4, py + 5, pw, ph, RGB(0,0,0));
    gfx_rounded_rect(px, py, pw, ph, 8, THEME_PANEL);
    gfx_rounded_rect_outline(px, py, pw, ph, 8, THEME_ACCENT);
    gfx_string(px + 14, py + 10, "Privacy", THEME_TEXT, THEME_PANEL, 0);

    int uam = http_get_ua_mode();
    gfx_string(px + 14, py + 34, "Identify as:", THEME_TEXT_DIM, THEME_PANEL, 0);
    ui_button(px + 14,  py + 52, 96, 24, "ZapczOS", uam == 0);
    ui_button(px + 116, py + 52, 96, 24, "Firefox", uam == 1);
    ui_button(px + 218, py + 52, 96, 24, "Nothing", uam == 2);

    priv_toggle_row(px + 14, py + 92, http_get_dnt(), "Send Do-Not-Track", "asks sites not to track you");
    gfx_string(px + 14, py + 132, "Your IP is always visible to sites.", THEME_TEXT_FAINT, THEME_PANEL, 0);
    gfx_string(px + 14, py + 148, "Hiding it needs a VPN/proxy, not a", THEME_TEXT_FAINT, THEME_PANEL, 0);
    gfx_string(px + 14, py + 164, "browser setting.", THEME_TEXT_FAINT, THEME_PANEL, 0);
}

static int priv_panel_click(i32 x, i32 y, i32 w, i32 h, i32 mx, i32 my) {
    if (!priv_panel_open) return 0;
    i32 px, py, pw, ph;
    priv_panel_geom(x, y, w, h, &px, &py, &pw, &ph);
    if (ui_point_in(mx, my, px + 14,  py + 52, 96, 24)) { http_set_privacy(0, http_get_dnt()); return 1; }
    if (ui_point_in(mx, my, px + 116, py + 52, 96, 24)) { http_set_privacy(1, http_get_dnt()); return 1; }
    if (ui_point_in(mx, my, px + 218, py + 52, 96, 24)) { http_set_privacy(2, http_get_dnt()); return 1; }
    if (ui_point_in(mx, my, px + 14,  py + 92, 240, 20)) { http_set_privacy(http_get_ua_mode(), !http_get_dnt()); return 1; }
    if (!ui_point_in(mx, my, px, py, pw, ph)) { priv_panel_open = 0; return 1; }
    return 1;
}


static char dl_status[80] = "";
static u32 dl_status_tick = 0;

static void url_basename(const char* url, char* out, u32 cap) {
    const char* last = url;
    for (const char* q = url; *q; q++) if (*q == '/') last = q + 1;
    u32 i = 0;
    for (; last[i] && i + 1 < cap && last[i] != '?' && last[i] != '#'; i++) out[i] = last[i];
    out[i] = 0;
    if (i == 0) str_copy(out, "download.bin", cap);
}

static void fat_safe_name(const char* in, char* out) {
    int j = 0;
    int dot = -1;
    for (int i = 0; in[i]; i++) if (in[i] == '.') dot = i;
    for (int i = 0; in[i] && j < 8; i++) {
        if (dot >= 0 && i >= dot) break;
        char c = in[i];
        if (c >= 'a' && c <= 'z') c = (char)(c - 'a' + 'A');
        if ((c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9')) out[j++] = c;
    }
    if (j == 0) { out[j++] = 'D'; out[j++] = 'L'; }
    out[j++] = '.';
    int k = 0;
    if (dot >= 0) {
        for (int i = dot + 1; in[i] && k < 3; i++) {
            char c = in[i];
            if (c >= 'a' && c <= 'z') c = (char)(c - 'a' + 'A');
            if ((c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9')) out[j++] = c, k++;
        }
    }
    if (k == 0) { out[j++] = 'B'; out[j++] = 'I'; out[j++] = 'N'; }
    out[j] = 0;
}

static void browser_download(const char* src) {
    char ihost[80], ipath[160]; int itls; u16 iport;
    if (!resolve_img_url(src, ihost, sizeof(ihost), ipath, sizeof(ipath), &itls, &iport)) {
        str_copy(dl_status, "Download: bad URL", 80); dl_status_tick = ticks_get(); return;
    }
    http_response_t ir;
    int got = 0;
    for (int hop = 0; hop < 3 && !got; hop++) {
        if (http_get(ihost, iport, ipath, itls, img_dl_buf, sizeof(img_dl_buf), &ir) <= 0) break;
        if (ir.status_code >= 300 && ir.status_code < 400 && ir.location[0]) {
            char nh[80], np[160]; int nt; u16 npo;
            if (!resolve_img_url(ir.location, nh, sizeof(nh), np, sizeof(np), &nt, &npo)) break;
            str_copy(ihost, nh, sizeof(ihost)); str_copy(ipath, np, sizeof(ipath));
            itls = nt; iport = npo;
            continue;
        }
        if (ir.status_code != 200) break;
        got = 1;
    }
    if (!got) { str_copy(dl_status, "Download failed", 80); dl_status_tick = ticks_get(); return; }

    char base[64], fname[16];
    url_basename(ipath, base, sizeof(base));
    fat_safe_name(base, fname);
    if (fat32_write_file(fname, img_dl_buf, ir.body_len)) {
        str_copy(dl_status, "Saved ", 80); str_cat(dl_status, fname, 80);
        char nb[12]; u32_to_str(ir.body_len / 1024, nb);
        str_cat(dl_status, " (", 80); str_cat(dl_status, nb, 80); str_cat(dl_status, " KB)", 80);
    } else {
        str_copy(dl_status, "Could not save (disk full or read-only)", 80);
    }
    dl_status_tick = ticks_get();
}

void app_browser_rclick(i32 rx, i32 ry) {
    i32 wx = windows[APP_BROWSER].x, wy = windows[APP_BROWSER].y;
    for (int i = 0; i < img_hit_n; i++) {
        if (rx + wx >= img_hit_x[i] && rx + wx < img_hit_x[i] + img_hit_w[i] &&
            ry + wy >= img_hit_y[i] && ry + wy < img_hit_y[i] + img_hit_h[i]) {
            int slot = web_img_slot_for(img_hit_el[i]);
            if (slot >= 0) { browser_download(web_img_src[slot]); return; }
        }
    }
    str_copy(dl_status, "Right-click an image to save it", 80);
    dl_status_tick = ticks_get();
}

void app_browser_draw(i32 x, i32 y, i32 w, i32 h) {
    i32 by = y + BAR_Y;

    ui_button(x + BACK_X, by, NAV_BTN_W, NAV_BTN_H, "<", 0);
    ui_button(x + FWD_X, by, NAV_BTN_W, NAV_BTN_H, ">", 0);
    ui_button(x + HOME_X, by, HOME_W, NAV_BTN_H, "Home", 0);

    i32 priv_x = x + w - 12 - 74;
    i32 go_x = priv_x - 6 - GO_W;
    i32 addr_x = x + ADDR_X;
    i32 addr_w = go_x - 8 - addr_x;
    color_t field_bg = RGB(14, 15, 20);
    gfx_rounded_rect(addr_x, by, addr_w, 28, THEME_RADIUS_CTRL, field_bg);
    gfx_rounded_rect_outline(addr_x, by, addr_w, 28, THEME_RADIUS_CTRL, THEME_BORDER);

    char shown[40];
    str_copy(shown, addr_buf, 40);
    if ((ticks_get() / 30) % 2 == 0 && str_len(shown) < 38) str_cat(shown, "_", 40);
    gfx_string(addr_x + 8, by + (28 - 16) / 2, shown, THEME_TEXT, field_bg, 0);

    /* While a page is downloading the button becomes Stop, so a slow site can
       be abandoned instead of waiting it out. */
    ui_button(go_x, by, GO_W, 28, g_loading ? "Stop" : "Go", 1);
    ui_button(priv_x, by, 74, 28, "Privacy", priv_panel_open);

    gfx_hline(x + 12, by + 38, w - 24, THEME_BORDER);

    i32 view_top = y + CONTENT_TOP;
    i32 view_h = (y + h - 24) - view_top;
    i32 content_h = 0;
    clip_t content_clip = { x, view_top, x + w, y + h - 24 };
    gfx_set_clip(content_clip);

    const page_t* p = find_page(addr_buf);
    if (p) {
        layout_page(x, y, p, 0, -1, -1, 0, &content_h);
        browser_scroll = scroll_clamp(browser_scroll, content_h, view_h);
        layout_page(x, y, p, 1, -1, -1, browser_scroll, 0);
    } else if (local_kind == 'H') {
        g_view_top_px = view_top;
        g_view_bot_px = y + h - 24;
        { u8 pr,pg,pb; int pgr; u8 a1,b1,c1,a2,b2,c2;
          html_page_bg(&pr,&pg,&pb,&pgr,&a1,&b1,&c1,&a2,&b2,&c2);
          if (pgr) gfx_gradient_v(x, view_top, w, (y + h - 24) - view_top, RGB(a1,b1,c1), RGB(a2,b2,c2));
          else gfx_rect(x, view_top, w, (y + h - 24) - view_top, RGB(pr,pg,pb)); }
        static i32 cached_h = 0;
        static i32 cached_w = -1;
        static u32 cached_gen = 0xFFFFFFFFu;
        if (cached_w != w || cached_gen != local_doc_gen) {
            html_layout(x, y, w, 0, -1, -1, 0, &cached_h);
            cached_w = w;
            cached_gen = local_doc_gen;
        }
        content_h = cached_h;
        browser_scroll = scroll_clamp(browser_scroll, content_h, view_h);
        html_layout(x, y, w, 1, -1, -1, browser_scroll, 0);
    } else if (local_kind == 'I') {
        i32 max_w = w - CONTENT_X * 2;
        if (max_w > LOCAL_IMG_MAX) max_w = LOCAL_IMG_MAX;
        i32 dw = (i32)local_img_w, dh = (i32)local_img_h;
        if (dw > max_w) { dh = dh * max_w / dw; dw = max_w; }
        content_h = dh;
        browser_scroll = scroll_clamp(browser_scroll, content_h, view_h);
        i32 ix = x + (w - dw) / 2, iy = view_top - browser_scroll;
        for (i32 dy = 0; dy < dh; dy++) {
            u32 sy = (u32)dy * local_img_h / (u32)dh;
            for (i32 dx = 0; dx < dw; dx++) {
                u32 sx = (u32)dx * local_img_w / (u32)dw;
                color_t c = RGB(local_img[sy][sx][0], local_img[sy][sx][1], local_img[sy][sx][2]);
                gfx_pixel(ix + dx, iy + dy, c);
            }
        }
    } else {
        browser_scroll = 0;
        char msg[64] = "No such ZapczOS page: ";
        str_cat(msg, addr_buf, 64);
        gfx_string(x + CONTENT_X, y + CONTENT_TOP, msg, THEME_WARNING, THEME_PANEL, 0);
        if (local_status[0]) {
            gfx_string(x + CONTENT_X, y + CONTENT_TOP + 24, local_status, THEME_WARNING, THEME_PANEL, 0);
        } else {
            gfx_string(x + CONTENT_X, y + CONTENT_TOP + 24, "Try the Home button, or zapcz://help.",
                       THEME_TEXT_DIM, THEME_PANEL, 0);
        }
    }
    gfx_clear_clip();
    browser_content_h = content_h;
    scroll_draw_bar(x + w - 14, view_top, view_h, browser_scroll, content_h, view_h,
                    THEME_PANEL_ALT, THEME_BORDER);

    gfx_string(x + 12, y + h - 22, net_ready() ? "ZapczNet -- local pages, files, and live http(s):// sites" :
               "ZapczNet -- local pages and files (no network connection)",
               THEME_TEXT_FAINT, THEME_PANEL, 0);
    if (dl_status[0] && ticks_get() - dl_status_tick < ticks_per_sec() * 6)
        gfx_string(x + 12, y + h - 20, dl_status, THEME_ACCENT, THEME_PANEL, 0);
    priv_panel_draw(x, y, w, h);
}

void app_browser_wheel(i32 delta) {
    i32 h = windows[APP_BROWSER].h;
    i32 view_h = (h - 24) - CONTENT_TOP;
    browser_scroll = scroll_clamp(browser_scroll - delta * 54, browser_content_h, view_h);
}

void app_browser_drag(i32 rx, i32 ry) {
    i32 w = windows[APP_BROWSER].w;
    i32 h = windows[APP_BROWSER].h;
    i32 view_h = (h - 24) - CONTENT_TOP;
    if (scroll_bar_hit(rx, ry, w - 14, CONTENT_TOP, view_h, browser_content_h, view_h)) {
        browser_scroll = scroll_bar_drag_to(ry, CONTENT_TOP, view_h, browser_content_h, view_h);
    }
}

void app_browser_click(i32 rx, i32 ry) {
    i32 w = windows[APP_BROWSER].w;
    i32 h = windows[APP_BROWSER].h;

    if (priv_panel_click(0, 0, w, h, rx, ry)) return;
    {
        i32 priv_x = w - 12 - 74;
        if (ui_point_in(rx, ry, priv_x, BAR_Y, 74, 28)) { priv_panel_open = !priv_panel_open; return; }
    }

    if (ui_point_in(rx, ry, BACK_X, BAR_Y, NAV_BTN_W, NAV_BTN_H)) { go_back(); return; }
    if (ui_point_in(rx, ry, FWD_X, BAR_Y, NAV_BTN_W, NAV_BTN_H)) { go_forward(); return; }
    if (ui_point_in(rx, ry, HOME_X, BAR_Y, HOME_W, NAV_BTN_H)) { navigate("zapcz://home"); return; }

    i32 go_x = w - 12 - 74 - 6 - GO_W;
    if (ui_point_in(rx, ry, go_x, BAR_Y, GO_W, 28)) {
        if (g_loading) browser_cancel_load();
        else browser_follow(addr_buf);
        return;
    }

    i32 view_h = (h - 24) - CONTENT_TOP;
    if (scroll_bar_hit(rx, ry, w - 14, CONTENT_TOP, view_h, browser_content_h, view_h)) {
        browser_scroll = scroll_bar_drag_to(ry, CONTENT_TOP, view_h, browser_content_h, view_h);
        return;
    }

    const page_t* p = find_page(addr_buf);
    if (p) {
        const char* dest = layout_page(0, 0, p, 0, rx, ry, browser_scroll, 0);
        if (dest) follow_link(dest);
    } else if (local_kind == 'H') {
        const char* dest = html_layout(0, 0, w, 0, rx, ry, browser_scroll, 0);
        if (dest) follow_link(dest);
    }
}

void app_browser_key(int key) {
    if (key == KEY_ENTER) {
        browser_follow(addr_buf);
    } else if (key == KEY_BACKSPACE) {
        if (addr_len > 0) addr_buf[--addr_len] = 0;
    } else if (kbd_is_printable(key)) {
        if (addr_len < sizeof(addr_buf) - 1) {
            addr_buf[addr_len++] = (char)key;
            addr_buf[addr_len] = 0;
        }
    }
}
