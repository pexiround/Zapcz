#ifndef CALCULATOR_H
#define CALCULATOR_H
#include "io.h"

void calc_init(void);
void app_calc_draw(i32 x, i32 y, i32 w, i32 h);
void app_calc_click(i32 rx, i32 ry);
void app_calc_key(int key);

#endif
