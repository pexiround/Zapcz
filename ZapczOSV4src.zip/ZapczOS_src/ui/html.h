#ifndef HTML_H
#define HTML_H
#include "io.h"

#define HTML_MAX_ELEMENTS 4096
#define HTML_POOL_SIZE    262144
#define HTML_MAX_ANCHORS  128

typedef enum { HEL_HEADING, HEL_TEXT, HEL_LINK, HEL_IMG, HEL_GAP, HEL_HR } html_el_type_t;

#define HAL_LEFT   0
#define HAL_CENTER 1
#define HAL_RIGHT  2

#define HFS_SMALL  0
#define HFS_NORMAL 1
#define HFS_LARGE  2
#define HFS_XLARGE 3

typedef struct {
    html_el_type_t type;
    u32  text_off, text_len;
    u32  href_off, href_len;
    u8   fg_r, fg_g, fg_b;
    u8   bg_r, bg_g, bg_b;
    int  bold, italic, code, heading, is_pre;
    u8   align, fsize, underline, strike, indent, hidden, bullet;
    u32  dom_id_off, dom_id_len;
} html_el_t;

typedef struct { char name[40]; int el; } html_anchor_t;

typedef struct {
    html_el_t els[HTML_MAX_ELEMENTS];
    int       count;
    char      pool[HTML_POOL_SIZE];
    u32       pool_used;
    html_anchor_t anchors[HTML_MAX_ANCHORS];
    int       anchor_count;
    int       css_rules;
    int       scripts_run;
    int       js_errors;
    char      js_error[96];
} html_doc_t;

void html_emit_text(html_doc_t* doc, const char* s, u32 len);
int  html_set_by_id(html_doc_t* doc, const char* id, const char* text, u32 len);

int  html_anchor_el(const html_doc_t* doc, const char* name);
void html_page_bg(u8*r,u8*g,u8*b,int*grad,u8*g1r,u8*g1g,u8*g1b,u8*g2r,u8*g2g,u8*g2b);

void html_parse(const char* src, u32 len, u32 max_chars_per_line, html_doc_t* doc);
void md_parse  (const char* src, u32 len, u32 max_chars_per_line, html_doc_t* doc);
void txt_parse (const char* src, u32 len, u32 max_chars_per_line, html_doc_t* doc);
void html_text (const html_doc_t* doc, u32 off, u32 len, char* out, u32 out_size);

#endif
