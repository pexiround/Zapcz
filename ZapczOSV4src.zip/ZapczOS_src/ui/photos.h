#ifndef PHOTOS_H
#define PHOTOS_H
#include "io.h"

void photos_init(void);
void app_photos_draw(i32 x, i32 y, i32 w, i32 h);

void photos_open_file(const char* filename);

#endif
