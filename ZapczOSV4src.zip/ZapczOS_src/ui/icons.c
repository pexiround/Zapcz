#include "icons.h"
#include "desktop.h"
#include "util.h"
#include "font8x16.h"
#include "icon_bitmaps.h"
#include "logo.h"

static color_t logo_lerp(color_t a, color_t b, i32 num, i32 den) {
    if (den <= 0) return a;
    if (num < 0) num = 0;
    if (num > den) num = den;
    return RGB(a.r + (i32)(b.r - a.r) * num / den,
               a.g + (i32)(b.g - a.g) * num / den,
               a.b + (i32)(b.b - a.b) * num / den);
}

void logo_draw_ex(i32 x, i32 y, i32 bw, i32 bh, color_t bg, int transparent) {
    if (bw <= 0 || bh <= 0) return;
    static unsigned char outline_map[LOGO_H_][LOGO_W];
    static unsigned char edge_map[LOGO_H_][LOGO_W];
    static int outline_ready = 0;
    if (!outline_ready) {
        for (int j = 0; j < LOGO_H_; j++)
            for (int i = 0; i < LOGO_W; i++) {
                unsigned char o = 0;
                if (logo_bitmap[j][i] == 1) {
                    for (int dj = -1; dj <= 1 && !o; dj++)
                        for (int di = -1; di <= 1; di++) {
                            int nj = j + dj, ni = i + di;
                            if (nj < 0 || nj >= LOGO_H_ || ni < 0 || ni >= LOGO_W) continue;
                            if (logo_bitmap[nj][ni] == 2) { o = 1; break; }
                        }
                }
                outline_map[j][i] = o;
                unsigned char e = 0;
                if (logo_bitmap[j][i] == 0) {
                    for (int dj = -1; dj <= 1 && !e; dj++)
                        for (int di = -1; di <= 1; di++) {
                            int nj = j + dj, ni = i + di;
                            if (nj < 0 || nj >= LOGO_H_ || ni < 0 || ni >= LOGO_W) continue;
                            if (logo_bitmap[nj][ni] != 0) { e = 1; break; }
                        }
                }
                edge_map[j][i] = e;
            }
        outline_ready = 1;
    }
    color_t c_center = RGB(120, 224, 216), c_mid = RGB(64, 140, 172), c_edge = RGB(58, 74, 146);
    color_t white = RGB(248, 250, 252), outline = RGB(16, 18, 24);
    i32 cx = LOGO_W / 2, cy = LOGO_H_ / 2, maxr = cx + 2;
    const int SS = 4;
    for (i32 oy = 0; oy < bh; oy++) {
        i32 py = y + oy;
        if (py < 0 || (u32)py >= gfx.height) continue;
        for (i32 ox = 0; ox < bw; ox++) {
            i32 px = x + ox;
            if (px < 0 || (u32)px >= gfx.width) continue;
            color_t pbg = transparent ? gfx_get_pixel(px, py) : bg;
            i32 ar = 0, ag = 0, ab = 0;
            for (int syi = 0; syi < SS; syi++) {
                i32 sj = (oy * SS + syi) * LOGO_H_ / (bh * SS);
                if (sj >= LOGO_H_) sj = LOGO_H_ - 1;
                for (int sxi = 0; sxi < SS; sxi++) {
                    i32 si = (ox * SS + sxi) * LOGO_W / (bw * SS);
                    if (si >= LOGO_W) si = LOGO_W - 1;
                    unsigned char v = logo_bitmap[sj][si];
                    color_t c;
                    if (v == 0) c = (transparent && edge_map[sj][si]) ? outline : pbg;
                    else if (v == 2) c = white;
                    else if (outline_map[sj][si]) c = outline;
                    else {
                        i32 dx = si - cx, dy = (sj - cy) * 2;
                        i32 d = dx < 0 ? -dx : dx;
                        i32 dyy = dy < 0 ? -dy : dy;
                        i32 rad = d + dyy / 2;
                        if (rad < maxr / 2) c = logo_lerp(c_center, c_mid, rad * 2, maxr);
                        else c = logo_lerp(c_mid, c_edge, (rad - maxr / 2) * 2, maxr);
                    }
                    ar += c.r; ag += c.g; ab += c.b;
                }
            }
            i32 n = SS * SS;
            gfx_pixel(px, py, RGB((u8)(ar / n), (u8)(ag / n), (u8)(ab / n)));
        }
    }
}

void logo_draw(i32 x, i32 y, i32 bw, i32 bh, color_t bg) {
    logo_draw_ex(x, y, bw, bh, bg, 0);
}

static void icon_tile(i32 x, i32 y, i32 size, color_t top, color_t bot) {
    i32 r = size * 22 / 100;
    if (r < 2) r = 2;
    gfx_rounded_rect(x + 1, y + size * 5 / 100 + 1, size, size, r, RGB(0, 0, 0));
    gfx_rounded_gradient_v(x, y, size, size, r, top, bot);
    color_t sheen = gfx_lerp_color(top, RGB(255, 255, 255), 34, 100);
    gfx_rounded_rect_top(x + size * 8 / 100, y + size * 6 / 100,
                         size - size * 16 / 100, size * 26 / 100, r * 2 / 3, sheen);
    gfx_rounded_rect_outline(x, y, size, size, r, gfx_lerp_color(bot, RGB(0, 0, 0), 22, 100));
}

#define GW RGB(255,255,255)

static void icon_about(i32 x, i32 y, i32 size, color_t fg) {
    (void)fg;
    icon_tile(x, y, size, RGB(120, 176, 255), RGB(38, 96, 216));
    i32 cx = x + size / 2, cy = y + size / 2;
    gfx_circle_fill(cx, cy - size * 15 / 100, size * 7 / 100, GW);
    i32 bw = size * 12 / 100, bh = size * 32 / 100;
    gfx_rounded_rect(cx - bw / 2, cy - size * 2 / 100, bw, bh, bw / 2, GW);
}

static void icon_clock(i32 x, i32 y, i32 size, color_t fg) {
    (void)fg;
    icon_tile(x, y, size, RGB(126, 214, 232), RGB(28, 130, 176));
    i32 cx = x + size / 2, cy = y + size / 2, r = size * 32 / 100;
    gfx_circle_fill(cx, cy, r, GW);
    gfx_circle_fill(cx, cy, r - size * 6 / 100, RGB(236, 246, 252));
    color_t hand = RGB(24, 74, 110);
    for (i32 t = -1; t <= 1; t++) {
        gfx_line(cx + t, cy, cx + t, cy - r * 3 / 5, hand);
        gfx_line(cx, cy + t, cx + r * 2 / 5, cy + t, hand);
    }
    gfx_circle_fill(cx, cy, size * 5 / 100, hand);
}

static void icon_files(i32 x, i32 y, i32 size, color_t fg) {
    (void)fg;
    icon_tile(x, y, size, RGB(255, 214, 122), RGB(232, 158, 30));
    i32 fx = x + size * 18 / 100, fw = size * 64 / 100;
    i32 fy = y + size * 32 / 100, fh = size * 38 / 100;
    gfx_rounded_rect(fx, fy - size * 9 / 100, fw * 45 / 100, size * 12 / 100, 2, RGB(255, 245, 220));
    gfx_rounded_rect(fx, fy, fw, fh, size * 6 / 100, GW);
    gfx_rounded_rect(fx, fy, fw, size * 9 / 100, size * 6 / 100, RGB(252, 238, 208));
}

static void icon_editor(i32 x, i32 y, i32 size, color_t fg) {
    (void)fg;
    icon_tile(x, y, size, RGB(186, 196, 214), RGB(96, 110, 138));
    i32 pw = size * 46 / 100, ph = size * 60 / 100;
    i32 px = x + (size - pw) / 2, py = y + (size - ph) / 2;
    gfx_rounded_rect(px, py, pw, ph, size * 5 / 100, GW);
    color_t ink = RGB(108, 122, 150);
    for (int i = 0; i < 4; i++) {
        i32 ly = py + ph * (22 + i * 18) / 100;
        i32 lw = (i == 3) ? pw * 40 / 100 : pw * 66 / 100;
        gfx_rounded_rect(px + pw * 16 / 100, ly, lw, size * 4 / 100, 1, ink);
    }
}

static void icon_terminal(i32 x, i32 y, i32 size, color_t fg) {
    (void)fg;
    icon_tile(x, y, size, RGB(72, 82, 104), RGB(24, 28, 40));
    i32 pw = size * 66 / 100, ph = size * 52 / 100;
    i32 px = x + (size - pw) / 2, py = y + (size - ph) / 2 + size * 4 / 100;
    gfx_rounded_rect(px, py, pw, ph, size * 6 / 100, RGB(16, 20, 30));
    gfx_rounded_rect_outline(px, py, pw, ph, size * 6 / 100, RGB(96, 108, 132));
    color_t grn = RGB(96, 232, 140);
    i32 ax = px + pw * 18 / 100, ay = py + ph * 34 / 100, s = size * 8 / 100;
    for (i32 t = 0; t < 2; t++) {
        gfx_line(ax, ay - s + t, ax + s, ay + t, grn);
        gfx_line(ax + s, ay + t, ax, ay + s + t, grn);
    }
    gfx_rounded_rect(ax + s + size * 6 / 100, ay + s - size * 3 / 100, pw * 32 / 100, size * 5 / 100, 1, grn);
}


static void icon_compiler(i32 x, i32 y, i32 size, color_t fg) {
    (void)fg;
    icon_tile(x, y, size, RGB(246, 176, 84), RGB(198, 96, 24));
    color_t ink = RGB(255, 252, 246);
    i32 cx = x + size / 2;
    i32 s = size * 10 / 100;
    i32 ay = y + size * 46 / 100;
    i32 ax = x + size * 22 / 100;
    for (i32 t = 0; t < 3; t++) {
        gfx_line(ax, ay - s + t, ax + s, ay + t, ink);
        gfx_line(ax + s, ay + t, ax, ay + s + t, ink);
    }
    i32 bx = x + size * 62 / 100;
    for (i32 t = 0; t < 3; t++) {
        gfx_line(bx + s, ay - s + t, bx, ay + t, ink);
        gfx_line(bx, ay + t, bx + s, ay + s + t, ink);
    }
    gfx_rounded_rect(cx - size * 3 / 100, y + size * 30 / 100, size * 6 / 100, size * 34 / 100, 1, ink);
    gfx_rounded_rect(x + size * 22 / 100, y + size * 70 / 100, size * 56 / 100, size * 7 / 100, 2, ink);
}

static void icon_perf(i32 x, i32 y, i32 size, color_t fg) {
    (void)fg;
    icon_tile(x, y, size, RGB(140, 226, 178), RGB(28, 148, 104));
    i32 bw = size * 13 / 100, base = y + size * 72 / 100;
    i32 hs[4] = { 22, 38, 30, 50 };
    for (int i = 0; i < 4; i++) {
        i32 bx = x + size * 18 / 100 + i * (bw + size * 5 / 100);
        i32 bh = size * hs[i] / 100;
        gfx_rounded_rect(bx, base - bh, bw, bh, bw / 3, GW);
    }
}

static void icon_wallpaper(i32 x, i32 y, i32 size, color_t fg) {
    (void)fg;
    icon_tile(x, y, size, RGB(196, 164, 244), RGB(112, 66, 200));
    i32 fw = size * 64 / 100, fh = size * 48 / 100;
    i32 fx = x + (size - fw) / 2, fy = y + (size - fh) / 2;
    gfx_rounded_rect(fx, fy, fw, fh, size * 5 / 100, GW);
    gfx_rounded_rect(fx + 2, fy + fh * 52 / 100, fw - 4, fh * 44 / 100, 2, RGB(150, 206, 240));
    gfx_circle_fill(fx + fw * 28 / 100, fy + fh * 30 / 100, size * 6 / 100, RGB(255, 214, 96));
    for (i32 i = 0; i < fw - 4; i++) {
        i32 hgt = (i < (fw - 4) / 2) ? i : (fw - 4 - i);
        gfx_vline(fx + 2 + i, fy + fh - 2 - hgt * 60 / 100, hgt * 60 / 100, RGB(96, 170, 122));
    }
}

static void icon_snake(i32 x, i32 y, i32 size, color_t fg) {
    (void)fg;
    icon_tile(x, y, size, RGB(158, 232, 128), RGB(52, 152, 46));
    i32 s = size * 15 / 100;
    i32 bx = x + size * 20 / 100, by = y + size * 26 / 100;
    gfx_rounded_rect(bx, by, s, s, 2, GW);
    gfx_rounded_rect(bx + s, by, s, s, 2, GW);
    gfx_rounded_rect(bx + s, by + s, s, s, 2, GW);
    gfx_rounded_rect(bx + s * 2, by + s, s, s, 2, GW);
    gfx_rounded_rect(bx + s * 2, by + s * 2, s, s, 2, GW);
    gfx_circle_fill(bx + s / 2, by + s * 5 / 2, size * 7 / 100, RGB(255, 120, 110));
}

static void icon_browser(i32 x, i32 y, i32 size, color_t fg) {
    (void)fg;
    icon_tile(x, y, size, RGB(122, 190, 255), RGB(24, 108, 210));
    i32 cx = x + size / 2, cy = y + size / 2, r = size * 32 / 100;
    gfx_circle_fill(cx, cy, r, GW);
    color_t sea = RGB(58, 140, 226);
    gfx_circle(cx, cy, r, sea);
    gfx_circle(cx, cy, r * 60 / 100, sea);
    for (i32 t = -1; t <= 1; t++) gfx_line(cx - r + 1, cy + t, cx + r - 1, cy + t, sea);
    for (i32 t = -1; t <= 1; t++) gfx_line(cx + t, cy - r + 1, cx + t, cy + r - 1, sea);
}

static void icon_store(i32 x, i32 y, i32 size, color_t fg) {
    (void)fg;
    icon_tile(x, y, size, RGB(255, 168, 168), RGB(214, 52, 92));
    i32 bw = size * 52 / 100, bh = size * 40 / 100;
    i32 bx = x + (size - bw) / 2, by = y + size * 42 / 100;
    gfx_rounded_rect(bx, by, bw, bh, size * 5 / 100, GW);
    i32 hr = size * 15 / 100;
    gfx_circle(bx + bw / 2, by, hr, GW);
    gfx_rect(bx + bw / 2 - hr, by, hr * 2, hr, RGB(0, 0, 0));
    gfx_circle(bx + bw / 2, by, hr, GW);
    gfx_rounded_rect(bx, by, bw, bh, size * 5 / 100, GW);
}

static void icon_settings(i32 x, i32 y, i32 size, color_t fg) {
    (void)fg;
    icon_tile(x, y, size, RGB(178, 190, 208), RGB(84, 98, 122));
    i32 cx = x + size / 2, cy = y + size / 2;
    i32 ro = size * 32 / 100, ri = size * 14 / 100;
    gfx_circle_fill(cx, cy, ro, GW);
    for (int i = 0; i < 4; i++) {
        i32 t = size * 11 / 100;
        if (i == 0) gfx_rounded_rect(cx - t / 2, cy - ro - t / 2, t, t * 2, 2, GW);
        if (i == 1) gfx_rounded_rect(cx - t / 2, cy + ro - t * 3 / 2, t, t * 2, 2, GW);
        if (i == 2) gfx_rounded_rect(cx - ro - t / 2, cy - t / 2, t * 2, t, 2, GW);
        if (i == 3) gfx_rounded_rect(cx + ro - t * 3 / 2, cy - t / 2, t * 2, t, 2, GW);
    }
    gfx_circle_fill(cx, cy, ri, RGB(96, 110, 134));
}

static void icon_photos(i32 x, i32 y, i32 size, color_t fg) {
    (void)fg;
    icon_tile(x, y, size, RGB(255, 190, 140), RGB(226, 106, 58));
    i32 fw = size * 62 / 100, fh = size * 48 / 100;
    i32 fx = x + (size - fw) / 2, fy = y + (size - fh) / 2;
    gfx_rounded_rect(fx, fy, fw, fh, size * 5 / 100, GW);
    gfx_circle_fill(fx + fw * 26 / 100, fy + fh * 28 / 100, size * 6 / 100, RGB(255, 206, 96));
    for (i32 i = 0; i < fw - 4; i++) {
        i32 h1 = (i < (fw - 4) * 45 / 100) ? i : ((fw - 4) * 90 / 100 - i);
        if (h1 < 0) h1 = 0;
        gfx_vline(fx + 2 + i, fy + fh - 2 - h1 * 70 / 100, h1 * 70 / 100, RGB(120, 186, 130));
    }
}

static void icon_calc(i32 x, i32 y, i32 size, color_t fg) {
    (void)fg;
    icon_tile(x, y, size, RGB(150, 168, 200), RGB(58, 74, 110));
    i32 bw = size * 56 / 100, bh = size * 64 / 100;
    i32 bx = x + (size - bw) / 2, by = y + (size - bh) / 2;
    gfx_rounded_rect(bx, by, bw, bh, size * 6 / 100, GW);
    gfx_rounded_rect(bx + bw * 10 / 100, by + bh * 8 / 100, bw * 80 / 100, bh * 22 / 100, 2, RGB(126, 186, 156));
    i32 k = size * 9 / 100;
    for (int r2 = 0; r2 < 3; r2++)
        for (int c2 = 0; c2 < 3; c2++)
            gfx_rounded_rect(bx + bw * 12 / 100 + c2 * (k + size * 4 / 100),
                             by + bh * 38 / 100 + r2 * (k + size * 3 / 100), k, k, 2, RGB(108, 122, 150));
}

static void icon_paint(i32 x, i32 y, i32 size, color_t fg) {
    (void)fg;
    icon_tile(x, y, size, RGB(246, 150, 200), RGB(186, 44, 132));
    i32 cx = x + size / 2, cy = y + size / 2;
    gfx_circle_fill(cx, cy, size * 32 / 100, GW);
    gfx_circle_fill(cx - size * 13 / 100, cy - size * 10 / 100, size * 6 / 100, RGB(226, 72, 72));
    gfx_circle_fill(cx + size * 11 / 100, cy - size * 12 / 100, size * 6 / 100, RGB(72, 132, 226));
    gfx_circle_fill(cx + size * 15 / 100, cy + size * 6 / 100, size * 6 / 100, RGB(246, 196, 62));
    gfx_circle_fill(cx - size * 6 / 100, cy + size * 13 / 100, size * 6 / 100, RGB(96, 196, 120));
    gfx_circle_fill(cx + size * 2 / 100, cy + size * 1 / 100, size * 7 / 100, RGB(226, 158, 200));
}

static void icon_ttt(i32 x, i32 y, i32 size, color_t fg) {
    (void)fg;
    icon_tile(x, y, size, RGB(160, 214, 240), RGB(46, 118, 176));
    i32 g0 = x + size * 22 / 100, g1 = x + size * 78 / 100;
    i32 v0 = y + size * 22 / 100, v1 = y + size * 78 / 100;
    i32 t = size * 5 / 100; if (t < 1) t = 1;
    gfx_rounded_rect(x + size * 41 / 100, v0, t, v1 - v0, 1, GW);
    gfx_rounded_rect(x + size * 57 / 100, v0, t, v1 - v0, 1, GW);
    gfx_rounded_rect(g0, y + size * 41 / 100, g1 - g0, t, 1, GW);
    gfx_rounded_rect(g0, y + size * 57 / 100, g1 - g0, t, 1, GW);
    gfx_circle(x + size * 31 / 100, y + size * 31 / 100, size * 7 / 100, GW);
    gfx_line(g1 - size * 12 / 100, v1 - size * 12 / 100, g1, v1, GW);
    gfx_line(g1, v1 - size * 12 / 100, g1 - size * 12 / 100, v1, GW);
}

static void icon_cube3d(i32 x, i32 y, i32 size, color_t fg) {
    (void)fg;
    icon_tile(x, y, size, RGB(184, 168, 246), RGB(88, 60, 196));
    i32 cx = x + size / 2, cy = y + size / 2, s = size * 26 / 100;
    i32 tx = cx, ty = cy - s;
    gfx_line(tx, ty, cx + s, cy - s / 3, GW);
    gfx_line(cx + s, cy - s / 3, cx + s, cy + s / 2, GW);
    gfx_line(cx + s, cy + s / 2, cx, cy + s, GW);
    gfx_line(cx, cy + s, cx - s, cy + s / 2, GW);
    gfx_line(cx - s, cy + s / 2, cx - s, cy - s / 3, GW);
    gfx_line(cx - s, cy - s / 3, tx, ty, GW);
    gfx_line(cx, cy + s, cx, cy, GW);
    gfx_line(cx, cy, cx + s, cy - s / 3, GW);
    gfx_line(cx, cy, cx - s, cy - s / 3, GW);
}

static void icon_accounts(i32 x, i32 y, i32 size, color_t fg) {
    (void)fg;
    icon_tile(x, y, size, RGB(148, 206, 236), RGB(44, 116, 176));
    i32 cx = x + size / 2;
    gfx_circle_fill(cx, y + size * 38 / 100, size * 14 / 100, GW);
    i32 bw = size * 46 / 100, bh = size * 24 / 100;
    gfx_rounded_rect(cx - bw / 2, y + size * 56 / 100, bw, bh, bw / 2, GW);
}

static void icon_installer(i32 x, i32 y, i32 size, color_t fg) {
    (void)fg;
    icon_tile(x, y, size, RGB(150, 214, 178), RGB(34, 132, 96));
    i32 cx = x + size / 2;
    i32 aw = size * 10 / 100;
    gfx_rounded_rect(cx - aw / 2, y + size * 24 / 100, aw, size * 30 / 100, aw / 2, GW);
    for (i32 i = 0; i <= size * 14 / 100; i++) {
        gfx_hline(cx - size * 14 / 100 + i, y + size * 54 / 100 + i, (size * 28 / 100) - i * 2, GW);
    }
    gfx_rounded_rect(x + size * 24 / 100, y + size * 74 / 100, size * 52 / 100, size * 7 / 100, 2, GW);
}

static void icon_2048(i32 x, i32 y, i32 size, color_t fg) {
    (void)fg;
    icon_tile(x, y, size, RGB(246, 206, 140), RGB(224, 146, 62));
    i32 k = size * 30 / 100, g = size * 6 / 100;
    i32 bx = x + (size - (k * 2 + g)) / 2, by = y + (size - (k * 2 + g)) / 2;
    gfx_rounded_rect(bx, by, k, k, size * 5 / 100, GW);
    gfx_rounded_rect(bx + k + g, by, k, k, size * 5 / 100, RGB(255, 236, 206));
    gfx_rounded_rect(bx, by + k + g, k, k, size * 5 / 100, RGB(255, 236, 206));
    gfx_rounded_rect(bx + k + g, by + k + g, k, k, size * 5 / 100, GW);
}

static void icon_mines(i32 x, i32 y, i32 size, color_t fg) {
    (void)fg;
    icon_tile(x, y, size, RGB(178, 190, 210), RGB(72, 84, 108));
    i32 cx = x + size / 2, cy = y + size * 54 / 100, r = size * 22 / 100;
    for (int i = 0; i < 4; i++) {
        i32 dx = (i == 0 || i == 1) ? r + size * 8 / 100 : 0;
        i32 dy = (i == 2 || i == 3) ? r + size * 8 / 100 : 0;
        if (i == 1) dx = -dx;
        if (i == 3) dy = -dy;
        gfx_line(cx - dx, cy - dy, cx + dx, cy + dy, RGB(28, 32, 44));
    }
    gfx_circle_fill(cx, cy, r, RGB(28, 32, 44));
    gfx_circle_fill(cx - r / 3, cy - r / 3, r / 4, GW);
}

static void icon_life(i32 x, i32 y, i32 size, color_t fg) {
    (void)fg;
    icon_tile(x, y, size, RGB(150, 224, 214), RGB(28, 140, 140));
    i32 k = size * 17 / 100, g = size * 4 / 100;
    i32 bx = x + size * 20 / 100, by = y + size * 20 / 100;
    const int on[9] = { 0,1,0, 1,1,1, 0,1,0 };
    for (int r2 = 0; r2 < 3; r2++)
        for (int c2 = 0; c2 < 3; c2++)
            if (on[r2 * 3 + c2])
                gfx_rounded_rect(bx + c2 * (k + g), by + r2 * (k + g), k, k, 2, GW);
}

static void icon_draw_bitmap(const u8* src, i32 x, i32 y, i32 size) {
    if (size <= 0) return;
    for (i32 dy = 0; dy < size; dy++) {
        i32 sy = dy * ICON_BMP_H / size;
        i32 py = y + dy;
        if (py < 0 || (u32)py >= gfx.height) continue;
        for (i32 dx = 0; dx < size; dx++) {
            i32 sx = dx * ICON_BMP_W / size;
            const u8* p = src + ((u32)sy * ICON_BMP_W + (u32)sx) * 4;
            u8 a = p[3];
            if (a == 0) continue;
            i32 px = x + dx;
            if (!gfx_clip_test(px, py)) continue;

            if (a == 255) {
                gfx_pixel(px, py, RGB(p[0], p[1], p[2]));
            } else {
                u32 off = (u32)py * gfx.width * gfx.bypp + (u32)px * gfx.bypp;
                u8 dr = gfx.back[off + 2], dg = gfx.back[off + 1], db = gfx.back[off + 0];
                u8 or_ = (u8)(((u32)p[0] * a + (u32)dr * (255 - a)) / 255);
                u8 og  = (u8)(((u32)p[1] * a + (u32)dg * (255 - a)) / 255);
                u8 ob  = (u8)(((u32)p[2] * a + (u32)db * (255 - a)) / 255);
                gfx_pixel(px, py, RGB(or_, og, ob));
            }
        }
    }
}

int icon_has_bitmap(int app_id) {
    return (app_id >= 0 && app_id < APP_COUNT && ICON_BITMAP_TABLE[app_id] != 0);
}


void icon_draw(int app_id, i32 x, i32 y, i32 size, color_t fg) {
    if (app_id >= 0 && app_id < APP_COUNT && ICON_BITMAP_TABLE[app_id]) {
        icon_draw_bitmap(ICON_BITMAP_TABLE[app_id], x, y, size);
        return;
    }
    switch (app_id) {
        case APP_2048: icon_2048(x, y, size, fg); break;
        case APP_CLOCK: icon_clock(x, y, size, fg); break;
        case APP_FILES: icon_files(x, y, size, fg); break;
        case APP_EDITOR: icon_editor(x, y, size, fg); break;
        case APP_TERMINAL: icon_terminal(x, y, size, fg); break;
        case APP_PERF: icon_perf(x, y, size, fg); break;
        case APP_WALLPAPER: icon_wallpaper(x, y, size, fg); break;
        case APP_SNAKE: icon_snake(x, y, size, fg); break;
        case APP_BROWSER: icon_browser(x, y, size, fg); break;
        case APP_STORE: icon_store(x, y, size, fg); break;
        case APP_SETTINGS: icon_settings(x, y, size, fg); break;
        case APP_PHOTOS: icon_photos(x, y, size, fg); break;
        case APP_ACCOUNTS: icon_accounts(x, y, size, fg); break;
        case APP_INSTALLER: icon_installer(x, y, size, fg); break;
        case APP_CALC: icon_calc(x, y, size, fg); break;
        case APP_PAINT: icon_paint(x, y, size, fg); break;
        case APP_TTT: icon_ttt(x, y, size, fg); break;
        case APP_CUBE3D: icon_cube3d(x, y, size, fg); break;
        case APP_DESKSETTINGS: icon_settings(x, y, size, fg); break;
        case APP_MINES: icon_mines(x, y, size, fg); break;
        case APP_LIFE: icon_life(x, y, size, fg); break;
        case APP_NOTIFY: icon_about(x, y, size, fg); break;
        case APP_CALENDAR: icon_clock(x, y, size, fg); break;
        case APP_TRASH: icon_files(x, y, size, fg); break;
        case APP_WRITER: icon_editor(x, y, size, fg); break;
        case APP_SHEET: icon_calc(x, y, size, fg); break;
        case APP_MEDIA: icon_photos(x, y, size, fg); break;
        case APP_IDE: icon_terminal(x, y, size, fg); break;
        case APP_COMPILER: icon_compiler(x, y, size, fg); break;
        default: icon_about(x, y, size, fg); break;
    }
}

static char ft_upper(char c) { return (c >= 'a' && c <= 'z') ? (char)(c - 'a' + 'A') : c; }

static int ft_get_ext(const char* name83, char* out) {
    u32 len = str_len(name83);
    i32 dot = -1;
    for (i32 i = (i32)len - 1; i >= 0; i--) {
        if (name83[i] == '.') { dot = i; break; }
    }
    if (dot < 0) { out[0] = 0; return 0; }
    int n = 0;
    for (u32 i = (u32)dot + 1; i < len && n < 6; i++) out[n++] = ft_upper(name83[i]);
    out[n] = 0;
    return n;
}

static int ft_ext_is(const char* ext, const char* lit) {
    int i = 0;
    for (; ext[i] && lit[i]; i++) if (ext[i] != lit[i]) return 0;
    return ext[i] == 0 && lit[i] == 0;
}

static int ft_is_image(const char* ext) {
    return ft_ext_is(ext, "PNG") || ft_ext_is(ext, "BMP") || ft_ext_is(ext, "JPG") ||
           ft_ext_is(ext, "GIF") || ft_ext_is(ext, "ICO") || ft_ext_is(ext, "JPEG");
}

typedef struct { const char* ext; const char* label; color_t color; } filetype_t;

static const filetype_t FILETYPE_TABLE[] = {
    { "C",    "C",   {90,150,230} },
    { "H",    "H",   {120,190,230} },
    { "CPP",  "C++", {145,120,232} },
    { "HPP",  "C++", {145,120,232} },
    { "CC",   "C++", {145,120,232} },
    { "ASM",  "ASM", {220,95,90}  },
    { "S",    "ASM", {220,95,90}  },
    { "PY",   "PY",  {70,170,165} },
    { "JS",   "JS",  {235,200,65} },
    { "RS",   "RS",  {205,115,65} },
    { "GO",   "GO",  {80,205,190} },
    { "MD",   "MD",  {150,175,205} },
    { "TXT",  "TXT", {190,190,196} },
    { "HTM",  "WEB", {225,120,70} },
    { "HTML", "WEB", {225,120,70} },
    { "CSS",  "CSS", {120,150,225} },
    { "INI",  "CFG", {135,175,125} },
    { "CFG",  "CFG", {135,175,125} },
    { "LOG",  "LOG", {145,150,160} },
    { "BAT",  "SH",  {95,200,120} },
    { "SH",   "SH",  {95,200,120} },
    { "ZIP",  "ZIP", {205,175,95} },
    { "DAT",  "DAT", {125,135,155} },
    { "BIN",  "BIN", {165,125,125} },
    { "SYS",  "SYS", {165,125,125} },
    { "OBJ",  "OBJ", {165,125,125} },
    { "WAV",  "WAV", {175,115,210} },
    { "INC",  "INC", {120,190,230} },
};
#define FILETYPE_TABLE_COUNT (int)(sizeof(FILETYPE_TABLE) / sizeof(FILETYPE_TABLE[0]))

static const color_t FT_FALLBACK_PALETTE[] = {
    {100,200,130}, {90,170,235}, {205,140,90}, {150,130,235},
    {90,200,190}, {220,150,170}, {160,180,90}, {140,150,210},
};
#define FT_FALLBACK_COUNT (int)(sizeof(FT_FALLBACK_PALETTE) / sizeof(FT_FALLBACK_PALETTE[0]))

static color_t ft_fallback_color(const char* ext, int len) {
    u32 h = 5381;
    for (int i = 0; i < len; i++) h = h * 33u + (u32)ext[i];
    return FT_FALLBACK_PALETTE[h % FT_FALLBACK_COUNT];
}

void filetype_icon_draw(i32 x, i32 y, i32 size, const char* name83) {
    char ext[7];
    int extlen = ft_get_ext(name83, ext);
    int is_image = extlen > 0 && ft_is_image(ext);

    if (is_image) {
        gfx_rounded_rect(x, y, size, size, size / 5, RGB(64, 150, 108));
        icon_photos(x, y, size, RGB(255,255,255));
        return;
    }

    color_t accent;
    const char* label = 0;
    if (extlen > 0) {
        accent = ft_fallback_color(ext, extlen);
        label = ext;
        for (int i = 0; i < FILETYPE_TABLE_COUNT; i++) {
            if (ft_ext_is(ext, FILETYPE_TABLE[i].ext)) {
                accent = FILETYPE_TABLE[i].color;
                label = FILETYPE_TABLE[i].label;
                break;
            }
        }
    } else {
        accent = RGB(150, 160, 178);
    }

    i32 fold = size * 5 / 16; if (fold < 3) fold = 3;
    i32 rr = size / 6; if (rr < 2) rr = 2;
    color_t paper = RGB(252, 252, 254);
    color_t foldc = RGB(210, 216, 230);
    color_t border = RGB(158, 166, 184);

    for (i32 j = 0; j < size; j++) {
        i32 py = y + j; if (py < 0 || (u32)py >= gfx.height) continue;
        for (i32 i = 0; i < size; i++) {
            int skip = 0;
            if (i < rr && j < rr) { i32 dx = rr-1-i, dy = rr-1-j; if (dx*dx+dy*dy > rr*rr) skip = 1; }
            else if (i < rr && j >= size-rr) { i32 dx = rr-1-i, dy = j-(size-rr); if (dx*dx+dy*dy > rr*rr) skip = 1; }
            else if (i >= size-rr && j >= size-rr) { i32 dx = i-(size-rr), dy = j-(size-rr); if (dx*dx+dy*dy > rr*rr) skip = 1; }
            if (skip) continue;
            color_t c;
            if (i >= size - fold && j <= fold) {
                i32 diff = (i - (size - fold)) - j;
                if (diff > 0) continue;
                c = foldc;
            } else {
                c = paper;
            }
            if (i == 0 || i == size-1 || j == 0 || j == size-1) c = border;
            i32 px = x + i; if (px < 0 || (u32)px >= gfx.width) continue;
            gfx_pixel(px, py, c);
        }
    }
    for (i32 tt = 0; tt <= fold; tt++) gfx_pixel(x + size - fold + tt, y + tt, border);
    gfx_vline(x + size - fold, y, fold, border);

    i32 bh = size * 26 / 100; if (bh < 5) bh = 5;
    i32 bw2 = size - size * 24 / 100;
    i32 bx = x + size * 12 / 100;
    i32 by = y + size - bh - size * 12 / 100;
    gfx_rounded_rect(bx, by, bw2, bh, bh / 3, accent);

    if (label && size >= 26) {
        int lw = gfx_string_width(label);
        if (lw <= bw2 - 2)
            gfx_string(bx + (bw2 - lw) / 2, by + (bh - FONT_H) / 2, label, RGB(255,255,255), accent, 0);
    } else {
        i32 lx0 = x + size * 24 / 100, lx1 = x + size * 66 / 100;
        i32 ly = y + size * 30 / 100;
        gfx_hline(lx0, ly, lx1 - lx0, RGB(198,204,216));
        gfx_hline(lx0, ly + size * 12 / 100, (lx1 - lx0) * 3 / 4, RGB(198,204,216));
    }
}

void folder_icon_draw(i32 x, i32 y, i32 size) {
    color_t body = RGB(94, 156, 224);
    color_t tab  = RGB(120, 178, 236);
    color_t edge = RGB(58, 112, 180);
    i32 bx = x + size * 6 / 100;
    i32 bw = size * 88 / 100;
    i32 topy = y + size * 30 / 100;
    i32 bh = size * 52 / 100;
    gfx_rounded_rect(bx + size * 4 / 100, y + size * 18 / 100, size * 44 / 100, size * 22 / 100, 2, tab);
    gfx_rounded_rect(bx, topy, bw, bh, 3, body);
    gfx_rounded_rect(bx, topy, bw, size * 12 / 100, 3, tab);
    gfx_rounded_rect_outline(bx, topy, bw, bh, 3, edge);
}

void znap_folder_icon_draw(i32 x, i32 y, i32 size) {
    color_t purple = RGB(150, 92, 222);
    color_t purple_lt = RGB(180, 128, 240);
    color_t blue = RGB(66, 118, 224);
    color_t blue_dk = RGB(42, 84, 188);
    color_t label = RGB(236, 236, 248);
    i32 bx = x + size * 6 / 100;
    i32 bw = size * 88 / 100;
    i32 body_y = y + size * 30 / 100;
    i32 body_h = size * 54 / 100;
    gfx_rounded_rect(bx + size * 4 / 100, y + size * 16 / 100, size * 46 / 100, size * 22 / 100, 2, purple);
    gfx_rounded_rect(bx, body_y, bw, body_h, 3, blue);
    gfx_rounded_rect(bx, body_y, bw, size * 20 / 100, 3, purple);
    gfx_rounded_rect(bx, body_y, bw, size * 6 / 100, 3, purple_lt);
    gfx_rounded_rect_outline(bx, body_y, bw, body_h, 3, blue_dk);
    if (size >= 34) {
        gfx_string(bx + size * 12 / 100, body_y + size * 30 / 100, ".znap", label, blue, 0);
    } else {
        i32 lw = size * 20 / 100, lh = size * 16 / 100;
        i32 lx = x + size / 2 - lw / 2, ly = body_y + body_h / 2 - lh / 4;
        gfx_rounded_rect(lx, ly, lw, lh, 1, label);
        gfx_rounded_rect_outline(lx + lw / 4, ly - lh / 2, lw / 2, lh / 2 + 1, 1, label);
    }
}
