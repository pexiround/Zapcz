#include "scroll.h"

i32 scroll_clamp(i32 offset, i32 content_h, i32 view_h) {
    i32 max_off = content_h - view_h;
    if (max_off < 0) max_off = 0;
    if (offset < 0) offset = 0;
    if (offset > max_off) offset = max_off;
    return offset;
}

static i32 thumb_geom(i32 track_h, i32 offset, i32 content_h, i32 view_h, i32* out_y) {
    i32 max_off = content_h - view_h;
    if (max_off < 0) max_off = 0;
    i32 th = (content_h > 0) ? (track_h * view_h / content_h) : track_h;
    if (th < 24) th = 24;
    if (th > track_h) th = track_h;
    i32 ty = 0;
    if (max_off > 0) ty = (track_h - th) * offset / max_off;
    *out_y = ty;
    return th;
}

void scroll_draw_bar(i32 x, i32 y, i32 h, i32 offset, i32 content_h, i32 view_h, color_t track, color_t thumb) {
    if (content_h <= view_h) return;
    gfx_rounded_rect(x, y, 8, h, 4, track);
    i32 ty;
    i32 th = thumb_geom(h, offset, content_h, view_h, &ty);
    gfx_rounded_rect(x, y + ty, 8, th, 4, thumb);
}

int scroll_bar_hit(i32 rx, i32 ry, i32 x, i32 y, i32 h, i32 content_h, i32 view_h) {
    if (content_h <= view_h) return 0;
    return (rx >= x && rx < x + 8 && ry >= y && ry < y + h);
}

i32 scroll_bar_drag_to(i32 ry, i32 y, i32 h, i32 content_h, i32 view_h) {
    i32 max_off = content_h - view_h;
    if (max_off <= 0) return 0;
    i32 dummy_ty;
    i32 th = thumb_geom(h, 0, content_h, view_h, &dummy_ty);
    i32 usable = h - th;
    if (usable <= 0) return max_off;
    i32 rel = ry - y - th / 2;
    if (rel < 0) rel = 0;
    if (rel > usable) rel = usable;
    return rel * max_off / usable;
}
