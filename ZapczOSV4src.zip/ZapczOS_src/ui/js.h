#ifndef JS_H
#define JS_H
#include "io.h"
#include "html.h"

void js_run(const char* src, u32 len, html_doc_t* doc);
const char* js_last_error(void);
int js_had_error(void);

#endif
