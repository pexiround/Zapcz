#include "desktop.h"
#include "screenshot.h"
static int demo_on;
#include "apprecover.h"
#include "graphics.h"
#include "apps.h"
#include "mouse.h"
#include "keyboard.h"
#include "boot_screen.h"
#include "crash.h"
#include "rtc.h"
#include "pit.h"
#include "libc_shim.h"
#include "mm.h"
#include "util.h"
#include "theme.h"
#include "appstore.h"
#include "icons.h"
#include "fat32.h"
#include "installer.h"
#include "accounts.h"
#include "net.h"
#include "io.h"
#include "scroll.h"
#include "wallpaper_bitmaps.h"
#include "config.h"
#include "battery.h"
#include "net.h"
#include "wifi.h"
#include "ath9k.h"
#include "iwlwifi.h"
#include "logo.h"
#include "accounts.h"

extern int g_iwl_available;

window_t windows[APP_COUNT];
static int z_order[APP_COUNT];

/* ---- virtual desktops (workspaces) ---- */
#define WS_COUNT 4
static int g_workspace = 0;
static int win_ws[APP_COUNT];          /* which workspace each window lives on */
static i32 g_pager_x = 0, g_pager_y = 0, g_pager_pw = 16, g_pager_gap = 4;
static i32 g_bell_x = 0, g_bell_y = 0, g_bell_w = 22, g_bell_h = 18;

/* ---- window open/close animation ----
   anim runs 0..100. Opening rises to 100, closing falls back to 0 and then
   actually hides the window, so closing reads as motion rather than a stall. */
static i32 win_anim[APP_COUNT];
static int win_closing[APP_COUNT];

void desktop_close_app(int app) {
    if (app < 0 || app >= APP_COUNT) return;
    if (!windows[app].visible) return;
    win_closing[app] = 1;              /* hidden once the animation finishes */
}

static int windows_animating(void) {
    for (int i = 0; i < APP_COUNT; i++)
        if (windows[i].visible && (win_closing[i] || win_anim[i] < 100)) return 1;
    return 0;
}

static void step_window_anim(void) {
    for (int i = 0; i < APP_COUNT; i++) {
        if (!windows[i].visible) { win_anim[i] = 0; win_closing[i] = 0; continue; }
        if (win_closing[i]) {
            win_anim[i] -= 22;
            if (win_anim[i] <= 0) {
                win_anim[i] = 0;
                win_closing[i] = 0;
                windows[i].visible = 0;
            }
        } else if (win_anim[i] < 100) {
            win_anim[i] += 20;
            if (win_anim[i] > 100) win_anim[i] = 100;
        }
    }
}

int  desktop_get_workspace(void) { return g_workspace; }
int  desktop_ws_count(void) { return WS_COUNT; }

/* A window is shown only if it is on the active workspace. */
static int win_on_ws(int app) { (void)app; return 1; }   /* single desktop */

static int ws_window_count(int ws) {
    int n = 0;
    for (int i = 0; i < APP_COUNT; i++)
        if (windows[i].visible && win_ws[i] == ws) n++;
    return n;
}

void desktop_set_workspace(int ws) {
    if (ws < 0 || ws >= WS_COUNT || ws == g_workspace) return;
    g_workspace = ws;
    gfx_mark_all_dirty();
}

/* Move the focused window to another workspace and follow it. */
void desktop_move_focused_to_ws(int ws) {
    if (ws < 0 || ws >= WS_COUNT) return;
    int a = desktop_focused_app();
    if (a < 0 || !windows[a].visible) return;
    win_ws[a] = ws;
    desktop_set_workspace(ws);
}
static int start_menu_open = 0;
static int ctx_menu_open = 0;
static i32 ctx_menu_x = 0, ctx_menu_y = 0;
static u32 start_menu_open_tick = 0;
static int dragging_app = -1;
static i32 drag_dx, drag_dy;
static int resizing_app = -1;
static int rz_mode = 0;
static i32 rz_ox, rz_oy, rz_ow, rz_oh;
#define WIN_MIN_W 240
#define WIN_MIN_H 150

static char sm_search_text[24] = "";
static u32 sm_search_len = 0;

#define SM_CAT_COUNT 6
static const char* SM_CATEGORIES[SM_CAT_COUNT] = {
    "Accessories", "Internet", "Graphics", "Games", "System Tools", "Utilities"
};
static const color_t SM_CAT_COLOR[SM_CAT_COUNT] = {
    {224,74,74}, {53,132,228}, {240,150,50}, {70,180,90}, {120,128,140}, {150,110,220}
};
static const int SM_APP_CATEGORY[APP_COUNT] = {
    3, 0, 5, 0, 4,
    4, 5, 3,
    1, 5, 4, 2,
    4, 4,
    0, 2, 3, 3,
    3, 3, 3,
    5, 5, 5, 0,
    0, 0, 4, 4
};
static int sm_open_cat = -1;

static i32 ui_scale_pct(void) {
    if (gfx.height >= 1400) return 175;
    if (gfx.height >= 1080) return 150;
    if (gfx.height >= 900)  return 130;
    if (gfx.height >= 720)  return 115;
    return 100;
}
/* user-selected UI/font scale: 0 = small, 1 = normal, 2 = large */
static int g_ui_size = 1;
static const int UI_SIZE_PCT[3] = { 85, 100, 120 };
int  desktop_get_ui_size(void) { return g_ui_size; }
void desktop_set_ui_size(int s) {
    if (s < 0 || s > 2 || s == g_ui_size) return;
    g_ui_size = s;
    desktop_invalidate_bg();
    gfx_mark_all_dirty();
}

i32 ui_scale(i32 base) {
    return (base * ui_scale_pct() * UI_SIZE_PCT[g_ui_size]) / 10000;
}

#define TASKBAR_H ui_scale(52)
#define TITLEBAR_H ui_scale(30)
#define MENUBAR_H 0

static int taskbar_top_pos = TASKBAR_BOTTOM;
void desktop_set_taskbar_position(int top) { taskbar_top_pos = top ? TASKBAR_TOP : TASKBAR_BOTTOM; }
int desktop_get_taskbar_position(void) { return taskbar_top_pos; }
static i32 g_taskbar_off = 0;
static int g_taskbar_opacity = 100;
void desktop_set_taskbar_opacity(int pct) { g_taskbar_opacity = pct < 15 ? 15 : (pct > 100 ? 100 : pct); }
int desktop_get_taskbar_opacity(void) { return g_taskbar_opacity; }
static int g_system_font = 0;
void desktop_set_system_font(int f) { g_system_font = (f < 0 || f >= FONT_STYLE_COUNT) ? 0 : f; }
int desktop_get_system_font(void) { return g_system_font; }
static char g_crash_name[40];
static const char* g_crash_reason = 0;
static char g_crash_loc[48];
static int g_crash_show = 0;
static i32 taskbar_y(void) {
    if (taskbar_top_pos == TASKBAR_TOP) return -g_taskbar_off;
    return (i32)gfx.height - TASKBAR_H + g_taskbar_off;
}
/* y for a popup/menu of height h that sits against the taskbar's inner edge */
static i32 taskbar_popup_y(i32 h) {
    if (taskbar_top_pos == TASKBAR_TOP) return taskbar_y() + TASKBAR_H + ui_scale(8);
    return taskbar_y() - h - ui_scale(8);
}
static int in_content_area(i32 my) {
    if (taskbar_top_pos == TASKBAR_TOP) return my >= taskbar_y() + TASKBAR_H && my < (i32)gfx.height;
    return my >= MENUBAR_H && my < taskbar_y();
}
#define TASKBAR_MARGIN_X ui_scale(14)
#define TASKBAR_MARGIN_Y ui_scale(8)
static i32 taskbar_bar_y(void) { return taskbar_y() + TASKBAR_MARGIN_Y; }
static i32 taskbar_bar_h(void) { return TASKBAR_H - TASKBAR_MARGIN_Y * 2; }
static i32 taskbar_start_x(void) { return TASKBAR_MARGIN_X + 8; }
static i32 taskbar_start_size(void) { return taskbar_bar_h() - 8; }
static i32 taskbar_start_y(void) { return taskbar_bar_y() + (taskbar_bar_h() - taskbar_start_size()) / 2; }
static int taskbar_hover_app = -1;
static u32 taskbar_hover_since = 0;
static i32 taskbar_hover_box_x = 0;
static i32 taskbar_hover_box_y = 0;

static const color_t APP_BADGE_COLOR[APP_COUNT] = {
    {70,140,255},
    {235,150,70},
    {230,180,70},
    {100,200,130},
    {160,120,235},
    {225,95,120},
    {70,190,195},
    {140,205,70},
    {90,170,235},
    {235,120,180},
    {150,155,165},
    {180,140,220},
    {235,180,90},
    {110,180,200},
    {235,150,70},
    {120,200,255},
    {150,210,110},
    {150,130,235},
    {200,40,40},
};

static color_t lighten(color_t c, int amt) {
    int r = c.r + amt, g = c.g + amt, b = c.b + amt;
    if (r > 255) r = 255;
    if (g > 255) g = 255;
    if (b > 255) b = 255;
    return RGB(r, g, b);
}

static color_t darken(color_t c, int amt) {
    int r = c.r - amt, g = c.g - amt, b = c.b - amt;
    if (r < 0) r = 0;
    if (g < 0) g = 0;
    if (b < 0) b = 0;
    return RGB(r, g, b);
}

static const i16 SIN_Q[91] = {
    0,17,35,52,70,87,105,122,139,156,174,191,208,225,242,259,276,292,309,326,
    342,358,375,391,407,423,438,454,469,485,500,515,530,545,559,574,588,602,616,629,
    643,656,669,682,695,707,719,731,743,755,766,777,788,799,809,819,829,839,848,857,
    866,875,883,891,899,906,914,921,927,934,940,946,951,956,961,966,970,974,978,982,
    985,988,990,993,995,996,998,999,999,1000,1000
};
static i32 isin1000(i32 deg) {
    deg %= 360; if (deg < 0) deg += 360;
    if (deg <= 90)  return SIN_Q[deg];
    if (deg <= 180) return SIN_Q[180 - deg];
    if (deg <= 270) return -SIN_Q[deg - 180];
    return -SIN_Q[360 - deg];
}

static color_t mix(color_t a, color_t b, i32 num, i32 den) {
    if (den <= 0) return a;
    if (num < 0) num = 0; if (num > den) num = den;
    return RGB(a.r + (b.r - a.r) * num / den,
               a.g + (b.g - a.g) * num / den,
               a.b + (b.b - a.b) * num / den);
}

static void power_off(void) {
    outw(0x604, 0x2000);
    outw(0xB004, 0x2000);
    outw(0x4004, 0x3400);
    for (;;) __asm__ volatile ("cli; hlt");
}

static void desktop_shutdown(void) {
    boot_screen_shutdown_init();
    boot_screen_section("Stopping desktop environment ...");
    boot_screen_log("Closing applications");        boot_screen_status(1);
    boot_screen_log("Saving session state");         boot_screen_status(1);
    boot_screen_section("Shutting down services ...");
    boot_screen_log("Bringing down network stack");  boot_screen_status(1);
    boot_screen_log("Flushing and unmounting filesystems"); boot_screen_status(1);
    boot_screen_log("Stopping timers and drivers");  boot_screen_status(1);
    boot_screen_section("Powering off ...");
    boot_screen_good("ZapczOS V4 halted");
    boot_screen_goodbye();
    power_off();
}

static const char* current_user_name(void) {
    int idx = accounts_current_index();
    const char* n = (idx >= 0) ? accounts_name_at(idx) : 0;
    return (n && n[0]) ? n : "User";
}

static void draw_badge(i32 x, i32 y, i32 size, int app_id, i32 corner_radius) {
    (void)corner_radius;
    icon_draw(app_id, x, y, size, RGB(255,255,255));
}

static int focused_app(void) {
    for (int i = APP_COUNT - 1; i >= 0; i--) {
        int a = z_order[i];
        if (windows[a].visible && !windows[a].minimized) return a;
    }
    return z_order[APP_COUNT - 1];
}
static void refresh_desktop_files(void);
void desktop_refresh_files(void) { refresh_desktop_files(); }

static void raise_app(int app_id) {
    int idx = -1;
    for (int i = 0; i < APP_COUNT; i++) if (z_order[i] == app_id) { idx = i; break; }
    if (idx < 0) return;
    for (int i = idx; i < APP_COUNT - 1; i++) z_order[i] = z_order[i + 1];
    z_order[APP_COUNT - 1] = app_id;
    windows[app_id].minimized = 0;
}

static void toggle_maximize(window_t* w) {
    if (w->maximized) {
        w->x = w->rx; w->y = w->ry; w->w = w->rw; w->h = w->rh;
        w->maximized = 0;
    } else {
        w->rx = w->x; w->ry = w->y; w->rw = w->w; w->rh = w->h;
        i32 margin = 16;
        i32 top = MENUBAR_H + TITLEBAR_H + margin;
        i32 bottom = (i32)gfx.height - TASKBAR_H - margin;
        w->x = margin;
        w->y = top;
        w->w = (i32)gfx.width - margin * 2;
        w->h = bottom - top;
        w->maximized = 1;
    }
}

void desktop_open_app(int app_id) {
    if (!windows[app_id].visible) { win_anim[app_id] = 0; win_closing[app_id] = 0; }
    windows[app_id].visible = 1;
    raise_app(app_id);
    start_menu_open = 0;
}

void desktop_reset_session(void) {
    for (int i = 0; i < APP_COUNT; i++) { windows[i].visible = 0; win_ws[i] = 0; }
    g_workspace = 0;
    start_menu_open = 0;
}

int desktop_focused_app(void) { return focused_app(); }

void desktop_init(void) {
    accounts_init();
    apps_init();

    const char* names[APP_COUNT] = {
        "2048", "Clock", "Files", "Editor", "Terminal",
        "Performance", "Wallpaper", "Snake",
        "Browser", "App Store", "Settings", "Photos", "Accounts", "Install OS",
        "Calculator", "Paint", "Tic-Tac-Toe", "3D Grapher", "Desktop Settings",
        "Minesweeper", "Game of Life",
        "Notifications", "Calendar", "Trash", "Writer", "Sheet", "Media", "Code", "Compiler"
    };
    i32 base_x = 70, base_y = 70;
    for (int i = 0; i < APP_COUNT; i++) {
        /* Cascade, but wrap so later apps do not start off the right/bottom
           edge of the screen (app 26+ used to open outside an 800x600 frame). */
        windows[i].x = base_x + (i % 10) * 26;
        windows[i].y = base_y + (i % 10) * 16;
        windows[i].w = 480;
        windows[i].h = 360;
        windows[i].visible = 0;
        windows[i].app_id = i;
        for (int c = 0; names[i][c]; c++) windows[i].title[c] = names[i][c];
        windows[i].title[strlen(names[i])] = 0;
        z_order[i] = i;
    }
    windows[APP_2048].w = 360; windows[APP_2048].h = 470;
    windows[APP_MINES].w = 320; windows[APP_MINES].h = 400;
    windows[APP_LIFE].w = 540; windows[APP_LIFE].h = 460;
    windows[APP_TERMINAL].w = 640; windows[APP_TERMINAL].h = 400;
    windows[APP_FILES].w = 600; windows[APP_FILES].h = 392;
    windows[APP_EDITOR].w = 560; windows[APP_EDITOR].h = 420;
    windows[APP_CLOCK].w = 320; windows[APP_CLOCK].h = 220;
    windows[APP_PERF].w = 400; windows[APP_PERF].h = 360;
    windows[APP_WALLPAPER].w = 600; windows[APP_WALLPAPER].h = 400;
    windows[APP_SNAKE].w = 490; windows[APP_SNAKE].h = 350;
    windows[APP_BROWSER].w = 620; windows[APP_BROWSER].h = 460;
    windows[APP_STORE].w = 560; windows[APP_STORE].h = 440;
    windows[APP_SETTINGS].w = 480; windows[APP_SETTINGS].h = 420;
    windows[APP_PHOTOS].w = 460; windows[APP_PHOTOS].h = 400;
    windows[APP_CALC].w = 280; windows[APP_CALC].h = 400;
    windows[APP_PAINT].w = 560; windows[APP_PAINT].h = 420;
    windows[APP_TTT].w = 360; windows[APP_TTT].h = 420;
    windows[APP_CUBE3D].w = 460; windows[APP_CUBE3D].h = 420;
    windows[APP_DESKSETTINGS].w = 470; windows[APP_DESKSETTINGS].h = 430;
    windows[APP_NOTIFY].w = 420;   windows[APP_NOTIFY].h = 400;
    windows[APP_CALENDAR].w = 420; windows[APP_CALENDAR].h = 380;
    windows[APP_TRASH].w = 440;    windows[APP_TRASH].h = 320;
    windows[APP_WRITER].w = 560;   windows[APP_WRITER].h = 460;
    windows[APP_SHEET].w = 600;    windows[APP_SHEET].h = 420;
    windows[APP_MEDIA].w = 520;    windows[APP_MEDIA].h = 400;
    windows[APP_IDE].w = 640;      windows[APP_IDE].h = 480;
    windows[APP_COMPILER].w = 680; windows[APP_COMPILER].h = 560;

    for (int i = 0; i < APP_COUNT; i++) {
        i32 maxw = (i32)gfx.width - 16;
        i32 maxh = (i32)gfx.height - 110;
        if (windows[i].w > maxw) windows[i].w = maxw;
        if (windows[i].h > maxh) windows[i].h = maxh;
        if (windows[i].x + windows[i].w > (i32)gfx.width - 8)
            windows[i].x = (i32)gfx.width - 8 - windows[i].w;
        if (windows[i].y + windows[i].h > (i32)gfx.height - 60)
            windows[i].y = (i32)gfx.height - 60 - windows[i].h;
        if (windows[i].x < 8) windows[i].x = 8;
        if (windows[i].y < TITLEBAR_H + 8) windows[i].y = TITLEBAR_H + 8;
    }
    windows[APP_DESKSETTINGS].x = 260; windows[APP_DESKSETTINGS].y = 120;
    windows[APP_ACCOUNTS].w = 480; windows[APP_ACCOUNTS].h = 460;
    windows[APP_INSTALLER].w = 600; windows[APP_INSTALLER].h = 600;

    for (int i = 0; i < APP_COUNT; i++) {
        if (i == APP_DESKSETTINGS) continue;
        windows[i].x = ui_scale(windows[i].x);
        windows[i].y = ui_scale(windows[i].y);
        windows[i].w = ui_scale(windows[i].w);
        windows[i].h = ui_scale(windows[i].h);
    }

    refresh_desktop_files();
}

int ui_point_in(i32 px, i32 py, i32 x, i32 y, i32 w, i32 h) {
    return px >= x && px < x + w && py >= y && py < y + h;
}

int ui_button(i32 x, i32 y, i32 w, i32 h, const char* label, int highlighted) {
    int hot = ui_point_in(mouse_x(), mouse_y(), x, y, w, h);
    color_t bg = highlighted ? THEME_ACCENT : (hot ? lighten(THEME_PANEL_RAISED, 10) : THEME_PANEL_RAISED);
    gfx_rounded_rect(x, y, w, h, THEME_RADIUS_CTRL, bg);
    color_t tc = highlighted ? THEME_ACCENT_TEXT : THEME_TEXT;
    int tw = gfx_string_width(label);
    gfx_string(x + (w - tw) / 2, y + (h - 16) / 2, label, tc, bg, 0);
    return hot && mouse_left_pressed();
}

static u8* bg_cache = 0;
static int bg_dirty = 1;
static int bg_variant = 0;
#define BG_VARIANTS 5

static int wp_active = 1;
static int wp_mode = BG_MODE_BITMAP;
static color_t wp_a, wp_b;
static const u8* wp_bitmap = WP_BMP_ALPINE_MIRROR;

void desktop_set_wallpaper(int mode, color_t a, color_t b, color_t c, color_t d, const u8* bitmap) {
    (void)c; (void)d;
    if (mode == BG_MODE_MOUNTAINS) { wp_active = 0; bg_variant = 0; bg_dirty = 1; return; }
    if (mode >= BG_MODE_AURORA && mode <= BG_MODE_SILK) {
        wp_active = 0; bg_variant = mode - BG_MODE_AURORA + 1; bg_dirty = 1; return;
    }
    wp_active = 1; wp_mode = mode; wp_a = a; wp_b = b; wp_bitmap = bitmap;
    bg_dirty = 1;
}

void desktop_cycle_wallpaper(void) {
    wp_active = 0;
    bg_variant = (bg_variant + 1) % BG_VARIANTS;
    bg_dirty = 1;
}

int desktop_get_wallpaper_variant(void) { return bg_variant; }

void desktop_set_wallpaper_variant(int v) {
    if (v < 0 || v >= BG_VARIANTS) return;
    wp_active = 0;
    bg_variant = v;
    bg_dirty = 1;
    gfx_mark_all_dirty();
}
int desktop_wallpaper_count(void) { return BG_VARIANTS; }

/* ---- power management ---- */
static int g_sleep_minutes = 0;      /* 0 = never */
static int g_lock_on_resume = 1;
static int g_power_saver = 0;
int  desktop_get_sleep_minutes(void) { return g_sleep_minutes; }
void desktop_set_sleep_minutes(int m) { if (m >= 0 && m <= 60) g_sleep_minutes = m; }
int  desktop_get_lock_on_resume(void) { return g_lock_on_resume; }
void desktop_set_lock_on_resume(int v) { g_lock_on_resume = v ? 1 : 0; }
int  desktop_get_power_saver(void) { return g_power_saver; }
void desktop_set_power_saver(int v) { g_power_saver = v ? 1 : 0; }

static int g_accent_idx = 0;
static const color_t ACCENT_PRESETS[6] = {
    {53, 132, 228}, {120, 80, 255}, {46, 170, 110}, {240, 150, 40}, {230, 80, 140}, {225, 70, 70}
};
void desktop_set_accent(int idx) {
    if (idx < 0) idx = 0;
    if (idx > 5) idx = 5;
    g_accent_idx = idx;
    color_t a = ACCENT_PRESETS[idx];
    THEME_ACCENT = a;
    /* The dim variant is a *background* for selected rows, so it has to follow
       the theme: a pale tint under dark text in light mode, a deep shade under
       light text in dark mode. Using one formula for both made selected text
       unreadable in light mode. */
    if (theme_get_mode() == THEME_MODE_LIGHT) {
        THEME_ACCENT_DIM = (color_t){ (u8)(200 + a.r / 5), (u8)(205 + a.g / 6), (u8)(215 + a.b / 7) };
    } else {
        THEME_ACCENT_DIM = (color_t){ (u8)(a.r / 2 + 20), (u8)(a.g / 2 + 20), (u8)(a.b / 2 + 20) };
    }
    THEME_ACCENT_TEXT = (color_t){255, 255, 255};
}
int desktop_get_accent(void) { return g_accent_idx; }
void desktop_invalidate_bg(void) { bg_dirty = 1; }

#define BG_MAX_W 2560
static i32 g_horizon[4][BG_MAX_W];

static void build_horizons(int W, int H) {
    static const struct { i32 base_pct; i32 a1; i32 f1; i32 p1; i32 a2; i32 f2; i32 p2; i32 a3; i32 f3; i32 p3; }
    L[4] = {
        { 40,  22, 5,  40,  10, 13, 200,  5, 27,  90 },
        { 53,  30, 4, 130,  16, 11,  20,  7, 23, 250 },
        { 66,  40, 3, 220,  22,  9, 150, 10, 17,  60 },
        { 80,  52, 2,  70,  30,  7, 300, 14, 15, 190 },
    };
    for (int l = 0; l < 4; l++) {
        i32 base = H * L[l].base_pct / 100;
        for (int x = 0; x < W && x < BG_MAX_W; x++) {
            i32 d1 = (x * L[l].f1) / 10 + L[l].p1;
            i32 d2 = (x * L[l].f2) / 10 + L[l].p2;
            i32 d3 = (x * L[l].f3) / 10 + L[l].p3;
            i32 y = base
                  - L[l].a1 * isin1000(d1) / 1000
                  - L[l].a2 * isin1000(d2) / 1000
                  - L[l].a3 * isin1000(d3) / 1000;
            g_horizon[l][x] = y;
        }
    }
}

static i32 wp_sin(i32 x) {
    x &= 1023;
    i32 sign = 1;
    if (x >= 512) { x -= 512; sign = -1; }
    i32 val = (4 * x * (512 - x)) / 256;
    return sign * val;
}
static u32 wp_hash(i32 x, i32 y) {
    u32 h = (u32)(x * 374761393 + y * 668265263);
    h = (h ^ (h >> 13)) * 1274126177u;
    return h ^ (h >> 16);
}
static int wp_clamp(int v) { return v < 0 ? 0 : (v > 255 ? 255 : v); }

static void render_background_into_cache(void) {
    if (!bg_cache) return;
    int W = (int)gfx.width, H = (int)gfx.height;
    u32 bypp = gfx.bypp;

    if (wp_active) {
        for (int y = 0; y < H; y++) {
            for (int x = 0; x < W; x++) {
                color_t c;
                if (wp_mode == BG_MODE_SOLID) {
                    c = wp_a;
                } else if (wp_mode == BG_MODE_BITMAP && wp_bitmap) {
                    i32 fxp = (W > 1) ? (x * (WALLPAPER_BMP_W - 1) * 256) / (W - 1) : 0;
                    i32 fyp = (H > 1) ? (y * (WALLPAPER_BMP_H - 1) * 256) / (H - 1) : 0;
                    i32 sx0 = fxp >> 8, sy0 = fyp >> 8;
                    i32 tx = fxp & 255, ty = fyp & 255;
                    i32 sx1 = (sx0 + 1 < WALLPAPER_BMP_W) ? sx0 + 1 : sx0;
                    i32 sy1 = (sy0 + 1 < WALLPAPER_BMP_H) ? sy0 + 1 : sy0;
                    const u8* p00 = wp_bitmap + ((u32)sy0 * WALLPAPER_BMP_W + (u32)sx0) * 3;
                    const u8* p10 = wp_bitmap + ((u32)sy0 * WALLPAPER_BMP_W + (u32)sx1) * 3;
                    const u8* p01 = wp_bitmap + ((u32)sy1 * WALLPAPER_BMP_W + (u32)sx0) * 3;
                    const u8* p11 = wp_bitmap + ((u32)sy1 * WALLPAPER_BMP_W + (u32)sx1) * 3;
                    i32 w00 = (256 - tx) * (256 - ty), w10 = tx * (256 - ty);
                    i32 w01 = (256 - tx) * ty,         w11 = tx * ty;
                    i32 rr = (p00[0]*w00 + p10[0]*w10 + p01[0]*w01 + p11[0]*w11) >> 16;
                    i32 gg = (p00[1]*w00 + p10[1]*w10 + p01[1]*w01 + p11[1]*w11) >> 16;
                    i32 bb = (p00[2]*w00 + p10[2]*w10 + p01[2]*w01 + p11[2]*w11) >> 16;
                    c = RGB((u8)rr, (u8)gg, (u8)bb);
                } else {
                    c = mix(wp_a, wp_b, y * 100, H * 100);
                }
                u32 off = (u32)y * W * bypp + (u32)x * bypp;
                bg_cache[off] = c.b; bg_cache[off+1] = c.g; bg_cache[off+2] = c.r;
                if (bypp == 4) bg_cache[off+3] = 0xFF;
            }
        }
        bg_dirty = 0;
        return;
    }

    int v = bg_variant;

    if (v == 0) build_horizons(W, H);

    int dark_bg = (theme_get_mode() == THEME_MODE_DARK);
    color_t sky_top  = dark_bg ? RGB(22, 26, 46)  : RGB(240, 180, 196);
    color_t sky_mid  = dark_bg ? RGB(28, 32, 54)  : RGB(210, 176, 218);
    color_t sky_haze = dark_bg ? RGB(40, 44, 70)  : RGB(190, 180, 228);
    color_t valley   = dark_bg ? RGB(26, 30, 50)  : RGB(206, 198, 232);
    color_t layer_col[4] = {
        dark_bg ? RGB(54, 60, 92) : RGB(202, 188, 226),
        dark_bg ? RGB(45, 51, 80) : RGB(180, 164, 216),
        dark_bg ? RGB(37, 43, 68) : RGB(157, 141, 202),
        dark_bg ? RGB(29, 35, 56) : RGB(132, 117, 186)
    };

    for (int y = 0; y < H; y++) {
        for (int x = 0; x < W; x++) {
            color_t c;
            if (v == 0) {
                if (y < H * 40 / 100) c = mix(sky_top, sky_mid, y * 100, H * 40);
                else c = mix(sky_mid, sky_haze, (y - H * 40 / 100) * 100, H * 60);
                int xi = x < BG_MAX_W ? x : BG_MAX_W - 1;
                for (int l = 0; l < 4; l++) {
                    i32 hy = g_horizon[l][xi];
                    if (y >= hy) {
                        color_t base = layer_col[l];
                        i32 depth = y - hy;
                        color_t shaded = mix(base, mix(base, RGB(255,255,255), 60, 100), depth, H / 2);
                        if (depth < 26) c = mix(mix(base, RGB(255,255,255), 55, 100), shaded, depth, 26);
                        else c = shaded;
                    }
                }
                if (y > H * 78 / 100) {
                    i32 t = (y - H * 78 / 100) * 100 / (H * 22 / 100 + 1);
                    c = mix(c, valley, t * 70 / 100, 100);
                }
            } else if (v == 1) {
                int rr = 10 + y * 26 / H, gg = 14 + y * 20 / H, bb = 46 + y * 34 / H;
                if (y < H * 60 / 100 && (wp_hash(x, y) % 850) < 2) {
                    int b = 190 + (int)(wp_hash(x + 7, y) % 60);
                    rr = b; gg = b; bb = b;
                }
                int by1 = H * 34 / 100 + wp_sin(x * 3) * (H * 9 / 100) / 1024;
                int d1 = by1 > y ? by1 - y : y - by1; int g1 = H * 13 / 100;
                if (d1 < g1) { int t = (g1 - d1) * 200 / g1; rr += 30 * t / 255; gg += 210 * t / 255; bb += 130 * t / 255; }
                int by2 = H * 46 / 100 + wp_sin(x * 4 + 300) * (H * 7 / 100) / 1024;
                int d2 = by2 > y ? by2 - y : y - by2; int g2 = H * 10 / 100;
                if (d2 < g2) { int t = (g2 - d2) * 170 / g2; rr += 40 * t / 255; gg += 170 * t / 255; bb += 200 * t / 255; }
                int by3 = H * 27 / 100 + wp_sin(x * 2 + 620) * (H * 11 / 100) / 1024;
                int d3 = by3 > y ? by3 - y : y - by3; int g3 = H * 9 / 100;
                if (d3 < g3) { int t = (g3 - d3) * 150 / g3; rr += 130 * t / 255; gg += 70 * t / 255; bb += 190 * t / 255; }
                c = RGB(wp_clamp(rr), wp_clamp(gg), wp_clamp(bb));
            } else if (v == 2) {
                int rr = 6 + y * 10 / H, gg = 5 + y * 6 / H, bb = 12 + y * 20 / H;
                int n1 = (wp_sin(x * 2 + y) + 1024) / 2;
                int n2 = (wp_sin(y * 3 - x + 200) + 1024) / 2;
                int n3 = (wp_sin(x + y * 2 + 500) + 1024) / 2;
                int cloud = (n1 * n2) / 1024;
                rr += cloud * 165 / 1024 + (n3 * 40 / 1024);
                gg += (n2 * n3 / 1024) * 70 / 1024 + cloud * 30 / 1024;
                bb += cloud * 150 / 1024 + n3 * 130 / 1024;
                gg += n3 * 60 / 1024;
                if ((wp_hash(x, y) % 1100) < 2) { int b = 200 + (int)(wp_hash(y, x) % 56); rr = b; gg = b; bb = b; }
                c = RGB(wp_clamp(rr), wp_clamp(gg), wp_clamp(bb));
            } else if (v == 3) {
                int horizon = H * 70 / 100;
                int rr, gg, bb;
                if (y < horizon) {
                    int t = y * 1024 / horizon;
                    if (t < 512) { int u = t * 1024 / 512; rr = 46 + (250 - 46) * u / 1024; gg = 32 + (150 - 32) * u / 1024; bb = 92 + (70 - 92) * u / 1024; }
                    else { int u = (t - 512) * 1024 / 512; rr = 250 + (255 - 250) * u / 1024; gg = 150 + (225 - 150) * u / 1024; bb = 70 + (140 - 70) * u / 1024; }
                } else {
                    int u = (y - horizon) * 1024 / (H - horizon + 1);
                    rr = 250 - 200 * u / 1024; gg = 130 - 110 * u / 1024; bb = 90 - 40 * u / 1024;
                }
                int sunx = W / 2, suny = horizon - H * 6 / 100, sunr = H * 11 / 100;
                long dx = x - sunx, dy = (y - suny) * 100 / 62; long dd = dx * dx + dy * dy; long rr2 = (long)sunr * sunr;
                if (dd < rr2) { rr = rr + (255 - rr) * 3 / 4; gg = gg + (246 - gg) * 3 / 4; bb = bb + (205 - bb) * 3 / 4; }
                else if (dd < rr2 * 6) { long t = (rr2 * 6 - dd) * 255 / (rr2 * 5); rr += (int)(90 * t / 255); gg += (int)(60 * t / 255); bb += (int)(10 * t / 255); }
                c = RGB(wp_clamp(rr), wp_clamp(gg), wp_clamp(bb));
            } else {
                int wv = wp_sin((x + y) * 2 + wp_sin(x * 3) / 4);
                int t = (wv + 1024) / 2;
                color_t a = mix(RGB(28, 176, 176), RGB(120, 60, 200), x * 1024 / W, 1024);
                color_t b = mix(RGB(120, 60, 200), RGB(230, 120, 190), y * 1024 / H, 1024);
                c = mix(a, b, t, 1024);
                int lift = wp_sin((x - y) * 3 + 200) / 12;
                c = RGB(wp_clamp(c.r + lift), wp_clamp(c.g + lift), wp_clamp(c.b + lift));
            }
            u32 off = (u32)y * W * bypp + (u32)x * bypp;
            bg_cache[off] = c.b; bg_cache[off+1] = c.g; bg_cache[off+2] = c.r;
            if (bypp == 4) bg_cache[off+3] = 0xFF;
        }
    }
    bg_dirty = 0;
}

static void draw_background(void) {
    u32 bytes = gfx.width * gfx.height * gfx.bypp;
    if (!bg_cache) {
        bg_cache = (u8*)kmalloc(bytes);
        bg_dirty = 1;
    }
    if (!bg_cache) {
        gfx_gradient_v(0, 0, (i32)gfx.width, (i32)gfx.height, THEME_BG_TOP, THEME_BG_BOTTOM);
        return;
    }
    if (bg_dirty) render_background_into_cache();
    memcpy(gfx.back, bg_cache, bytes);
}

static void draw_background_band(i32 y0, i32 y1) {
    if (y0 < 0) y0 = 0;
    if (y1 > (i32)gfx.height) y1 = (i32)gfx.height;
    if (y0 >= y1) return;
    if (!bg_cache) { draw_background(); return; }
    if (bg_dirty) render_background_into_cache();
    u32 row = gfx.width * gfx.bypp;
    memcpy(gfx.back + (u32)y0 * row, bg_cache + (u32)y0 * row, row * (u32)(y1 - y0));
}

#define DESKTOP_ICON_W ui_scale(80)
#define DESKTOP_ICON_H ui_scale(80)
#define DESKTOP_ICON_SIZE ui_scale(42)
#define DESKTOP_ICONS_MAX 32

static const int DESKTOP_APPS[] = {
    APP_FILES, APP_BROWSER, APP_TERMINAL, APP_STORE, APP_WALLPAPER, APP_SETTINGS
};
#define DESKTOP_APPS_N ((int)(sizeof(DESKTOP_APPS)/sizeof(DESKTOP_APPS[0])))

static int desktop_icons_hidden = 0;
#define DESKTOP_SLOTS_MAX 64
static i32 icon_pos_x[DESKTOP_SLOTS_MAX];
static i32 icon_pos_y[DESKTOP_SLOTS_MAX];
static int icon_pos_set[DESKTOP_SLOTS_MAX];
static int icon_drag_slot = -1;
static int icon_drag_moved = 0;
static i32 icon_drag_dx = 0, icon_drag_dy = 0;
static fat_dirent_t desktop_files[DESKTOP_ICONS_MAX];
static int desktop_files_count = 0;
static int desktop_selected_file = -1;
static u32 desktop_last_click_tick = 0;
static int desktop_last_click_idx = -1;

static int is_hidden_system_file(const char* name) {
    return str_eq_ci(name, "ZAPCZUSR.DAT") || str_eq_ci(name, "ZAPCZCFG.DAT");
}

static void refresh_desktop_files(void) {
    fat_dirent_t raw[DESKTOP_ICONS_MAX];
    int raw_count = fat32_available() ? fat32_list_root(raw, DESKTOP_ICONS_MAX) : 0;
    desktop_files_count = 0;
    for (int i = 0; i < raw_count; i++) {
        if (raw[i].is_dir) continue;
        if (is_hidden_system_file(raw[i].display_name)) continue;
        desktop_files[desktop_files_count++] = raw[i];
    }
    if (desktop_selected_file >= desktop_files_count) desktop_selected_file = -1;
}

static void desktop_icon_pos(int idx, i32* ox, i32* oy) {
    if (idx >= 0 && idx < DESKTOP_SLOTS_MAX && icon_pos_set[idx]) {
        *ox = icon_pos_x[idx]; *oy = icon_pos_y[idx];
        return;
    }
    i32 top_margin = MENUBAR_H + 16;
    i32 bottom_margin = TASKBAR_H + 16;
    i32 avail_h = (i32)gfx.height - top_margin - bottom_margin;
    int rows = avail_h / DESKTOP_ICON_H;
    if (rows < 1) rows = 1;
    int col = idx / rows, row = idx % rows;
    *ox = 16 + col * DESKTOP_ICON_W;
    *oy = top_margin + row * DESKTOP_ICON_H;
}

static void draw_desktop_label(i32 ix, i32 iy, const char* name, int sel) {
    char label[16];
    str_copy(label, name, 16);
    int lw = gfx_string_width(label);
    i32 lx = ix + (DESKTOP_ICON_W - 8 - lw) / 2;
    if (lx < ix) lx = ix;
    i32 ly2 = iy + DESKTOP_ICON_SIZE + 10;
    color_t lblc, shadow;
    if (sel) { lblc = RGB(255,255,255); shadow = RGB(24,44,84); }
    else if (theme_get_mode() == THEME_MODE_DARK) { lblc = RGB(240,243,250); shadow = RGB(12,16,24); }
    else { lblc = RGB(250,251,254); shadow = RGB(28,32,42); }
    if (sel) {
        gfx_rounded_rect(lx - 5, ly2 - 2, lw + 10, 16, 5, THEME_ACCENT);
    }
    gfx_string(lx + 1, ly2 + 1, label, shadow, shadow, 0);
    gfx_string(lx, ly2, label, lblc, shadow, 0);
}

static void draw_desktop_icons(void) {
    if (desktop_icons_hidden) return;
    for (int a = 0; a < DESKTOP_APPS_N; a++) {
        i32 ix, iy;
        desktop_icon_pos(a, &ix, &iy);
        int hot = ui_point_in(mouse_x(), mouse_y(), ix, iy, DESKTOP_ICON_W - 8, DESKTOP_ICON_H - 6);
        if (hot) gfx_rounded_rect(ix - 2, iy - 2, DESKTOP_ICON_W - 4, DESKTOP_ICON_H - 2, 8, THEME_PANEL_ALT);
        i32 tx = ix + (DESKTOP_ICON_W - 8 - DESKTOP_ICON_SIZE) / 2;
        icon_draw(DESKTOP_APPS[a], tx, iy + 4, DESKTOP_ICON_SIZE, RGB(255,255,255));
        draw_desktop_label(ix, iy, windows[DESKTOP_APPS[a]].title, 0);
    }
    for (int i = 0; i < desktop_files_count; i++) {
        i32 ix, iy;
        desktop_icon_pos(i + DESKTOP_APPS_N, &ix, &iy);
        int hot = ui_point_in(mouse_x(), mouse_y(), ix, iy, DESKTOP_ICON_W - 8, DESKTOP_ICON_H - 6);
        int sel = (i == desktop_selected_file);

        if (sel) {
            gfx_rounded_rect(ix - 2, iy - 2, DESKTOP_ICON_W - 4, DESKTOP_ICON_H - 2, 8, THEME_ACCENT_DIM);
        } else if (hot) {
            gfx_rounded_rect(ix - 2, iy - 2, DESKTOP_ICON_W - 4, DESKTOP_ICON_H - 2, 8, THEME_PANEL_ALT);
        }

        i32 tx = ix + (DESKTOP_ICON_W - 8 - DESKTOP_ICON_SIZE) / 2;
        filetype_icon_draw(tx, iy + 4, DESKTOP_ICON_SIZE, desktop_files[i].display_name);

        draw_desktop_label(ix, iy, desktop_files[i].display_name, sel);
    }
}

static i32 win_corner_inset(i32 dy, i32 r) {
    i32 rr = r * r - dy * dy;
    if (rr < 0) return r;
    i32 sv = 0;
    while ((sv + 1) * (sv + 1) <= rr) sv++;
    return r - sv;
}
static void restore_bg_px(i32 x, i32 y) {
    if (x < 0 || y < 0 || (u32)x >= gfx.width || (u32)y >= gfx.height) return;
    if (!bg_cache) return;
    u32 off = ((u32)y * gfx.width + (u32)x) * gfx.bypp;
    gfx.back[off] = bg_cache[off];
    gfx.back[off + 1] = bg_cache[off + 1];
    gfx.back[off + 2] = bg_cache[off + 2];
    if (gfx.bypp == 4) gfx.back[off + 3] = bg_cache[off + 3];
}
static void round_window_bottom(window_t* win) {
    i32 r = THEME_RADIUS_WIN;
    i32 bx = win->x, bw = win->w, by = win->y + win->h;
    for (i32 k = 0; k < r; k++) {
        i32 yy = by - 1 - k;
        i32 inset = win_corner_inset(r - 1 - k, r);
        for (i32 xx = bx; xx < bx + inset; xx++) restore_bg_px(xx, yy);
        for (i32 xx = bx + bw - inset; xx < bx + bw; xx++) restore_bg_px(xx, yy);
    }
}
/* Run app code with a recovery point armed. If the app wedges, the timer
   interrupt unwinds us back here and we report it instead of hanging. */
static app_ctx_t g_app_ctx;
static int g_app_hung_pending = -1;
static int g_app_hung_reported = -1;

static int guard_enter(int app_id) {
    if (app_ctx_save(g_app_ctx) != 0) {
        /* we got here by being unwound out of a hung app */
        g_app_hung_pending = app_guard_hung_app();
        return 0;
    }
    app_guard_arm(g_app_ctx, app_id);
    return 1;
}
static void guard_leave(void) { app_guard_disarm(); }

static void draw_window(window_t* win, int is_focused) {
    if (!win->visible || win->minimized) return;

    /* rise-and-settle on open, sink on close */
    i32 a = win_anim[win->app_id];
    if (a < 0) a = 0; if (a > 100) a = 100;
    i32 rise = ((100 - a) * ui_scale(14)) / 100;

    i32 outer_y = win->y - TITLEBAR_H + rise;
    i32 outer_h  = win->h + TITLEBAR_H;
    i32 r = THEME_RADIUS_WIN;

    /* soft ambient shadow: three faint layers instead of one hard slab */
    if (is_focused) {
        gfx_glass_rounded_rect(win->x - 2, outer_y + 10, win->w + 4, outer_h + 2, r + 4, RGB(40,48,68), 7);
        gfx_glass_rounded_rect(win->x - 1, outer_y + 6,  win->w + 2, outer_h + 1, r + 3, RGB(40,48,68), 9);
        gfx_glass_rounded_rect(win->x,     outer_y + 3,  win->w,     outer_h,     r + 1, RGB(40,48,68), 11);
    } else {
        gfx_glass_rounded_rect(win->x - 1, outer_y + 5, win->w + 2, outer_h + 1, r + 2, RGB(50,58,78), 6);
        gfx_glass_rounded_rect(win->x,     outer_y + 2, win->w,     outer_h,     r + 1, RGB(50,58,78), 7);
    }

    gfx_rounded_rect(win->x, outer_y, win->w, outer_h, r, THEME_WINDOW);

    /* hairline edge, no glow */
    gfx_rounded_rect_outline(win->x, outer_y, win->w, outer_h, r,
                             is_focused ? THEME_GLOW_BORDER : THEME_GLOW_DIM);

    /* flat titlebar that reads as part of the window, separated by a hairline */
    color_t tb = is_focused ? THEME_TITLEBAR_FOCUS : THEME_TITLEBAR_TOP;
    gfx_rounded_rect_top(win->x, outer_y, win->w, TITLEBAR_H, r, tb);
    gfx_rect(win->x, outer_y + TITLEBAR_H - 1, win->w, 1, THEME_SEP);

    gfx_rect(win->x, win->y + rise, win->w, win->h, THEME_WINDOW);

    i32 dot_cy = outer_y + TITLEBAR_H / 2;
    i32 close_cx = win->x + 19, min_cx = win->x + 39, max_cx = win->x + 59;
    int dot_r = 6;
    int hot_c = ui_point_in(mouse_x(), mouse_y(), close_cx - 8, dot_cy - 8, 16, 16);
    int hot_m = ui_point_in(mouse_x(), mouse_y(), min_cx - 8, dot_cy - 8, 16, 16);
    int hot_x = ui_point_in(mouse_x(), mouse_y(), max_cx - 8, dot_cy - 8, 16, 16);

    if (is_focused) {
        gfx_circle_fill(close_cx, dot_cy, dot_r, hot_c ? RGB(255,105,97)  : RGB(237,106,94));
        gfx_circle_fill(min_cx,   dot_cy, dot_r, hot_m ? RGB(255,205,70)   : RGB(228,180,64));
        gfx_circle_fill(max_cx,   dot_cy, dot_r, hot_x ? RGB(105,222,100)  : RGB(97,197,84));
    } else {
        color_t dim = RGB(215,218,224);
        gfx_circle_fill(close_cx, dot_cy, dot_r, dim);
        gfx_circle_fill(min_cx,   dot_cy, dot_r, dim);
        gfx_circle_fill(max_cx,   dot_cy, dot_r, dim);
    }
    if (hot_c && is_focused) {
        gfx_line(close_cx-3, dot_cy-3, close_cx+3, dot_cy+3, RGB(100,15,15));
        gfx_line(close_cx+3, dot_cy-3, close_cx-3, dot_cy+3, RGB(100,15,15));
    }
    if (hot_m && is_focused) gfx_rect(min_cx-3, dot_cy, 6, 1, RGB(100,70,10));
    if (hot_x && is_focused) gfx_rounded_rect_outline(max_cx-3, dot_cy-3, 6, 6, 1, RGB(10,60,15));

    i32 title_x = win->x + 88;
    draw_badge(title_x, outer_y + (TITLEBAR_H - 18) / 2, 18, win->app_id, -1);
    gfx_string(title_x + 24, outer_y + (TITLEBAR_H - 16) / 2, win->title,
               is_focused ? RGB(233,234,241) : RGB(150,152,166), RGB(0,0,0), 0);

    clip_t c = { win->x, win->y, win->x + win->w, win->y + win->h };
    gfx_set_clip(c);
    g_crash_app = win->app_id;
    if (!guard_enter(win->app_id)) { gfx_clear_clip(); g_crash_app = -1; return; }
    if (app_draw_table[win->app_id])
        app_draw_table[win->app_id](win->x, win->y, win->w, win->h);
    guard_leave();
    g_crash_app = -1;
    gfx_clear_clip();

    round_window_bottom(win);
    if (is_focused)
        gfx_glow_border(win->x, outer_y, win->w, outer_h, r, THEME_GLOW_BORDER, 2);
    else
        gfx_rounded_rect_outline(win->x, outer_y, win->w, outer_h, r, THEME_GLOW_DIM);

    i32 gx = win->x + win->w - 4, gy = win->y + win->h - 4;
    int hot_grip = ui_point_in(mouse_x(), mouse_y(), win->x + win->w - 18, win->y + win->h - 18, 22, 22);
    color_t grip = hot_grip ? THEME_ACCENT : (is_focused ? THEME_TEXT_FAINT : THEME_GLOW_DIM);
    for (int k = 1; k <= 4; k++)
        gfx_line(gx - k * 5, gy, gx, gy - k * 5, grip);
}

static int taskbar_icon_button(i32 x, i32 y, i32 size, int app_id, int is_focused) {
    int hot = ui_point_in(mouse_x(), mouse_y(), x, y, size, size);
    if (is_focused) {
        gfx_glass_rect(x - 4, y - 4, size + 8, size + 8, THEME_ACCENT, 28);
        gfx_rounded_rect_outline(x - 3, y - 3, size + 6, size + 6, 6, THEME_ACCENT);
    }
    draw_badge(x, y, size, app_id, 0);
    if (hot && !is_focused) gfx_glass_rect(x-2, y-2, size+4, size+4, RGB(255,255,255), 8);
    return hot && mouse_left_pressed();
}


static i32 g_net_icon_x = 0, g_net_icon_y = 0;
static i32 g_net_icon_w = 20, g_net_icon_h = 56;
static int g_wifi_popup_open = 0;
static wifi_bss_t g_wifi_scan_results[8];
static u32 g_wifi_scan_count = 0;
static int g_wifi_selected = -1;
static char g_wifi_pass_buf[64];
static u32 g_wifi_pass_len = 0;
static char g_wifi_status_msg[64];

static void wifi_popup_rect(i32* ox, i32* oy, i32* ow, i32* oh) {
    i32 pw = ui_scale(300), ph = ui_scale(252);
    i32 px = g_net_icon_x + g_net_icon_w / 2 + ui_scale(12) - pw;
    if (px + pw > (i32)gfx.width - ui_scale(8)) px = (i32)gfx.width - ui_scale(8) - pw;
    if (px < ui_scale(8)) px = ui_scale(8);
    i32 py = taskbar_popup_y(ph);
    if (py < ui_scale(8)) py = ui_scale(8);
    if (py + ph > (i32)gfx.height - ui_scale(8)) py = (i32)gfx.height - ui_scale(8) - ph;
    *ox = px; *oy = py; *ow = pw; *oh = ph;
}

static i32 wifi_row_top(i32 py) { return py + ui_scale(40); }
#define WIFI_ROW_H ui_scale(28)

static void draw_wifi_popup(void) {
    i32 px, py, pw, ph;
    wifi_popup_rect(&px, &py, &pw, &ph);
    color_t bg = THEME_WINDOW;

    gfx_glass_rounded_rect(px + 2, py + 4, pw, ph, 10, RGB(60, 70, 95), 18);
    gfx_rounded_rect(px, py, pw, ph, 10, bg);
    gfx_rounded_rect_outline(px, py, pw, ph, 10, THEME_BORDER);
    gfx_string(px + 14, py + 12, "Network", THEME_TEXT, bg, 0);
    gfx_rect(px + 14, py + 30, pw - 28, 1, THEME_SEP);

    int ns = net_state();
    const char* eth = ns == 2 ? "Connected" : ns == 1 ? "Link, no IP" : "Not connected";
    color_t ec = ns == 2 ? THEME_SUCCESS : ns == 1 ? THEME_WARNING : THEME_TEXT_FAINT;

    const char* unsup = wifi_detect_unsupported();
    if (!wifi_available()) {
        i32 yy = py + ui_scale(42);
        if (unsup) {
            gfx_string(px + 14, yy, unsup, THEME_TEXT, bg, 0); yy += ui_scale(20);
            gfx_string(px + 14, yy, "Firmware bundled; driver is", THEME_TEXT_DIM, bg, 0); yy += ui_scale(16);
            gfx_string(px + 14, yy, "experimental. Powers up but", THEME_TEXT_DIM, bg, 0); yy += ui_scale(16);
            gfx_string(px + 14, yy, "cannot associate yet -- use", THEME_WARNING, bg, 0); yy += ui_scale(16);
            gfx_string(px + 14, yy, "Ethernet on this machine.", THEME_WARNING, bg, 0); yy += ui_scale(20);
            {
                extern int iwl_detect_family(void);
                int fam = iwl_detect_family();
                char fl[48];
                str_copy(fl, "Chip family: ", sizeof(fl));
                if (fam) { char nb[12]; u32_to_str((u32)fam, nb); str_cat(fl, nb, sizeof(fl)); }
                else str_copy(fl, "Chip family: none detected", sizeof(fl));
                gfx_string(px + 14, yy, fl, THEME_TEXT_FAINT, bg, 0); yy += ui_scale(16);

                const char* st = iwl_status();
                if (st && st[0]) { gfx_string(px + 14, yy, st, THEME_TEXT_FAINT, bg, 0); yy += ui_scale(16); }
                gfx_string(px + 14, yy, "Firmware boots; scan/assoc not",
                           THEME_TEXT_FAINT, bg, 0); yy += ui_scale(16);
                gfx_string(px + 14, yy, "implemented (no MVM RX path).",
                           THEME_TEXT_FAINT, bg, 0); yy += ui_scale(16);
            }
        } else {
            gfx_string(px + 14, yy, "No WiFi adapter detected.", THEME_TEXT_DIM, bg, 0); yy += ui_scale(20);
            gfx_string(px + 14, yy, "Atheros AR9xxx works natively;", THEME_TEXT_FAINT, bg, 0); yy += ui_scale(16);
            gfx_string(px + 14, yy, "otherwise use Ethernet.", THEME_TEXT_FAINT, bg, 0); yy += ui_scale(20);
        }
        gfx_string(px + 14, py + ph - ui_scale(26), "Ethernet:", THEME_TEXT_DIM, bg, 0);
        gfx_string(px + ui_scale(84), py + ph - ui_scale(26), eth, ec, bg, 0);
        return;
    }

    if (g_wifi_scan_count == 0) {
        gfx_string(px + 14, py + ui_scale(44), "No networks found", THEME_TEXT_DIM, bg, 0);
        int hot = ui_point_in(mouse_x(), mouse_y(), px + 14, py + ui_scale(66), ui_scale(80), ui_scale(24));
        gfx_rounded_rect(px + 14, py + ui_scale(66), ui_scale(80), ui_scale(24), 6, hot ? THEME_ACCENT : THEME_ACCENT_DIM);
        gfx_string(px + ui_scale(32), py + ui_scale(70), "Scan", hot ? THEME_ACCENT_TEXT : THEME_ACCENT, bg, 0);
        gfx_string(px + 14, py + ph - ui_scale(26), "Ethernet:", THEME_TEXT_DIM, bg, 0);
        gfx_string(px + ui_scale(84), py + ph - ui_scale(26), eth, ec, bg, 0);
        return;
    }

    i32 ry = wifi_row_top(py);
    for (u32 i = 0; i < g_wifi_scan_count && i < 5; i++) {
        int sel = ((i32)i == g_wifi_selected);
        color_t rbg = sel ? THEME_ACCENT_DIM : THEME_PANEL_ALT;
        gfx_rounded_rect(px + 10, ry, pw - 20, ui_scale(24), 5, rbg);
        if (sel) gfx_rounded_rect_outline(px + 10, ry, pw - 20, ui_scale(24), 5, THEME_ACCENT);
        gfx_string(px + 16, ry + ui_scale(4), g_wifi_scan_results[i].ssid, THEME_TEXT, rbg, 0);
        if (g_wifi_scan_results[i].has_wpa2) {
            i32 lx = px + pw - ui_scale(52), lyy = ry + ui_scale(7);
            gfx_rounded_rect_outline(lx + 1, lyy - 3, 6, 5, 2, THEME_TEXT_DIM);
            gfx_rounded_rect(lx, lyy, 8, 6, 1, THEME_TEXT_DIM);
        }
        char rssi_s[16]; i32_to_str(g_wifi_scan_results[i].rssi, rssi_s);
        gfx_string(px + pw - ui_scale(36), ry + ui_scale(4), rssi_s, THEME_TEXT_FAINT, rbg, 0);
        ry += WIFI_ROW_H;
    }

    if (g_wifi_selected >= 0) {
        gfx_rounded_rect(px + 10, ry, pw - 20, ui_scale(22), 5, RGB(255,255,255));
        gfx_rounded_rect_outline(px + 10, ry, pw - 20, ui_scale(22), 5, THEME_BORDER);
        char pwd_display[64]; u32 pd = 0;
        for (u32 i = 0; i < g_wifi_pass_len && pd < 40; i++) pwd_display[pd++] = '*';
        pwd_display[pd] = 0;
        if (pd == 0) str_copy(pwd_display, "Password...", 64);
        gfx_string(px + 16, ry + ui_scale(3), pwd_display, g_wifi_pass_len ? THEME_TEXT : THEME_TEXT_FAINT, RGB(255,255,255), 0);
        ry += ui_scale(26);
        int hot = ui_point_in(mouse_x(), mouse_y(), px + 10, ry, pw - 20, ui_scale(24));
        gfx_rounded_rect(px + 10, ry, pw - 20, ui_scale(24), 6, hot ? lighten(THEME_ACCENT, 8) : THEME_ACCENT);
        i32 cwid = gfx_string_width("Connect");
        gfx_string(px + (pw - cwid) / 2, ry + ui_scale(4), "Connect", THEME_ACCENT_TEXT, THEME_ACCENT, 0);
    }

    if (g_wifi_status_msg[0])
        gfx_string(px + 14, py + ph - ui_scale(22), g_wifi_status_msg, THEME_TEXT_DIM, bg, 0);
}

static int wifi_popup_handle_click(i32 mx, i32 my) {
    if (!g_wifi_popup_open) return 0;
    i32 px, py, pw, ph;
    wifi_popup_rect(&px, &py, &pw, &ph);
    if (!ui_point_in(mx, my, px, py, pw, ph)) { g_wifi_popup_open = 0; return 1; }
    if (!wifi_available()) return 1;
    if (g_wifi_scan_count == 0) {
        if (ui_point_in(mx, my, px + 14, py + ui_scale(66), ui_scale(80), ui_scale(24))) {
            u32 cnt = 0; wifi_scan(g_wifi_scan_results, 8, &cnt); g_wifi_scan_count = cnt;
        }
        return 1;
    }
    i32 ry = wifi_row_top(py);
    for (u32 i = 0; i < g_wifi_scan_count && i < 5; i++) {
        if (ui_point_in(mx, my, px + 10, ry, pw - 20, ui_scale(24))) {
            g_wifi_selected = (i32)i;
            g_wifi_pass_len = 0; g_wifi_pass_buf[0] = 0; g_wifi_status_msg[0] = 0;
            return 1;
        }
        ry += WIFI_ROW_H;
    }
    if (g_wifi_selected >= 0) {
        i32 connect_y = ry + ui_scale(26);
        if (ui_point_in(mx, my, px + 10, connect_y, pw - 20, ui_scale(24))) {
            str_copy(g_wifi_status_msg, "Connecting...", 64);
            int ok = wifi_connect(g_wifi_scan_results[g_wifi_selected].ssid, g_wifi_pass_buf);
            str_copy(g_wifi_status_msg, ok ? "Connected" : "Failed - check password", 64);
        }
    }
    return 1;
}

static int wifi_popup_handle_key(int key) {
    if (!g_wifi_popup_open || g_wifi_selected < 0) return 0;
    if (key == KEY_BACKSPACE) {
        if (g_wifi_pass_len > 0) g_wifi_pass_buf[--g_wifi_pass_len] = 0;
    } else if (key == KEY_ENTER) {
        str_copy(g_wifi_status_msg, "Connecting...", 64);
        int ok = wifi_connect(g_wifi_scan_results[g_wifi_selected].ssid, g_wifi_pass_buf);
        str_copy(g_wifi_status_msg, ok ? "Connected!" : "Failed - check password", 64);
    } else if (key == KEY_ESC) {
        g_wifi_popup_open = 0;
    } else if (kbd_is_printable(key)) {
        if (g_wifi_pass_len < 63) {
            g_wifi_pass_buf[g_wifi_pass_len++] = (char)key;
            g_wifi_pass_buf[g_wifi_pass_len] = 0;
        }
    }
    return 1;
}

static int dow_sakamoto(int y, int m, int d) {
    static const int t[12] = {0,3,2,5,0,3,5,1,4,6,2,4};
    if (m < 3) y -= 1;
    return (y + y/4 - y/100 + y/400 + t[m-1] + d) % 7;
}

static void draw_taskbar(void) {
    i32 W = (i32)gfx.width;
    i32 by = taskbar_y();
    i32 bh = TASKBAR_H;

    if (taskbar_top_pos == TASKBAR_TOP) {
        gfx_glass_rect(0, by + bh, W, ui_scale(5), RGB(40, 55, 80), 9);
        gfx_glass_rect(0, by, W, bh, THEME_TASKBAR, g_taskbar_opacity);
        gfx_rect(0, by + bh - 1, W, 1, THEME_BORDER);
    } else {
        gfx_glass_rect(0, by - ui_scale(5), W, ui_scale(5), RGB(40, 55, 80), 9);
        gfx_glass_rect(0, by, W, bh, THEME_TASKBAR, g_taskbar_opacity);
        gfx_rect(0, by, W, 1, THEME_BORDER);
    }

    i32 start_size = taskbar_start_size();
    i32 start_x = taskbar_start_x();
    i32 start_y = taskbar_start_y();
    int start_hot = ui_point_in(mouse_x(), mouse_y(), start_x, start_y, start_size, start_size);
    if (start_menu_open)
        gfx_rounded_rect(start_x, start_y, start_size, start_size, 8, THEME_ACCENT_DIM);
    else if (start_hot)
        gfx_rounded_rect(start_x, start_y, start_size, start_size, 8, RGB(232, 236, 242));
    i32 li = ui_scale(2);
    logo_draw_ex(start_x + li, start_y + li, start_size - li * 2, start_size - li * 2,
                 THEME_TASKBAR, 1);
    if (start_hot && mouse_left_pressed()) {
        start_menu_open = !start_menu_open;
        if (start_menu_open) {
            start_menu_open_tick = ticks_get();
            sm_open_cat = -1; sm_search_text[0] = 0; sm_search_len = 0;
        }
    }

    i32 tile = start_size;
    i32 tile_y = by + (bh - tile) / 2;
    i32 bx = start_x + start_size + ui_scale(14);
    int hovered_this_frame = -1;
    for (int i = 0; i < APP_COUNT; i++) {
        if (!windows[i].visible) continue;
        int isf = (i == focused_app());
        if (taskbar_icon_button(bx, tile_y, tile, i, isf)) {
            if (!windows[i].minimized && isf) desktop_close_app(i);
            else raise_app(i);
        }
        if (ui_point_in(mouse_x(), mouse_y(), bx, tile_y, tile, tile)) {
            hovered_this_frame = i;
            taskbar_hover_box_x = bx;
            taskbar_hover_box_y = tile_y;
        }
        i32 dot_y = by + bh - ui_scale(4);
        i32 dw = isf ? ui_scale(12) : ui_scale(4);
        gfx_rounded_rect(bx + tile / 2 - dw / 2, dot_y, dw, ui_scale(3), 1,
                         isf ? THEME_ACCENT : THEME_TEXT_FAINT);
        bx += tile + ui_scale(14);
    }

    i32 pad = ui_scale(16);
    i32 cy = by + bh / 2;

    rtc_time_t t; rtc_read(&t); config_local_time(&t);
    static const char* WD[7] = {"Sun","Mon","Tue","Wed","Thu","Fri","Sat"};
    int wd = dow_sakamoto((int)t.year, (int)t.month, (int)t.day);
    if (wd < 0) wd += 7;
    int h12 = t.hour % 12; if (h12 == 0) h12 = 12;
    const char* ap = (t.hour < 12) ? "AM" : "PM";
    const char* dg = "0123456789";
    char cbuf[24]; int p = 0;
    const char* wname = WD[wd % 7];
    for (int i = 0; wname[i]; i++) cbuf[p++] = wname[i];
    cbuf[p++] = ' ';
    if (h12 >= 10) cbuf[p++] = dg[h12 / 10];
    cbuf[p++] = dg[h12 % 10]; cbuf[p++] = ':';
    cbuf[p++] = dg[t.minute / 10]; cbuf[p++] = dg[t.minute % 10]; cbuf[p++] = ' ';
    cbuf[p++] = ap[0]; cbuf[p++] = ap[1]; cbuf[p] = 0;
    i32 cw = gfx_string_width(cbuf);
    i32 clock_x = W - pad - cw;
    gfx_string(clock_x, cy - 8, cbuf, THEME_TEXT, RGB(0,0,0), 0);

    i32 tray_x = clock_x - ui_scale(14);
    battery_status_t batt; battery_read(&batt);
    i32 bw_b = ui_scale(26), bh_b = ui_scale(12);
    i32 bx_b = tray_x - bw_b, by_b = cy - bh_b / 2;
    color_t bframe = RGB(146, 152, 164);
    gfx_rounded_rect_outline(bx_b, by_b, bw_b, bh_b, ui_scale(3), bframe);
    gfx_rounded_rect_outline(bx_b + 1, by_b + 1, bw_b - 2, bh_b - 2, ui_scale(2), bframe);
    gfx_rounded_rect(bx_b + bw_b + 1, cy - ui_scale(3), ui_scale(2), ui_scale(6), ui_scale(1), bframe);
    if (!batt.present) {
        gfx_rounded_rect(bx_b + 3, by_b + 3, bw_b - 6, bh_b - 6, ui_scale(1), RGB(120, 150, 210));
    } else {
        color_t bat_col = (batt.percent > 20 || batt.charging) ? RGB(74, 196, 96) : RGB(230, 74, 60);
        i32 fill = (bw_b - 6) * batt.percent / 100; if (fill < 2) fill = 2;
        gfx_rounded_rect(bx_b + 3, by_b + 3, fill, bh_b - 6, ui_scale(1), bat_col);
        if (batt.charging) {
            u8 bolt[7][5] = {{0,0,1,1,0},{0,1,1,0,0},{1,1,1,1,0},{0,0,1,1,0},{0,1,1,0,0},{0,0,1,0,0},{0,0,0,0,0}};
            i32 mx = bx_b + bw_b / 2 - 2, myb = cy - 3;
            for (int ry = 0; ry < 7; ry++) for (int rx = 0; rx < 5; rx++)
                if (bolt[ry][rx]) gfx_pixel(mx + rx, myb + ry, RGB(255, 255, 255));
        }
    }

    i32 net_box = ui_scale(24);
    g_net_icon_w = net_box; g_net_icon_h = bh; g_net_icon_y = by;
    g_net_icon_x = bx_b - ui_scale(12) - net_box;
    {
        int ns = net_state();
        int wf = wifi_available();
        i32 wcx = g_net_icon_x + net_box / 2, wcy = cy + ui_scale(7);
        color_t on = RGB(74, 196, 96), warn = RGB(214, 150, 40), off = RGB(150, 156, 168), link = RGB(90, 140, 220);
        color_t arc_col = wf ? (ns == 2 ? on : link) : (ns == 2 ? on : ns == 1 ? warn : off);
        for (int band = 0; band < 3; band++) {
            i32 r0 = ui_scale(4 + band * 4);
            i32 r1 = r0 + ui_scale(2);
            color_t c = (band == 2) ? arc_col : mix(arc_col, RGB(255, 255, 255), 42, 100);
            if (ns == 0 && !wf) c = mix(off, RGB(255, 255, 255), 30, 100);
            for (i32 dy = -r1; dy <= -ui_scale(1); dy++) {
                for (i32 dx = -r1; dx <= r1; dx++) {
                    i32 d2 = dx * dx + dy * dy;
                    if (d2 < r0 * r0 || d2 > r1 * r1) continue;
                    i32 ax = dx < 0 ? -dx : dx;
                    if (ax * 100 > (-dy) * 173) continue;
                    gfx_pixel(wcx + dx, wcy + dy, c);
                }
            }
        }
        gfx_circle_fill(wcx, wcy, ui_scale(2), arc_col);
        if (ns == 0 && !wf)
            gfx_string(wcx + ui_scale(10), cy - ui_scale(9), "!", RGB(210, 90, 60), RGB(0, 0, 0), 0);
        if (g_wifi_popup_open) draw_wifi_popup();
    }

    if (hovered_this_frame != taskbar_hover_app) {
        taskbar_hover_app = hovered_this_frame;
        taskbar_hover_since = ticks_get();
    }
    if (taskbar_hover_app >= 0 && ticks_get() - taskbar_hover_since >= ticks_per_sec()) {
        const char* name = windows[taskbar_hover_app].title;
        i32 tw = gfx_string_width(name);
        i32 tp = 8, box_w = tw + tp * 2, box_h = 22;
        i32 box_x = taskbar_hover_box_x + tile / 2 - box_w / 2;
        if (box_x < 2) box_x = 2;
        if (box_x + box_w > W - 2) box_x = W - 2 - box_w;
        i32 box_y = by - box_h - 8;
        gfx_glass_rounded_rect(box_x + 1, box_y + 2, box_w, box_h, 6, RGB(60, 70, 95), 16);
        gfx_rounded_rect(box_x, box_y, box_w, box_h, 6, THEME_PANEL_RAISED);
        gfx_rounded_rect_outline(box_x, box_y, box_w, box_h, 6, THEME_BORDER);
        gfx_string(box_x + tp, box_y + (box_h - 16) / 2, name, THEME_TEXT, THEME_PANEL_RAISED, 0);
    }
}


static char sm_lower(char c) { return (c >= 'A' && c <= 'Z') ? (char)(c - 'A' + 'a') : c; }
static int sm_contains_ci(const char* hay, const char* needle) {
    if (!needle[0]) return 1;
    u32 hlen = str_len(hay), nlen = str_len(needle);
    if (nlen > hlen) return 0;
    for (u32 i = 0; i + nlen <= hlen; i++) {
        u32 j = 0;
        for (; j < nlen; j++) if (sm_lower(hay[i + j]) != sm_lower(needle[j])) break;
        if (j == nlen) return 1;
    }
    return 0;
}

static void start_menu_rect(i32* ox, i32* oy, i32* ow, i32* oh) {
    i32 w = ui_scale(540), h = ui_scale(400);
    if (w > (i32)gfx.width - ui_scale(24)) w = (i32)gfx.width - ui_scale(24);
    if (h > (i32)gfx.height - TASKBAR_H - ui_scale(20)) h = (i32)gfx.height - TASKBAR_H - ui_scale(20);
    i32 x = taskbar_start_x() - ui_scale(4);
    if (x < ui_scale(8)) x = ui_scale(8);
    i32 y = taskbar_popup_y(h);
    if (y < ui_scale(8)) y = ui_scale(8);
    if (y + h > (i32)gfx.height - ui_scale(8)) y = (i32)gfx.height - ui_scale(8) - h;
    *ox = x; *oy = y; *ow = w; *oh = h;
}

static void sm_folder_icon(i32 x, i32 y, i32 s, color_t c) {
    gfx_rounded_rect(x, y + s / 5, s / 2, s / 4, 1, c);
    gfx_rounded_rect(x, y + s / 3, s, s * 2 / 3, 2, c);
}

static int sm_app_row(i32 lx, i32 ry, i32 lw, i32 rh, int app) {
    i32 rowh = rh - ui_scale(4);
    int hot = ui_point_in(mouse_x(), mouse_y(), lx, ry, lw, rowh);
    if (hot) gfx_rounded_rect(lx, ry, lw, rowh, 6, THEME_ACCENT_DIM);
    i32 isz = ui_scale(24);
    draw_badge(lx + ui_scale(6), ry + (rowh - isz) / 2, isz, app, 5);
    gfx_string(lx + ui_scale(6) + isz + ui_scale(10), ry + (rowh - 16) / 2,
               windows[app].title, THEME_TEXT, THEME_ACCENT_DIM, 0);
    return hot && mouse_left_pressed();
}

static int sm_cat_row(i32 lx, i32 ry, i32 lw, i32 rh, int c) {
    i32 rowh = rh - ui_scale(4);
    int hot = ui_point_in(mouse_x(), mouse_y(), lx, ry, lw, rowh);
    if (hot) gfx_rounded_rect(lx, ry, lw, rowh, 6, THEME_ACCENT_DIM);
    i32 isz = ui_scale(22);
    i32 iy = ry + (rowh - isz) / 2;
    gfx_rounded_rect(lx + ui_scale(6), iy, isz, isz, 5, SM_CAT_COLOR[c]);
    char in[2] = { SM_CATEGORIES[c][0], 0 };
    gfx_string(lx + ui_scale(6) + (isz - 8) / 2, iy + (isz - 16) / 2, in, RGB(255,255,255), SM_CAT_COLOR[c], 0);
    gfx_string(lx + ui_scale(6) + isz + ui_scale(10), ry + (rowh - 16) / 2,
               SM_CATEGORIES[c], THEME_TEXT, THEME_ACCENT_DIM, 0);
    i32 chx = lx + lw - ui_scale(16), chy = ry + rowh / 2;
    gfx_line(chx, chy - ui_scale(4), chx + ui_scale(4), chy, THEME_TEXT_FAINT);
    gfx_line(chx + ui_scale(4), chy, chx, chy + ui_scale(4), THEME_TEXT_FAINT);
    return hot && mouse_left_pressed();
}

static int sm_place_row(i32 rx, i32 ry, i32 rw, i32 rh, const char* label, color_t ic) {
    i32 rowh = rh - ui_scale(4);
    int hot = ui_point_in(mouse_x(), mouse_y(), rx, ry, rw, rowh);
    if (hot) gfx_rounded_rect(rx, ry, rw, rowh, 6, THEME_ACCENT_DIM);
    i32 isz = ui_scale(18);
    sm_folder_icon(rx + ui_scale(4), ry + (rowh - isz) / 2, isz, ic);
    gfx_string(rx + ui_scale(4) + isz + ui_scale(10), ry + (rowh - 16) / 2, label, THEME_TEXT, THEME_ACCENT_DIM, 0);
    return hot && mouse_left_pressed();
}

static int sm_round_btn(i32 cx, i32 cy, i32 r, int kind) {
    int hot = ui_point_in(mouse_x(), mouse_y(), cx - r, cy - r, r * 2, r * 2);
    gfx_circle_fill(cx, cy, r, hot ? THEME_ACCENT_DIM : RGB(238, 240, 244));
    gfx_circle(cx, cy, r, THEME_BORDER);
    color_t gc = (kind == 2) ? THEME_DANGER : THEME_TEXT_DIM;
    if (kind == 0) {
        gfx_rect(cx - ui_scale(5), cy - ui_scale(5), ui_scale(2), ui_scale(10), gc);
        gfx_rect(cx - ui_scale(5), cy - ui_scale(5), ui_scale(7), ui_scale(2), gc);
        gfx_rect(cx - ui_scale(5), cy + ui_scale(3), ui_scale(7), ui_scale(2), gc);
        gfx_line(cx, cy, cx + ui_scale(6), cy, gc);
        gfx_line(cx + ui_scale(6), cy, cx + ui_scale(3), cy - ui_scale(3), gc);
        gfx_line(cx + ui_scale(6), cy, cx + ui_scale(3), cy + ui_scale(3), gc);
    } else if (kind == 1) {
        gfx_rounded_rect_outline(cx - ui_scale(3), cy - ui_scale(6), ui_scale(6), ui_scale(5), 2, gc);
        gfx_rounded_rect(cx - ui_scale(5), cy - ui_scale(2), ui_scale(10), ui_scale(8), 2, gc);
    } else {
        gfx_circle(cx, cy + ui_scale(1), ui_scale(5), gc);
        gfx_rect(cx - ui_scale(3), cy - ui_scale(5), ui_scale(6), ui_scale(4), hot ? THEME_ACCENT_DIM : RGB(238, 240, 244));
        gfx_rect(cx - ui_scale(1), cy - ui_scale(6), ui_scale(2), ui_scale(5), gc);
    }
    return hot && mouse_left_pressed();
}

static int point_on_any_window(i32 px, i32 py) {
    for (int i = APP_COUNT - 1; i >= 0; i--) {
        int app = z_order[i];
        window_t* w = &windows[app];
        if (!w->visible || w->minimized || !win_on_ws(app)) continue;
        if (ui_point_in(px, py, w->x, w->y - TITLEBAR_H, w->w, w->h + TITLEBAR_H)) return 1;
    }
    return 0;
}

static int g_want_screenshot = 0;
static const char* CTX_LABELS[3] = { "Open Terminal", "Open Notes", "Desktop Settings" };
static const int   CTX_APPS[3]   = { APP_TERMINAL, APP_EDITOR, APP_DESKSETTINGS };

static void draw_context_menu(void) {
    if (!ctx_menu_open) return;
    i32 n = 5;
    i32 item_h = ui_scale(34);
    i32 mw = ui_scale(200), mh = n * item_h + ui_scale(8);
    i32 mx = ctx_menu_x, my = ctx_menu_y;
    if (mx + mw > (i32)gfx.width)  mx = (i32)gfx.width  - mw - 4;
    if (my + mh > (i32)gfx.height) my = (i32)gfx.height - mh - 4;
    if (mx < 0) mx = 0;
    if (my < 0) my = 0;

    gfx_glass_rect(mx + 3, my + 4, mw, mh, RGB(0, 0, 0), 22);
    gfx_rounded_rect(mx, my, mw, mh, 10, THEME_WINDOW);
    gfx_rounded_rect_outline(mx, my, mw, mh, 10, THEME_BORDER);

    int clicked = mouse_left_pressed();
    int handled = 0;
    for (int i = 0; i < 3; i++) {
        i32 iy = my + ui_scale(4) + i * item_h;
        int hot = ui_point_in(mouse_x(), mouse_y(), mx + 4, iy, mw - 8, item_h);
        if (hot) gfx_rounded_rect(mx + 4, iy, mw - 8, item_h, 6, THEME_ACCENT);
        gfx_string(mx + ui_scale(14), iy + (item_h - 16) / 2, CTX_LABELS[i],
                   hot ? THEME_ACCENT_TEXT : THEME_TEXT, hot ? THEME_ACCENT : THEME_WINDOW, 0);
        if (hot && clicked) { desktop_open_app(CTX_APPS[i]); ctx_menu_open = 0; handled = 1; }
    }
    {
        i32 iy = my + ui_scale(4) + 3 * item_h;
        int hot = ui_point_in(mouse_x(), mouse_y(), mx + 4, iy, mw - 8, item_h);
        if (hot) gfx_rounded_rect(mx + 4, iy, mw - 8, item_h, 6, THEME_ACCENT);
        gfx_string(mx + ui_scale(14), iy + (item_h - 16) / 2,
                   desktop_icons_hidden ? "Show Desktop Icons" : "Hide Desktop Icons",
                   hot ? THEME_ACCENT_TEXT : THEME_TEXT, hot ? THEME_ACCENT : THEME_WINDOW, 0);
        if (hot && clicked) { desktop_icons_hidden = !desktop_icons_hidden; ctx_menu_open = 0; handled = 1; }
    }
    {
        i32 iy = my + ui_scale(4) + 4 * item_h;
        int hot = ui_point_in(mouse_x(), mouse_y(), mx + 4, iy, mw - 8, item_h);
        if (hot) gfx_rounded_rect(mx + 4, iy, mw - 8, item_h, 6, THEME_ACCENT);
        gfx_string(mx + ui_scale(14), iy + (item_h - 16) / 2, "Take Screenshot",
                   hot ? THEME_ACCENT_TEXT : THEME_TEXT, hot ? THEME_ACCENT : THEME_WINDOW, 0);
        if (hot && clicked) { ctx_menu_open = 0; g_want_screenshot = 1; handled = 1; }
    }
    if (clicked && !handled && !ui_point_in(mouse_x(), mouse_y(), mx, my, mw, mh))
        ctx_menu_open = 0;
}

static void draw_start_menu(void) {
    if (!start_menu_open) return;
    i32 x, y, w, h;
    start_menu_rect(&x, &y, &w, &h);
    i32 pad = ui_scale(12);
    color_t bg = THEME_PANEL;

    gfx_glass_rounded_rect(x + 3, y + 6, w, h, 14, RGB(50, 62, 90), 20);
    gfx_rounded_rect(x, y, w, h, 14, bg);
    gfx_rounded_rect_outline(x, y, w, h, 14, THEME_BORDER);

    i32 lx = x + pad, lw = ui_scale(298);
    i32 rx = lx + lw + ui_scale(14);
    i32 rwid = x + w - pad - rx;
    gfx_rect(rx - ui_scale(8), y + pad, 1, h - pad * 2, THEME_SEP);

    i32 sh = ui_scale(34);
    i32 sy = y + h - pad - sh;
    i32 sx = lx, swid = lw;
    i32 list_y = y + pad, list_h = sy - ui_scale(10) - list_y;
    i32 rh = ui_scale(34);

    if (sm_search_text[0]) {
        gfx_string(lx + ui_scale(4), list_y, "Search results", THEME_TEXT_DIM, bg, 0);
        i32 top = list_y + ui_scale(22);
        int shown = 0;
        for (int i = 0; i < APP_COUNT; i++) {
            if (!app_is_installed(i)) continue;
            if (i == APP_NOTIFY) continue;
            if (!sm_contains_ci(windows[i].title, sm_search_text)) continue;
            i32 ry = top + shown * rh;
            if (ry + rh > list_y + list_h) break;
            if (sm_app_row(lx, ry, lw, rh, i)) { desktop_open_app(i); start_menu_open = 0; }
            shown++;
        }
        if (shown == 0)
            gfx_string(lx + ui_scale(4), top, "No apps found", THEME_TEXT_FAINT, bg, 0);
    } else if (sm_open_cat < 0) {
        gfx_string(lx + ui_scale(4), list_y, "All Apps", THEME_TEXT_DIM, bg, 0);
        i32 top = list_y + ui_scale(22);
        for (int c = 0; c < SM_CAT_COUNT; c++) {
            i32 ry = top + c * rh;
            if (sm_cat_row(lx, ry, lw, rh, c)) sm_open_cat = c;
        }
    } else {
        i32 rowh = rh - ui_scale(4);
        int hb = ui_point_in(mouse_x(), mouse_y(), lx, list_y, lw, rowh);
        if (hb) gfx_rounded_rect(lx, list_y, lw, rowh, 6, THEME_ACCENT_DIM);
        i32 bcx = lx + ui_scale(12), bcy = list_y + rowh / 2;
        gfx_line(bcx + ui_scale(4), bcy - ui_scale(5), bcx - ui_scale(2), bcy, SM_CAT_COLOR[sm_open_cat]);
        gfx_line(bcx - ui_scale(2), bcy, bcx + ui_scale(4), bcy + ui_scale(5), SM_CAT_COLOR[sm_open_cat]);
        gfx_string(lx + ui_scale(28), list_y + (rowh - 16) / 2, SM_CATEGORIES[sm_open_cat], THEME_TEXT, THEME_ACCENT_DIM, 0);
        if (hb && mouse_left_pressed()) sm_open_cat = -1;
        i32 top = list_y + rh + ui_scale(2);
        int shown = 0;
        for (int i = 0; i < APP_COUNT; i++) {
            if (!app_is_installed(i)) continue;
            if (i == APP_NOTIFY) continue;
            if (SM_APP_CATEGORY[i] != sm_open_cat) continue;
            i32 ry = top + shown * rh;
            if (ry + rh > list_y + list_h) break;
            if (sm_app_row(lx, ry, lw, rh, i)) { desktop_open_app(i); start_menu_open = 0; }
            shown++;
        }
    }

    gfx_rounded_rect(sx, sy, swid, sh, sh / 2, THEME_INPUT);
    gfx_rounded_rect_outline(sx, sy, swid, sh, sh / 2, THEME_BORDER);
    i32 gcx = sx + ui_scale(18), gcy = sy + sh / 2;
    gfx_circle(gcx, gcy, ui_scale(5), THEME_TEXT_DIM);
    gfx_line(gcx + ui_scale(4), gcy + ui_scale(4), gcx + ui_scale(8), gcy + ui_scale(8), THEME_TEXT_DIM);
    char sbuf[28];
    if (sm_search_text[0]) str_copy(sbuf, sm_search_text, sizeof(sbuf));
    else str_copy(sbuf, "Type to search...", sizeof(sbuf));
    if (sm_search_text[0] && (ticks_get() / 30) % 2 == 0 && str_len(sbuf) < 25)
        str_cat(sbuf, "_", sizeof(sbuf));
    gfx_string(sx + ui_scale(32), sy + (sh - 16) / 2, sbuf,
               sm_search_text[0] ? THEME_TEXT : THEME_TEXT_FAINT, THEME_INPUT, 0);

    i32 ry2 = y + pad;
    i32 av = ui_scale(30);
    gfx_circle_fill(rx + av / 2, ry2 + av / 2, av / 2, THEME_ACCENT);
    const char* un = current_user_name();
    char initial[2];
    initial[0] = (un[0] >= 'a' && un[0] <= 'z') ? (char)(un[0] - 32) : un[0];
    initial[1] = 0;
    gfx_string(rx + av / 2 - 4, ry2 + av / 2 - 8, initial, RGB(255,255,255), THEME_ACCENT, 0);
    gfx_string(rx + av + ui_scale(10), ry2 + av / 2 - 8, un, THEME_TEXT, bg, 0);
    ry2 += av + ui_scale(12);

    gfx_string(rx, ry2, "Places", THEME_TEXT_DIM, bg, 0);
    ry2 += ui_scale(20);
    color_t fc = RGB(90, 150, 220);
    if (sm_place_row(rx, ry2, rwid, ui_scale(28), "Home", fc)) { desktop_open_app(APP_FILES); start_menu_open = 0; }
    ry2 += ui_scale(28);
    if (sm_place_row(rx, ry2, rwid, ui_scale(28), "Documents", fc)) { desktop_open_app(APP_FILES); start_menu_open = 0; }
    ry2 += ui_scale(28);
    if (sm_place_row(rx, ry2, rwid, ui_scale(28), "Downloads", fc)) { desktop_open_app(APP_FILES); start_menu_open = 0; }
    ry2 += ui_scale(28);
    if (sm_place_row(rx, ry2, rwid, ui_scale(28), "Pictures", RGB(90, 180, 120))) { desktop_open_app(APP_PHOTOS); start_menu_open = 0; }
    ry2 += ui_scale(28);
    if (sm_place_row(rx, ry2, rwid, ui_scale(28), "Videos", RGB(200, 120, 90))) { desktop_open_app(APP_FILES); start_menu_open = 0; }
    ry2 += ui_scale(28);

    gfx_rect(rx, ry2 + ui_scale(2), rwid, 1, THEME_SEP);
    ry2 += ui_scale(10);
    if (sm_place_row(rx, ry2, rwid, ui_scale(28), "Software", RGB(150, 110, 220))) { desktop_open_app(APP_STORE); start_menu_open = 0; }
    ry2 += ui_scale(28);
    if (sm_place_row(rx, ry2, rwid, ui_scale(28), "Settings", RGB(120, 128, 140))) { desktop_open_app(APP_SETTINGS); start_menu_open = 0; }

    i32 bcy2 = y + h - pad - ui_scale(18);
    i32 br = ui_scale(15);
    i32 bx0 = rx + rwid - br - ui_scale(2);
    i32 bx1 = bx0 - (br * 2 + ui_scale(10));
    i32 bx2 = bx1 - (br * 2 + ui_scale(10));
    if (sm_round_btn(bx2, bcy2, br, 0)) { accounts_logout(); start_menu_open = 0; }
    if (sm_round_btn(bx1, bcy2, br, 1)) { accounts_logout(); start_menu_open = 0; }
    if (sm_round_btn(bx0, bcy2, br, 2)) { desktop_shutdown(); }
}

static void start_menu_key(int key) {
    if (!start_menu_open) return;
    if (key == KEY_ESC) { start_menu_open = 0; return; }
    if (key == KEY_BACKSPACE) {
        if (sm_search_len > 0) sm_search_text[--sm_search_len] = 0;
        sm_open_cat = -1;
        return;
    }
    if (key >= 32 && key < 127) {
        if (sm_search_len < sizeof(sm_search_text) - 1) {
            sm_search_text[sm_search_len++] = (char)key;
            sm_search_text[sm_search_len] = 0;
            sm_open_cat = -1;
        }
    }
}

void desktop_draw_cursor(void) {
    i32 x = mouse_x(), y = mouse_y();
    static const char* shape[18] = {
        "B...........",
        "BB..........",
        "BWB.........",
        "BWWB........",
        "BWWWB.......",
        "BWWWWB......",
        "BWWWWWB.....",
        "BWWWWWWB....",
        "BWWWWWWWB...",
        "BWWWWWWWWB..",
        "BWWWWWBBBB..",
        "BWWBWWB.....",
        "BWB.BWWB....",
        "BB...BWWB...",
        "B.....BWWB..",
        ".......BWWB.",
        "........BWWB",
        ".........BB.",
    };
    for (int j = 0; j < 18; j++) {
        for (int i = 0; shape[j][i]; i++) {
            char c = shape[j][i];
            if (c == 'B') gfx_pixel(x + i, y + j, RGB(0,0,0));
            else if (c == 'W') gfx_pixel(x + i, y + j, RGB(255,255,255));
        }
    }
}


static int handle_input(void) {
    if (g_crash_show) {
        if (mouse_left_pressed()) g_crash_show = 0;
        return 1;
    }
    i32 mx = mouse_x(), my = mouse_y();
    int dirty = 0;

    /* An app that wedged was unwound out of by the timer interrupt; retire it
       here, on solid ground, rather than from inside the interrupt. */
    if (g_app_hung_pending >= 0 && g_app_hung_pending < APP_COUNT) {
        int a = g_app_hung_pending;
        g_app_hung_pending = -1;
        str_copy(g_crash_name, windows[a].title, 40);
        windows[a].visible = 0;
        windows[a].minimized = 0;
        win_anim[a] = 0;
        win_closing[a] = 0;
        g_app_hung_reported = a;
        extern void serial_puts(const char*);
        serial_puts("[app] closed unresponsive app: ");
        serial_puts(g_crash_name);
        serial_puts("\r\n");
        dirty = 1;
    }

    /* Drive any in-flight page load a slice at a time, and keep repainting
       while it runs so the UI never appears frozen. */
    {
        extern void browser_tick(void);
        extern int  browser_is_loading(void);
        extern void browser_cancel_load(void);
        /* The connect/TLS-handshake phase is still synchronous and does heavy
           bignum work; if it wedges, the guard unwinds us out instead of
           leaving the whole screen frozen. */
        if (guard_enter(APP_BROWSER)) {
            browser_tick();
            guard_leave();
        } else {
            extern void serial_puts(const char*);
            serial_puts("[app] page load wedged - aborted, desktop still alive\r\n");
            browser_cancel_load();
            g_app_hung_pending = -1;      /* handled here; do not close the window */
            str_copy(g_crash_name, "Browser", 40);
        }
        if (browser_is_loading()) dirty = 1;
    }

    /* window open/close animation needs continuous frames */
    if (windows_animating()) { step_window_anim(); dirty = 1; }

    if (mouse_right_pressed()) {
        if (in_content_area(my) && !point_on_any_window(mx, my)) {
            ctx_menu_open = 1; ctx_menu_x = mx; ctx_menu_y = my;
            start_menu_open = 0;
        } else {
            ctx_menu_open = 0;
        }
        dirty = 1;
    }
    if (ctx_menu_open && mouse_left_pressed()) dirty = 1;

    if (resizing_app >= 0) {
        dirty = 1;
        if (mouse_left()) {
            window_t* w = &windows[resizing_app];
            if (rz_mode & 1) {
                w->w = rz_ow + (mx - rz_ox);
                if (w->w < WIN_MIN_W) w->w = WIN_MIN_W;
                if (w->x + w->w > (i32)gfx.width) w->w = (i32)gfx.width - w->x;
            }
            if (rz_mode & 2) {
                w->h = rz_oh + (my - rz_oy);
                if (w->h < WIN_MIN_H) w->h = WIN_MIN_H;
                if (w->y + w->h > (i32)gfx.height - TASKBAR_H) w->h = (i32)gfx.height - TASKBAR_H - w->y;
            }
        } else resizing_app = -1;
    }

    if (dragging_app >= 0) {
        dirty = 1;
        if (mouse_left()) {
            window_t* w = &windows[dragging_app];
            w->x = mx - drag_dx;
            w->y = my - drag_dy;
            i32 min_y = TITLEBAR_H + MENUBAR_H;
            if (w->y < min_y) w->y = min_y;
            if (w->x < -w->w + 60) w->x = -w->w + 60;
            if (w->x > (i32)gfx.width - 60) w->x = (i32)gfx.width - 60;
        } else {
            dragging_app = -1;
        }
    }

    if (mouse_left() && dragging_app < 0 && !start_menu_open && !ctx_menu_open && in_content_area(my)) {
        for (int i = APP_COUNT - 1; i >= 0; i--) {
            int app = z_order[i];
            window_t* w = &windows[app];
            if (!w->visible || w->minimized || !win_on_ws(app)) continue;
            if (ui_point_in(mx, my, w->x, w->y - TITLEBAR_H, w->w, TITLEBAR_H)) break;
            if (ui_point_in(mx, my, w->x, w->y, w->w, w->h)) {
                if (app_drag_table[app]) {
                    app_drag_table[app](mx - w->x, my - w->y);
                    dirty = 1;
                }
                break;
            }
        }
    }

    if (demo_on) dirty = 1;
    int key = kbd_getchar();
    if (key) {
        dirty = 1;
        if (key == KEY_F12) {
            gfx_clear_clip();
            screenshot_take();
            desktop_refresh_files();
        } else if (key == KEY_F3) {
            desktop_shutdown();
        } else if (g_wifi_popup_open && wifi_popup_handle_key(key)) {
        } else if (start_menu_open) {
            start_menu_key(key);
        } else if (app_key_table[focused_app()]) {
            g_crash_app = focused_app(); app_key_table[focused_app()](key); g_crash_app = -1;
        }
    }

    i32 wheel = mouse_wheel_delta();
    if (wheel != 0 && start_menu_open) {
        dirty = 1;
    } else if (wheel != 0 && !start_menu_open && in_content_area(my) && dragging_app < 0) {
        for (int i = APP_COUNT - 1; i >= 0; i--) {
            int app = z_order[i];
            window_t* w = &windows[app];
            if (!w->visible || w->minimized || !win_on_ws(app)) continue;
            if (ui_point_in(mx, my, w->x, w->y, w->w, w->h)) {
                if (app_wheel_table[app]) {
                    app_wheel_table[app](wheel);
                    dirty = 1;
                }
                break;
            }
        }
    }

    if (mouse_right_pressed() && in_content_area(my)) {
        for (int i = APP_COUNT - 1; i >= 0; i--) {
            int app = z_order[i];
            window_t* w = &windows[app];
            if (!w->visible || w->minimized || !win_on_ws(app)) continue;
            if (ui_point_in(mx, my, w->x, w->y - TITLEBAR_H, w->w, w->h + TITLEBAR_H)) {
                raise_app(app);
                if (app_rclick_table[app] && ui_point_in(mx, my, w->x, w->y, w->w, w->h))
                    app_rclick_table[app](mx - w->x, my - w->y);
                return 1;
            }
        }
        for (int i = 0; i < desktop_files_count && !desktop_icons_hidden; i++) {
            i32 ix, iy;
            desktop_icon_pos(i + DESKTOP_APPS_N, &ix, &iy);
            if (ui_point_in(mx, my, ix, iy, DESKTOP_ICON_W - 8, DESKTOP_ICON_H - 6)) {
                desktop_selected_file = i;
                files_open_entry(&desktop_files[i]);
                return 1;
            }
        }
        return dirty;
    }

    if (!mouse_left_pressed()) return dirty;
    if (ctx_menu_open) return dirty;
    dirty = 1;

    if (wifi_popup_handle_click(mx, my)) return dirty;

    if (ui_point_in(mx, my, g_net_icon_x, g_net_icon_y, g_net_icon_w, g_net_icon_h)) {
        g_wifi_popup_open = !g_wifi_popup_open;
        if (g_wifi_popup_open && wifi_available() && g_wifi_scan_count == 0) {
            u32 cnt = 0;
            wifi_scan(g_wifi_scan_results, 8, &cnt);
            g_wifi_scan_count = cnt;
        }
        g_wifi_selected = -1;
        g_wifi_pass_len = 0; g_wifi_pass_buf[0] = 0;
        g_wifi_status_msg[0] = 0;
        return dirty;
    }

    if (start_menu_open) {
        i32 x, y, w, h;
        start_menu_rect(&x, &y, &w, &h);
        i32 start_size = taskbar_start_size();
        i32 start_x = taskbar_start_x();
        i32 start_y = taskbar_start_y();
        if (!ui_point_in(mx, my, x, y, w, h) &&
            !ui_point_in(mx, my, start_x, start_y, start_size, start_size)) {
            start_menu_open = 0;
        }
        return dirty;
    }

    if (!in_content_area(my)) return dirty;

    for (int i = APP_COUNT - 1; i >= 0; i--) {
        int app = z_order[i];
        window_t* w = &windows[app];
        if (!w->visible || w->minimized || !win_on_ws(app)) continue;

        i32 EG = 12;
        i32 CG = 22;
        int in_corner = (mx >= w->x + w->w - CG && mx <= w->x + w->w + 4 && my >= w->y + w->h - CG && my <= w->y + w->h + 4);
        int on_right = (mx >= w->x + w->w - EG && mx <= w->x + w->w + 4 && my >= w->y - 2 && my <= w->y + w->h + 4);
        int on_bottom = (my >= w->y + w->h - EG && my <= w->y + w->h + 4 && mx >= w->x - 2 && mx <= w->x + w->w + 4);
        if (in_corner || on_right || on_bottom) {
            raise_app(app);
            resizing_app = app;
            rz_ox = mx; rz_oy = my; rz_ow = w->w; rz_oh = w->h;
            rz_mode = in_corner ? 3 : ((on_right ? 1 : 0) | (on_bottom ? 2 : 0));
            return dirty;
        }

        if (ui_point_in(mx, my, w->x, w->y - TITLEBAR_H, w->w, TITLEBAR_H)) {
            raise_app(app);
            i32 dot_cy = (w->y - TITLEBAR_H) + TITLEBAR_H / 2;
            i32 close_cx = w->x + 18, min_cx = w->x + 40, max_cx = w->x + 62;
            if (ui_point_in(mx, my, close_cx - 8, dot_cy - 8, 16, 16)) {
                w->minimized = 0;
                desktop_close_app(app);
            } else if (ui_point_in(mx, my, min_cx - 8, dot_cy - 8, 16, 16)) {
                w->minimized = 1;
            } else if (ui_point_in(mx, my, max_cx - 8, dot_cy - 8, 16, 16)) {
                toggle_maximize(w);
            } else {
                dragging_app = app;
                drag_dx = mx - w->x;
                drag_dy = my - w->y;
            }
            return dirty;
        }
        if (ui_point_in(mx, my, w->x, w->y, w->w, w->h)) {
            raise_app(app);
            g_crash_app = app; if (app_click_table[app]) app_click_table[app](mx - w->x, my - w->y); g_crash_app = -1;
            return dirty;
        }
    }

    for (int a = 0; a < DESKTOP_APPS_N && !desktop_icons_hidden; a++) {
        i32 ix, iy;
        desktop_icon_pos(a, &ix, &iy);
        if (ui_point_in(mx, my, ix, iy, DESKTOP_ICON_W - 8, DESKTOP_ICON_H - 6)) {
            u32 now = ticks_get();
            icon_drag_slot = a; icon_drag_moved = 0;
            icon_drag_dx = mx - ix; icon_drag_dy = my - iy;
            if (desktop_last_click_idx == (1000 + a) && now - desktop_last_click_tick < ticks_per_sec() / 2) {
                desktop_open_app(DESKTOP_APPS[a]);
                desktop_last_click_idx = -1;
            } else {
                desktop_selected_file = -1;
                desktop_last_click_idx = 1000 + a;
                desktop_last_click_tick = now;
            }
            return dirty;
        }
    }

    for (int i = 0; i < desktop_files_count && !desktop_icons_hidden; i++) {
        i32 ix, iy;
        desktop_icon_pos(i + DESKTOP_APPS_N, &ix, &iy);
        if (ui_point_in(mx, my, ix, iy, DESKTOP_ICON_W - 8, DESKTOP_ICON_H - 6)) {
            u32 now = ticks_get();
            icon_drag_slot = i + DESKTOP_APPS_N; icon_drag_moved = 0;
            icon_drag_dx = mx - ix; icon_drag_dy = my - iy;
            if (desktop_last_click_idx == i && now - desktop_last_click_tick < ticks_per_sec() / 2) {
                files_open_entry(&desktop_files[i]);
                desktop_last_click_idx = -1;
            } else {
                desktop_selected_file = i;
                desktop_last_click_idx = i;
                desktop_last_click_tick = now;
            }
            return dirty;
        }
    }
    desktop_selected_file = -1;
    return dirty;
}

#define FRAME_TICKS 3

static u32 perf_window_start = 0;
static u32 perf_frame_count = 0;
static u32 perf_busy_accum = 0;
static u32 perf_cyc_busy = 0;
static u32 perf_cyc_start = 0;

static inline u32 cpu_cycles(void) {
    u32 lo, hi;
    __asm__ volatile ("rdtsc" : "=a"(lo), "=d"(hi));
    (void)hi;
    return lo;
}
static u32 perf_last_fps = 0;
static u32 perf_last_cpu_pct = 0;

void desktop_get_perf_stats(perf_stats_t* out) {
    out->fps = perf_last_fps;
    out->cpu_busy_pct = perf_last_cpu_pct;
    u32 used = 0, free = 0;
    heap_stats(&used, &free);
    out->heap_used_kb = used / 1024;
    out->heap_free_kb = free / 1024;
}

static u32 last_forced_redraw_tick = 0;
static u32 last_files_scan_tick = 0;

static void crash_hex32(u32 v, char* out) {
    const char* d = "0123456789ABCDEF";
    out[0] = '0'; out[1] = 'x';
    for (int i = 0; i < 8; i++) out[2 + i] = d[(v >> ((7 - i) * 4)) & 0xF];
    out[10] = 0;
}
static void crash_recover(void) {
    gfx_clear_clip();
    int app = g_crash_app;
    if (app >= 0 && app < APP_COUNT) {
        str_copy(g_crash_name, windows[app].title, 40);
        windows[app].visible = 0;
        windows[app].minimized = 0;
    } else {
        str_copy(g_crash_name, "System task", 40);
    }
    g_crash_reason = crash_vec_name(g_crash_vec);
    char e[12], a[12];
    crash_hex32(g_crash_eip, e);
    crash_hex32(g_crash_addr, a);
    str_copy(g_crash_loc, "at ", 48); str_cat(g_crash_loc, e, 48);
    str_cat(g_crash_loc, "  addr ", 48); str_cat(g_crash_loc, a, 48);
    g_crash_show = 1;
    g_crash_app = -1;
    serial_puts("crash: application faulted, recovered to desktop\r\n");
}
static void draw_crash_overlay(void) {
    if (!g_crash_show) return;
    i32 pw = 470, ph = 196;
    i32 px = ((i32)gfx.width - pw) / 2, py = ((i32)gfx.height - ph) / 2;
    gfx_glass_rounded_rect(px + 3, py + 10, pw, ph, 12, RGB(26,10,14), 44);
    gfx_rounded_rect(px, py, pw, ph, 12, RGB(38,24,28));
    gfx_rounded_rect_outline(px, py, pw, ph, 12, RGB(232,92,82));
    gfx_rect(px, py + 6, pw, 30, RGB(206,64,58));
    gfx_rounded_rect(px, py, pw, 14, 12, RGB(206,64,58));
    gfx_string(px + 16, py + 11, "Application stopped", RGB(255,255,255), RGB(206,64,58), 1);
    gfx_string(px + 16, py + 54, "App:", RGB(198,178,178), RGB(38,24,28), 0);
    gfx_string(px + 72, py + 54, g_crash_name, RGB(255,236,236), RGB(38,24,28), 0);
    gfx_string(px + 16, py + 78, "Reason:", RGB(198,178,178), RGB(38,24,28), 0);
    gfx_string(px + 96, py + 78, g_crash_reason ? g_crash_reason : "Fault", RGB(255,220,120), RGB(38,24,28), 0);
    gfx_string(px + 16, py + 102, g_crash_loc, RGB(168,173,188), RGB(38,24,28), 0);
    gfx_string(px + 16, py + 134, "It was closed so the rest of the system keeps running.", RGB(210,210,216), RGB(38,24,28), 0);
    ui_button(px + pw - 108, py + ph - 38, 92, 26, "Dismiss", 1);
}

static u8 g_cur_backup[20 * 24 * 4];
static i32 g_cur_bx = -1, g_cur_by = -1;
static int g_cur_drawn = 0;
static i32 g_cursor_px = -100000, g_cursor_py = -100000;
static int g_was_over_chrome = 0;

static const char* g_cursor_shape[24] = {
    ".WWWWW..............",
    "WWBBBWW.............",
    "WBBBBBWW............",
    "WBBBBBBWWW..........",
    "WBBBBBBBBWW.........",
    "WBBBBBBBBBWW........",
    "WBBBBBBBBBBWW.......",
    "WBBBBBBBBBBBWW......",
    "WBBBBBBBBBBBBWWW....",
    "WBBBBBBBBBBBBBBWW...",
    "WBBBBBBBBBBBBBBBWW..",
    "WBBBBBBBBBBBBBBBBWW.",
    "WBBBBBBBBBBBBBBBBBWW",
    "WBBBBBBBBBBBBBBBBBBW",
    "WWBBBBBBBBBBBBBBBBBW",
    ".WBBBBBBBBBBBBBBBBBW",
    ".WBBBBBBBBBBBBBBBWWW",
    ".WBBBBBBBWWWWWWWWW..",
    ".WBBBBBBWW..........",
    ".WBBBBBBW...........",
    ".WBBBBBWW...........",
    ".WBBBBWW............",
    ".WWBBWW.............",
    "..WWWW.............."
};
static void cursor_back_draw(i32 x, i32 y) {
    x -= 2; y -= 1;
    if (x < 0) x = 0;
    if (y < 0) y = 0;
    gfx_clear_clip();
    gfx_back_save(x, y, 20, 24, g_cur_backup);
    for (int j = 0; j < 24; j++)
        for (int i = 0; g_cursor_shape[j][i]; i++) {
            char c = g_cursor_shape[j][i];
            if (c == 'B') gfx_pixel(x + i, y + j, RGB(0,0,0));
            else if (c == 'W') gfx_pixel(x + i, y + j, RGB(255,255,255));
            else if (c == 'G') gfx_pixel(x + i, y + j, RGB(110,110,116));
        }
    gfx_mark_dirty(y, y + 24);
    g_cur_bx = x; g_cur_by = y; g_cur_drawn = 1;
}
static void cursor_back_erase(void) {
    if (!g_cur_drawn) return;
    gfx_back_restore(g_cur_bx, g_cur_by, 20, 24, g_cur_backup);
    g_cur_drawn = 0;
}
static int over_hover_chrome(i32 mx, i32 my) {
    if (start_menu_open || g_wifi_popup_open || ctx_menu_open) return 1;
    if (my >= (i32)gfx.height - (TASKBAR_H + 16)) return 1;
    for (int i = 0; i < APP_COUNT; i++) {
        window_t* w = &windows[i];
        if (!w->visible || w->minimized || !win_on_ws(i)) continue;
        if (mx >= w->x - 4 && mx <= w->x + w->w + 4 &&
            my >= w->y - TITLEBAR_H - 4 && my <= w->y + 4) return 1;
        if (mx >= w->x + w->w - 22 && mx <= w->x + w->w &&
            my >= w->y + w->h - 22 && my <= w->y + w->h) return 1;
    }
    return 0;
}


/* ---- scripted demo tour (only with the "zapczdemo" kernel flag) ----
   Drives the desktop from inside the OS so a feature tour can be captured
   without depending on injected mouse events. */
static u32  demo_t0 = 0;
static int  demo_step = 0;
static const char* demo_typing = 0;
static u32  demo_type_i = 0;
static u32  demo_next_key = 0;
static char demo_caption[64] = "";

void desktop_demo_enable(void) { demo_on = 1; demo_t0 = 0; demo_step = 0; }
int  desktop_demo_active(void) { return demo_on; }

static void demo_type(const char* s) { demo_typing = s; demo_type_i = 0; }

static u32 demo_f = 0;

static void demo_tick(void) {
    if (!demo_on) return;
    demo_f++;
    u32 now = ticks_get();
    u32 hz = ticks_per_sec();
    if (hz == 0) hz = 100;

    if (demo_typing) {
        if (now >= demo_next_key) {
            char c = demo_typing[demo_type_i];
            if (!c) { demo_typing = 0; }
            else {
                if (app_key_table[focused_app()]) app_key_table[focused_app()](c);
                demo_type_i++;
                demo_next_key = now + hz / 12;
            }
        }
        return;
    }

    /* Frame-based schedule: the demo forces a redraw every frame, so this
       advances at a steady rate regardless of the timer's tick rate. */
    #define D_UNIT 90u
    u32 el = demo_f / D_UNIT;

    switch (demo_step) {
        case 0:  if (el >= 1)  { str_copy(demo_caption, "ZapczOS V4 - a from-scratch x86 OS written in C", sizeof(demo_caption)); demo_step++; } break;
        case 1:  if (el >= 4)  { str_copy(demo_caption, "Terminal", sizeof(demo_caption)); desktop_open_app(APP_TERMINAL); demo_step++; } break;
        case 2:  if (el >= 6)  { demo_type("sysfetch\n"); demo_step++; } break;
        case 3:  if (el >= 11) { str_copy(demo_caption, "A C compiler that runs inside the OS", sizeof(demo_caption)); demo_type("zapcc demo.c\n"); demo_step++; } break;
        case 4:  if (el >= 16) { str_copy(demo_caption, "Running the .ZAP executable it just built", sizeof(demo_caption)); demo_type("zaprun demo.zap\n"); demo_step++; } break;
        case 5:  if (el >= 23) { str_copy(demo_caption, "The Compiler app", sizeof(demo_caption)); desktop_close_app(APP_TERMINAL); desktop_open_app(APP_COMPILER); demo_step++; } break;
        case 6:  if (el >= 29) { str_copy(demo_caption, "Files", sizeof(demo_caption)); desktop_close_app(APP_COMPILER); desktop_open_app(APP_FILES); demo_step++; } break;
        case 7:  if (el >= 34) { str_copy(demo_caption, "Web browser with its own HTML/CSS engine", sizeof(demo_caption)); desktop_close_app(APP_FILES); desktop_open_app(APP_BROWSER); demo_step++; } break;
        case 8:  if (el >= 40) { str_copy(demo_caption, "Paint", sizeof(demo_caption)); desktop_close_app(APP_BROWSER); desktop_open_app(APP_PAINT); demo_step++; } break;
        case 9:  if (el >= 45) { str_copy(demo_caption, "Settings", sizeof(demo_caption)); desktop_close_app(APP_PAINT); desktop_open_app(APP_DESKSETTINGS); demo_step++; } break;
        case 10: if (el >= 50) { str_copy(demo_caption, "System monitor", sizeof(demo_caption)); desktop_close_app(APP_DESKSETTINGS); desktop_open_app(APP_PERF); demo_step++; } break;
        case 11: if (el >= 55) { str_copy(demo_caption, "Every pixel drawn from scratch. ZapczOS V4.", sizeof(demo_caption)); desktop_close_app(APP_PERF); demo_step++; } break;
        default: break;
    }
}

static void demo_draw_caption(void) {
    if (!demo_on || !demo_caption[0]) return;
    int tw = gfx_string_width(demo_caption);
    i32 bw = tw + 28, bh = 30;
    i32 bx = (i32)gfx.width / 2 - bw / 2;
    i32 by = 16;
    gfx_glass_rect(bx, by, bw, bh, RGB(10, 10, 16), 180);
    gfx_string(bx + 14, by + 7, demo_caption, RGB(255, 255, 255), RGB(0, 0, 0), 0);
}

void desktop_run_frame(void) {
    if (demo_on) demo_tick();
    u32 t0 = ticks_get();
    u32 frame_cyc0 = cpu_cycles();
    if (perf_cyc_start == 0) perf_cyc_start = frame_cyc0;
    watchdog_heartbeat("frame start");

    mouse_poll_frame();
    net_poll();

    if (!accounts_logged_in()) {
        watchdog_heartbeat("login screen");
        i32 mx = mouse_x(), my = mouse_y();
        if (mouse_left_pressed()) accounts_login_click(mx, my);
        int key = kbd_getchar();
        if (key) accounts_login_key(key);

        gfx_mark_all_dirty();
        accounts_login_draw();
        gfx_present();

        u32 target = t0 + FRAME_TICKS;
        while (ticks_get() < target) { __asm__ volatile ("hlt"); }
        return;
    }

    if (kj_setjmp(g_kj_env) != 0) {
        __asm__ volatile ("sti");
        crash_recover();
    }
    g_guard_active = 1;

    int dirty = handle_input();
    watchdog_heartbeat("input handled");
    installer_tick();

    {
        i32 my = mouse_y();
        int near_edge = (taskbar_top_pos == TASKBAR_TOP)
                        ? (my <= TASKBAR_H - g_taskbar_off + 6)
                        : (my >= (i32)gfx.height - TASKBAR_H + g_taskbar_off - 6);
        int want_show = start_menu_open || dragging_app >= 0 || resizing_app >= 0 || g_wifi_popup_open
                     || near_edge;
        i32 tgt = want_show ? 0 : TASKBAR_H;
        if (g_taskbar_off != tgt) {
            if (g_taskbar_off < tgt) { g_taskbar_off += 10; if (g_taskbar_off > tgt) g_taskbar_off = tgt; }
            else { g_taskbar_off -= 10; if (g_taskbar_off < tgt) g_taskbar_off = tgt; }
            dirty = 1;
        }
    }

    if (windows[APP_CLOCK].visible || windows[APP_SNAKE].visible || windows[APP_PERF].visible ||
        windows[APP_CUBE3D].visible || windows[APP_DESKSETTINGS].visible ||
        (windows[APP_LIFE].visible && life_is_running()) ||
        installer_active()) dirty = 1;
    if (t0 - last_forced_redraw_tick >= ticks_per_sec()) {
        dirty = 1;
        if (t0 - last_files_scan_tick >= ticks_per_sec() * 5) {
            last_files_scan_tick = t0;
            refresh_desktop_files();
        }
    }

    i32 cmx = mouse_x(), cmy = mouse_y();
    int cursor_moved = (cmx != g_cursor_px || cmy != g_cursor_py);

    if (icon_drag_slot >= 0) {
        if (mouse_left()) {
            if (cursor_moved && icon_drag_slot < DESKTOP_SLOTS_MAX) {
                i32 nx = cmx - icon_drag_dx, ny = cmy - icon_drag_dy;
                i32 gx0 = 16, gy0 = MENUBAR_H + 16;
                i32 col = (nx - gx0 + DESKTOP_ICON_W / 2) / DESKTOP_ICON_W;
                i32 row = (ny - gy0 + DESKTOP_ICON_H / 2) / DESKTOP_ICON_H;
                i32 max_col = ((i32)gfx.width - gx0) / DESKTOP_ICON_W - 1;
                i32 max_row = ((i32)gfx.height - gy0 - TASKBAR_H) / DESKTOP_ICON_H - 1;
                if (col < 0) col = 0;
                if (row < 0) row = 0;
                if (col > max_col) col = max_col;
                if (row > max_row) row = max_row;
                icon_pos_x[icon_drag_slot] = gx0 + col * DESKTOP_ICON_W;
                icon_pos_y[icon_drag_slot] = gy0 + row * DESKTOP_ICON_H;
                icon_pos_set[icon_drag_slot] = 1;
                icon_drag_moved = 1;
                dirty = 1;
            }
        } else {
            if (icon_drag_moved) dirty = 1;
            icon_drag_slot = -1;
            icon_drag_moved = 0;
        }
    }
    int oc = over_hover_chrome(cmx, cmy);
    int menus_open = (start_menu_open || g_wifi_popup_open || ctx_menu_open);
    int hover_dirty = (cursor_moved && (oc || g_was_over_chrome));
    int hover_only = (!dirty && hover_dirty && !menus_open);
    if (hover_dirty) dirty = 1;
    g_was_over_chrome = oc;

    if (dirty) {
        i32 band_y0 = 0, band_y1 = (i32)gfx.height;
        if (hover_only) {
            i32 lo = cmy < g_cursor_py ? cmy : g_cursor_py;
            i32 hi = cmy > g_cursor_py ? cmy : g_cursor_py;
            band_y0 = lo - ui_scale(52);
            band_y1 = hi + ui_scale(52);
            i32 tb_top = (i32)gfx.height - (TASKBAR_H + 16);
            if (cmy >= tb_top || g_cursor_py >= tb_top) {
                i32 t = tb_top - ui_scale(72);
                if (t < band_y0) band_y0 = t;
                band_y1 = (i32)gfx.height;
            }
            if (band_y0 < 0) band_y0 = 0;
            if (band_y1 > (i32)gfx.height) band_y1 = (i32)gfx.height;
            clip_t cb = { 0, band_y0, (i32)gfx.width, band_y1 };
            gfx_set_clip(cb);
            gfx_mark_dirty(band_y0, band_y1);
            draw_background_band(band_y0, band_y1);
        } else {
            last_forced_redraw_tick = t0;
            gfx_clear_clip();
            gfx_mark_all_dirty();
            draw_background();
        }

        gfx_set_font(g_system_font);
        draw_desktop_icons();
        for (int i = 0; i < APP_COUNT; i++) {
            int app = z_order[i];
            if (!win_on_ws(app)) continue;      /* other virtual desktop */
            if (windows[app].visible && !windows[app].minimized) {
                watchdog_heartbeat(windows[app].title);
            }
            draw_window(&windows[app], app == focused_app());
        }
        watchdog_heartbeat("desktop shell");
        draw_taskbar();
        draw_start_menu();
        draw_context_menu();
        draw_crash_overlay();
        demo_draw_caption();

        gfx_clear_clip();
        g_cur_drawn = 0;
        cursor_back_draw(cmx, cmy);
        gfx_present();
    } else if (cursor_moved) {
        cursor_back_erase();
        cursor_back_draw(cmx, cmy);
        gfx_present();
    }
    g_cursor_px = cmx; g_cursor_py = cmy;

    if (g_want_screenshot) {
        g_want_screenshot = 0;
        cursor_back_erase();
        gfx_clear_clip();
        screenshot_take();
        desktop_refresh_files();
        gfx_mark_all_dirty();
    }

    u32 t1 = ticks_get();
    u32 busy = t1 - t0;
    perf_cyc_busy += cpu_cycles() - frame_cyc0;
    if (dirty) {
        perf_frame_count++;
        perf_busy_accum += busy;
    }
    u32 hz = ticks_per_sec();
    if (t1 - perf_window_start >= hz) {
        perf_last_fps = perf_frame_count;
        u32 elapsed = t1 - perf_window_start;
        u32 cyc_now = cpu_cycles();
        u32 cyc_total = cyc_now - perf_cyc_start;
        u32 b = perf_cyc_busy >> 10, e = cyc_total >> 10;
        perf_last_cpu_pct = e ? (b * 100) / e : 0;
        if (perf_last_cpu_pct > 100) perf_last_cpu_pct = 100;
        perf_cyc_busy = 0;
        perf_cyc_start = cyc_now;
        (void)elapsed;
        perf_frame_count = 0;
        perf_busy_accum = 0;
        perf_window_start = t1;
    }

    g_guard_active = 0;

    u32 target = t0 + FRAME_TICKS;
    while (ticks_get() < target) { __asm__ volatile ("hlt"); }
}
