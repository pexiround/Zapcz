#include "js.h"
#include "util.h"
#include "libc_shim.h"
#include "pit.h"

#define JS_MAX_TOKENS   3000
#define JS_STR_LEN      96
#define JS_TEMP_SLOTS   96
#define JS_MAX_VARS     128
#define JS_VAR_STR      96
#define JS_MAX_ARRAYS   8
#define JS_ARR_ITEMS    64
#define JS_ARR_STR      48
#define JS_MAX_FUNCS    24
#define JS_MAX_PARAMS   6
#define JS_MAX_DEPTH    24
#define JS_STEP_LIMIT   400000

#define TK_EOF   0
#define TK_NUM   1
#define TK_STR   2
#define TK_IDENT 3
#define TK_PUNCT 4

typedef struct {
    u8  t;
    u8  plen;
    char p[4];
    i32 num;
    u16 spos, slen;
} jstok_t;

#define JV_UNDEF 0
#define JV_NUM   1
#define JV_STR   2
#define JV_BOOL  3
#define JV_ARR   4
#define JV_ELEM  5

typedef struct {
    u8  t;
    i32 n;
    i16 slot;
} jsval_t;

#define R_NORMAL   0
#define R_BREAK    1
#define R_CONTINUE 2
#define R_RETURN   3
#define R_ERROR    4

typedef struct {
    char name[24];
    u8   t;
    i32  n;
    char s[JS_VAR_STR];
    i16  arr;
    int  frame;
} jsvar_t;

typedef struct {
    u8   t;
    i32  n;
    char s[JS_ARR_STR];
} jsitem_t;

typedef struct {
    int      used;
    int      len;
    jsitem_t items[JS_ARR_ITEMS];
} jsarr_t;

typedef struct {
    char name[24];
    char params[JS_MAX_PARAMS][24];
    int  nparams;
    int  body_start;
    int  body_end;
} jsfunc_t;

static jstok_t toks[JS_MAX_TOKENS];
static int     ntoks;
static char    src_copy[16384];
static u32     src_len;

static char    temp_str[JS_TEMP_SLOTS][JS_STR_LEN];
static int     temp_next;

static jsvar_t vars[JS_MAX_VARS];
static int     nvars;
static int     frame_depth;

static jsarr_t arrays[JS_MAX_ARRAYS];
static jsfunc_t funcs[JS_MAX_FUNCS];
static int     nfuncs;

static html_doc_t* g_doc;
static char    g_err[96];
static int     g_error;
static u32     g_steps;
static int     g_pc;
static int     g_depth;

static char    elem_id[24];

const char* js_last_error(void) { return g_err; }
int js_had_error(void) { return g_error; }

static void jerr(const char* m) {
    if (!g_error) { str_copy(g_err, m, sizeof(g_err)); g_error = 1; }
}

static int is_dig(char c) { return c >= '0' && c <= '9'; }
static int is_alpha(char c) {
    return (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || c == '_' || c == '$';
}
static int is_alnum(char c) { return is_alpha(c) || is_dig(c); }

static int tok_is(int i, const char* s) {
    if (i < 0 || i >= ntoks) return 0;
    const jstok_t* t = &toks[i];
    if (t->t == TK_PUNCT) {
        int k = 0;
        while (s[k] && k < t->plen) { if (t->p[k] != s[k]) return 0; k++; }
        return s[k] == 0 && k == t->plen;
    }
    if (t->t == TK_IDENT) {
        u32 l = 0; while (s[l]) l++;
        if (l != t->slen) return 0;
        for (u32 k = 0; k < l; k++) if (src_copy[t->spos + k] != s[k]) return 0;
        return 1;
    }
    return 0;
}

static void ident_text(int i, char* out, u32 outlen) {
    out[0] = 0;
    if (i < 0 || i >= ntoks) return;
    u32 n = toks[i].slen;
    if (n > outlen - 1) n = outlen - 1;
    for (u32 k = 0; k < n; k++) out[k] = src_copy[toks[i].spos + k];
    out[n] = 0;
}

static int alloc_temp(void) {
    int s = temp_next;
    temp_next = (temp_next + 1) % JS_TEMP_SLOTS;
    temp_str[s][0] = 0;
    return s;
}

static const char* val_str(const jsval_t* v) {
    if (v->t == JV_STR || v->t == JV_ELEM) {
        if (v->slot >= 0 && v->slot < JS_TEMP_SLOTS) return temp_str[v->slot];
        return "";
    }
    return "";
}

static jsval_t mk_num(i32 n) { jsval_t v; v.t = JV_NUM; v.n = n; v.slot = -1; return v; }
static jsval_t mk_bool(int b) { jsval_t v; v.t = JV_BOOL; v.n = b ? 1 : 0; v.slot = -1; return v; }
static jsval_t mk_undef(void) { jsval_t v; v.t = JV_UNDEF; v.n = 0; v.slot = -1; return v; }
static jsval_t mk_arr(int a) { jsval_t v; v.t = JV_ARR; v.n = a; v.slot = -1; return v; }

static jsval_t mk_str(const char* s, u32 len) {
    jsval_t v; v.t = JV_STR; v.n = 0;
    int slot = alloc_temp();
    if (len > JS_STR_LEN - 1) len = JS_STR_LEN - 1;
    for (u32 i = 0; i < len; i++) temp_str[slot][i] = s[i];
    temp_str[slot][len] = 0;
    v.slot = (i16)slot;
    return v;
}

static void num_to_text(i32 n, char* out) { i32_to_str(n, out); }

static const char* to_text(const jsval_t* v, char* scratch, u32 slen) {
    if (v->t == JV_STR || v->t == JV_ELEM) return val_str(v);
    if (v->t == JV_NUM) { num_to_text(v->n, scratch); return scratch; }
    if (v->t == JV_BOOL) return v->n ? "true" : "false";
    if (v->t == JV_ARR) {
        scratch[0] = 0;
        jsarr_t* a = &arrays[v->n];
        for (int i = 0; i < a->len; i++) {
            if (i) str_cat(scratch, ",", slen);
            if (a->items[i].t == JV_STR) str_cat(scratch, a->items[i].s, slen);
            else { char nb[16]; num_to_text(a->items[i].n, nb); str_cat(scratch, nb, slen); }
        }
        return scratch;
    }
    return "undefined";
}

static i32 to_num(const jsval_t* v) {
    if (v->t == JV_NUM || v->t == JV_BOOL) return v->n;
    if (v->t == JV_STR) {
        const char* s = val_str(v);
        int neg = 0; u32 i = 0;
        while (s[i] == ' ') i++;
        if (s[i] == '-') { neg = 1; i++; } else if (s[i] == '+') i++;
        i32 r = 0;
        while (is_dig(s[i])) { r = r * 10 + (s[i] - '0'); i++; }
        return neg ? -r : r;
    }
    return 0;
}

static int truthy(const jsval_t* v) {
    if (v->t == JV_NUM || v->t == JV_BOOL) return v->n != 0;
    if (v->t == JV_STR) return val_str(v)[0] != 0;
    if (v->t == JV_ARR || v->t == JV_ELEM) return 1;
    return 0;
}

static int find_var(const char* name) {
    for (int i = nvars - 1; i >= 0; i--) {
        if (vars[i].frame != frame_depth && vars[i].frame != 0) continue;
        if (str_eq(vars[i].name, name)) return i;
    }
    return -1;
}

static int new_var(const char* name) {
    int e = find_var(name);
    if (e >= 0) return e;
    if (nvars >= JS_MAX_VARS) { jerr("too many variables"); return -1; }
    int i = nvars++;
    str_copy(vars[i].name, name, sizeof(vars[i].name));
    vars[i].t = JV_UNDEF; vars[i].n = 0; vars[i].s[0] = 0; vars[i].arr = -1;
    vars[i].frame = frame_depth;
    return i;
}

static void store_var(int vi, const jsval_t* v) {
    if (vi < 0) return;
    vars[vi].t = v->t;
    vars[vi].n = v->n;
    vars[vi].arr = -1;
    vars[vi].s[0] = 0;
    if (v->t == JV_STR || v->t == JV_ELEM) str_copy(vars[vi].s, val_str(v), JS_VAR_STR);
    else if (v->t == JV_ARR) vars[vi].arr = (i16)v->n;
}

static jsval_t load_var(int vi) {
    jsval_t v = mk_undef();
    if (vi < 0) return v;
    if (vars[vi].t == JV_STR || vars[vi].t == JV_ELEM) {
        v = mk_str(vars[vi].s, str_len(vars[vi].s));
        v.t = vars[vi].t;
        return v;
    }
    v.t = vars[vi].t;
    v.n = (vars[vi].t == JV_ARR) ? vars[vi].arr : vars[vi].n;
    return v;
}

static int alloc_array(void) {
    for (int i = 0; i < JS_MAX_ARRAYS; i++) {
        if (!arrays[i].used) { arrays[i].used = 1; arrays[i].len = 0; return i; }
    }
    jerr("too many arrays");
    return -1;
}

static void arr_set(int ai, int idx, const jsval_t* v) {
    if (ai < 0 || ai >= JS_MAX_ARRAYS || idx < 0 || idx >= JS_ARR_ITEMS) return;
    jsarr_t* a = &arrays[ai];
    a->items[idx].t = v->t;
    a->items[idx].n = v->n;
    a->items[idx].s[0] = 0;
    if (v->t == JV_STR) str_copy(a->items[idx].s, val_str(v), JS_ARR_STR);
    if (idx >= a->len) a->len = idx + 1;
}

static jsval_t arr_get(int ai, int idx) {
    if (ai < 0 || ai >= JS_MAX_ARRAYS || idx < 0 || idx >= arrays[ai].len) return mk_undef();
    jsitem_t* it = &arrays[ai].items[idx];
    if (it->t == JV_STR) return mk_str(it->s, str_len(it->s));
    jsval_t v = mk_undef(); v.t = it->t; v.n = it->n; return v;
}

static void out_text(const char* s, u32 len) {
    if (!g_doc) return;
    html_emit_text(g_doc, s, len);
}

static jsval_t expr(int run);
static int stmt(int run);
static int block_or_stmt(int run);

static void skip_balanced(char open, char close) {
    int d = 0;
    while (g_pc < ntoks) {
        if (toks[g_pc].t == TK_PUNCT && toks[g_pc].plen == 1) {
            if (toks[g_pc].p[0] == open) d++;
            else if (toks[g_pc].p[0] == close) { d--; g_pc++; if (d <= 0) return; continue; }
        }
        g_pc++;
    }
}

static int expect(const char* p) {
    if (tok_is(g_pc, p)) { g_pc++; return 1; }
    jerr("syntax error");
    return 0;
}

static int find_func(const char* name) {
    for (int i = 0; i < nfuncs; i++) if (str_eq(funcs[i].name, name)) return i;
    return -1;
}

static jsval_t call_func(int fi, jsval_t* args, int nargs, int run) {
    if (!run) return mk_undef();
    if (g_depth >= JS_MAX_DEPTH) { jerr("call depth exceeded"); return mk_undef(); }
    jsfunc_t* f = &funcs[fi];
    int saved_pc = g_pc;
    int saved_nvars = nvars;
    int saved_frame = frame_depth;

    frame_depth++;
    g_depth++;
    for (int i = 0; i < f->nparams; i++) {
        int vi = new_var(f->params[i]);
        if (i < nargs) store_var(vi, &args[i]);
    }
    int ri = new_var("__ret");
    g_pc = f->body_start;
    int r = block_or_stmt(1);
    jsval_t rv = mk_undef();
    if (r == R_RETURN) rv = load_var(ri);

    nvars = saved_nvars;
    frame_depth = saved_frame;
    g_depth--;
    g_pc = saved_pc;
    if (rv.t == JV_STR) {
        jsval_t c = mk_str(val_str(&rv), str_len(val_str(&rv)));
        return c;
    }
    return rv;
}

static i32 isqrt32(i32 v) {
    if (v <= 0) return 0;
    i32 x = v, y = (x + 1) / 2;
    while (y < x) { x = y; y = (x + v / x) / 2; }
    return x;
}

static i32 ipow(i32 b, i32 e) {
    i32 r = 1;
    while (e > 0) { r *= b; e--; if (r > 1000000000 || r < -1000000000) break; }
    return r;
}

static jsval_t builtin_call(const char* obj, const char* meth, jsval_t* a, int n, int run) {
    char sc[160];
    if (str_eq(obj, "document")) {
        if (str_eq(meth, "write") || str_eq(meth, "writeln")) {
            if (run) {
                for (int i = 0; i < n; i++) {
                    const char* s = to_text(&a[i], sc, sizeof(sc));
                    out_text(s, str_len(s));
                }
            }
            return mk_undef();
        }
        if (str_eq(meth, "getElementById")) {
            jsval_t v = (n > 0) ? mk_str(to_text(&a[0], sc, sizeof(sc)), str_len(to_text(&a[0], sc, sizeof(sc)))) : mk_str("", 0);
            v.t = JV_ELEM;
            return v;
        }
        jerr("unsupported document method");
        return mk_undef();
    }
    if (str_eq(obj, "console")) {
        if (run) {
            for (int i = 0; i < n; i++) {
                const char* s = to_text(&a[i], sc, sizeof(sc));
                out_text(s, str_len(s));
                if (i + 1 < n) out_text(" ", 1);
            }
            out_text("\n", 1);
        }
        return mk_undef();
    }
    if (str_eq(obj, "Math")) {
        i32 x = n > 0 ? to_num(&a[0]) : 0;
        i32 y = n > 1 ? to_num(&a[1]) : 0;
        if (str_eq(meth, "abs")) return mk_num(x < 0 ? -x : x);
        if (str_eq(meth, "max")) { i32 m = x; for (int i = 1; i < n; i++) { i32 t = to_num(&a[i]); if (t > m) m = t; } return mk_num(n ? m : 0); }
        if (str_eq(meth, "min")) { i32 m = x; for (int i = 1; i < n; i++) { i32 t = to_num(&a[i]); if (t < m) m = t; } return mk_num(n ? m : 0); }
        if (str_eq(meth, "floor") || str_eq(meth, "ceil") || str_eq(meth, "round") || str_eq(meth, "trunc")) return mk_num(x);
        if (str_eq(meth, "sqrt")) return mk_num(isqrt32(x));
        if (str_eq(meth, "pow")) return mk_num(ipow(x, y));
        jerr("unsupported Math method");
        return mk_undef();
    }
    return mk_undef();
}

static jsval_t str_method(const jsval_t* base, const char* meth, jsval_t* a, int n) {
    char sc[160];
    const char* s = to_text(base, sc, sizeof(sc));
    u32 sl = str_len(s);
    if (str_eq(meth, "charAt")) {
        i32 i = n > 0 ? to_num(&a[0]) : 0;
        if (i < 0 || (u32)i >= sl) return mk_str("", 0);
        return mk_str(s + i, 1);
    }
    if (str_eq(meth, "toUpperCase")) {
        char b[JS_STR_LEN]; u32 i = 0;
        for (; i < sl && i < JS_STR_LEN - 1; i++) b[i] = (s[i] >= 'a' && s[i] <= 'z') ? (char)(s[i] - 32) : s[i];
        return mk_str(b, i);
    }
    if (str_eq(meth, "toLowerCase")) {
        char b[JS_STR_LEN]; u32 i = 0;
        for (; i < sl && i < JS_STR_LEN - 1; i++) b[i] = (s[i] >= 'A' && s[i] <= 'Z') ? (char)(s[i] + 32) : s[i];
        return mk_str(b, i);
    }
    if (str_eq(meth, "indexOf")) {
        char nb[JS_STR_LEN]; str_copy(nb, n > 0 ? val_str(&a[0]) : "", sizeof(nb));
        u32 nl = str_len(nb);
        if (!nl) return mk_num(0);
        for (u32 i = 0; i + nl <= sl; i++) {
            u32 k = 0; while (k < nl && s[i + k] == nb[k]) k++;
            if (k == nl) return mk_num((i32)i);
        }
        return mk_num(-1);
    }
    if (str_eq(meth, "substring") || str_eq(meth, "substr") || str_eq(meth, "slice")) {
        i32 b = n > 0 ? to_num(&a[0]) : 0;
        i32 e = n > 1 ? to_num(&a[1]) : (i32)sl;
        if (str_eq(meth, "substr") && n > 1) e = b + to_num(&a[1]);
        if (b < 0) b = 0; if (e > (i32)sl) e = (i32)sl; if (e < b) e = b;
        return mk_str(s + b, (u32)(e - b));
    }
    if (str_eq(meth, "repeat")) {
        i32 c = n > 0 ? to_num(&a[0]) : 0;
        char b[JS_STR_LEN]; u32 o = 0;
        for (i32 k = 0; k < c && o + sl < JS_STR_LEN - 1; k++) { for (u32 i = 0; i < sl; i++) b[o++] = s[i]; }
        return mk_str(b, o);
    }
    jerr("unsupported string method");
    return mk_undef();
}

static jsval_t arr_method(int ai, const char* meth, jsval_t* a, int n) {
    if (ai < 0) return mk_undef();
    jsarr_t* arr = &arrays[ai];
    if (str_eq(meth, "push")) {
        for (int i = 0; i < n; i++) {
            if (arr->len >= JS_ARR_ITEMS) { jerr("array full"); break; }
            arr_set(ai, arr->len, &a[i]);
        }
        return mk_num(arr->len);
    }
    if (str_eq(meth, "pop")) {
        if (arr->len <= 0) return mk_undef();
        jsval_t v = arr_get(ai, arr->len - 1);
        arr->len--;
        return v;
    }
    if (str_eq(meth, "join")) {
        char sep[16]; str_copy(sep, n > 0 ? val_str(&a[0]) : ",", sizeof(sep));
        char b[JS_STR_LEN]; b[0] = 0;
        for (int i = 0; i < arr->len; i++) {
            if (i) str_cat(b, sep, sizeof(b));
            if (arr->items[i].t == JV_STR) str_cat(b, arr->items[i].s, sizeof(b));
            else { char nb[16]; num_to_text(arr->items[i].n, nb); str_cat(b, nb, sizeof(b)); }
        }
        return mk_str(b, str_len(b));
    }
    if (str_eq(meth, "indexOf")) {
        for (int i = 0; i < arr->len; i++) {
            if (n > 0 && arr->items[i].t == a[0].t) {
                if (a[0].t == JV_STR) { if (str_eq(arr->items[i].s, val_str(&a[0]))) return mk_num(i); }
                else if (arr->items[i].n == a[0].n) return mk_num(i);
            }
        }
        return mk_num(-1);
    }
    jerr("unsupported array method");
    return mk_undef();
}

static int parse_args(jsval_t* out, int max, int run) {
    int n = 0;
    if (!expect("(")) return 0;
    if (tok_is(g_pc, ")")) { g_pc++; return 0; }
    while (g_pc < ntoks && !g_error) {
        jsval_t v = expr(run);
        if (n < max) out[n++] = v;
        if (tok_is(g_pc, ",")) { g_pc++; continue; }
        break;
    }
    expect(")");
    return n;
}

static jsval_t postfix(jsval_t base, int run);

static jsval_t primary(int run) {
    if (g_error || g_pc >= ntoks) return mk_undef();
    jstok_t* t = &toks[g_pc];

    if (t->t == TK_NUM) { g_pc++; return mk_num(t->num); }
    if (t->t == TK_STR) { g_pc++; return mk_str(src_copy + t->spos, t->slen); }

    if (tok_is(g_pc, "(")) {
        g_pc++;
        jsval_t v = expr(run);
        expect(")");
        return postfix(v, run);
    }
    if (tok_is(g_pc, "[")) {
        g_pc++;
        int ai = run ? alloc_array() : -1;
        while (g_pc < ntoks && !tok_is(g_pc, "]") && !g_error) {
            jsval_t v = expr(run);
            if (run && ai >= 0 && arrays[ai].len < JS_ARR_ITEMS) arr_set(ai, arrays[ai].len, &v);
            if (tok_is(g_pc, ",")) { g_pc++; continue; }
            break;
        }
        expect("]");
        return postfix(run && ai >= 0 ? mk_arr(ai) : mk_undef(), run);
    }
    if (tok_is(g_pc, "!")) { g_pc++; jsval_t v = primary(run); return mk_bool(!truthy(&v)); }
    if (tok_is(g_pc, "-")) { g_pc++; jsval_t v = primary(run); return mk_num(-to_num(&v)); }
    if (tok_is(g_pc, "+")) { g_pc++; jsval_t v = primary(run); return mk_num(to_num(&v)); }
    if (tok_is(g_pc, "~")) { g_pc++; jsval_t v = primary(run); return mk_num(~to_num(&v)); }
    if (tok_is(g_pc, "++") || tok_is(g_pc, "--")) {
        int inc = tok_is(g_pc, "++");
        g_pc++;
        if (toks[g_pc].t != TK_IDENT) { jerr("bad ++"); return mk_undef(); }
        char nm[24]; ident_text(g_pc, nm, sizeof(nm)); g_pc++;
        int vi = find_var(nm);
        if (run && vi >= 0) {
            jsval_t cur = load_var(vi);
            jsval_t nv = mk_num(to_num(&cur) + (inc ? 1 : -1));
            store_var(vi, &nv);
            return nv;
        }
        return mk_undef();
    }

    if (t->t == TK_IDENT) {
        char nm[24]; ident_text(g_pc, nm, sizeof(nm));

        if (str_eq(nm, "true")) { g_pc++; return mk_bool(1); }
        if (str_eq(nm, "false")) { g_pc++; return mk_bool(0); }
        if (str_eq(nm, "null") || str_eq(nm, "undefined")) { g_pc++; return mk_undef(); }
        if (str_eq(nm, "new")) { g_pc++; return primary(run); }

        if (str_eq(nm, "document") || str_eq(nm, "console") || str_eq(nm, "Math")) {
            g_pc++;
            if (!tok_is(g_pc, ".")) return mk_undef();
            g_pc++;
            char meth[24]; ident_text(g_pc, meth, sizeof(meth)); g_pc++;
            if (str_eq(nm, "Math") && !tok_is(g_pc, "(")) {
                if (str_eq(meth, "PI")) return mk_num(3);
                if (str_eq(meth, "E")) return mk_num(2);
                return mk_undef();
            }
            jsval_t args[6];
            int n = parse_args(args, 6, run);
            jsval_t r = builtin_call(nm, meth, args, n, run);
            return postfix(r, run);
        }

        if (str_eq(nm, "Array")) {
            g_pc++;
            jsval_t args[6];
            parse_args(args, 6, run);
            return run ? mk_arr(alloc_array()) : mk_undef();
        }
        if (str_eq(nm, "parseInt") || str_eq(nm, "Number")) {
            g_pc++;
            jsval_t args[4]; int n = parse_args(args, 4, run);
            return mk_num(n ? to_num(&args[0]) : 0);
        }
        if (str_eq(nm, "String")) {
            g_pc++;
            jsval_t args[4]; int n = parse_args(args, 4, run);
            char sc[160];
            if (!n) return mk_str("", 0);
            const char* s = to_text(&args[0], sc, sizeof(sc));
            return mk_str(s, str_len(s));
        }
        if (str_eq(nm, "alert")) {
            g_pc++;
            jsval_t args[4]; int n = parse_args(args, 4, run);
            if (run && n) {
                char sc[160];
                const char* s = to_text(&args[0], sc, sizeof(sc));
                out_text(s, str_len(s));
                out_text("\n", 1);
            }
            return mk_undef();
        }

        int fi = find_func(nm);
        if (fi >= 0 && tok_is(g_pc + 1, "(")) {
            g_pc++;
            jsval_t args[JS_MAX_PARAMS];
            int n = parse_args(args, JS_MAX_PARAMS, run);
            return postfix(call_func(fi, args, n, run), run);
        }

        g_pc++;
        int vi = find_var(nm);
        if (vi < 0) {
            if (tok_is(g_pc, "(")) { jsval_t a2[4]; parse_args(a2, 4, run); jerr("unknown function"); return mk_undef(); }
            if (tok_is(g_pc, "++") || tok_is(g_pc, "--")) g_pc++;
            return postfix(mk_undef(), run);
        }
        if (tok_is(g_pc, "++") || tok_is(g_pc, "--")) {
            int inc = tok_is(g_pc, "++");
            g_pc++;
            jsval_t old = load_var(vi);
            i32 ov = to_num(&old);
            if (run) {
                jsval_t nv = mk_num(ov + (inc ? 1 : -1));
                store_var(vi, &nv);
            }
            return mk_num(ov);
        }
        return postfix(load_var(vi), run);
    }

    g_pc++;
    return mk_undef();
}

static jsval_t postfix(jsval_t base, int run) {
    while (g_pc < ntoks && !g_error) {
        if (tok_is(g_pc, ".")) {
            g_pc++;
            char meth[24]; ident_text(g_pc, meth, sizeof(meth)); g_pc++;
            if (str_eq(meth, "length")) {
                if (base.t == JV_ARR) base = mk_num(arrays[base.n].len);
                else { char sc[160]; base = mk_num((i32)str_len(to_text(&base, sc, sizeof(sc)))); }
                continue;
            }
            if (base.t == JV_ELEM && (str_eq(meth, "innerHTML") || str_eq(meth, "textContent") || str_eq(meth, "innerText"))) {
                str_copy(elem_id, val_str(&base), sizeof(elem_id));
                jsval_t marker = mk_str(elem_id, str_len(elem_id));
                marker.t = JV_ELEM;
                base = marker;
                continue;
            }
            if (tok_is(g_pc, "(")) {
                jsval_t args[6];
                int n = parse_args(args, 6, run);
                if (!run) { base = mk_undef(); continue; }
                if (base.t == JV_ARR) base = arr_method(base.n, meth, args, n);
                else base = str_method(&base, meth, args, n);
                continue;
            }
            base = mk_undef();
            continue;
        }
        if (tok_is(g_pc, "[")) {
            g_pc++;
            jsval_t idx = expr(run);
            expect("]");
            if (!run) { base = mk_undef(); continue; }
            if (base.t == JV_ARR) base = arr_get(base.n, to_num(&idx));
            else {
                char sc[160];
                const char* s = to_text(&base, sc, sizeof(sc));
                i32 i = to_num(&idx);
                base = (i >= 0 && (u32)i < str_len(s)) ? mk_str(s + i, 1) : mk_str("", 0);
            }
            continue;
        }
        break;
    }
    return base;
}

static jsval_t mul_expr(int run) {
    jsval_t l = primary(run);
    while (!g_error && (tok_is(g_pc, "*") || tok_is(g_pc, "/") || tok_is(g_pc, "%"))) {
        char op = toks[g_pc].p[0];
        g_pc++;
        jsval_t r = primary(run);
        i32 a = to_num(&l), b = to_num(&r);
        if (op == '*') l = mk_num(a * b);
        else if (op == '/') l = mk_num(b ? a / b : 0);
        else l = mk_num(b ? a % b : 0);
    }
    return l;
}

static jsval_t add_expr(int run) {
    jsval_t l = mul_expr(run);
    while (!g_error && (tok_is(g_pc, "+") || tok_is(g_pc, "-"))) {
        int plus = tok_is(g_pc, "+");
        g_pc++;
        jsval_t r = mul_expr(run);
        if (plus && (l.t == JV_STR || r.t == JV_STR)) {
            char sa[160], sb[160], out[JS_STR_LEN];
            const char* x = to_text(&l, sa, sizeof(sa));
            const char* y = to_text(&r, sb, sizeof(sb));
            str_copy(out, x, sizeof(out));
            str_cat(out, y, sizeof(out));
            l = mk_str(out, str_len(out));
        } else {
            i32 a = to_num(&l), b = to_num(&r);
            l = mk_num(plus ? a + b : a - b);
        }
    }
    return l;
}

static jsval_t shift_expr(int run) {
    jsval_t l = add_expr(run);
    while (!g_error && (tok_is(g_pc, "<<") || tok_is(g_pc, ">>"))) {
        int left = tok_is(g_pc, "<<");
        g_pc++;
        jsval_t r = add_expr(run);
        i32 a = to_num(&l), b = to_num(&r) & 31;
        l = mk_num(left ? (a << b) : (a >> b));
    }
    return l;
}

static jsval_t rel_expr(int run) {
    jsval_t l = shift_expr(run);
    while (!g_error && (tok_is(g_pc, "<") || tok_is(g_pc, ">") || tok_is(g_pc, "<=") || tok_is(g_pc, ">="))) {
        char o0 = toks[g_pc].p[0];
        int eq = toks[g_pc].plen == 2;
        g_pc++;
        jsval_t r = shift_expr(run);
        i32 a = to_num(&l), b = to_num(&r);
        int res = (o0 == '<') ? (eq ? a <= b : a < b) : (eq ? a >= b : a > b);
        l = mk_bool(res);
    }
    return l;
}

static int vals_equal(jsval_t* a, jsval_t* b) {
    if (a->t == JV_STR || b->t == JV_STR) {
        char sa[160], sb[160];
        return str_eq(to_text(a, sa, sizeof(sa)), to_text(b, sb, sizeof(sb)));
    }
    return to_num(a) == to_num(b);
}

static jsval_t eq_expr(int run) {
    jsval_t l = rel_expr(run);
    while (!g_error && (tok_is(g_pc, "==") || tok_is(g_pc, "!=") || tok_is(g_pc, "===") || tok_is(g_pc, "!=="))) {
        int neg = toks[g_pc].p[0] == '!';
        g_pc++;
        jsval_t r = rel_expr(run);
        int e = vals_equal(&l, &r);
        l = mk_bool(neg ? !e : e);
    }
    return l;
}

static jsval_t band_expr(int run) {
    jsval_t l = eq_expr(run);
    while (!g_error && tok_is(g_pc, "&")) { g_pc++; jsval_t r = eq_expr(run); l = mk_num(to_num(&l) & to_num(&r)); }
    return l;
}
static jsval_t bxor_expr(int run) {
    jsval_t l = band_expr(run);
    while (!g_error && tok_is(g_pc, "^")) { g_pc++; jsval_t r = band_expr(run); l = mk_num(to_num(&l) ^ to_num(&r)); }
    return l;
}
static jsval_t bor_expr(int run) {
    jsval_t l = bxor_expr(run);
    while (!g_error && tok_is(g_pc, "|")) { g_pc++; jsval_t r = bxor_expr(run); l = mk_num(to_num(&l) | to_num(&r)); }
    return l;
}
static jsval_t and_expr(int run) {
    jsval_t l = bor_expr(run);
    while (!g_error && tok_is(g_pc, "&&")) {
        g_pc++;
        int lt = truthy(&l);
        jsval_t r = bor_expr(run && lt);
        l = lt ? r : mk_bool(0);
    }
    return l;
}
static jsval_t or_expr(int run) {
    jsval_t l = and_expr(run);
    while (!g_error && tok_is(g_pc, "||")) {
        g_pc++;
        int lt = truthy(&l);
        jsval_t r = and_expr(run && !lt);
        l = lt ? l : r;
    }
    return l;
}

static jsval_t cond_expr(int run) {
    jsval_t c = or_expr(run);
    if (tok_is(g_pc, "?")) {
        g_pc++;
        int t = truthy(&c);
        jsval_t a = expr(run && t);
        expect(":");
        jsval_t b = expr(run && !t);
        return t ? a : b;
    }
    return c;
}

static jsval_t expr(int run) {
    if (g_error) return mk_undef();
    g_steps++;
    if (g_steps > JS_STEP_LIMIT) { jerr("script ran too long"); return mk_undef(); }

    if (toks[g_pc].t == TK_IDENT) {
        char nm[24]; ident_text(g_pc, nm, sizeof(nm));

        if (str_eq(nm, "document") && tok_is(g_pc + 1, ".")) {
            int save = g_pc;
            jsval_t v = cond_expr(run);
            if (v.t == JV_ELEM && (tok_is(g_pc, "=") || tok_is(g_pc, "+="))) {
                int append = tok_is(g_pc, "+=");
                g_pc++;
                jsval_t rhs = expr(run);
                if (run && g_doc) {
                    char sc[160];
                    const char* s = to_text(&rhs, sc, sizeof(sc));
                    if (!html_set_by_id(g_doc, elem_id, s, str_len(s)) && !append) {
                        out_text(s, str_len(s));
                        out_text("\n", 1);
                    }
                }
                return rhs;
            }
            (void)save;
            return v;
        }

        int assign_op = -1;
        if (tok_is(g_pc + 1, "=")) assign_op = 0;
        else if (tok_is(g_pc + 1, "+=")) assign_op = 1;
        else if (tok_is(g_pc + 1, "-=")) assign_op = 2;
        else if (tok_is(g_pc + 1, "*=")) assign_op = 3;
        else if (tok_is(g_pc + 1, "/=")) assign_op = 4;
        else if (tok_is(g_pc + 1, "%=")) assign_op = 5;

        if (assign_op >= 0) {
            g_pc += 2;
            jsval_t rhs = expr(run);
            if (!run) return rhs;
            int vi = find_var(nm);
            if (vi < 0) vi = new_var(nm);
            if (assign_op == 0) { store_var(vi, &rhs); return rhs; }
            jsval_t cur = load_var(vi);
            jsval_t nv;
            if (assign_op == 1 && (cur.t == JV_STR || rhs.t == JV_STR)) {
                char sa[160], sb[160], out[JS_STR_LEN];
                str_copy(out, to_text(&cur, sa, sizeof(sa)), sizeof(out));
                str_cat(out, to_text(&rhs, sb, sizeof(sb)), sizeof(out));
                nv = mk_str(out, str_len(out));
            } else {
                i32 a = to_num(&cur), b = to_num(&rhs);
                i32 r = a;
                if (assign_op == 1) r = a + b;
                else if (assign_op == 2) r = a - b;
                else if (assign_op == 3) r = a * b;
                else if (assign_op == 4) r = b ? a / b : 0;
                else if (assign_op == 5) r = b ? a % b : 0;
                nv = mk_num(r);
            }
            store_var(vi, &nv);
            return nv;
        }

        int vi = find_var(nm);
        if (vi >= 0 && vars[vi].t == JV_ARR && tok_is(g_pc + 1, "[")) {
            int save = g_pc;
            g_pc += 2;
            jsval_t idx = expr(run);
            if (tok_is(g_pc, "]") && tok_is(g_pc + 1, "=")) {
                g_pc += 2;
                jsval_t rhs = expr(run);
                if (run) arr_set(vars[vi].arr, to_num(&idx), &rhs);
                return rhs;
            }
            g_pc = save;
        }
    }
    return cond_expr(run);
}

static int block_or_stmt(int run) {
    if (tok_is(g_pc, "{")) {
        g_pc++;
        while (g_pc < ntoks && !tok_is(g_pc, "}") && !g_error) {
            int r = stmt(run);
            if (r != R_NORMAL) {
                int d = 1;
                while (g_pc < ntoks && d > 0) {
                    if (tok_is(g_pc, "{")) d++;
                    else if (tok_is(g_pc, "}")) d--;
                    if (d > 0) g_pc++;
                }
                if (tok_is(g_pc, "}")) g_pc++;
                return r;
            }
        }
        if (tok_is(g_pc, "}")) g_pc++;
        return R_NORMAL;
    }
    return stmt(run);
}

static void skip_semi(void) { while (tok_is(g_pc, ";")) g_pc++; }

static int stmt(int run) {
    if (g_error || g_pc >= ntoks) return R_NORMAL;
    g_steps++;
    if (g_steps > JS_STEP_LIMIT) { jerr("script ran too long"); return R_ERROR; }
    if ((g_steps & 0x3FFF) == 0) watchdog_heartbeat("js");

    if (tok_is(g_pc, ";")) { g_pc++; return R_NORMAL; }
    if (tok_is(g_pc, "{")) return block_or_stmt(run);

    if (toks[g_pc].t == TK_IDENT) {
        char nm[24]; ident_text(g_pc, nm, sizeof(nm));

        if (str_eq(nm, "var") || str_eq(nm, "let") || str_eq(nm, "const")) {
            g_pc++;
            while (g_pc < ntoks && !g_error) {
                char vn[24]; ident_text(g_pc, vn, sizeof(vn)); g_pc++;
                int vi = run ? new_var(vn) : -1;
                if (tok_is(g_pc, "=")) {
                    g_pc++;
                    jsval_t v = expr(run);
                    if (run) store_var(vi, &v);
                }
                if (tok_is(g_pc, ",")) { g_pc++; continue; }
                break;
            }
            skip_semi();
            return R_NORMAL;
        }

        if (str_eq(nm, "function")) {
            g_pc++;
            g_pc++;
            skip_balanced('(', ')');
            if (tok_is(g_pc, "{")) skip_balanced('{', '}');
            return R_NORMAL;
        }

        if (str_eq(nm, "if")) {
            g_pc++;
            expect("(");
            jsval_t c = expr(run);
            expect(")");
            int t = run && truthy(&c);
            int r = block_or_stmt(t);
            if (tok_is(g_pc, "else")) {
                g_pc++;
                int r2 = block_or_stmt(run && !t);
                if (!t) r = r2;
            }
            return t || !run ? r : R_NORMAL;
        }

        if (str_eq(nm, "while")) {
            g_pc++;
            int cond_pc = g_pc;
            int iter = 0;
            while (!g_error) {
                g_pc = cond_pc;
                expect("(");
                jsval_t c = expr(run);
                expect(")");
                int t = run && truthy(&c);
                int r = block_or_stmt(t);
                if (!t) break;
                if (r == R_BREAK) break;
                if (r == R_RETURN) return r;
                if (++iter > 100000) { jerr("loop limit reached"); break; }
                g_steps++;
                if (g_steps > JS_STEP_LIMIT) { jerr("script ran too long"); break; }
            }
            return R_NORMAL;
        }

        if (str_eq(nm, "do")) {
            g_pc++;
            int body_pc = g_pc;
            int iter = 0;
            while (!g_error) {
                g_pc = body_pc;
                int r = block_or_stmt(run);
                if (r == R_RETURN) return r;
                if (!tok_is(g_pc, "while")) { jerr("expected while"); break; }
                g_pc++;
                expect("(");
                jsval_t c = expr(run);
                expect(")");
                skip_semi();
                if (r == R_BREAK) break;
                if (!run || !truthy(&c)) break;
                if (++iter > 100000) { jerr("loop limit reached"); break; }
            }
            return R_NORMAL;
        }

        if (str_eq(nm, "for")) {
            g_pc++;
            expect("(");
            if (!tok_is(g_pc, ";")) stmt(run);
            skip_semi();
            int cond_pc = g_pc;
            int iter = 0;
            int inc_pc = -1, body_pc = -1;
            while (!g_error) {
                g_pc = cond_pc;
                int t = 1;
                if (!tok_is(g_pc, ";")) { jsval_t c = expr(run); t = run && truthy(&c); }
                skip_semi();
                inc_pc = g_pc;
                if (!tok_is(g_pc, ")")) expr(0);
                expect(")");
                body_pc = g_pc;
                int r = block_or_stmt(t);
                if (!t) break;
                if (r == R_BREAK) break;
                if (r == R_RETURN) return r;
                g_pc = inc_pc;
                if (!tok_is(g_pc, ")")) expr(run);
                if (++iter > 100000) { jerr("loop limit reached"); break; }
                g_steps++;
                if (g_steps > JS_STEP_LIMIT) { jerr("script ran too long"); break; }
            }
            (void)body_pc;
            return R_NORMAL;
        }

        if (str_eq(nm, "return")) {
            g_pc++;
            jsval_t v = mk_undef();
            if (!tok_is(g_pc, ";") && !tok_is(g_pc, "}")) v = expr(run);
            skip_semi();
            if (run) {
                int vi = find_var("__ret");
                if (vi >= 0) store_var(vi, &v);
            }
            return R_RETURN;
        }
        if (str_eq(nm, "break")) { g_pc++; skip_semi(); return R_BREAK; }
        if (str_eq(nm, "continue")) { g_pc++; skip_semi(); return R_CONTINUE; }
    }

    expr(run);
    skip_semi();
    return R_NORMAL;
}

static void tokenize(const char* s, u32 len) {
    ntoks = 0;
    u32 i = 0;
    while (i < len && ntoks < JS_MAX_TOKENS - 1) {
        char c = s[i];
        if (c == ' ' || c == '\t' || c == '\n' || c == '\r') { i++; continue; }
        if (c == '/' && i + 1 < len && s[i + 1] == '/') { while (i < len && s[i] != '\n') i++; continue; }
        if (c == '/' && i + 1 < len && s[i + 1] == '*') {
            i += 2;
            while (i + 1 < len && !(s[i] == '*' && s[i + 1] == '/')) i++;
            i += 2;
            continue;
        }
        jstok_t* t = &toks[ntoks];
        t->num = 0; t->spos = 0; t->slen = 0; t->plen = 0;

        if (is_dig(c)) {
            i32 v = 0;
            if (c == '0' && i + 1 < len && (s[i + 1] == 'x' || s[i + 1] == 'X')) {
                i += 2;
                while (i < len) {
                    char h = s[i];
                    int d;
                    if (is_dig(h)) d = h - '0';
                    else if (h >= 'a' && h <= 'f') d = h - 'a' + 10;
                    else if (h >= 'A' && h <= 'F') d = h - 'A' + 10;
                    else break;
                    v = v * 16 + d; i++;
                }
            } else {
                while (i < len && is_dig(s[i])) { v = v * 10 + (s[i] - '0'); i++; }
                if (i < len && s[i] == '.') { i++; while (i < len && is_dig(s[i])) i++; }
            }
            t->t = TK_NUM; t->num = v; ntoks++;
            continue;
        }
        if (c == '"' || c == '\'' || c == '`') {
            char q = c;
            i++;
            u32 st = i;
            u32 outp = st;
            while (i < len && s[i] != q) {
                if (s[i] == '\\' && i + 1 < len) {
                    i++;
                    char e = s[i];
                    char d = e;
                    if (e == 'n') d = '\n';
                    else if (e == 't') d = '\t';
                    else if (e == 'r') d = '\r';
                    src_copy[outp++] = d;
                    i++;
                    continue;
                }
                src_copy[outp++] = s[i];
                i++;
            }
            if (i < len) i++;
            t->t = TK_STR; t->spos = (u16)st; t->slen = (u16)(outp - st); ntoks++;
            continue;
        }
        if (is_alpha(c)) {
            u32 st = i;
            while (i < len && is_alnum(s[i])) i++;
            t->t = TK_IDENT; t->spos = (u16)st; t->slen = (u16)(i - st); ntoks++;
            continue;
        }

        static const char* three[] = { "===", "!==", "<<=", ">>=", 0 };
        static const char* two[] = { "==", "!=", "<=", ">=", "&&", "||", "++", "--",
                                     "+=", "-=", "*=", "/=", "%=", "<<", ">>", 0 };
        int matched = 0;
        for (int k = 0; three[k] && !matched; k++) {
            if (i + 2 < len && s[i] == three[k][0] && s[i + 1] == three[k][1] && s[i + 2] == three[k][2]) {
                t->t = TK_PUNCT; t->plen = 3;
                t->p[0] = three[k][0]; t->p[1] = three[k][1]; t->p[2] = three[k][2]; t->p[3] = 0;
                i += 3; ntoks++; matched = 1;
            }
        }
        if (matched) continue;
        for (int k = 0; two[k] && !matched; k++) {
            if (i + 1 < len && s[i] == two[k][0] && s[i + 1] == two[k][1]) {
                t->t = TK_PUNCT; t->plen = 2;
                t->p[0] = two[k][0]; t->p[1] = two[k][1]; t->p[2] = 0;
                i += 2; ntoks++; matched = 1;
            }
        }
        if (matched) continue;
        t->t = TK_PUNCT; t->plen = 1; t->p[0] = c; t->p[1] = 0;
        i++; ntoks++;
    }
    toks[ntoks].t = TK_EOF;
    toks[ntoks].plen = 0;
    toks[ntoks].p[0] = 0;
}

static void collect_functions(void) {
    nfuncs = 0;
    for (int i = 0; i < ntoks && nfuncs < JS_MAX_FUNCS; i++) {
        if (toks[i].t != TK_IDENT) continue;
        if (!tok_is(i, "function")) continue;
        if (i + 1 >= ntoks || toks[i + 1].t != TK_IDENT) continue;
        jsfunc_t* f = &funcs[nfuncs];
        ident_text(i + 1, f->name, sizeof(f->name));
        f->nparams = 0;
        int j = i + 2;
        if (!tok_is(j, "(")) continue;
        j++;
        while (j < ntoks && !tok_is(j, ")")) {
            if (toks[j].t == TK_IDENT && f->nparams < JS_MAX_PARAMS) {
                ident_text(j, f->params[f->nparams], 24);
                f->nparams++;
            }
            j++;
        }
        j++;
        if (!tok_is(j, "{")) continue;
        f->body_start = j;
        int d = 0, k = j;
        while (k < ntoks) {
            if (tok_is(k, "{")) d++;
            else if (tok_is(k, "}")) { d--; if (d == 0) break; }
            k++;
        }
        f->body_end = k;
        nfuncs++;
    }
}

void js_run(const char* src, u32 len, html_doc_t* doc) {
    g_doc = doc;
    g_error = 0;
    g_err[0] = 0;
    g_steps = 0;
    g_pc = 0;
    g_depth = 0;
    nvars = 0;
    frame_depth = 0;
    temp_next = 0;
    for (int i = 0; i < JS_MAX_ARRAYS; i++) { arrays[i].used = 0; arrays[i].len = 0; }

    if (len >= sizeof(src_copy)) len = sizeof(src_copy) - 1;
    for (u32 i = 0; i < len; i++) src_copy[i] = src[i];
    src_copy[len] = 0;
    src_len = len;

    tokenize(src_copy, src_len);
    collect_functions();

    while (g_pc < ntoks && !g_error) {
        int before = g_pc;
        int r = stmt(1);
        if (r == R_ERROR) break;
        if (g_pc == before) g_pc++;
    }

    if (g_error && doc) {
        doc->js_errors++;
        str_copy(doc->js_error, g_err, sizeof(doc->js_error));
    }
}
