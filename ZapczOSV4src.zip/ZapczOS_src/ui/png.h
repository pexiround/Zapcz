#ifndef PNG_H
#define PNG_H
#include "io.h"

#define PNG_OK                 1
#define PNG_ERR_NO_DISK         0
#define PNG_ERR_NOT_FOUND      -1
#define PNG_ERR_TOO_BIG        -2
#define PNG_ERR_BAD_SIGNATURE  -3
#define PNG_ERR_UNSUPPORTED    -4
#define PNG_ERR_WRITE_FAILED   -5

int png_encode_rgb_to_file(const char* filename, const u8* rgb, u32 width, u32 height);

int png_decode_file(const char* filename, u8* out_rgb, u32 max_w, u32 max_h,
                     u32* out_w, u32* out_h);
int png_decode_mem(const u8* data, u32 len, u8* out_rgb, u32 max_w, u32 max_h,
                     u32* out_w, u32* out_h);

const char* png_error_string(int code);

#endif
