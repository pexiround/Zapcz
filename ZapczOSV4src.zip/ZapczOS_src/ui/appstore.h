#ifndef APPSTORE_H
#define APPSTORE_H
#include "io.h"

void store_init(void);
void app_store_draw(i32 x, i32 y, i32 w, i32 h);
void app_store_click(i32 rx, i32 ry);
void app_store_key(int key);
void app_store_wheel(i32 delta);
void app_store_drag(i32 rx, i32 ry);

int app_is_installed(int app_id);

#endif
