#ifndef CUBE3D_H
#define CUBE3D_H
#include "io.h"

void cube3d_init(void);
void app_cube3d_draw(i32 x, i32 y, i32 w, i32 h);
void cube3d_toggle(void);
void app_cube3d_key(int key);
void app_cube3d_click(i32 rx, i32 ry);

#endif
