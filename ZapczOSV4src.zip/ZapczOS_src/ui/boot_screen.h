#ifndef BOOT_SCREEN_H
#define BOOT_SCREEN_H
#include "io.h"
#include "graphics.h"

void boot_screen_init(void);
void boot_screen_section(const char* msg);
void boot_screen_log(const char* msg);
void boot_screen_status(int ok);
void boot_screen_finish(void);
void boot_screen_goodbye(void);
void boot_screen_shutdown_init(void);
void boot_screen_warn(const char* msg);
void boot_screen_good(const char* msg);
void boot_screen_note(const char* msg);

#endif
