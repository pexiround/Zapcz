#include "zapcc.h"
#include "util.h"
#include "libc_shim.h"
#include "pit.h"

#define TK_EOF   0
#define TK_NUM   1
#define TK_STR   2
#define TK_IDENT 3
#define TK_PUNCT 4

#define MAX_TOKENS  7000
#define MAX_SRC     49152
#define MAX_GLOBALS 192
#define MAX_LOCALS  96
#define MAX_FUNCS   96
#define MAX_MACROS  64
#define MAX_RELOC   512
#define MAX_IMPORT  64
#define MAX_PATCH   64
#define MAX_LOOPS   16

typedef struct {
    u8  t;
    u8  plen;
    char p[4];
    i32 num;
    u16 spos, slen;
    u16 line;
} tok_t;

typedef struct {
    u8  base;
    u8  ptr;
    u32 arr;
} ctype_t;

#define T_VOID 0
#define T_CHAR 1
#define T_INT  2

typedef struct {
    char    name[28];
    ctype_t ty;
    i32     off;
    int     is_arr;
} sym_t;

typedef struct {
    char name[28];
    u32  code_off;
    int  nparams;
    int  defined;
    u32  fixup[MAX_PATCH];
    int  nfixup;
} func_t;

typedef struct {
    char name[28];
    int  tok_start;
    int  tok_count;
} macro_t;

static char   src_buf[MAX_SRC];
static u32    src_n;
static tok_t  toks[MAX_TOKENS];
static int    ntoks;
static int    pc;

static u8     code[ZAP_CODE_MAX];
static u32    code_n;
static u8     data[ZAP_DATA_MAX];
static u32    data_n;
static u32    bss_n;

static u32    relocs[MAX_RELOC];
static int    nreloc;
static zap_import_t imports[MAX_IMPORT];
static int    nimport;

static sym_t  globals[MAX_GLOBALS];
static int    nglobals;
static sym_t  locals[MAX_LOCALS];
static int    nlocals;
static i32    frame_size;
static func_t funcs[MAX_FUNCS];
static int    nfuncs;
static macro_t macros[MAX_MACROS];
static int    nmacros;
static tok_t  macro_toks[768];
static int    nmacro_toks;

static char   err[128];
static int    err_line;
static int    had_err;

static u32    loop_brk[MAX_LOOPS][MAX_PATCH];
static int    loop_nbrk[MAX_LOOPS];
static u32    loop_cont_target[MAX_LOOPS];
static u32    loop_cont[MAX_LOOPS][MAX_PATCH];
static int    loop_ncont[MAX_LOOPS];
static int    loop_depth;

static u32    ret_patch[MAX_PATCH];
static int    nret_patch;

static const char* IMPORT_NAMES[] = {
    "print", "print_int", "put_char", "print_line", "clear",
    "rand", "srand", "ticks", "sleep",
    "strlen", "strcmp", "strcpy", "strcat", "memset", "memcpy",
    "plot", "canvas_clear", "canvas_rect", "canvas_on",
    "abs", "min", "max", "sqrt", "pow",
    0
};

const char* zapcc_error(void) { return err; }
int zapcc_error_line(void) { return err_line; }
int zapcc_stat_funcs(void) { return nfuncs; }
int zapcc_stat_globals(void) { return nglobals; }
u32 zapcc_stat_code(void) { return code_n; }

static void cerr(const char* m) {
    if (had_err) return;
    had_err = 1;
    str_copy(err, m, sizeof(err));
    err_line = (pc >= 0 && pc < ntoks) ? toks[pc].line : 0;
}

static int is_dig(char c) { return c >= '0' && c <= '9'; }
static int is_alpha(char c) { return (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || c == '_'; }
static int is_alnum(char c) { return is_alpha(c) || is_dig(c); }

static int tk_is(int i, const char* s) {
    if (i < 0 || i >= ntoks) return 0;
    const tok_t* t = &toks[i];
    if (t->t == TK_PUNCT) {
        int k = 0;
        while (s[k] && k < t->plen) { if (t->p[k] != s[k]) return 0; k++; }
        return s[k] == 0 && k == t->plen;
    }
    if (t->t == TK_IDENT) {
        u32 l = 0; while (s[l]) l++;
        if (l != t->slen) return 0;
        for (u32 k = 0; k < l; k++) if (src_buf[t->spos + k] != s[k]) return 0;
        return 1;
    }
    return 0;
}

static void tk_text(int i, char* out, u32 outlen) {
    out[0] = 0;
    if (i < 0 || i >= ntoks) return;
    u32 n = toks[i].slen;
    if (n > outlen - 1) n = outlen - 1;
    for (u32 k = 0; k < n; k++) out[k] = src_buf[toks[i].spos + k];
    out[n] = 0;
}

static int expect(const char* s) {
    if (tk_is(pc, s)) { pc++; return 1; }
    char m[64] = "expected '";
    str_cat(m, s, sizeof(m));
    str_cat(m, "'", sizeof(m));
    cerr(m);
    return 0;
}

static void emit(u8 b) {
    if (code_n >= ZAP_CODE_MAX) { cerr("program too large"); return; }
    code[code_n++] = b;
}
static void emit32(u32 v) {
    emit((u8)(v & 0xFF)); emit((u8)((v >> 8) & 0xFF));
    emit((u8)((v >> 16) & 0xFF)); emit((u8)((v >> 24) & 0xFF));
}
static void patch32(u32 at, u32 v) {
    if (at + 4 > ZAP_CODE_MAX) return;
    code[at] = (u8)(v & 0xFF); code[at+1] = (u8)((v >> 8) & 0xFF);
    code[at+2] = (u8)((v >> 16) & 0xFF); code[at+3] = (u8)((v >> 24) & 0xFF);
}
static void add_reloc(u32 off) {
    if (nreloc < MAX_RELOC) relocs[nreloc++] = off;
    else cerr("too many relocations");
}

static u32 type_size(const ctype_t* t) {
    u32 base = (t->ptr > 0) ? 4 : (t->base == T_CHAR ? 1 : 4);
    if (t->arr > 0) return base * t->arr;
    return base;
}
static u32 elem_size(const ctype_t* t) {
    if (t->ptr > 1) return 4;
    if (t->ptr == 1) return (t->base == T_CHAR) ? 1 : 4;
    return (t->base == T_CHAR) ? 1 : 4;
}
static ctype_t mk_int(void) { ctype_t t; t.base = T_INT; t.ptr = 0; t.arr = 0; return t; }
static ctype_t mk_char(void) { ctype_t t; t.base = T_CHAR; t.ptr = 0; t.arr = 0; return t; }

static int find_local(const char* n) {
    for (int i = nlocals - 1; i >= 0; i--) if (str_eq(locals[i].name, n)) return i;
    return -1;
}
static int find_global(const char* n) {
    for (int i = 0; i < nglobals; i++) if (str_eq(globals[i].name, n)) return i;
    return -1;
}
static int find_func(const char* n) {
    for (int i = 0; i < nfuncs; i++) if (str_eq(funcs[i].name, n)) return i;
    return -1;
}
static int find_import(const char* n) {
    for (int i = 0; IMPORT_NAMES[i]; i++) if (str_eq(IMPORT_NAMES[i], n)) return i;
    return -1;
}

static u32 data_alloc(u32 size, u32 align) {
    while (data_n % align) data_n++;
    if (data_n + size > ZAP_DATA_MAX) { cerr("out of static data space"); return 0; }
    u32 o = data_n;
    data_n += size;
    return o;
}

static void push_eax(void) { emit(0x50); }
static void pop_ecx(void)  { emit(0x59); }
static void pop_eax(void)  { emit(0x58); }
static void mov_ecx_eax(void) { emit(0x89); emit(0xC1); }
static void mov_eax_imm(u32 v) { emit(0xB8); emit32(v); }

static void load_addr_local(i32 off) { emit(0x8D); emit(0x85); emit32((u32)off); }
static void load_addr_global(u32 doff) {
    emit(0xB8);
    add_reloc(code_n);
    emit32(doff);
}
static void deref_load(const ctype_t* t) {
    if (t->ptr == 0 && t->base == T_CHAR) { emit(0x0F); emit(0xBE); emit(0x00); }
    else { emit(0x8B); emit(0x00); }
}
static void store_through(const ctype_t* t) {
    pop_ecx();
    if (t->ptr == 0 && t->base == T_CHAR) { emit(0x88); emit(0x01); }
    else { emit(0x89); emit(0x01); }
}

static u32 emit_jmp(void) { emit(0xE9); u32 at = code_n; emit32(0); return at; }
static u32 emit_jz(void)  { emit(0x85); emit(0xC0); emit(0x0F); emit(0x84); u32 at = code_n; emit32(0); return at; }
static u32 emit_jnz(void) { emit(0x85); emit(0xC0); emit(0x0F); emit(0x85); u32 at = code_n; emit32(0); return at; }
static void patch_jump_here(u32 at) { patch32(at, code_n - (at + 4)); }
static void patch_jump_to(u32 at, u32 target) { patch32(at, target - (at + 4)); }

static ctype_t expr_assign(void);
static void statement(void);

static int parse_base_type(ctype_t* out) {
    if (tk_is(pc, "unsigned") || tk_is(pc, "signed")) {
        pc++;
        out->base = T_INT; out->ptr = 0; out->arr = 0;
        if (tk_is(pc, "int") || tk_is(pc, "long") || tk_is(pc, "short")) pc++;
        else if (tk_is(pc, "char")) { pc++; out->base = T_CHAR; }
        return 1;
    }
    if (tk_is(pc, "int") || tk_is(pc, "long") || tk_is(pc, "short")) {
        pc++;
        if (tk_is(pc, "int")) pc++;
        out->base = T_INT; out->ptr = 0; out->arr = 0;
        return 1;
    }
    if (tk_is(pc, "char")) { pc++; out->base = T_CHAR; out->ptr = 0; out->arr = 0; return 1; }
    if (tk_is(pc, "void")) { pc++; out->base = T_VOID; out->ptr = 0; out->arr = 0; return 1; }
    return 0;
}

static int at_type(void) {
    int save = pc;
    if (tk_is(pc, "const") || tk_is(pc, "static")) {
        int p2 = pc + 1;
        int r = tk_is(p2, "int") || tk_is(p2, "char") || tk_is(p2, "void") ||
                tk_is(p2, "unsigned") || tk_is(p2, "signed") || tk_is(p2, "long") || tk_is(p2, "short");
        pc = save;
        return r;
    }
    ctype_t t;
    int r = parse_base_type(&t);
    pc = save;
    return r;
}

static int parse_decl_type(ctype_t* t) {
    while (tk_is(pc, "const") || tk_is(pc, "static") || tk_is(pc, "extern")) pc++;
    if (!parse_base_type(t)) return 0;
    while (tk_is(pc, "*")) { pc++; t->ptr++; }
    return 1;
}

static void gen_call_import(int idx) {
    emit(0xE8);
    if (nimport < MAX_IMPORT) {
        imports[nimport].slot_off = code_n;
        str_copy(imports[nimport].name, IMPORT_NAMES[idx], 20);
        nimport++;
    } else cerr("too many library calls");
    emit32(0);
}

static ctype_t expr_unary(void);

static ctype_t lvalue_addr(const char* name, ctype_t* out_ty, int* found) {
    ctype_t r = mk_int();
    *found = 0;
    int li = find_local(name);
    if (li >= 0) {
        load_addr_local(locals[li].off);
        *out_ty = locals[li].ty;
        *found = 1;
        return r;
    }
    int gi = find_global(name);
    if (gi >= 0) {
        load_addr_global((u32)globals[gi].off);
        *out_ty = globals[gi].ty;
        *found = 1;
        return r;
    }
    return r;
}

static void index_base_load(const ctype_t* vt) {
    if (vt->arr == 0 && vt->ptr > 0) {
        emit(0x8B); emit(0x00);
    }
}

static ctype_t expr_primary(void) {
    ctype_t ty = mk_int();
    if (had_err) return ty;

    if (pc >= ntoks) { cerr("unexpected end of file"); return ty; }

    if (toks[pc].t == TK_NUM) { mov_eax_imm((u32)toks[pc].num); pc++; return ty; }

    if (toks[pc].t == TK_STR) {
        u32 slen = toks[pc].slen;
        u32 off = data_alloc(slen + 1, 1);
        for (u32 i = 0; i < slen; i++) data[off + i] = (u8)src_buf[toks[pc].spos + i];
        data[off + slen] = 0;
        load_addr_global(off);
        pc++;
        ty.base = T_CHAR; ty.ptr = 1; ty.arr = 0;
        return ty;
    }

    if (tk_is(pc, "(")) {
        pc++;
        if (at_type()) {
            ctype_t cast;
            parse_decl_type(&cast);
            expect(")");
            expr_unary();
            return cast;
        }
        ty = expr_assign();
        expect(")");
        return ty;
    }

    if (tk_is(pc, "sizeof")) {
        pc++;
        int paren = tk_is(pc, "(");
        if (paren) pc++;
        ctype_t st;
        u32 sz = 4;
        if (at_type()) {
            parse_decl_type(&st);
            sz = type_size(&st);
        } else {
            char nm[28];
            tk_text(pc, nm, sizeof(nm));
            int li = find_local(nm);
            int gi = find_global(nm);
            if (li >= 0) sz = type_size(&locals[li].ty);
            else if (gi >= 0) sz = type_size(&globals[gi].ty);
            pc++;
        }
        if (paren) expect(")");
        mov_eax_imm(sz);
        return mk_int();
    }

    if (toks[pc].t == TK_IDENT) {
        char nm[28];
        tk_text(pc, nm, sizeof(nm));

        if (tk_is(pc + 1, "(")) {
            pc += 2;
            u32 argbuf[8];
            int nargs = 0;
            int arg_tok[8];
            while (!tk_is(pc, ")") && pc < ntoks && !had_err) {
                if (nargs < 8) arg_tok[nargs] = pc;
                nargs++;
                int depth = 0;
                while (pc < ntoks) {
                    if (tk_is(pc, "(") || tk_is(pc, "[")) depth++;
                    else if (tk_is(pc, ")") || tk_is(pc, "]")) {
                        if (depth == 0) break;
                        depth--;
                    } else if (tk_is(pc, ",") && depth == 0) break;
                    pc++;
                }
                if (tk_is(pc, ",")) pc++;
            }
            int end_tok = pc;
            expect(")");
            if (nargs > 8) { cerr("too many arguments (max 8)"); return ty; }

            for (int i = nargs - 1; i >= 0; i--) {
                int save = pc;
                pc = arg_tok[i];
                expr_assign();
                push_eax();
                pc = save;
                argbuf[i] = 0;
            }
            (void)argbuf;
            (void)end_tok;

            int imp = find_import(nm);
            if (imp >= 0) {
                gen_call_import(imp);
            } else {
                int fi = find_func(nm);
                if (fi < 0) {
                    if (nfuncs >= MAX_FUNCS) { cerr("too many functions"); return ty; }
                    fi = nfuncs++;
                    str_copy(funcs[fi].name, nm, sizeof(funcs[fi].name));
                    funcs[fi].defined = 0;
                    funcs[fi].nfixup = 0;
                    funcs[fi].code_off = 0;
                    funcs[fi].nparams = nargs;
                }
                emit(0xE8);
                if (funcs[fi].defined) {
                    u32 at = code_n;
                    emit32(funcs[fi].code_off - (at + 4));
                } else {
                    if (funcs[fi].nfixup < MAX_PATCH) funcs[fi].fixup[funcs[fi].nfixup++] = code_n;
                    emit32(0);
                }
            }
            if (nargs > 0) { emit(0x81); emit(0xC4); emit32((u32)(nargs * 4)); }
            pc = end_tok;
            expect(")");
            return mk_int();
        }

        pc++;
        ctype_t vt;
        int found = 0;
        lvalue_addr(nm, &vt, &found);
        if (!found) { cerr("undeclared identifier"); return ty; }
        if (vt.arr > 0) {
            ctype_t pt = vt;
            pt.arr = 0;
            pt.ptr = (u8)(vt.ptr + 1);
            return pt;
        }
        deref_load(&vt);
        return vt;
    }

    cerr("unexpected token in expression");
    pc++;
    return ty;
}

static ctype_t expr_postfix(void) {
    int start = pc;
    char nm[28];
    nm[0] = 0;
    int simple_var = 0;
    if (toks[pc].t == TK_IDENT && !tk_is(pc + 1, "(")) {
        tk_text(pc, nm, sizeof(nm));
        if (tk_is(pc + 1, "++") || tk_is(pc + 1, "--")) simple_var = 1;
    }

    if (simple_var) {
        int inc = tk_is(pc + 1, "++");
        ctype_t vt;
        int found = 0;
        lvalue_addr(nm, &vt, &found);
        if (!found) { cerr("undeclared identifier"); return mk_int(); }
        pc += 2;
        u32 step = (vt.ptr > 0) ? elem_size(&vt) : 1;
        push_eax();
        deref_load(&vt);
        push_eax();
        if (inc) { emit(0x05); emit32(step); } else { emit(0x2D); emit32(step); }
        emit(0x8B); emit(0x4C); emit(0x24); emit(0x04);
        if (vt.ptr == 0 && vt.base == T_CHAR) { emit(0x88); emit(0x01); }
        else { emit(0x89); emit(0x01); }
        pop_eax();
        emit(0x83); emit(0xC4); emit(0x04);
        return vt;
    }
    (void)start;

    ctype_t ty = expr_primary();

    while (!had_err) {
        if (tk_is(pc, "[")) {
            pc++;
            push_eax();
            expr_assign();
            expect("]");
            u32 es = elem_size(&ty);
            if (es > 1) {
                emit(0x69); emit(0xC0); emit32(es);
            }
            mov_ecx_eax();
            pop_eax();
            emit(0x01); emit(0xC8);
            ctype_t et = ty;
            if (et.ptr > 0) et.ptr--;
            et.arr = 0;
            deref_load(&et);
            ty = et;
            continue;
        }
        break;
    }
    return ty;
}

static ctype_t expr_unary(void) {
    if (had_err) return mk_int();

    if (tk_is(pc, "-")) { pc++; ctype_t t = expr_unary(); emit(0xF7); emit(0xD8); return t; }
    if (tk_is(pc, "+")) { pc++; return expr_unary(); }
    if (tk_is(pc, "!")) {
        pc++;
        expr_unary();
        emit(0x85); emit(0xC0);
        emit(0x0F); emit(0x94); emit(0xC0);
        emit(0x0F); emit(0xB6); emit(0xC0);
        return mk_int();
    }
    if (tk_is(pc, "~")) { pc++; ctype_t t = expr_unary(); emit(0xF7); emit(0xD0); return t; }
    if (tk_is(pc, "*")) {
        pc++;
        ctype_t t = expr_unary();
        ctype_t r = t;
        if (r.ptr > 0) r.ptr--;
        deref_load(&r);
        return r;
    }
    if (tk_is(pc, "&")) {
        pc++;
        if (toks[pc].t == TK_IDENT) {
            char nm[28];
            tk_text(pc, nm, sizeof(nm));
            if (!tk_is(pc + 1, "[")) {
                ctype_t vt;
                int found = 0;
                pc++;
                lvalue_addr(nm, &vt, &found);
                if (!found) { cerr("undeclared identifier"); return mk_int(); }
                ctype_t r = vt;
                r.arr = 0;
                r.ptr++;
                return r;
            }
            ctype_t vt;
            int found = 0;
            pc++;
            lvalue_addr(nm, &vt, &found);
            if (!found) { cerr("undeclared identifier"); return mk_int(); }
            index_base_load(&vt);
            pc++;
            push_eax();
            expr_assign();
            expect("]");
            u32 es = elem_size(&vt);
            if (es > 1) { emit(0x69); emit(0xC0); emit32(es); }
            mov_ecx_eax();
            pop_eax();
            emit(0x01); emit(0xC8);
            ctype_t r = vt;
            r.arr = 0;
            if (r.ptr == 0) r.ptr = 1;
            return r;
        }
        cerr("& needs a variable");
        return mk_int();
    }
    if (tk_is(pc, "++") || tk_is(pc, "--")) {
        int inc = tk_is(pc, "++");
        pc++;
        char nm[28];
        tk_text(pc, nm, sizeof(nm));
        ctype_t vt;
        int found = 0;
        pc++;
        lvalue_addr(nm, &vt, &found);
        if (!found) { cerr("undeclared identifier"); return mk_int(); }
        u32 step = (vt.ptr > 0) ? elem_size(&vt) : 1;
        push_eax();
        deref_load(&vt);
        if (inc) { emit(0x05); emit32(step); } else { emit(0x2D); emit32(step); }
        pop_ecx();
        if (vt.ptr == 0 && vt.base == T_CHAR) { emit(0x88); emit(0x01); }
        else { emit(0x89); emit(0x01); }
        return vt;
    }
    return expr_postfix();
}

static ctype_t expr_mul(void) {
    ctype_t l = expr_unary();
    while (!had_err && (tk_is(pc, "*") || tk_is(pc, "/") || tk_is(pc, "%"))) {
        char op = toks[pc].p[0];
        pc++;
        push_eax();
        expr_unary();
        mov_ecx_eax();
        pop_eax();
        if (op == '*') { emit(0x0F); emit(0xAF); emit(0xC1); }
        else { emit(0x99); emit(0xF7); emit(0xF9); if (op == '%') { emit(0x89); emit(0xD0); } }
        l = mk_int();
    }
    return l;
}

static ctype_t expr_add(void) {
    ctype_t l = expr_mul();
    while (!had_err && (tk_is(pc, "+") || tk_is(pc, "-"))) {
        int plus = tk_is(pc, "+");
        pc++;
        u32 scale = (l.ptr > 0) ? elem_size(&l) : 1;
        push_eax();
        ctype_t r = expr_mul();
        if (scale > 1 && r.ptr == 0) { emit(0x69); emit(0xC0); emit32(scale); }
        mov_ecx_eax();
        pop_eax();
        if (plus) { emit(0x01); emit(0xC8); }
        else {
            emit(0x29); emit(0xC8);
            if (l.ptr > 0 && r.ptr > 0 && scale > 1) {
                emit(0x99);
                emit(0xB9); emit32(scale);
                emit(0xF7); emit(0xF9);
                l = mk_int();
            }
        }
        if (l.ptr == 0 && r.ptr > 0) l = r;
    }
    return l;
}

static ctype_t expr_shift(void) {
    ctype_t l = expr_add();
    while (!had_err && (tk_is(pc, "<<") || tk_is(pc, ">>"))) {
        int left = tk_is(pc, "<<");
        pc++;
        push_eax();
        expr_add();
        mov_ecx_eax();
        pop_eax();
        emit(0xD3); emit(left ? 0xE0 : 0xF8);
        l = mk_int();
    }
    return l;
}

static void gen_setcc(u8 cc) {
    emit(0x39); emit(0xC8);
    emit(0x0F); emit(cc); emit(0xC0);
    emit(0x0F); emit(0xB6); emit(0xC0);
}

static ctype_t expr_rel(void) {
    ctype_t l = expr_shift();
    while (!had_err && (tk_is(pc, "<") || tk_is(pc, ">") || tk_is(pc, "<=") || tk_is(pc, ">="))) {
        char c0 = toks[pc].p[0];
        int eq = toks[pc].plen == 2;
        pc++;
        push_eax();
        expr_shift();
        mov_ecx_eax();
        pop_eax();
        if (c0 == '<') gen_setcc(eq ? 0x9E : 0x9C);
        else gen_setcc(eq ? 0x9D : 0x9F);
        l = mk_int();
    }
    return l;
}

static ctype_t expr_eq(void) {
    ctype_t l = expr_rel();
    while (!had_err && (tk_is(pc, "==") || tk_is(pc, "!="))) {
        int neg = toks[pc].p[0] == '!';
        pc++;
        push_eax();
        expr_rel();
        mov_ecx_eax();
        pop_eax();
        gen_setcc(neg ? 0x95 : 0x94);
        l = mk_int();
    }
    return l;
}

static ctype_t expr_band(void) {
    ctype_t l = expr_eq();
    while (!had_err && tk_is(pc, "&")) {
        pc++;
        push_eax(); expr_eq(); mov_ecx_eax(); pop_eax();
        emit(0x21); emit(0xC8);
        l = mk_int();
    }
    return l;
}
static ctype_t expr_bxor(void) {
    ctype_t l = expr_band();
    while (!had_err && tk_is(pc, "^")) {
        pc++;
        push_eax(); expr_band(); mov_ecx_eax(); pop_eax();
        emit(0x31); emit(0xC8);
        l = mk_int();
    }
    return l;
}
static ctype_t expr_bor(void) {
    ctype_t l = expr_bxor();
    while (!had_err && tk_is(pc, "|")) {
        pc++;
        push_eax(); expr_bxor(); mov_ecx_eax(); pop_eax();
        emit(0x09); emit(0xC8);
        l = mk_int();
    }
    return l;
}

static ctype_t expr_and(void) {
    ctype_t l = expr_bor();
    u32 fixes[16];
    int nf = 0;
    while (!had_err && tk_is(pc, "&&")) {
        pc++;
        if (nf < 16) fixes[nf++] = emit_jz();
        expr_bor();
        emit(0x85); emit(0xC0);
        emit(0x0F); emit(0x95); emit(0xC0);
        emit(0x0F); emit(0xB6); emit(0xC0);
        l = mk_int();
    }
    if (nf) {
        u32 done = emit_jmp();
        for (int i = 0; i < nf; i++) patch_jump_here(fixes[i]);
        mov_eax_imm(0);
        patch_jump_here(done);
    }
    return l;
}

static ctype_t expr_or(void) {
    ctype_t l = expr_and();
    u32 fixes[16];
    int nf = 0;
    while (!had_err && tk_is(pc, "||")) {
        pc++;
        if (nf < 16) fixes[nf++] = emit_jnz();
        expr_and();
        emit(0x85); emit(0xC0);
        emit(0x0F); emit(0x95); emit(0xC0);
        emit(0x0F); emit(0xB6); emit(0xC0);
        l = mk_int();
    }
    if (nf) {
        u32 done = emit_jmp();
        for (int i = 0; i < nf; i++) patch_jump_here(fixes[i]);
        mov_eax_imm(1);
        patch_jump_here(done);
    }
    return l;
}

static ctype_t expr_cond(void) {
    ctype_t l = expr_or();
    if (tk_is(pc, "?")) {
        pc++;
        u32 f = emit_jz();
        ctype_t a = expr_assign();
        u32 d = emit_jmp();
        expect(":");
        patch_jump_here(f);
        expr_cond();
        patch_jump_here(d);
        return a;
    }
    return l;
}

static int is_assign_op(int i, int* kind) {
    if (tk_is(i, "=")) { *kind = 0; return 1; }
    if (tk_is(i, "+=")) { *kind = 1; return 1; }
    if (tk_is(i, "-=")) { *kind = 2; return 1; }
    if (tk_is(i, "*=")) { *kind = 3; return 1; }
    if (tk_is(i, "/=")) { *kind = 4; return 1; }
    if (tk_is(i, "%=")) { *kind = 5; return 1; }
    if (tk_is(i, "&=")) { *kind = 6; return 1; }
    if (tk_is(i, "|=")) { *kind = 7; return 1; }
    if (tk_is(i, "^=")) { *kind = 8; return 1; }
    if (tk_is(i, "<<=")) { *kind = 9; return 1; }
    if (tk_is(i, ">>=")) { *kind = 10; return 1; }
    return 0;
}

static void gen_compound(int kind) {
    mov_ecx_eax();
    pop_eax();
    switch (kind) {
        case 1: emit(0x01); emit(0xC8); break;
        case 2: emit(0x29); emit(0xC8); break;
        case 3: emit(0x0F); emit(0xAF); emit(0xC1); break;
        case 4: emit(0x99); emit(0xF7); emit(0xF9); break;
        case 5: emit(0x99); emit(0xF7); emit(0xF9); emit(0x89); emit(0xD0); break;
        case 6: emit(0x21); emit(0xC8); break;
        case 7: emit(0x09); emit(0xC8); break;
        case 8: emit(0x31); emit(0xC8); break;
        case 9: emit(0xD3); emit(0xE0); break;
        case 10: emit(0xD3); emit(0xF8); break;
        default: break;
    }
}

static int lhs_is_assignable(int* out_end) {
    int i = pc;
    int depth = 0;
    if (toks[i].t == TK_IDENT) {
        i++;
        while (i < ntoks) {
            if (tk_is(i, "[")) { depth++; i++; continue; }
            if (tk_is(i, "]")) { if (depth == 0) break; depth--; i++; continue; }
            if (depth > 0) { i++; continue; }
            break;
        }
        *out_end = i;
        return depth == 0;
    }
    if (tk_is(i, "*")) {
        *out_end = -1;
        return 1;
    }
    return 0;
}

static ctype_t expr_assign(void) {
    if (had_err) return mk_int();

    int end = 0;
    int kind = 0;
    if (lhs_is_assignable(&end)) {
        if (end > 0 && is_assign_op(end, &kind)) {
            char nm[28];
            tk_text(pc, nm, sizeof(nm));
            ctype_t vt;
            int found = 0;
            int has_index = tk_is(pc + 1, "[");
            pc++;
            lvalue_addr(nm, &vt, &found);
            if (!found) { cerr("undeclared identifier"); return mk_int(); }
            ctype_t target = vt;
            if (has_index) {
                index_base_load(&vt);
                pc++;
                push_eax();
                expr_assign();
                expect("]");
                u32 es = elem_size(&vt);
                if (es > 1) { emit(0x69); emit(0xC0); emit32(es); }
                mov_ecx_eax();
                pop_eax();
                emit(0x01); emit(0xC8);
                target = vt;
                if (target.ptr > 0) target.ptr--;
                target.arr = 0;
            } else if (target.arr > 0) {
                cerr("cannot assign to an array");
                return mk_int();
            }
            pc = end + 1;
            push_eax();
            if (kind != 0) {
                emit(0x8B); emit(0x04); emit(0x24);
                deref_load(&target);
                push_eax();
            }
            ctype_t rt = expr_assign();
            if (kind != 0) {
                if (target.ptr > 0 && rt.ptr == 0 && (kind == 1 || kind == 2)) {
                    u32 es = elem_size(&target);
                    if (es > 1) { emit(0x69); emit(0xC0); emit32(es); }
                }
                gen_compound(kind);
            }
            store_through(&target);
            return target;
        }
        if (tk_is(pc, "*")) {
            int save = pc;
            int depth = 0;
            int j = pc;
            while (j < ntoks) {
                if (tk_is(j, "(") || tk_is(j, "[")) depth++;
                else if (tk_is(j, ")") || tk_is(j, "]")) {
                    if (depth == 0) { j = ntoks; break; }
                    depth--;
                }
                else if (depth == 0 && is_assign_op(j, &kind)) break;
                else if (depth == 0 && (tk_is(j, ";") || tk_is(j, ","))) { j = ntoks; break; }
                j++;
            }
            if (j < ntoks && is_assign_op(j, &kind)) {
                pc++;
                ctype_t pt = expr_unary();
                ctype_t target = pt;
                if (target.ptr > 0) target.ptr--;
                target.arr = 0;
                pc = j + 1;
                push_eax();
                if (kind != 0) {
                    emit(0x8B); emit(0x04); emit(0x24);
                    deref_load(&target);
                    push_eax();
                }
                expr_assign();
                if (kind != 0) gen_compound(kind);
                store_through(&target);
                return target;
            }
            pc = save;
        }
    }
    return expr_cond();
}

static void declare_local(void) {
    ctype_t base;
    if (!parse_decl_type(&base)) { cerr("bad declaration"); return; }
    while (!had_err) {
        ctype_t t = base;
        while (tk_is(pc, "*")) { pc++; t.ptr++; }
        char nm[28];
        tk_text(pc, nm, sizeof(nm));
        if (toks[pc].t != TK_IDENT) { cerr("expected variable name"); return; }
        pc++;
        int is_arr = 0;
        if (tk_is(pc, "[")) {
            pc++;
            u32 n = 0;
            if (toks[pc].t == TK_NUM) { n = (u32)toks[pc].num; pc++; }
            expect("]");
            t.arr = n;
            is_arr = 1;
        }
        if (nlocals >= MAX_LOCALS) { cerr("too many local variables"); return; }
        u32 sz = type_size(&t);
        sz = (sz + 3) & ~3u;
        frame_size += (i32)sz;
        sym_t* s = &locals[nlocals++];
        str_copy(s->name, nm, sizeof(s->name));
        s->ty = t;
        s->off = -frame_size;
        s->is_arr = is_arr;

        if (tk_is(pc, "=")) {
            pc++;
            if (tk_is(pc, "{")) {
                pc++;
                u32 idx = 0;
                while (!tk_is(pc, "}") && pc < ntoks && !had_err) {
                    load_addr_local(s->off);
                    emit(0x05); emit32(idx * elem_size(&t));
                    push_eax();
                    expr_assign();
                    ctype_t et = t; et.arr = 0;
                    store_through(&et);
                    idx++;
                    if (tk_is(pc, ",")) pc++;
                }
                expect("}");
            } else {
                load_addr_local(s->off);
                push_eax();
                expr_assign();
                ctype_t et = t; et.arr = 0;
                store_through(&et);
            }
        }
        if (tk_is(pc, ",")) { pc++; continue; }
        break;
    }
    expect(";");
}

static void statement(void) {
    if (had_err || pc >= ntoks) return;
    watchdog_heartbeat("zapcc");

    if (tk_is(pc, "{")) {
        pc++;
        int saved = nlocals;
        while (!tk_is(pc, "}") && pc < ntoks && !had_err) statement();
        expect("}");
        nlocals = saved;
        return;
    }
    if (tk_is(pc, ";")) { pc++; return; }

    if (at_type()) { declare_local(); return; }

    if (tk_is(pc, "if")) {
        pc++;
        expect("(");
        expr_assign();
        expect(")");
        u32 f = emit_jz();
        statement();
        if (tk_is(pc, "else")) {
            pc++;
            u32 d = emit_jmp();
            patch_jump_here(f);
            statement();
            patch_jump_here(d);
        } else {
            patch_jump_here(f);
        }
        return;
    }

    if (tk_is(pc, "while")) {
        pc++;
        if (loop_depth >= MAX_LOOPS) { cerr("loops nested too deeply"); return; }
        int ld = loop_depth++;
        loop_nbrk[ld] = 0;
        loop_ncont[ld] = 0;
        u32 top = code_n;
        loop_cont_target[ld] = top;
        expect("(");
        expr_assign();
        expect(")");
        u32 f = emit_jz();
        statement();
        u32 back = emit_jmp();
        patch_jump_to(back, top);
        patch_jump_here(f);
        for (int i = 0; i < loop_nbrk[ld]; i++) patch_jump_here(loop_brk[ld][i]);
        for (int i = 0; i < loop_ncont[ld]; i++) patch_jump_to(loop_cont[ld][i], top);
        loop_depth--;
        return;
    }

    if (tk_is(pc, "do")) {
        pc++;
        if (loop_depth >= MAX_LOOPS) { cerr("loops nested too deeply"); return; }
        int ld = loop_depth++;
        loop_nbrk[ld] = 0;
        loop_ncont[ld] = 0;
        u32 top = code_n;
        statement();
        u32 cont_here = code_n;
        loop_cont_target[ld] = cont_here;
        if (!tk_is(pc, "while")) { cerr("expected while after do"); loop_depth--; return; }
        pc++;
        expect("(");
        expr_assign();
        expect(")");
        expect(";");
        u32 again = emit_jnz();
        patch_jump_to(again, top);
        for (int i = 0; i < loop_nbrk[ld]; i++) patch_jump_here(loop_brk[ld][i]);
        for (int i = 0; i < loop_ncont[ld]; i++) patch_jump_to(loop_cont[ld][i], cont_here);
        loop_depth--;
        return;
    }

    if (tk_is(pc, "for")) {
        pc++;
        int saved = nlocals;
        expect("(");
        if (!tk_is(pc, ";")) {
            if (at_type()) declare_local();
            else { expr_assign(); expect(";"); }
        } else pc++;

        if (loop_depth >= MAX_LOOPS) { cerr("loops nested too deeply"); return; }
        int ld = loop_depth++;
        loop_nbrk[ld] = 0;
        loop_ncont[ld] = 0;

        u32 cond_top = code_n;
        u32 f = 0;
        int has_cond = !tk_is(pc, ";");
        if (has_cond) { expr_assign(); f = emit_jz(); }
        expect(";");

        int inc_tok = pc;
        int depth = 0;
        while (pc < ntoks) {
            if (tk_is(pc, "(")) depth++;
            else if (tk_is(pc, ")")) { if (depth == 0) break; depth--; }
            pc++;
        }
        int body_tok = pc + 1;
        expect(")");

        statement();
        u32 inc_here = code_n;
        int after_body = pc;
        pc = inc_tok;
        if (!tk_is(pc, ")")) expr_assign();
        pc = after_body;
        u32 back = emit_jmp();
        patch_jump_to(back, cond_top);
        if (has_cond) patch_jump_here(f);
        for (int i = 0; i < loop_nbrk[ld]; i++) patch_jump_here(loop_brk[ld][i]);
        for (int i = 0; i < loop_ncont[ld]; i++) patch_jump_to(loop_cont[ld][i], inc_here);
        loop_depth--;
        nlocals = saved;
        (void)body_tok;
        return;
    }

    if (tk_is(pc, "break")) {
        pc++;
        expect(";");
        if (loop_depth > 0) {
            int ld = loop_depth - 1;
            if (loop_nbrk[ld] < MAX_PATCH) loop_brk[ld][loop_nbrk[ld]++] = emit_jmp();
        } else cerr("break outside a loop");
        return;
    }
    if (tk_is(pc, "continue")) {
        pc++;
        expect(";");
        if (loop_depth > 0) {
            int ld = loop_depth - 1;
            if (loop_ncont[ld] < MAX_PATCH) loop_cont[ld][loop_ncont[ld]++] = emit_jmp();
        } else cerr("continue outside a loop");
        return;
    }
    if (tk_is(pc, "return")) {
        pc++;
        if (!tk_is(pc, ";")) expr_assign();
        else mov_eax_imm(0);
        expect(";");
        if (nret_patch < MAX_PATCH) ret_patch[nret_patch++] = emit_jmp();
        return;
    }

    expr_assign();
    expect(";");
}

static void declare_global(ctype_t base, const char* first_name) {
    char nm[28];
    str_copy(nm, first_name, sizeof(nm));
    ctype_t t = base;
    int first = 1;
    while (!had_err) {
        if (!first) {
            t = base;
            while (tk_is(pc, "*")) { pc++; t.ptr++; }
            if (toks[pc].t != TK_IDENT) { cerr("expected variable name"); return; }
            tk_text(pc, nm, sizeof(nm));
            pc++;
        }
        first = 0;
        if (tk_is(pc, "[")) {
            pc++;
            u32 n = 0;
            if (toks[pc].t == TK_NUM) { n = (u32)toks[pc].num; pc++; }
            expect("]");
            t.arr = n;
        }
        if (nglobals >= MAX_GLOBALS) { cerr("too many global variables"); return; }
        u32 sz = type_size(&t);
        if (sz == 0) sz = 4;
        u32 off = data_alloc(sz, 4);
        sym_t* s = &globals[nglobals++];
        str_copy(s->name, nm, sizeof(s->name));
        s->ty = t;
        s->off = (i32)off;
        s->is_arr = t.arr > 0;

        if (tk_is(pc, "=")) {
            pc++;
            if (tk_is(pc, "{")) {
                pc++;
                u32 idx = 0;
                u32 es = elem_size(&t);
                while (!tk_is(pc, "}") && pc < ntoks && !had_err) {
                    int neg = 0;
                    if (tk_is(pc, "-")) { neg = 1; pc++; }
                    if (toks[pc].t == TK_NUM) {
                        i32 v = neg ? -toks[pc].num : toks[pc].num;
                        if (off + idx * es + es <= ZAP_DATA_MAX) {
                            if (es == 1) data[off + idx] = (u8)v;
                            else {
                                u32 uv = (u32)v;
                                data[off + idx*4]     = (u8)(uv & 0xFF);
                                data[off + idx*4 + 1] = (u8)((uv >> 8) & 0xFF);
                                data[off + idx*4 + 2] = (u8)((uv >> 16) & 0xFF);
                                data[off + idx*4 + 3] = (u8)((uv >> 24) & 0xFF);
                            }
                        }
                        pc++;
                    } else if (toks[pc].t == TK_STR) {
                        pc++;
                    } else { cerr("global arrays take constant initialisers only"); return; }
                    idx++;
                    if (tk_is(pc, ",")) pc++;
                }
                expect("}");
            } else if (toks[pc].t == TK_NUM || tk_is(pc, "-")) {
                int neg = 0;
                if (tk_is(pc, "-")) { neg = 1; pc++; }
                if (toks[pc].t != TK_NUM) { cerr("global needs a constant initialiser"); return; }
                u32 uv = (u32)(neg ? -toks[pc].num : toks[pc].num);
                pc++;
                if (t.base == T_CHAR && t.ptr == 0) data[off] = (u8)uv;
                else {
                    data[off]     = (u8)(uv & 0xFF);
                    data[off + 1] = (u8)((uv >> 8) & 0xFF);
                    data[off + 2] = (u8)((uv >> 16) & 0xFF);
                    data[off + 3] = (u8)((uv >> 24) & 0xFF);
                }
            } else if (toks[pc].t == TK_STR) {
                u32 slen = toks[pc].slen;
                u32 so = data_alloc(slen + 1, 1);
                for (u32 i = 0; i < slen; i++) data[so + i] = (u8)src_buf[toks[pc].spos + i];
                data[so + slen] = 0;
                data[off]     = (u8)(so & 0xFF);
                data[off + 1] = (u8)((so >> 8) & 0xFF);
                data[off + 2] = (u8)((so >> 16) & 0xFF);
                data[off + 3] = (u8)((so >> 24) & 0xFF);
                add_reloc(ZAP_CODE_MAX + off);
                pc++;
            } else { cerr("global needs a constant initialiser"); return; }
        }
        if (tk_is(pc, ",")) { pc++; continue; }
        break;
    }
    expect(";");
}

static void parse_function(ctype_t ret, const char* name) {
    (void)ret;
    int fi = find_func(name);
    if (fi < 0) {
        if (nfuncs >= MAX_FUNCS) { cerr("too many functions"); return; }
        fi = nfuncs++;
        str_copy(funcs[fi].name, name, sizeof(funcs[fi].name));
        funcs[fi].defined = 0;
        funcs[fi].nfixup = 0;
    }

    nlocals = 0;
    frame_size = 0;
    nret_patch = 0;

    expect("(");
    int nparams = 0;
    i32 param_off = 8;
    while (!tk_is(pc, ")") && pc < ntoks && !had_err) {
        if (tk_is(pc, "void") && tk_is(pc + 1, ")")) { pc++; break; }
        ctype_t pt;
        if (!parse_decl_type(&pt)) { cerr("bad parameter"); return; }
        char pn[28];
        tk_text(pc, pn, sizeof(pn));
        if (toks[pc].t != TK_IDENT) { cerr("expected parameter name"); return; }
        pc++;
        if (tk_is(pc, "[")) { pc++; if (toks[pc].t == TK_NUM) pc++; expect("]"); pt.ptr++; }
        if (nlocals < MAX_LOCALS) {
            sym_t* s = &locals[nlocals++];
            str_copy(s->name, pn, sizeof(s->name));
            s->ty = pt;
            s->off = param_off;
            s->is_arr = 0;
        }
        param_off += 4;
        nparams++;
        if (tk_is(pc, ",")) pc++;
    }
    expect(")");

    if (tk_is(pc, ";")) { pc++; funcs[fi].nparams = nparams; return; }

    funcs[fi].code_off = code_n;
    funcs[fi].defined = 1;
    funcs[fi].nparams = nparams;
    for (int i = 0; i < funcs[fi].nfixup; i++) {
        patch32(funcs[fi].fixup[i], funcs[fi].code_off - (funcs[fi].fixup[i] + 4));
    }
    funcs[fi].nfixup = 0;

    emit(0x55);
    emit(0x89); emit(0xE5);
    emit(0x81); emit(0xEC);
    u32 frame_patch = code_n;
    emit32(0);

    if (!tk_is(pc, "{")) { cerr("expected function body"); return; }
    statement();

    mov_eax_imm(0);
    for (int i = 0; i < nret_patch; i++) patch_jump_here(ret_patch[i]);
    emit(0x89); emit(0xEC);
    emit(0x5D);
    emit(0xC3);

    patch32(frame_patch, (u32)((frame_size + 15) & ~15));
}

static void preprocess_and_tokenize(const char* s, u32 len) {
    ntoks = 0;
    src_n = 0;
    nmacros = 0;
    nmacro_toks = 0;
    u32 i = 0;
    u16 line = 1;
    int at_line_start = 1;

    while (i < len && ntoks < MAX_TOKENS - 2) {
        char c = s[i];
        if (c == '\n') { line++; i++; at_line_start = 1; continue; }
        if (c == ' ' || c == '\t' || c == '\r') { i++; continue; }
        if (c == '/' && i + 1 < len && s[i+1] == '/') { while (i < len && s[i] != '\n') i++; continue; }
        if (c == '/' && i + 1 < len && s[i+1] == '*') {
            i += 2;
            while (i + 1 < len && !(s[i] == '*' && s[i+1] == '/')) { if (s[i] == '\n') line++; i++; }
            i += 2;
            continue;
        }
        if (c == '#' && at_line_start) {
            u32 ds = i + 1;
            while (ds < len && (s[ds] == ' ' || s[ds] == '\t')) ds++;
            int is_define = (ds + 6 <= len && s[ds]=='d' && s[ds+1]=='e' && s[ds+2]=='f' &&
                             s[ds+3]=='i' && s[ds+4]=='n' && s[ds+5]=='e');
            if (is_define) {
                u32 p = ds + 6;
                while (p < len && (s[p] == ' ' || s[p] == '\t')) p++;
                u32 ns = p;
                while (p < len && is_alnum(s[p])) p++;
                if (nmacros < MAX_MACROS && p > ns) {
                    macro_t* m = &macros[nmacros];
                    u32 nl = p - ns;
                    if (nl > 27) nl = 27;
                    for (u32 k = 0; k < nl; k++) m->name[k] = s[ns + k];
                    m->name[nl] = 0;
                    m->tok_start = nmacro_toks;
                    i = p;
                    int start_tokens = nmacro_toks;
                    while (i < len && s[i] != '\n' && nmacro_toks < 760) {
                        char mc = s[i];
                        if (mc == ' ' || mc == '\t' || mc == '\r') { i++; continue; }
                        tok_t* t = &macro_toks[nmacro_toks];
                        t->num = 0; t->spos = 0; t->slen = 0; t->plen = 0; t->line = line;
                        if (is_dig(mc)) {
                            i32 v = 0;
                            if (mc == '0' && i + 1 < len && (s[i+1] == 'x' || s[i+1] == 'X')) {
                                i += 2;
                                while (i < len) {
                                    char h = s[i];
                                    int d;
                                    if (is_dig(h)) d = h - '0';
                                    else if (h >= 'a' && h <= 'f') d = h - 'a' + 10;
                                    else if (h >= 'A' && h <= 'F') d = h - 'A' + 10;
                                    else break;
                                    v = v * 16 + d; i++;
                                }
                            } else {
                                while (i < len && is_dig(s[i])) { v = v * 10 + (s[i] - '0'); i++; }
                            }
                            t->t = TK_NUM; t->num = v; nmacro_toks++;
                            continue;
                        }
                        if (is_alpha(mc)) {
                            u32 st = i;
                            while (i < len && is_alnum(s[i])) i++;
                            u32 l2 = i - st;
                            u32 dst = src_n;
                            for (u32 k = 0; k < l2 && src_n < MAX_SRC - 1; k++) src_buf[src_n++] = s[st + k];
                            t->t = TK_IDENT; t->spos = (u16)dst; t->slen = (u16)l2; nmacro_toks++;
                            continue;
                        }
                        if (mc == '"') {
                            i++;
                            u32 dst2 = src_n;
                            while (i < len && s[i] != '"') {
                                char ch = s[i];
                                if (ch == '\\' && i + 1 < len) {
                                    i++;
                                    char e = s[i];
                                    if (e == 'n') ch = '\n';
                                    else if (e == 't') ch = '\t';
                                    else if (e == 'r') ch = '\r';
                                    else if (e == '0') ch = 0;
                                    else ch = e;
                                }
                                if (src_n < MAX_SRC - 1) src_buf[src_n++] = ch;
                                i++;
                            }
                            if (i < len) i++;
                            t->t = TK_STR; t->spos = (u16)dst2; t->slen = (u16)(src_n - dst2); nmacro_toks++;
                            continue;
                        }
                        if (mc == '\'') {
                            i++;
                            i32 v = 0;
                            if (i < len && s[i] == '\\') {
                                i++;
                                char e = s[i];
                                if (e == 'n') v = '\n';
                                else if (e == 't') v = '\t';
                                else if (e == 'r') v = '\r';
                                else if (e == '0') v = 0;
                                else v = e;
                                i++;
                            } else if (i < len) { v = (unsigned char)s[i]; i++; }
                            if (i < len && s[i] == '\'') i++;
                            t->t = TK_NUM; t->num = v; nmacro_toks++;
                            continue;
                        }
                        t->t = TK_PUNCT; t->plen = 1; t->p[0] = mc; t->p[1] = 0;
                        i++; nmacro_toks++;
                    }
                    m->tok_count = nmacro_toks - start_tokens;
                    nmacros++;
                }
                at_line_start = 1;
                continue;
            }
            while (i < len && s[i] != '\n') i++;
            continue;
        }
        at_line_start = 0;

        tok_t* t = &toks[ntoks];
        t->num = 0; t->spos = 0; t->slen = 0; t->plen = 0; t->line = line;

        if (is_dig(c)) {
            i32 v = 0;
            if (c == '0' && i + 1 < len && (s[i+1] == 'x' || s[i+1] == 'X')) {
                i += 2;
                while (i < len) {
                    char h = s[i];
                    int d;
                    if (is_dig(h)) d = h - '0';
                    else if (h >= 'a' && h <= 'f') d = h - 'a' + 10;
                    else if (h >= 'A' && h <= 'F') d = h - 'A' + 10;
                    else break;
                    v = v * 16 + d; i++;
                }
            } else {
                while (i < len && is_dig(s[i])) { v = v * 10 + (s[i] - '0'); i++; }
            }
            while (i < len && (s[i] == 'u' || s[i] == 'U' || s[i] == 'l' || s[i] == 'L')) i++;
            t->t = TK_NUM; t->num = v; ntoks++;
            continue;
        }

        if (c == '\'') {
            i++;
            i32 v = 0;
            if (i < len && s[i] == '\\') {
                i++;
                char e = s[i];
                if (e == 'n') v = '\n';
                else if (e == 't') v = '\t';
                else if (e == 'r') v = '\r';
                else if (e == '0') v = 0;
                else if (e == '\\') v = '\\';
                else if (e == '\'') v = '\'';
                else v = e;
                i++;
            } else if (i < len) { v = (unsigned char)s[i]; i++; }
            if (i < len && s[i] == '\'') i++;
            t->t = TK_NUM; t->num = v; ntoks++;
            continue;
        }

        if (c == '"') {
            i++;
            u32 dst = src_n;
            while (i < len && s[i] != '"') {
                char ch = s[i];
                if (ch == '\\' && i + 1 < len) {
                    i++;
                    char e = s[i];
                    if (e == 'n') ch = '\n';
                    else if (e == 't') ch = '\t';
                    else if (e == 'r') ch = '\r';
                    else if (e == '0') ch = 0;
                    else ch = e;
                }
                if (src_n < MAX_SRC - 1) src_buf[src_n++] = ch;
                i++;
            }
            if (i < len) i++;
            t->t = TK_STR; t->spos = (u16)dst; t->slen = (u16)(src_n - dst); ntoks++;
            continue;
        }

        if (is_alpha(c)) {
            u32 st = i;
            while (i < len && is_alnum(s[i])) i++;
            u32 l2 = i - st;
            u32 dst = src_n;
            for (u32 k = 0; k < l2 && src_n < MAX_SRC - 1; k++) src_buf[src_n++] = s[st + k];
            t->t = TK_IDENT; t->spos = (u16)dst; t->slen = (u16)l2; ntoks++;
            continue;
        }

        static const char* three[] = { "<<=", ">>=", 0 };
        static const char* two[] = { "==", "!=", "<=", ">=", "&&", "||", "++", "--",
                                     "+=", "-=", "*=", "/=", "%=", "&=", "|=", "^=",
                                     "<<", ">>", "->", 0 };
        int matched = 0;
        for (int k = 0; three[k] && !matched; k++) {
            if (i + 2 < len && s[i] == three[k][0] && s[i+1] == three[k][1] && s[i+2] == three[k][2]) {
                t->t = TK_PUNCT; t->plen = 3;
                t->p[0] = three[k][0]; t->p[1] = three[k][1]; t->p[2] = three[k][2]; t->p[3] = 0;
                i += 3; ntoks++; matched = 1;
            }
        }
        if (matched) continue;
        for (int k = 0; two[k] && !matched; k++) {
            if (i + 1 < len && s[i] == two[k][0] && s[i+1] == two[k][1]) {
                t->t = TK_PUNCT; t->plen = 2;
                t->p[0] = two[k][0]; t->p[1] = two[k][1]; t->p[2] = 0;
                i += 2; ntoks++; matched = 1;
            }
        }
        if (matched) continue;
        t->t = TK_PUNCT; t->plen = 1; t->p[0] = c; t->p[1] = 0;
        i++; ntoks++;
    }
    toks[ntoks].t = TK_EOF;
    toks[ntoks].plen = 0;
    toks[ntoks].p[0] = 0;
    toks[ntoks].line = line;
}

static void expand_macros(void) {
    static tok_t out[MAX_TOKENS];
    for (int pass = 0; pass < 3; pass++) {
        int n = 0;
        int changed = 0;
        for (int i = 0; i < ntoks && n < MAX_TOKENS - 2; i++) {
            if (toks[i].t == TK_IDENT) {
                char nm[28];
                tk_text(i, nm, sizeof(nm));
                int mi = -1;
                for (int k = 0; k < nmacros; k++) if (str_eq(macros[k].name, nm)) { mi = k; break; }
                if (mi >= 0) {
                    for (int k = 0; k < macros[mi].tok_count && n < MAX_TOKENS - 2; k++) {
                        out[n++] = macro_toks[macros[mi].tok_start + k];
                    }
                    changed = 1;
                    continue;
                }
            }
            out[n++] = toks[i];
        }
        for (int i = 0; i < n; i++) toks[i] = out[i];
        ntoks = n;
        toks[ntoks].t = TK_EOF;
        toks[ntoks].plen = 0;
        toks[ntoks].p[0] = 0;
        if (!changed) break;
    }
}

int zapcc_compile(const char* src, u32 len, u8* out, u32 out_max, u32* out_size) {
    code_n = 0; data_n = 0; bss_n = 0;
    nreloc = 0; nimport = 0;
    nglobals = 0; nlocals = 0; nfuncs = 0;
    loop_depth = 0; nret_patch = 0;
    had_err = 0; err[0] = 0; err_line = 0;
    pc = 0;
    for (u32 i = 0; i < ZAP_DATA_MAX; i++) data[i] = 0;

    if (len > MAX_SRC - 1) { str_copy(err, "source file is too large", sizeof(err)); return 0; }

    preprocess_and_tokenize(src, len);
    expand_macros();

    while (pc < ntoks && !had_err) {
        watchdog_heartbeat("zapcc");
        if (tk_is(pc, ";")) { pc++; continue; }
        if (tk_is(pc, "typedef") || tk_is(pc, "struct") || tk_is(pc, "union") || tk_is(pc, "enum")) {
            cerr("struct/union/enum/typedef are not supported yet");
            break;
        }
        ctype_t t;
        if (!parse_decl_type(&t)) { cerr("expected a declaration"); break; }
        if (toks[pc].t != TK_IDENT) { cerr("expected a name"); break; }
        char nm[28];
        tk_text(pc, nm, sizeof(nm));
        pc++;
        if (tk_is(pc, "(")) parse_function(t, nm);
        else declare_global(t, nm);
    }

    if (!had_err) {
        int main_fi = find_func("main");
        if (main_fi < 0 || !funcs[main_fi].defined) {
            str_copy(err, "no main() function found", sizeof(err));
            err_line = 0;
            had_err = 1;
        } else {
            for (int i = 0; i < nfuncs; i++) {
                if (!funcs[i].defined && funcs[i].nfixup > 0) {
                    str_copy(err, "call to undefined function: ", sizeof(err));
                    str_cat(err, funcs[i].name, sizeof(err));
                    had_err = 1;
                    err_line = 0;
                    break;
                }
            }
        }
    }

    if (had_err) return 0;

    while (code_n % 4) code[code_n++] = 0x90;

    u32 data_base = code_n;
    for (int i = 0; i < nreloc; i++) {
        if (relocs[i] >= ZAP_CODE_MAX) relocs[i] = relocs[i] - ZAP_CODE_MAX + data_base;
    }

    int main_fi = find_func("main");

    u32 total = sizeof(zap_header_t) + code_n + data_n +
                (u32)nreloc * 4 + (u32)nimport * sizeof(zap_import_t);
    if (total > out_max) { str_copy(err, "compiled program is too large", sizeof(err)); return 0; }

    for (int i = 0; i < nreloc; i++) {
        u32 off = relocs[i];
        if (off + 4 <= code_n) {
            u32 v = (u32)code[off] | ((u32)code[off+1] << 8) | ((u32)code[off+2] << 16) | ((u32)code[off+3] << 24);
            if (v < ZAP_CODE_MAX) {
                v += data_base;
                code[off] = (u8)(v & 0xFF);
                code[off+1] = (u8)((v >> 8) & 0xFF);
                code[off+2] = (u8)((v >> 16) & 0xFF);
                code[off+3] = (u8)((v >> 24) & 0xFF);
            }
        } else {
            u32 d = off - data_base;
            if (d + 4 <= data_n) {
                u32 v = (u32)data[d] | ((u32)data[d+1] << 8) | ((u32)data[d+2] << 16) | ((u32)data[d+3] << 24);
                v += data_base;
                data[d] = (u8)(v & 0xFF);
                data[d+1] = (u8)((v >> 8) & 0xFF);
                data[d+2] = (u8)((v >> 16) & 0xFF);
                data[d+3] = (u8)((v >> 24) & 0xFF);
            }
        }
    }

    u8* p = out;
    zap_header_t h;
    h.magic = ZAP_MAGIC;
    h.version = ZAP_VERSION;
    h.code_size = code_n;
    h.data_size = data_n;
    h.bss_size = bss_n;
    h.entry = funcs[main_fi].code_off;
    h.nreloc = (u32)nreloc;
    h.nimport = (u32)nimport;
    memcpy(p, &h, sizeof(h));
    p += sizeof(h);
    memcpy(p, code, code_n);
    p += code_n;
    memcpy(p, data, data_n);
    p += data_n;
    for (int i = 0; i < nreloc; i++) { memcpy(p, &relocs[i], 4); p += 4; }
    for (int i = 0; i < nimport; i++) { memcpy(p, &imports[i], sizeof(zap_import_t)); p += sizeof(zap_import_t); }

    *out_size = (u32)(p - out);
    return 1;
}
