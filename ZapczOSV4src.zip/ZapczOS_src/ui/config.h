#ifndef CONFIG_H
#define CONFIG_H
#include "io.h"
#include "rtc.h"

#define CFG_INSTALLED_CALC   0x01
#define CFG_INSTALLED_PAINT  0x02
#define CFG_INSTALLED_TTT    0x04
#define CFG_INSTALLED_CUBE3D 0x08
#define CFG_INSTALLED_MINES  0x10
#define CFG_INSTALLED_LIFE   0x20
#define CFG_INSTALLED_SNAKE  0x40
#define CFG_INSTALLED_2048   0x80

void config_init(void);

int  config_disk_available(void);

u8   config_get_installed_mask(void);
void config_set_installed(u8 bit, int installed);

u8   config_get_theme_mode(void);
void config_set_theme_mode(u8 mode);

u8   config_get_mouse_sens(void);
void config_set_mouse_sens(u8 pct);

u8   config_get_taskbar_top(void);
void config_set_taskbar_top(u8 top);

i32  config_get_tz_offset(void);
void config_set_tz_offset(i32 off);
void config_local_time(rtc_time_t* t);

#endif
