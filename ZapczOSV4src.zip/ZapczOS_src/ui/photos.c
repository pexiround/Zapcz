#include "photos.h"
#include "graphics.h"
#include "desktop.h"
#include "theme.h"
#include "util.h"
#include "png.h"

#define PHOTOS_MAX_W 512
#define PHOTOS_MAX_H 512

static u8 img[PHOTOS_MAX_H][PHOTOS_MAX_W][3];
static u32 img_w = 0, img_h = 0;
static int has_image = 0;
static char cur_name[32] = "";
static char status[64] = "No image yet -- pick a .PNG file in Files.";

void photos_init(void) {
    has_image = 0;
    cur_name[0] = 0;
    str_copy(status, "No image yet -- pick a .PNG file in Files.", 64);
}

void photos_open_file(const char* filename) {
    u32 w = 0, h = 0;
    int rc = png_decode_file(filename, &img[0][0][0], PHOTOS_MAX_W, PHOTOS_MAX_H, &w, &h);
    if (rc == PNG_OK) {
        img_w = w; img_h = h;
        has_image = 1;
        str_copy(cur_name, filename, 32);
        str_copy(status, "", 64);
    } else {
        has_image = 0;
        str_copy(cur_name, filename, 32);
        str_copy(status, png_error_string(rc), 64);
    }
    desktop_open_app(APP_PHOTOS);
}

void app_photos_draw(i32 x, i32 y, i32 w, i32 h) {
    char header[64] = "Photos";
    if (cur_name[0]) { str_cat(header, " -- ", 64); str_cat(header, cur_name, 64); }
    gfx_string(x + 12, y + 10, header, THEME_TEXT, THEME_PANEL, 0);

    i32 area_x = x + 12, area_y = y + 36;
    i32 area_w = w - 24, area_h = h - 48;
    gfx_rounded_rect(area_x, area_y, area_w, area_h, THEME_RADIUS_CTRL, THEME_PANEL_ALT);
    gfx_rounded_rect_outline(area_x, area_y, area_w, area_h, THEME_RADIUS_CTRL, THEME_BORDER);

    if (!has_image) {
        const char* msg = status[0] ? status : "No image loaded.";
        gfx_string(area_x + (area_w - gfx_string_width(msg)) / 2,
                   area_y + area_h / 2 - 8, msg, THEME_TEXT_FAINT, THEME_PANEL_ALT, 0);
        return;
    }

    i32 pad = 8;
    i32 avail_w = area_w - pad * 2, avail_h = area_h - pad * 2 - 18;
    if (avail_w < 1) avail_w = 1;
    if (avail_h < 1) avail_h = 1;

    i32 disp_w = avail_w, disp_h = (i32)((u32)img_h * (u32)disp_w / img_w);
    if (disp_h > avail_h) { disp_h = avail_h; disp_w = (i32)((u32)img_w * (u32)disp_h / img_h); }
    if (disp_w < 1) disp_w = 1;
    if (disp_h < 1) disp_h = 1;

    i32 ox = area_x + (area_w - disp_w) / 2;
    i32 oy = area_y + pad;

    for (i32 dy = 0; dy < disp_h; dy++) {
        u32 sy = (u32)dy * img_h / (u32)disp_h;
        if (sy >= img_h) sy = img_h - 1;
        for (i32 dx = 0; dx < disp_w; dx++) {
            u32 sx = (u32)dx * img_w / (u32)disp_w;
            if (sx >= img_w) sx = img_w - 1;
            color_t c = RGB(img[sy][sx][0], img[sy][sx][1], img[sy][sx][2]);
            gfx_pixel(ox + dx, oy + dy, c);
        }
    }

    char dims[32]; char nb[12];
    str_copy(dims, "", 32);
    u32_to_str(img_w, nb); str_cat(dims, nb, 32); str_cat(dims, " x ", 32);
    u32_to_str(img_h, nb); str_cat(dims, nb, 32); str_cat(dims, " px", 32);
    gfx_string(area_x + (area_w - gfx_string_width(dims)) / 2, oy + disp_h + 6,
               dims, THEME_TEXT_FAINT, THEME_PANEL_ALT, 0);
}
