#include "jpeg.h"
#include "libc_shim.h"

#define JMAXCOMP 3
#define JOUT_MAX 512

static const u8 ZZ[64] = {
     0, 1, 8,16, 9, 2, 3,10,17,24,32,25,18,11, 4, 5,
    12,19,26,33,40,48,41,34,27,20,13, 6, 7,14,21,28,
    35,42,49,56,57,50,43,36,29,22,15,23,30,37,44,51,
    58,59,52,45,38,31,39,46,53,60,61,54,47,55,62,63
};

typedef struct {
    u8  cnt[17];
    u8  sym[256];
    int maxcode[18];
    int mincode[17];
    int valptr[17];
    int present;
} huff_t;

typedef struct { int id, h, v, tq, td, ta, pred; } comp_t;

static huff_t hdc[4], hac[4];
static u16    qt[4][64];
static comp_t comps[JMAXCOMP];
static int    ncomp, jW, jH, maxH, maxV, restart_iv;

static const u8* jd;
static const u8* jend;
static u32 jbb;
static int jbc, jeod;

static int acc_r[JOUT_MAX * JOUT_MAX];
static int acc_g[JOUT_MAX * JOUT_MAX];
static int acc_b[JOUT_MAX * JOUT_MAX];
static int acc_c[JOUT_MAX * JOUT_MAX];
static u8  cpix[JMAXCOMP][16 * 16];

static u16 rd16(const u8* p) { return (u16)((p[0] << 8) | p[1]); }

static int jrb(void) {
    if (jd >= jend) { jeod = 1; return 0; }
    int b = *jd++;
    if (b == 0xFF) {
        int c = (jd < jend) ? *jd : 0;
        while (c == 0xFF) { jd++; c = (jd < jend) ? *jd : 0; }
        if (c == 0) { jd++; return 0xFF; }
        jeod = 1; jd--; return 0;
    }
    return b;
}
static int jbit(void) { if (jbc == 0) { jbb = (u32)jrb(); jbc = 8; } jbc--; return (int)((jbb >> jbc) & 1); }
static int jbits(int n) { int v = 0; while (n-- > 0) v = (v << 1) | jbit(); return v; }
static int jrecv(int s) { if (s == 0) return 0; int v = jbits(s); if (v < (1 << (s - 1))) v += (-1 << s) + 1; return v; }

static void build_huff(huff_t* h) {
    int code = 0, p = 0;
    for (int l = 1; l <= 16; l++) {
        if (h->cnt[l]) { h->valptr[l] = p; h->mincode[l] = code; code += h->cnt[l]; h->maxcode[l] = code - 1; p += h->cnt[l]; }
        else h->maxcode[l] = -1;
        code <<= 1;
    }
    h->maxcode[17] = 0x7fffffff;
}
static int jhuff(huff_t* h) {
    int code = 0;
    for (int l = 1; l <= 16; l++) {
        code = (code << 1) | jbit();
        if (h->maxcode[l] >= 0 && code <= h->maxcode[l]) return h->sym[h->valptr[l] + (code - h->mincode[l])];
    }
    return 0;
}

#define F2F(x) ((int)((x) * 4096 + 0.5))
#define FSH(x) ((x) * 4096)
#define IDCT1D(s0,s1,s2,s3,s4,s5,s6,s7) \
    int t0,t1,t2,t3,p1,p2,p3,p4,p5,x0,x1,x2,x3; \
    p2 = s2; p3 = s6; p1 = (p2 + p3) * F2F(0.5411961f); \
    t2 = p1 + p3 * F2F(-1.847759065f); t3 = p1 + p2 * F2F(0.765366865f); \
    p2 = s0; p3 = s4; t0 = FSH(p2 + p3); t1 = FSH(p2 - p3); \
    x0 = t0 + t3; x3 = t0 - t3; x1 = t1 + t2; x2 = t1 - t2; \
    t0 = s7; t1 = s5; t2 = s3; t3 = s1; \
    p3 = t0 + t2; p4 = t1 + t3; p1 = t0 + t3; p2 = t1 + t2; \
    p5 = (p3 + p4) * F2F(1.175875602f); \
    t0 = t0 * F2F(0.298631336f); t1 = t1 * F2F(2.053119869f); t2 = t2 * F2F(3.072711026f); t3 = t3 * F2F(1.501321110f); \
    p1 = p5 + p1 * F2F(-0.899976223f); p2 = p5 + p2 * F2F(-2.562915447f); \
    p3 = p3 * F2F(-1.961570560f); p4 = p4 * F2F(-0.390180644f); \
    t3 += p1 + p4; t2 += p2 + p3; t1 += p2 + p4; t0 += p1 + p3;

static u8 clamp8(int x) { if (x < 0) return 0; if (x > 255) return 255; return (u8)x; }

static void idct(short* d, u8* out, int stride) {
    int val[64], i;
    for (i = 0; i < 8; i++) {
        short* dd = d + i; int* v = val + i;
        if (dd[8] == 0 && dd[16] == 0 && dd[24] == 0 && dd[32] == 0 && dd[40] == 0 && dd[48] == 0 && dd[56] == 0) {
            int dc = dd[0] * 4; v[0] = v[8] = v[16] = v[24] = v[32] = v[40] = v[48] = v[56] = dc;
        } else {
            IDCT1D(dd[0], dd[8], dd[16], dd[24], dd[32], dd[40], dd[48], dd[56])
            x0 += 512; x1 += 512; x2 += 512; x3 += 512;
            v[0] = (x0 + t3) >> 10; v[56] = (x0 - t3) >> 10;
            v[8] = (x1 + t2) >> 10; v[48] = (x1 - t2) >> 10;
            v[16] = (x2 + t1) >> 10; v[40] = (x2 - t1) >> 10;
            v[24] = (x3 + t0) >> 10; v[32] = (x3 - t0) >> 10;
        }
    }
    for (i = 0; i < 8; i++) {
        int* v = val + i * 8; u8* o = out + i * stride;
        IDCT1D(v[0], v[1], v[2], v[3], v[4], v[5], v[6], v[7])
        x0 += 65536 + (128 << 17); x1 += 65536 + (128 << 17); x2 += 65536 + (128 << 17); x3 += 65536 + (128 << 17);
        o[0] = clamp8((x0 + t3) >> 17); o[7] = clamp8((x0 - t3) >> 17);
        o[1] = clamp8((x1 + t2) >> 17); o[6] = clamp8((x1 - t2) >> 17);
        o[2] = clamp8((x2 + t1) >> 17); o[5] = clamp8((x2 - t1) >> 17);
        o[3] = clamp8((x3 + t0) >> 17); o[4] = clamp8((x3 - t0) >> 17);
    }
}

static void decode_block(int ci, u8* pixout, int stride) {
    short blk[64]; memset(blk, 0, sizeof(blk));
    comp_t* c = &comps[ci];
    int t = jhuff(&hdc[c->td]);
    c->pred += jrecv(t);
    blk[0] = (short)(c->pred * qt[c->tq][0]);
    int k = 1;
    while (k < 64) {
        int rs = jhuff(&hac[c->ta]);
        int r = rs >> 4, s = rs & 15;
        if (s == 0) { if (r == 15) { k += 16; continue; } break; }
        k += r; if (k >= 64) break;
        blk[ZZ[k]] = (short)(jrecv(s) * qt[c->tq][k]);
        k++;
    }
    idct(blk, pixout, stride);
}

int jpeg_decode_mem(const u8* data, u32 len, u8* out_rgb, u32 max_w, u32 max_h,
                    u32* out_w, u32* out_h) {
    if (len < 4 || data[0] != 0xFF || data[1] != 0xD8) return 0;
    const u8* p = data + 2;
    const u8* end = data + len;
    ncomp = 0; restart_iv = 0; jW = 0; jH = 0; maxH = 1; maxV = 1;
    for (int i = 0; i < 4; i++) { hdc[i].present = 0; hac[i].present = 0; }
    int got_sos = 0;

    while (p + 4 <= end && !got_sos) {
        if (p[0] != 0xFF) { p++; continue; }
        int m = p[1]; p += 2;
        if (m == 0xD9) break;
        if (m == 0x01 || (m >= 0xD0 && m <= 0xD7)) continue;
        if (p + 2 > end) break;
        int L = rd16(p); const u8* seg = p + 2; const u8* segend = p + L; p += L;
        if (segend > end) segend = end;

        if (m == 0xDB) {
            const u8* q = seg;
            while (q < segend) {
                int pq = q[0] >> 4, tq = q[0] & 15; q++;
                if (tq > 3) return 0;
                for (int i = 0; i < 64; i++) { if (pq) { qt[tq][i] = rd16(q); q += 2; } else { qt[tq][i] = *q++; } }
            }
        } else if (m == 0xC0 || m == 0xC1) {
            jH = rd16(seg + 1); jW = rd16(seg + 3); ncomp = seg[5];
            if (ncomp > JMAXCOMP || ncomp < 1) return 0;
            const u8* cc = seg + 6;
            for (int i = 0; i < ncomp; i++) {
                comps[i].id = cc[0]; comps[i].h = cc[1] >> 4; comps[i].v = cc[1] & 15; comps[i].tq = cc[2]; comps[i].pred = 0;
                if (comps[i].h > maxH) maxH = comps[i].h;
                if (comps[i].v > maxV) maxV = comps[i].v;
                cc += 3;
            }
            if (maxH > 2 || maxV > 2) return 0;
        } else if (m == 0xC2 || m == 0xC3 || (m >= 0xC5 && m <= 0xCF && m != 0xC8 && m != 0xCC)) {
            return 0;
        } else if (m == 0xC4) {
            const u8* q = seg;
            while (q < segend) {
                int tc = q[0] >> 4, th = q[0] & 15; q++;
                if (th > 3) return 0;
                huff_t* h = tc ? &hac[th] : &hdc[th];
                int total = 0;
                for (int i = 1; i <= 16; i++) { h->cnt[i] = q[i - 1]; total += h->cnt[i]; }
                q += 16;
                for (int i = 0; i < total && i < 256; i++) h->sym[i] = q[i];
                q += total;
                build_huff(h); h->present = 1;
            }
        } else if (m == 0xDD) {
            restart_iv = rd16(seg);
        } else if (m == 0xDA) {
            int ns = seg[0]; const u8* q = seg + 1;
            for (int i = 0; i < ns; i++) {
                int cid = q[0], t = q[1]; q += 2;
                for (int j = 0; j < ncomp; j++) if (comps[j].id == cid) { comps[j].td = t >> 4; comps[j].ta = t & 15; }
            }
            jd = segend; jend = end; jbb = 0; jbc = 0; jeod = 0;
            got_sos = 1;
        }
    }

    if (!got_sos || jW <= 0 || jH <= 0) return 0;
    if (jW > 4096 || jH > 4096) return 0;

    int ow = jW, oh = jH;
    if (ow > (int)max_w) { oh = oh * (int)max_w / ow; ow = (int)max_w; }
    if (oh > (int)max_h) { ow = ow * (int)max_h / oh; oh = (int)max_h; }
    if (ow < 1) ow = 1; if (oh < 1) oh = 1;
    if (ow > JOUT_MAX) ow = JOUT_MAX; if (oh > JOUT_MAX) oh = JOUT_MAX;
    int no = ow * oh;
    for (int i = 0; i < no; i++) { acc_r[i] = acc_g[i] = acc_b[i] = acc_c[i] = 0; }

    int mcuW = maxH * 8, mcuH = maxV * 8;
    int mx = (jW + mcuW - 1) / mcuW, my = (jH + mcuH - 1) / mcuH;
    for (int i = 0; i < ncomp; i++) comps[i].pred = 0;
    int mcucount = 0;

    for (int byy = 0; byy < my; byy++) {
        for (int bxx = 0; bxx < mx; bxx++) {
            if (restart_iv && mcucount > 0 && (mcucount % restart_iv) == 0) {
                jbc = 0; jeod = 0;
                while (jd + 1 < jend && !(jd[0] == 0xFF && jd[1] >= 0xD0 && jd[1] <= 0xD7)) jd++;
                if (jd + 1 < jend) jd += 2;
                for (int i = 0; i < ncomp; i++) comps[i].pred = 0;
            }
            for (int ci = 0; ci < ncomp; ci++) {
                comp_t* c = &comps[ci];
                int cw = c->h * 8;
                for (int vy = 0; vy < c->v; vy++)
                    for (int hx = 0; hx < c->h; hx++)
                        decode_block(ci, &cpix[ci][(vy * 8) * cw + hx * 8], cw);
            }
            int baseX = bxx * mcuW, baseY = byy * mcuH;
            for (int ly = 0; ly < mcuH; ly++) {
                int fy = baseY + ly; if (fy >= jH) break;
                int oy = fy * oh / jH;
                for (int lx = 0; lx < mcuW; lx++) {
                    int fx = baseX + lx; if (fx >= jW) break;
                    int ox = fx * ow / jW;
                    int Y, Cb = 128, Cr = 128;
                    { comp_t* c = &comps[0]; int cw = c->h * 8; int sy = ly * c->v / maxV, sx = lx * c->h / maxH; Y = cpix[0][sy * cw + sx]; }
                    if (ncomp == 3) {
                        { comp_t* c = &comps[1]; int cw = c->h * 8; int sy = ly * c->v / maxV, sx = lx * c->h / maxH; Cb = cpix[1][sy * cw + sx]; }
                        { comp_t* c = &comps[2]; int cw = c->h * 8; int sy = ly * c->v / maxV, sx = lx * c->h / maxH; Cr = cpix[2][sy * cw + sx]; }
                    }
                    int r, g, b;
                    if (ncomp == 1) { r = g = b = Y; }
                    else {
                        int cb = Cb - 128, cr = Cr - 128;
                        r = Y + ((91881 * cr) >> 16);
                        g = Y - ((22554 * cb) >> 16) - ((46802 * cr) >> 16);
                        b = Y + ((116130 * cb) >> 16);
                    }
                    int oi = oy * ow + ox;
                    acc_r[oi] += clamp8(r); acc_g[oi] += clamp8(g); acc_b[oi] += clamp8(b); acc_c[oi]++;
                }
            }
            mcucount++;
        }
    }

    for (int y = 0; y < oh; y++) {
        for (int x = 0; x < ow; x++) {
            int oi = y * ow + x; int cnt = acc_c[oi]; if (cnt < 1) cnt = 1;
            u8* o = out_rgb + (y * (int)max_w + x) * 3;
            o[0] = (u8)(acc_r[oi] / cnt); o[1] = (u8)(acc_g[oi] / cnt); o[2] = (u8)(acc_b[oi] / cnt);
        }
    }
    *out_w = (u32)ow; *out_h = (u32)oh;
    return JPEG_OK;
}
