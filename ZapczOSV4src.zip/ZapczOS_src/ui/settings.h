#ifndef SETTINGS_H
#define SETTINGS_H
#include "io.h"

void settings_init(void);
void app_settings_draw(i32 x, i32 y, i32 w, i32 h);
void app_settings_click(i32 rx, i32 ry);
void app_settings_wheel(i32 delta);
void app_settings_drag(i32 rx, i32 ry);

#endif
