#ifndef SCREENSHOT_H
#define SCREENSHOT_H
#include "io.h"

int         screenshot_take(void);
const char* screenshot_message(void);
const char* screenshot_last_name(void);

#endif
