#include "png.h"
#include "fat32.h"
#include "util.h"
#include "libc_shim.h"
#include "inflate.h"

#define PNG_SCRATCH_SIZE (4 * 1024 * 1024)
#define PNG_RAW_SIZE     (20 * 1024 * 1024)
static u8 scratch_a[PNG_SCRATCH_SIZE];
static u8 scratch_b[PNG_SCRATCH_SIZE];
static u8 png_raw[PNG_RAW_SIZE];

static void put_be32(u8* p, u32 v) {
    p[0] = (u8)(v >> 24); p[1] = (u8)(v >> 16); p[2] = (u8)(v >> 8); p[3] = (u8)v;
}
static u32 get_be32(const u8* p) {
    return ((u32)p[0] << 24) | ((u32)p[1] << 16) | ((u32)p[2] << 8) | (u32)p[3];
}
static void put_le16(u8* p, u16 v) { p[0] = (u8)v; p[1] = (u8)(v >> 8); }

static u32 crc32_calc(const u8* buf, u32 len) {
    u32 crc = 0xFFFFFFFFu;
    for (u32 i = 0; i < len; i++) {
        crc ^= buf[i];
        for (int k = 0; k < 8; k++) {
            if (crc & 1) crc = (crc >> 1) ^ 0xEDB88320u;
            else crc >>= 1;
        }
    }
    return crc ^ 0xFFFFFFFFu;
}

static u32 adler32_calc(const u8* buf, u32 len) {
    u32 a = 1, b = 0;
    for (u32 i = 0; i < len; i++) {
        a = (a + buf[i]) % 65521u;
        b = (b + a) % 65521u;
    }
    return (b << 16) | a;
}

const char* png_error_string(int code) {
    switch (code) {
        case PNG_OK: return "ok";
        case PNG_ERR_NO_DISK: return "no disk detected";
        case PNG_ERR_NOT_FOUND: return "file not found";
        case PNG_ERR_TOO_BIG: return "image too large";
        case PNG_ERR_BAD_SIGNATURE: return "not a PNG file";
        case PNG_ERR_UNSUPPORTED: return "PNG uses real compression or an unsupported layout (only simple/uncompressed PNGs are supported)";
        case PNG_ERR_WRITE_FAILED: return "write failed";
        default: return "unknown error";
    }
}

static int append_chunk(u8* buf, u32 cap, u32* pos, const char type[4],
                         const u8* data, u32 data_len) {
    if (*pos + 12 + data_len > cap) return 0;
    put_be32(buf + *pos, data_len);
    buf[*pos + 4] = (u8)type[0]; buf[*pos + 5] = (u8)type[1];
    buf[*pos + 6] = (u8)type[2]; buf[*pos + 7] = (u8)type[3];
    if (data_len) memcpy(buf + *pos + 8, data, data_len);
    u32 crc = crc32_calc(buf + *pos + 4, 4 + data_len);
    put_be32(buf + *pos + 8 + data_len, crc);
    *pos += 12 + data_len;
    return 1;
}

int png_encode_rgb_to_file(const char* filename, const u8* rgb, u32 width, u32 height) {
    if (!fat32_available()) return PNG_ERR_NO_DISK;
    if (width == 0 || height == 0) return PNG_ERR_TOO_BIG;

    u32 row_bytes = 1 + width * 3;
    u64 raw_size64 = (u64)row_bytes * (u64)height;
    if (raw_size64 > PNG_SCRATCH_SIZE - 4096) return PNG_ERR_TOO_BIG;
    u32 raw_size = (u32)raw_size64;

    u32 rp = 0;
    for (u32 y = 0; y < height; y++) {
        scratch_b[rp++] = 0;
        const u8* src_row = rgb + (u64)y * width * 3;
        memcpy(scratch_b + rp, src_row, (u32)width * 3);
        rp += width * 3;
    }

    u32 pos = 0;
    static const u8 sig[8] = {0x89,0x50,0x4E,0x47,0x0D,0x0A,0x1A,0x0A};
    memcpy(scratch_a, sig, 8);
    pos = 8;

    u8 ihdr[13];
    put_be32(ihdr + 0, width);
    put_be32(ihdr + 4, height);
    ihdr[8] = 8;
    ihdr[9] = 2;
    ihdr[10] = 0;
    ihdr[11] = 0;
    ihdr[12] = 0;
    if (!append_chunk(scratch_a, PNG_SCRATCH_SIZE, &pos, "IHDR", ihdr, 13)) return PNG_ERR_TOO_BIG;

    u32 idat_start = pos + 8;
    u32 ip = idat_start;
    scratch_a[ip++] = 0x78; scratch_a[ip++] = 0x01;

    u32 remaining = raw_size, off = 0;
    while (1) {
        u32 chunk_len = remaining > 65535 ? 65535 : remaining;
        u8 bfinal = (chunk_len == remaining) ? 1 : 0;
        scratch_a[ip++] = bfinal;
        put_le16(scratch_a + ip, (u16)chunk_len); ip += 2;
        put_le16(scratch_a + ip, (u16)(~chunk_len & 0xFFFF)); ip += 2;
        memcpy(scratch_a + ip, scratch_b + off, chunk_len);
        ip += chunk_len; off += chunk_len; remaining -= chunk_len;
        if (bfinal) break;
    }
    u32 adler = adler32_calc(scratch_b, raw_size);
    put_be32(scratch_a + ip, adler); ip += 4;

    u32 idat_len = ip - idat_start;

    put_be32(scratch_a + pos, idat_len);
    scratch_a[pos+4]='I'; scratch_a[pos+5]='D'; scratch_a[pos+6]='A'; scratch_a[pos+7]='T';
    u32 crc = crc32_calc(scratch_a + pos + 4, 4 + idat_len);
    put_be32(scratch_a + idat_start + idat_len, crc);
    pos = idat_start + idat_len + 4;

    if (!append_chunk(scratch_a, PNG_SCRATCH_SIZE, &pos, "IEND", 0, 0)) return PNG_ERR_TOO_BIG;

    if (!fat32_write_file(filename, scratch_a, pos)) return PNG_ERR_WRITE_FAILED;
    return PNG_OK;
}

static int png_decode_scratch(u32 len, u8* out_rgb, u32 max_w, u32 max_h,
                     u32* out_w, u32* out_h) {
    if (len < 8) return PNG_ERR_BAD_SIGNATURE;

    static const u8 sig[8] = {0x89,0x50,0x4E,0x47,0x0D,0x0A,0x1A,0x0A};
    if (memcmp(scratch_a, sig, 8) != 0) return PNG_ERR_BAD_SIGNATURE;

    u32 width = 0, height = 0;
    u8 palette[256 * 3];
    u32 palette_count = 0;
    int color_type = -1;
    u32 idat_total = 0;
    u32 p = 8;
    int have_ihdr = 0;

    while (p + 8 <= (u32)len) {
        u32 clen = get_be32(scratch_a + p);
        const u8* ctype = scratch_a + p + 4;
        const u8* cdata = scratch_a + p + 8;
        if (p + 12 + clen > (u32)len) break;

        if (memcmp(ctype, "IHDR", 4) == 0 && clen >= 13) {
            width = get_be32(cdata + 0);
            height = get_be32(cdata + 4);
            u8 bitdepth = cdata[8];
            color_type = cdata[9];
            u8 comp = cdata[10], filt = cdata[11], interlace = cdata[12];
            if (bitdepth != 8 || comp != 0 || filt != 0 || interlace != 0) return PNG_ERR_UNSUPPORTED;
            if (color_type != 0 && color_type != 2 && color_type != 3 && color_type != 6) return PNG_ERR_UNSUPPORTED;
            have_ihdr = 1;
        } else if (memcmp(ctype, "PLTE", 4) == 0) {
            u32 entries = clen / 3;
            if (entries > 256) entries = 256;
            memcpy(palette, cdata, entries * 3);
            palette_count = entries;
        } else if (memcmp(ctype, "IDAT", 4) == 0) {

            if (idat_total + clen <= PNG_SCRATCH_SIZE) {
                memcpy(scratch_b + idat_total, cdata, clen);
                idat_total += clen;
            }
        } else if (memcmp(ctype, "IEND", 4) == 0) {
            break;
        }
        p += 12 + clen;
    }

    if (!have_ihdr || idat_total < 2) return PNG_ERR_BAD_SIGNATURE;
    if (color_type == 3 && palette_count == 0) return PNG_ERR_UNSUPPORTED;
    if (width == 0 || height == 0) return PNG_ERR_TOO_BIG;

    u32 bpp = (color_type == 0 || color_type == 3) ? 1 : (color_type == 2) ? 3 : 4;
    u32 row_bytes = 1 + width * bpp;
    u64 raw_size64 = (u64)row_bytes * (u64)height;
    if (raw_size64 > PNG_RAW_SIZE) return PNG_ERR_TOO_BIG;
    u32 raw_size = (u32)raw_size64;

    if (idat_total < 2) return PNG_ERR_UNSUPPORTED;
    u32 outp = 0;
    if (!inflate_raw(scratch_b + 2, idat_total - 2, png_raw, PNG_RAW_SIZE, &outp)) {
        return PNG_ERR_UNSUPPORTED;
    }
    if (outp < raw_size) return PNG_ERR_UNSUPPORTED;

    {
        for (u32 y = 0; y < height; y++) {
            u8* row = png_raw + (u64)y * row_bytes;
            u8 ftype = row[0];
            u8* px = row + 1;
            const u8* prev_px = (y > 0) ? (png_raw + (u64)(y - 1) * row_bytes + 1) : 0;
            u32 plen = row_bytes - 1;
            for (u32 i = 0; i < plen; i++) {
                u8 a = (i >= bpp) ? px[i - bpp] : 0;
                u8 b = prev_px ? prev_px[i] : 0;
                u8 c = (prev_px && i >= bpp) ? prev_px[i - bpp] : 0;
                u8 recon;
                if (ftype == 0) recon = px[i];
                else if (ftype == 1) recon = (u8)(px[i] + a);
                else if (ftype == 2) recon = (u8)(px[i] + b);
                else if (ftype == 3) recon = (u8)(px[i] + (u8)(((u32)a + (u32)b) / 2));
                else if (ftype == 4) {
                    i32 p = (i32)a + (i32)b - (i32)c;
                    i32 pa = p > (i32)a ? p - (i32)a : (i32)a - p;
                    i32 pb = p > (i32)b ? p - (i32)b : (i32)b - p;
                    i32 pc = p > (i32)c ? p - (i32)c : (i32)c - p;
                    u8 pred = (pa <= pb && pa <= pc) ? a : (pb <= pc) ? b : c;
                    recon = (u8)(px[i] + pred);
                } else {
                    return PNG_ERR_UNSUPPORTED;
                }
                px[i] = recon;
            }
        }
    }

    u32 ow = width, oh = height;
    if (ow > max_w) { oh = oh * max_w / ow; ow = max_w; }
    if (oh > max_h) { ow = ow * max_h / oh; oh = max_h; }
    if (ow < 1) ow = 1;
    if (oh < 1) oh = 1;

    for (u32 oy = 0; oy < oh; oy++) {
        u32 sy0 = oy * height / oh, sy1 = (oy + 1) * height / oh;
        if (sy1 <= sy0) sy1 = sy0 + 1;
        u8* dst = out_rgb + (u64)oy * max_w * 3;
        for (u32 ox = 0; ox < ow; ox++) {
            u32 sx0 = ox * width / ow, sx1 = (ox + 1) * width / ow;
            if (sx1 <= sx0) sx1 = sx0 + 1;
            u32 sr = 0, sg = 0, sb = 0, cnt = 0;
            for (u32 sy = sy0; sy < sy1; sy++) {
                const u8* px = png_raw + (u64)sy * row_bytes + 1;
                for (u32 sx = sx0; sx < sx1; sx++) {
                    u8 r, g, b;
                    if (color_type == 0) { r = g = b = px[sx]; }
                    else if (color_type == 2) { r = px[sx*3+0]; g = px[sx*3+1]; b = px[sx*3+2]; }
                    else if (color_type == 3) {
                        u8 idx = px[sx];
                        if (idx >= palette_count) { r = g = b = 0; }
                        else { r = palette[idx*3+0]; g = palette[idx*3+1]; b = palette[idx*3+2]; }
                    } else { r = px[sx*4+0]; g = px[sx*4+1]; b = px[sx*4+2]; }
                    sr += r; sg += g; sb += b; cnt++;
                }
            }
            if (cnt < 1) cnt = 1;
            dst[ox*3+0] = (u8)(sr / cnt); dst[ox*3+1] = (u8)(sg / cnt); dst[ox*3+2] = (u8)(sb / cnt);
        }
    }

    *out_w = ow; *out_h = oh;
    return PNG_OK;
}
int png_decode_file(const char* filename, u8* out_rgb, u32 max_w, u32 max_h,
                    u32* out_w, u32* out_h) {
    if (!fat32_available()) return PNG_ERR_NO_DISK;
    fat_dirent_t ents[48];
    int n = fat32_list_root(ents, 48);
    const fat_dirent_t* found = 0;
    for (int i = 0; i < n; i++) {
        if (str_eq_ci(ents[i].display_name, filename)) { found = &ents[i]; break; }
    }
    if (!found) return PNG_ERR_NOT_FOUND;
    if (found->size > PNG_SCRATCH_SIZE) return PNG_ERR_TOO_BIG;
    int len = fat32_read_file(found, scratch_a, PNG_SCRATCH_SIZE);
    if (len < 0) len = 0;
    return png_decode_scratch((u32)len, out_rgb, max_w, max_h, out_w, out_h);
}
int png_decode_mem(const u8* data, u32 len, u8* out_rgb, u32 max_w, u32 max_h,
                   u32* out_w, u32* out_h) {
    if (len > PNG_SCRATCH_SIZE) return PNG_ERR_TOO_BIG;
    if (data != scratch_a) memcpy(scratch_a, data, len);
    return png_decode_scratch(len, out_rgb, max_w, max_h, out_w, out_h);
}
