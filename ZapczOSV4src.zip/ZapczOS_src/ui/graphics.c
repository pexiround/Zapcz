#include "graphics.h"
#include "mm.h"
#include "font8x16.h"
#include "libc_shim.h"
#include "io.h"

gfx_t gfx;
static clip_t cur_clip;
static int has_clip = 0;

void gfx_set_clip(clip_t c) { cur_clip = c; has_clip = 1; }
void gfx_clear_clip(void) { has_clip = 0; }

static inline int clip_ok(i32 x, i32 y) {
    if (x < 0 || y < 0 || (u32)x >= gfx.width || (u32)y >= gfx.height) return 0;
    if (has_clip) {
        if (x < cur_clip.x0 || x >= cur_clip.x1 ||
            y < cur_clip.y0 || y >= cur_clip.y1) return 0;
    }
    return 1;
}

int gfx_clip_test(i32 x, i32 y) { return clip_ok(x, y); }

/* Returns 0 if the mode the firmware gave us needs a bigger backbuffer than we
   reserved. Callers must not draw in that case -- writing past the buffer would
   corrupt the heap and triple-fault the machine. */
int gfx_mode_fits(u32 width, u32 height, u32 bpp) {
    u32 need = width * height * (bpp / 8);
    return need != 0 && need <= BACKBUFFER_MAXLEN;
}

void gfx_init(u32 fb_addr, u32 width, u32 height, u32 pitch, u32 bpp) {
    gfx.fb_addr = fb_addr;
    gfx.width = width;
    gfx.height = height;
    gfx.pitch = pitch;
    gfx.bpp = bpp;
    gfx.bypp = bpp / 8;
    gfx.back = (u8*)BACKBUFFER_ADDR;
}

static int has_dirty = 0;
static i32 d_y0 = 0, d_y1 = 0;

static inline void dirty_span(i32 y0, i32 y1) {
    if (y0 < 0) y0 = 0;
    if (y1 > (i32)gfx.height) y1 = (i32)gfx.height;
    if (y0 >= y1) return;
    if (!has_dirty) { d_y0 = y0; d_y1 = y1; has_dirty = 1; }
    else { if (y0 < d_y0) d_y0 = y0; if (y1 > d_y1) d_y1 = y1; }
}

void gfx_mark_dirty(i32 y0, i32 y1) { dirty_span(y0, y1); }
void gfx_mark_all_dirty(void) { dirty_span(0, (i32)gfx.height); }

void gfx_present(void) {
    if (!has_dirty) return;
    has_dirty = 0;
    i32 y0 = d_y0, y1 = d_y1;
    volatile u8* fb = (volatile u8*)(u32)gfx.fb_addr;
    u32 row_bytes = gfx.width * gfx.bypp;
    if (row_bytes == gfx.pitch) {
        memcpy((void*)(fb + (u32)y0 * row_bytes), gfx.back + (u32)y0 * row_bytes,
               row_bytes * (u32)(y1 - y0));
        return;
    }
    for (i32 y = y0; y < y1; y++) {
        u8* src = gfx.back + (u32)y * row_bytes;
        memcpy((void*)(fb + (u32)y * gfx.pitch), src, row_bytes);
    }
}

void gfx_back_save(i32 x, i32 y, i32 w, i32 h, u8* dst) {
    for (i32 j = 0; j < h; j++) {
        i32 yy = y + j;
        for (i32 i = 0; i < w; i++) {
            i32 xx = x + i;
            u8* d = dst + ((u32)j * (u32)w + (u32)i) * gfx.bypp;
            if (xx < 0 || yy < 0 || xx >= (i32)gfx.width || yy >= (i32)gfx.height) {
                for (u32 k = 0; k < gfx.bypp; k++) d[k] = 0;
                continue;
            }
            u8* s = gfx.back + (u32)yy * gfx.width * gfx.bypp + (u32)xx * gfx.bypp;
            for (u32 k = 0; k < gfx.bypp; k++) d[k] = s[k];
        }
    }
}
void gfx_back_restore(i32 x, i32 y, i32 w, i32 h, const u8* src) {
    for (i32 j = 0; j < h; j++) {
        i32 yy = y + j; if (yy < 0 || yy >= (i32)gfx.height) continue;
        for (i32 i = 0; i < w; i++) {
            i32 xx = x + i; if (xx < 0 || xx >= (i32)gfx.width) continue;
            const u8* s = src + ((u32)j * (u32)w + (u32)i) * gfx.bypp;
            u8* d = gfx.back + (u32)yy * gfx.width * gfx.bypp + (u32)xx * gfx.bypp;
            for (u32 k = 0; k < gfx.bypp; k++) d[k] = s[k];
        }
    }
    dirty_span(y, y + h);
}

void gfx_fb_read(i32 x, i32 y, i32 w, i32 h, u8* dst) {
    volatile u8* fb = (volatile u8*)(u32)gfx.fb_addr;
    for (i32 j = 0; j < h; j++) {
        i32 yy = y + j;
        for (i32 i = 0; i < w; i++) {
            i32 xx = x + i;
            u8* d = dst + ((u32)j * (u32)w + (u32)i) * gfx.bypp;
            if (xx < 0 || yy < 0 || xx >= (i32)gfx.width || yy >= (i32)gfx.height) {
                for (u32 k = 0; k < gfx.bypp; k++) d[k] = 0;
                continue;
            }
            volatile u8* s = fb + (u32)yy * gfx.pitch + (u32)xx * gfx.bypp;
            for (u32 k = 0; k < gfx.bypp; k++) d[k] = s[k];
        }
    }
}
void gfx_fb_write(i32 x, i32 y, i32 w, i32 h, const u8* src) {
    volatile u8* fb = (volatile u8*)(u32)gfx.fb_addr;
    for (i32 j = 0; j < h; j++) {
        i32 yy = y + j; if (yy < 0 || yy >= (i32)gfx.height) continue;
        for (i32 i = 0; i < w; i++) {
            i32 xx = x + i; if (xx < 0 || xx >= (i32)gfx.width) continue;
            const u8* s = src + ((u32)j * (u32)w + (u32)i) * gfx.bypp;
            volatile u8* d = fb + (u32)yy * gfx.pitch + (u32)xx * gfx.bypp;
            for (u32 k = 0; k < gfx.bypp; k++) d[k] = s[k];
        }
    }
}
void gfx_fb_pixel(i32 x, i32 y, color_t c) {
    if (x < 0 || y < 0 || x >= (i32)gfx.width || y >= (i32)gfx.height) return;
    volatile u8* fb = (volatile u8*)(u32)gfx.fb_addr;
    volatile u8* d = fb + (u32)y * gfx.pitch + (u32)x * gfx.bypp;
    d[0] = c.b; d[1] = c.g; d[2] = c.r; if (gfx.bypp == 4) d[3] = 0xFF;
}

static inline void put_back(i32 x, i32 y, color_t c) {
    u32 off = (u32)y * gfx.width * gfx.bypp + (u32)x * gfx.bypp;
    gfx.back[off + 0] = c.b;
    gfx.back[off + 1] = c.g;
    gfx.back[off + 2] = c.r;
    if (gfx.bypp == 4) gfx.back[off + 3] = 0xFF;
}

static inline void fill_row(i32 y, i32 xs, i32 xe, color_t c) {
    u32 row_off = (u32)y * gfx.width * gfx.bypp;
    if (gfx.bypp == 4) {
        u32 packed = (u32)c.b | ((u32)c.g << 8) | ((u32)c.r << 16) | (0xFFu << 24);
        u32* p = (u32*)(gfx.back + row_off) + xs;
        for (i32 i = xs; i < xe; i++) *p++ = packed;
    } else {
        u8* p = gfx.back + row_off + (u32)xs * gfx.bypp;
        for (i32 i = xs; i < xe; i++) {
            p[0] = c.b; p[1] = c.g; p[2] = c.r;
            p += gfx.bypp;
        }
    }
}

void gfx_pixel(i32 x, i32 y, color_t c) {
    if (!clip_ok(x, y)) return;
    put_back(x, y, c);
}

void gfx_rect(i32 x, i32 y, i32 w, i32 h, color_t c) {
    for (i32 j = y; j < y + h; j++) {
        if (j < 0 || (u32)j >= gfx.height) continue;
        if (has_clip && (j < cur_clip.y0 || j >= cur_clip.y1)) continue;
        i32 xs = x, xe = x + w;
        if (xe <= 0 || xs >= (i32)gfx.width) continue;
        if (xs < 0) xs = 0;
        if (xe > (i32)gfx.width) xe = (i32)gfx.width;
        if (has_clip) {
            if (xs < cur_clip.x0) xs = cur_clip.x0;
            if (xe > cur_clip.x1) xe = cur_clip.x1;
        }
        if (xe > xs) fill_row(j, xs, xe, c);
    }
}

static i32 corner_inset(i32 dy, i32 r) {
    i32 rr = r * r - dy * dy;
    if (rr < 0) return r;
    i32 s = 0;
    while ((s + 1) * (s + 1) <= rr) s++;
    return r - s;
}


/* Like gfx_rounded_rect but only the top two corners are rounded -- used for
   titlebars that sit flush against the window body below them. */
void gfx_rounded_rect_top(i32 x, i32 y, i32 w, i32 h, i32 radius, color_t c) {
    if (radius > h) radius = h;
    if (radius > w / 2) radius = w / 2;
    if (radius < 0) radius = 0;

    for (i32 j = 0; j < h; j++) {
        i32 inset = 0;
        if (j < radius) inset = corner_inset(radius - 1 - j, radius);
        i32 row = y + j;
        if (row < 0 || (u32)row >= gfx.height) continue;
        if (has_clip && (row < cur_clip.y0 || row >= cur_clip.y1)) continue;
        i32 xs = x + inset, xe = x + w - inset;
        if (xe <= 0 || xs >= (i32)gfx.width) continue;
        if (xs < 0) xs = 0;
        if (xe > (i32)gfx.width) xe = (i32)gfx.width;
        if (has_clip) {
            if (xs < cur_clip.x0) xs = cur_clip.x0;
            if (xe > cur_clip.x1) xe = cur_clip.x1;
        }
        for (i32 px = xs; px < xe; px++) put_back(px, row, c);
    }
}

void gfx_rounded_rect(i32 x, i32 y, i32 w, i32 h, i32 radius, color_t c) {
    if (radius > h / 2) radius = h / 2;
    if (radius > w / 2) radius = w / 2;
    if (radius < 0) radius = 0;

    for (i32 j = 0; j < h; j++) {
        i32 inset = 0;
        if (j < radius) {
            inset = corner_inset(radius - 1 - j, radius);
        } else if (j >= h - radius) {
            inset = corner_inset(j - (h - radius), radius);
        }
        i32 row = y + j;
        if (row < 0 || (u32)row >= gfx.height) continue;
        if (has_clip && (row < cur_clip.y0 || row >= cur_clip.y1)) continue;
        i32 xs = x + inset, xe = x + w - inset;
        if (xe <= 0 || xs >= (i32)gfx.width) continue;
        if (xs < 0) xs = 0;
        if (xe > (i32)gfx.width) xe = (i32)gfx.width;
        if (has_clip) {
            if (xs < cur_clip.x0) xs = cur_clip.x0;
            if (xe > cur_clip.x1) xe = cur_clip.x1;
        }
        if (xe > xs) fill_row(row, xs, xe, c);
    }
}

void gfx_rounded_rect4(i32 x, i32 y, i32 w, i32 h, i32 r_top, i32 r_bottom, color_t c) {
    if (r_top > h / 2) r_top = h / 2;
    if (r_top > w / 2) r_top = w / 2;
    if (r_bottom > h / 2) r_bottom = h / 2;
    if (r_bottom > w / 2) r_bottom = w / 2;
    if (r_top < 0) r_top = 0;
    if (r_bottom < 0) r_bottom = 0;

    for (i32 j = 0; j < h; j++) {
        i32 inset = 0;
        if (j < r_top) inset = corner_inset(r_top - 1 - j, r_top);
        else if (j >= h - r_bottom) inset = corner_inset(j - (h - r_bottom), r_bottom);

        i32 row = y + j;
        if (row < 0 || (u32)row >= gfx.height) continue;
        if (has_clip && (row < cur_clip.y0 || row >= cur_clip.y1)) continue;
        i32 xs = x + inset, xe = x + w - inset;
        if (xe <= 0 || xs >= (i32)gfx.width) continue;
        if (xs < 0) xs = 0;
        if (xe > (i32)gfx.width) xe = (i32)gfx.width;
        if (has_clip) {
            if (xs < cur_clip.x0) xs = cur_clip.x0;
            if (xe > cur_clip.x1) xe = cur_clip.x1;
        }
        if (xe > xs) fill_row(row, xs, xe, c);
    }
}

void gfx_rounded_rect_outline(i32 x, i32 y, i32 w, i32 h, i32 radius, color_t c) {
    if (radius > h / 2) radius = h / 2;
    if (radius > w / 2) radius = w / 2;
    if (radius < 0) radius = 0;

    for (i32 j = 0; j < h; j++) {
        i32 inset = 0;
        if (j < radius) inset = corner_inset(radius - 1 - j, radius);
        else if (j >= h - radius) inset = corner_inset(j - (h - radius), radius);

        i32 row = y + j;
        i32 left = x + inset;
        i32 right = x + w - 1 - inset;
        if (j == 0 || j == h - 1 || inset > 0) {

            gfx_pixel(left, row, c);
            if (right != left) gfx_pixel(right, row, c);

            if (inset == 0 && (j == 0 || j == h - 1)) {
                fill_row(row, left, right + 1, c);
            }
        } else {
            gfx_pixel(left, row, c);
            gfx_pixel(right, row, c);
        }
    }
}

void gfx_rect_outline(i32 x, i32 y, i32 w, i32 h, color_t c) {
    gfx_hline(x, y, w, c);
    gfx_hline(x, y + h - 1, w, c);
    gfx_vline(x, y, h, c);
    gfx_vline(x + w - 1, y, h, c);
}

void gfx_hline(i32 x, i32 y, i32 w, color_t c) { gfx_rect(x, y, w, 1, c); }
void gfx_vline(i32 x, i32 y, i32 h, color_t c) { gfx_rect(x, y, 1, h, c); }

void gfx_line(i32 x0, i32 y0, i32 x1, i32 y1, color_t c) {
    i32 dx = x1 - x0, dy = y1 - y0;
    i32 sx = (dx >= 0) ? 1 : -1;
    i32 sy = (dy >= 0) ? 1 : -1;
    dx = (dx >= 0) ? dx : -dx;
    dy = (dy >= 0) ? dy : -dy;
    i32 err = dx - dy;
    i32 x = x0, y = y0;
    for (;;) {
        gfx_pixel(x, y, c);
        if (x == x1 && y == y1) break;
        i32 e2 = err * 2;
        if (e2 > -dy) { err -= dy; x += sx; }
        if (e2 < dx)  { err += dx; y += sy; }
    }
}

void gfx_circle(i32 cx, i32 cy, i32 r, color_t c) {
    i32 x = r, y = 0, err = 0;
    while (x >= y) {
        gfx_pixel(cx + x, cy + y, c); gfx_pixel(cx + y, cy + x, c);
        gfx_pixel(cx - y, cy + x, c); gfx_pixel(cx - x, cy + y, c);
        gfx_pixel(cx - x, cy - y, c); gfx_pixel(cx - y, cy - x, c);
        gfx_pixel(cx + y, cy - x, c); gfx_pixel(cx + x, cy - y, c);
        y += 1;
        err += 1 + 2 * y;
        if (2 * err - 2 * x + 1 > 0) { x -= 1; err += 1 - 2 * x; }
    }
}

void gfx_circle_fill(i32 cx, i32 cy, i32 r, color_t c) {
    for (i32 y = -r; y <= r; y++) {
        i32 dx = 0;

        while (dx * dx + y * y <= r * r) dx++;
        dx--;
        gfx_hline(cx - dx, cy + y, dx * 2 + 1, c);
    }
}

void gfx_gradient_v(i32 x, i32 y, i32 w, i32 h, color_t top, color_t bottom) {
    for (i32 j = 0; j < h; j++) {
        i32 r = top.r + (bottom.r - top.r) * j / (h > 1 ? h - 1 : 1);
        i32 g = top.g + (bottom.g - top.g) * j / (h > 1 ? h - 1 : 1);
        i32 b = top.b + (bottom.b - top.b) * j / (h > 1 ? h - 1 : 1);
        gfx_hline(x, y + j, w, RGB(r, g, b));
    }
}

color_t gfx_lerp_color(color_t a, color_t b, i32 num, i32 den) {
    if (den <= 0) den = 1;
    if (num < 0) num = 0;
    if (num > den) num = den;
    i32 r = a.r + (b.r - a.r) * num / den;
    i32 g = a.g + (b.g - a.g) * num / den;
    i32 bb = a.b + (b.b - a.b) * num / den;
    return RGB(r, g, bb);
}

void gfx_rounded_gradient_v(i32 x, i32 y, i32 w, i32 h, i32 radius, color_t top, color_t bottom) {
    if (radius > h / 2) radius = h / 2;
    if (radius > w / 2) radius = w / 2;
    if (radius < 0) radius = 0;
    for (i32 j = 0; j < h; j++) {
        i32 inset = 0;
        if (j < radius) inset = corner_inset(radius - 1 - j, radius);
        else if (j >= h - radius) inset = corner_inset(j - (h - radius), radius);

        i32 rr = top.r + (bottom.r - top.r) * j / (h > 1 ? h - 1 : 1);
        i32 gg = top.g + (bottom.g - top.g) * j / (h > 1 ? h - 1 : 1);
        i32 bb = top.b + (bottom.b - top.b) * j / (h > 1 ? h - 1 : 1);
        i32 row = y + j;
        if (row < 0 || (u32)row >= gfx.height) continue;
        if (has_clip && (row < cur_clip.y0 || row >= cur_clip.y1)) continue;
        i32 xs = x + inset, xe = x + w - inset;
        if (xe <= 0 || xs >= (i32)gfx.width) continue;
        if (xs < 0) xs = 0;
        if (xe > (i32)gfx.width) xe = (i32)gfx.width;
        if (has_clip) {
            if (xs < cur_clip.x0) xs = cur_clip.x0;
            if (xe > cur_clip.x1) xe = cur_clip.x1;
        }
        if (xe > xs) fill_row(row, xs, xe, RGB(rr, gg, bb));
    }
}

int g_font_style = 0;
void gfx_set_font(int style) { if (style < 0 || style >= FONT_STYLE_COUNT) style = 0; g_font_style = style; }
int gfx_get_font(void) { return g_font_style; }
const char* gfx_font_name(int style) {
    static const char* n[FONT_STYLE_COUNT] = { "Regular", "Bold", "Italic", "Bold Italic", "Outline" };
    if (style < 0 || style >= FONT_STYLE_COUNT) style = 0;
    return n[style];
}

void gfx_char(i32 x, i32 y, char ch, color_t fg, color_t bg, int opaque) {
    if ((u8)ch < FONT_FIRST || (u8)ch > FONT_LAST) ch = '?';
    const u8* rows = font8x16[(u8)ch - FONT_FIRST];
    int style = g_font_style;
    for (i32 j = 0; j < FONT_H; j++) {
        u8 bits = rows[j];
        int xshift = 0;
        if (style == 1 || style == 3) bits = (u8)(bits | (bits >> 1));
        if (style == 2 || style == 3) xshift = (FONT_H - 1 - j) / 5;
        u8 above = (j > 0) ? rows[j - 1] : 0;
        u8 below = (j < FONT_H - 1) ? rows[j + 1] : 0;
        for (i32 i = 0; i < FONT_W; i++) {
            int on = (bits >> (7 - i)) & 1;
            if (style == 4 && on) {
                int lft = (i > 0) ? ((bits >> (7 - (i - 1))) & 1) : 0;
                int rgt = (i < 7) ? ((bits >> (7 - (i + 1))) & 1) : 0;
                int up  = (above >> (7 - i)) & 1;
                int dn  = (below >> (7 - i)) & 1;
                if (lft && rgt && up && dn) on = 0;
            }
            if (on) gfx_pixel(x + i + xshift, y + j, fg);
            else if (opaque) gfx_pixel(x + i, y + j, bg);
        }
    }
}

void gfx_string(i32 x, i32 y, const char* s, color_t fg, color_t bg, int opaque) {
    if (!s) return;
    i32 cx = x;
    while (*s) {
        if (*s == '\n') { cx = x; y += FONT_H; s++; continue; }
        gfx_char(cx, y, *s, fg, bg, opaque);
        cx += FONT_W;
        s++;
    }
}

int gfx_string_width(const char* s) {
    int w = 0, max = 0;
    while (*s) {
        if (*s == '\n') { if (w > max) max = w; w = 0; }
        else w += FONT_W;
        s++;
    }
    if (w > max) max = w;
    return max;
}

void gfx_char_scaled(i32 x, i32 y, char ch, color_t fg, int scale) {
    if ((u8)ch < FONT_FIRST || (u8)ch > FONT_LAST) ch = '?';
    const u8* rows = font8x16[(u8)ch - FONT_FIRST];
    for (i32 j = 0; j < FONT_H; j++) {
        u8 bits = rows[j];
        for (i32 i = 0; i < FONT_W; i++) {
            if ((bits >> (7 - i)) & 1) {
                for (int sy = 0; sy < scale; sy++)
                    for (int sx = 0; sx < scale; sx++)
                        gfx_pixel(x + i * scale + sx, y + j * scale + sy, fg);
            }
        }
    }
}
void gfx_string_scaled(i32 x, i32 y, const char* s, color_t fg, int scale) {
    if (!s) return;
    i32 cx = x;
    while (*s) { gfx_char_scaled(cx, y, *s, fg, scale); cx += FONT_W * scale; s++; }
}
int gfx_string_width_scaled(const char* s, int scale) {
    int n = 0; while (s[n]) n++;
    return n * FONT_W * scale;
}

void gfx_blit_rgb_scaled(const u8* src, i32 src_w, i32 src_h,
                         i32 dst_x, i32 dst_y, i32 dst_w, i32 dst_h) {
    if (dst_w <= 0 || dst_h <= 0) return;
    for (i32 dy = 0; dy < dst_h; dy++) {
        i32 py = dst_y + dy;
        if (py < 0 || (u32)py >= gfx.height) continue;
        i32 sy0 = dy * src_h / dst_h;
        i32 sy1 = (dy + 1) * src_h / dst_h;
        if (sy1 <= sy0) sy1 = sy0 + 1;
        if (sy1 > src_h) sy1 = src_h;
        for (i32 dx = 0; dx < dst_w; dx++) {
            i32 sx0 = dx * src_w / dst_w;
            i32 sx1 = (dx + 1) * src_w / dst_w;
            if (sx1 <= sx0) sx1 = sx0 + 1;
            if (sx1 > src_w) sx1 = src_w;
            u32 ar = 0, ag = 0, ab = 0, n = 0;
            for (i32 sy = sy0; sy < sy1; sy++) {
                const u8* row = src + ((u32)sy * (u32)src_w) * 3;
                for (i32 sx = sx0; sx < sx1; sx++) {
                    const u8* p = row + (u32)sx * 3;
                    ar += p[0]; ag += p[1]; ab += p[2]; n++;
                }
            }
            if (!n) n = 1;
            gfx_pixel(dst_x + dx, py, RGB((u8)(ar / n), (u8)(ag / n), (u8)(ab / n)));
        }
    }
}

color_t gfx_get_pixel(i32 x, i32 y) {
    if (x < 0 || y < 0 || (u32)x >= gfx.width || (u32)y >= gfx.height)
        return RGB(0,0,0);
    u32 off = (u32)y * gfx.width * gfx.bypp + (u32)x * gfx.bypp;
    color_t c;
    c.b = gfx.back[off]; c.g = gfx.back[off+1]; c.r = gfx.back[off+2];
    return c;
}

color_t gfx_lerp(color_t a, color_t b, int t) {
    int inv = 256 - t;
    color_t r;
    r.r = (u8)((a.r * inv + b.r * t) >> 8);
    r.g = (u8)((a.g * inv + b.g * t) >> 8);
    r.b = (u8)((a.b * inv + b.b * t) >> 8);
    return r;
}

void gfx_glass_rect(i32 x, i32 y, i32 w, i32 h, color_t tint, int opa) {
    i32 x1 = x + w, y1 = y + h;
    if (x < 0) x = 0; if (y < 0) y = 0;
    if (x1 > (i32)gfx.width)  x1 = (i32)gfx.width;
    if (y1 > (i32)gfx.height) y1 = (i32)gfx.height;
    int inv = 256 - (opa * 256 / 100);
    int fwd = opa * 256 / 100;
    u32 tr = tint.r * fwd, tg = tint.g * fwd, tb = tint.b * fwd;
    u32 rb = gfx.width * gfx.bypp;
    for (i32 py = y; py < y1; py++) {
        u8* row = gfx.back + (u32)py * rb + (u32)x * gfx.bypp;
        for (i32 px = x; px < x1; px++) {
            row[0] = (u8)((row[0] * inv + tb) >> 8);
            row[1] = (u8)((row[1] * inv + tg) >> 8);
            row[2] = (u8)((row[2] * inv + tr) >> 8);
            row += gfx.bypp;
        }
    }
}

void gfx_glass_rounded_rect(i32 x, i32 y, i32 w, i32 h, i32 r, color_t tint, int opa) {
    if (r <= 0) { gfx_glass_rect(x, y, w, h, tint, opa); return; }
    if (r > w / 2) r = w / 2;
    if (r > h / 2) r = h / 2;
    gfx_glass_rect(x + r, y,         w - r * 2, h,         tint, opa);
    gfx_glass_rect(x,     y + r,     r,         h - r * 2, tint, opa);
    gfx_glass_rect(x+w-r, y + r,     r,         h - r * 2, tint, opa);
    for (i32 cy = 0; cy < r; cy++) {
        for (i32 cx = 0; cx < r; cx++) {
            i32 dx = r - 1 - cx, dy = r - 1 - cy;
            if (dx * dx + dy * dy <= (r - 1) * (r - 1)) {
                i32 px0 = x + cx,       py0 = y + cy;
                i32 px1 = x + w - 1 - cx, py1 = y + h - 1 - cy;
                gfx_glass_rect(px0, py0, 1, 1, tint, opa);
                gfx_glass_rect(px1, py0, 1, 1, tint, opa);
                gfx_glass_rect(px0, py1, 1, 1, tint, opa);
                gfx_glass_rect(px1, py1, 1, 1, tint, opa);
            }
        }
    }
}

void gfx_glow_border(i32 x, i32 y, i32 w, i32 h, i32 r, color_t col, int strength) {
    for (int i = strength; i >= 1; i--) {
        int opa = (strength - i + 1) * 30 / strength;
        gfx_rounded_rect_outline(x - i, y - i, w + i*2, h + i*2, r + i, col);
        (void)opa;
    }
    gfx_rounded_rect_outline(x, y, w, h, r, col);
}

void gfx_gradient_titlebar(i32 x, i32 y, i32 w, i32 h, color_t top, color_t bot) {
    for (i32 py = y; py < y + h; py++) {
        int t = (py - y) * 256 / h;
        color_t c = gfx_lerp(top, bot, t);
        gfx_rect(x, py, w, 1, c);
    }
}

void gfx_specular_line(i32 x, i32 y, i32 w) {
    for (i32 px = x; px < x + w; px++) {
        int t = 0;
        int cx = px - x;
        if (cx < w / 4)       t = cx * 200 / (w / 4);
        else if (cx > 3*w/4)  t = (w - cx) * 200 / (w / 4);
        else                  t = 200;
        color_t spec;
        spec.r = (u8)(180 + t * 75 / 200);
        spec.g = (u8)(140 + t * 80 / 200);
        spec.b = (u8)(255);
        gfx_glass_rect(px, y, 1, 1, spec, 55);
    }
}
