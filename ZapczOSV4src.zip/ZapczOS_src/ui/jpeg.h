#ifndef JPEG_H
#define JPEG_H
#include "io.h"

#define JPEG_OK 1

int jpeg_decode_mem(const u8* data, u32 len, u8* out_rgb, u32 max_w, u32 max_h,
                    u32* out_w, u32* out_h);

#endif
