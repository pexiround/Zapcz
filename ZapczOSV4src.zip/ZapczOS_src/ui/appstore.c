#include "appstore.h"
#include "desktop.h"
#include "graphics.h"
#include "theme.h"
#include "util.h"
#include "pit.h"
#include "config.h"
#include "icons.h"
#include "keyboard.h"
#include "scroll.h"

typedef struct {
    int app_id;
    u8  cfg_bit;
    const char* name;
    const char* desc;
    const char* size_label;
    const char* category;
    color_t badge;
} store_entry_t;

static const store_entry_t catalog[] = {
    { APP_CALC,  CFG_INSTALLED_CALC,
      "Calculator", "Basic arithmetic, chainable operations, keyboard or mouse.",
      "18 KB", "Utility", {235,150,70} },
    { APP_PAINT, CFG_INSTALLED_PAINT,
      "Paint", "A small pixel canvas with a color palette. Saves as a real PNG.",
      "26 KB", "Creativity", {120,200,255} },
    { APP_TTT,   CFG_INSTALLED_TTT,
      "Tic-Tac-Toe", "Classic two-player, same-keyboard grid game.",
      "12 KB", "Games", {150,210,110} },
    { APP_CUBE3D, CFG_INSTALLED_CUBE3D,
      "3D Grapher", "View 3D shapes and function surfaces, solid or wireframe.",
      "14 KB", "Demos", {150,130,235} },
};
#define CATALOG_COUNT (sizeof(catalog)/sizeof(catalog[0]))

static const char* CATEGORIES[] = { "All", "Utility", "Creativity", "Games", "Demos" };
#define CATEGORY_COUNT (sizeof(CATEGORIES)/sizeof(CATEGORIES[0]))
static int category_filter = 0;

#define INSTALL_MS 1400u

static int installing_idx = -1;
static u32 installing_start_tick = 0;
static char store_status[64] = "";

static char search_text[24] = "";
static u32 search_len = 0;
static int search_focused = 0;

static int filtered_idx[CATALOG_COUNT];
static int filtered_count = 0;
static i32 store_scroll = 0;

void store_init(void) {
    installing_idx = -1;
    store_status[0] = 0;
}

int app_is_installed(int app_id) {
    u8 m = config_get_installed_mask();
    switch (app_id) {
        case APP_CALC:   return (m & CFG_INSTALLED_CALC)   != 0;
        case APP_PAINT:  return (m & CFG_INSTALLED_PAINT)  != 0;
        case APP_TTT:    return (m & CFG_INSTALLED_TTT)    != 0;
        case APP_CUBE3D: return (m & CFG_INSTALLED_CUBE3D) != 0;
        case APP_MINES:  return (m & CFG_INSTALLED_MINES)  != 0;
        case APP_LIFE:   return (m & CFG_INSTALLED_LIFE)   != 0;
        case APP_SNAKE:  return (m & CFG_INSTALLED_SNAKE)  != 0;
        case APP_2048:   return (m & CFG_INSTALLED_2048)   != 0;
        default:         return 1;
    }
}

static char lower_ascii_s(char c) { return (c >= 'A' && c <= 'Z') ? (char)(c - 'A' + 'a') : c; }

static int contains_ci(const char* hay, const char* needle) {
    if (!needle[0]) return 1;
    u32 hlen = str_len(hay), nlen = str_len(needle);
    if (nlen > hlen) return 0;
    for (u32 i = 0; i + nlen <= hlen; i++) {
        u32 j = 0;
        for (; j < nlen; j++) if (lower_ascii_s(hay[i+j]) != lower_ascii_s(needle[j])) break;
        if (j == nlen) return 1;
    }
    return 0;
}

static void recompute_filter(void) {
    filtered_count = 0;
    for (u32 i = 0; i < CATALOG_COUNT; i++) {
        int cat_ok = (category_filter == 0) || str_eq(catalog[i].category, CATEGORIES[category_filter]);
        int text_ok = contains_ci(catalog[i].name, search_text) || contains_ci(catalog[i].desc, search_text);
        if (cat_ok && text_ok) filtered_idx[filtered_count++] = (int)i;
    }
}

#define ROW_H 92
#define ROW_GAP 12
#define LIST_TOP 110
#define TAB_Y 66
#define SEARCH_Y 36

static i32 row_top(i32 y, u32 idx) { return y + LIST_TOP + (i32)idx * (ROW_H + ROW_GAP) - store_scroll; }

static i32 store_content_h(void) {
    if (filtered_count <= 0) return 0;
    return (filtered_count - 1) * (ROW_H + ROW_GAP) + ROW_H;
}

void app_store_draw(i32 x, i32 y, i32 w, i32 h) {
    recompute_filter();

    gfx_string(x + 16, y + 14, "App Store", THEME_TEXT, THEME_PANEL, 0);

    if (!config_disk_available()) {
        gfx_string(x + w - 250, y + 14, "no disk: won't persist", THEME_WARNING, THEME_PANEL, 0);
    }

    color_t fbg = RGB(18,19,25);
    gfx_rounded_rect(x + 16, y + SEARCH_Y, 220, 24, THEME_RADIUS_CTRL, fbg);
    gfx_rounded_rect_outline(x + 16, y + SEARCH_Y, 220, 24, THEME_RADIUS_CTRL,
                              search_focused ? THEME_ACCENT : THEME_BORDER);
    char sbuf[26];
    str_copy(sbuf, search_text[0] ? search_text : "Search apps...", 26);
    if (search_focused && (ticks_get() / 30) % 2 == 0 && str_len(sbuf) < 22) str_cat(sbuf, "_", 26);
    gfx_string(x + 24, y + SEARCH_Y + 4, sbuf,
               (search_text[0] || search_focused) ? THEME_TEXT : THEME_TEXT_FAINT, fbg, 0);

    i32 tx = x + 16;
    for (u32 i = 0; i < CATEGORY_COUNT; i++) {
        i32 tw = gfx_string_width(CATEGORIES[i]) + 20;
        ui_button(tx, y + TAB_Y, tw, 24, CATEGORIES[i], (int)i == category_filter);
        tx += tw + 8;
    }

    if (installing_idx >= 0) {
        u32 elapsed_ms = (ticks_get() - installing_start_tick) * 1000 / ticks_per_sec();
        if (elapsed_ms >= INSTALL_MS) {
            config_set_installed(catalog[installing_idx].cfg_bit, 1);
            str_copy(store_status, catalog[installing_idx].name, 64);
            str_cat(store_status, " installed. Find it in the Start menu.", 64);
            installing_idx = -1;
        }
    }

    if (filtered_count == 0) {
        gfx_string(x + 16, y + LIST_TOP + 4, "No apps match that search.", THEME_TEXT_FAINT, THEME_PANEL, 0);
    }

    i32 view_h = h - LIST_TOP;
    store_scroll = scroll_clamp(store_scroll, store_content_h(), view_h);

    clip_t list_clip = { x, y + LIST_TOP, x + w, y + h };
    gfx_set_clip(list_clip);
    for (int fi = 0; fi < filtered_count; fi++) {
        u32 i = (u32)filtered_idx[fi];
        i32 ry = row_top(y, (u32)fi);
        gfx_rounded_rect(x + 12, ry, w - 24, ROW_H, THEME_RADIUS_CTRL, THEME_PANEL_ALT);
        gfx_rounded_rect_outline(x + 12, ry, w - 24, ROW_H, THEME_RADIUS_CTRL, THEME_BORDER);

        gfx_rounded_rect(x + 24, ry + 14, 40, 40, 10, catalog[i].badge);
        icon_draw(catalog[i].app_id, x + 24, ry + 14, 40, RGB(255,255,255));

        gfx_string(x + 76, ry + 14, catalog[i].name, THEME_TEXT, THEME_PANEL_ALT, 0);
        gfx_string(x + 76, ry + 34, catalog[i].desc, THEME_TEXT_DIM, THEME_PANEL_ALT, 0);
        char sizebuf[40] = "Size: ";
        str_cat(sizebuf, catalog[i].size_label, 40);
        str_cat(sizebuf, "  -  ", 40);
        str_cat(sizebuf, catalog[i].category, 40);
        gfx_string(x + 76, ry + 54, sizebuf, THEME_TEXT_FAINT, THEME_PANEL_ALT, 0);

        i32 bx = x + w - 24 - 110, by = ry + ROW_H - 38;
        int installed = app_is_installed(catalog[i].app_id);
        int installing_this = (installing_idx == (int)i);

        if (installing_this) {
            u32 elapsed_ms = (ticks_get() - installing_start_tick) * 1000 / ticks_per_sec();
            u32 pct = elapsed_ms * 100 / INSTALL_MS;
            if (pct > 100) pct = 100;
            gfx_rounded_rect(bx, by, 110, 28, THEME_RADIUS_CTRL, THEME_PANEL_RAISED);
            i32 fillw = (i32)(108u * pct / 100u);
            if (fillw > 0) gfx_rounded_rect(bx + 1, by + 1, fillw, 26, 5, THEME_ACCENT);
            gfx_string(bx + 14, by + 6, "Installing", THEME_TEXT, THEME_PANEL_RAISED, 0);
        } else if (installed) {
            ui_button(bx, by, 110, 28, "Open", 1);
        } else {
            ui_button(bx, by, 110, 28, "Install", 0);
        }
    }
    gfx_clear_clip();
    scroll_draw_bar(x + w - 14, y + LIST_TOP, view_h, store_scroll, store_content_h(), view_h,
                    THEME_PANEL_ALT, THEME_BORDER);

    if (store_status[0]) {
        gfx_string(x + 16, row_top(y, (u32)filtered_count) + 4, store_status, THEME_SUCCESS, THEME_PANEL, 0);
    }
}

void app_store_click(i32 rx, i32 ry) {
    if (ui_point_in(rx, ry, 16, SEARCH_Y, 220, 24)) {
        search_focused = 1;
        return;
    }
    search_focused = 0;

    i32 tx = 16;
    for (u32 i = 0; i < CATEGORY_COUNT; i++) {
        i32 tw = gfx_string_width(CATEGORIES[i]) + 20;
        if (ui_point_in(rx, ry, tx, TAB_Y, tw, 24)) { category_filter = (int)i; return; }
        tx += tw + 8;
    }

    i32 w = windows[APP_STORE].w;
    i32 h = windows[APP_STORE].h;
    i32 view_h = h - LIST_TOP;
    if (scroll_bar_hit(rx, ry, w - 14, LIST_TOP, view_h, store_content_h(), view_h)) {
        store_scroll = scroll_bar_drag_to(ry, LIST_TOP, view_h, store_content_h(), view_h);
        return;
    }

    recompute_filter();
    for (int fi = 0; fi < filtered_count; fi++) {
        u32 i = (u32)filtered_idx[fi];
        i32 row_ry = LIST_TOP + fi * (ROW_H + ROW_GAP) - store_scroll;
        i32 bx = w - 24 - 110, by = row_ry + ROW_H - 38;
        if (!ui_point_in(rx, ry, bx, by, 110, 28)) continue;

        if (installing_idx >= 0) return;
        if (app_is_installed(catalog[i].app_id)) {
            desktop_open_app(catalog[i].app_id);
        } else {
            installing_idx = (int)i;
            installing_start_tick = ticks_get();
            store_status[0] = 0;
        }
        return;
    }
}

void app_store_wheel(i32 delta) {
    i32 h = windows[APP_STORE].h;
    i32 view_h = h - LIST_TOP;
    store_scroll = scroll_clamp(store_scroll - delta * (ROW_H + ROW_GAP) / 2, store_content_h(), view_h);
}

void app_store_drag(i32 rx, i32 ry) {
    i32 w = windows[APP_STORE].w;
    i32 h = windows[APP_STORE].h;
    i32 view_h = h - LIST_TOP;
    if (scroll_bar_hit(rx, ry, w - 14, LIST_TOP, view_h, store_content_h(), view_h)) {
        store_scroll = scroll_bar_drag_to(ry, LIST_TOP, view_h, store_content_h(), view_h);
    }
}

void app_store_key(int key) {
    if (!search_focused) return;
    if (key == KEY_BACKSPACE) {
        if (search_len > 0) search_text[--search_len] = 0;
    } else if (key == KEY_ENTER || key == KEY_ESC) {
        search_focused = 0;
    } else if (kbd_is_printable(key)) {
        if (search_len < sizeof(search_text) - 1) {
            search_text[search_len++] = (char)key;
            search_text[search_len] = 0;
        }
    }
}
