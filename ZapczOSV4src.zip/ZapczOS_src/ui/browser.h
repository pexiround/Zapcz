#ifndef BROWSER_H
#define BROWSER_H
#include "io.h"

void browser_init(void);
void app_browser_draw(i32 x, i32 y, i32 w, i32 h);
void app_browser_click(i32 rx, i32 ry);
void app_browser_key(int key);
void app_browser_wheel(i32 delta);
void app_browser_drag(i32 rx, i32 ry);

void browser_tick(void);
void browser_cancel_load(void);
int  browser_is_loading(void);

#endif
void app_browser_rclick(i32 rx, i32 ry);
