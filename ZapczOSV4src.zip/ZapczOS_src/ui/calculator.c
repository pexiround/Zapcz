#include "calculator.h"
#include "graphics.h"
#include "desktop.h"
#include "theme.h"
#include "util.h"
#include "keyboard.h"

static char display[20] = "0";
static i32 acc = 0;
static char pending_op = 0;
static int entering_new = 1;
static int error_state = 0;

void calc_init(void) {
    str_copy(display, "0", 20);
    acc = 0;
    pending_op = 0;
    entering_new = 1;
    error_state = 0;
}

static i32 str_to_i32(const char* s) {
    int neg = 0;
    i32 v = 0;
    if (*s == '-') { neg = 1; s++; }
    while (*s >= '0' && *s <= '9') { v = v * 10 + (*s - '0'); s++; }
    return neg ? -v : v;
}

static void int_to_display(i32 v) {
    if (v < 0) { display[0] = '-'; u32_to_str((u32)(-v), display + 1); }
    else u32_to_str((u32)v, display);
}

static i32 calc_apply(i32 a, char op, i32 b, int* err) {
    switch (op) {
        case '+': return a + b;
        case '-': return a - b;
        case '*': return a * b;
        case '/':
            if (b == 0) { *err = 1; return 0; }
            return a / b;
        default: return b;
    }
}

static void calc_input(char token) {
    if (error_state) {
        if (token == 'C') calc_init();
        return;
    }

    if (token >= '0' && token <= '9') {
        if (entering_new) { display[0] = token; display[1] = 0; entering_new = 0; }
        else {
            u32 len = str_len(display);
            u32 digits = len - (display[0] == '-' ? 1 : 0);
            if (digits < 10 && len + 1 < sizeof(display)) { display[len] = token; display[len + 1] = 0; }
        }
        return;
    }

    if (token == 8) {
        if (!entering_new) {
            u32 len = str_len(display);
            if (len > 0) display[len - 1] = 0;
            if (display[0] == 0 || (display[0] == '-' && display[1] == 0)) {
                str_copy(display, "0", 20);
                entering_new = 1;
            }
        }
        return;
    }

    if (token == '~') {
        if (str_eq(display, "0")) return;
        if (display[0] == '-') {
            char tmp[20]; str_copy(tmp, display + 1, 20); str_copy(display, tmp, 20);
        } else {
            char tmp[20] = "-"; str_cat(tmp, display, 20); str_copy(display, tmp, 20);
        }
        return;
    }

    if (token == 'C') { calc_init(); return; }

    if (token == '+' || token == '-' || token == '*' || token == '/') {
        i32 cur = str_to_i32(display);
        if (pending_op) {
            int err = 0;
            i32 r = calc_apply(acc, pending_op, cur, &err);
            if (err) { str_copy(display, "Error", 20); error_state = 1; pending_op = 0; entering_new = 1; return; }
            acc = r;
            int_to_display(acc);
        } else {
            acc = cur;
        }
        pending_op = token;
        entering_new = 1;
        return;
    }

    if (token == '=') {
        i32 cur = str_to_i32(display);
        if (pending_op) {
            int err = 0;
            i32 r = calc_apply(acc, pending_op, cur, &err);
            if (err) { str_copy(display, "Error", 20); error_state = 1; pending_op = 0; entering_new = 1; return; }
            acc = r;
            int_to_display(acc);
        }
        pending_op = 0;
        entering_new = 1;
        return;
    }
}

typedef struct { int col, row, colspan; const char* label; char token; } calc_btn_t;
static const calc_btn_t buttons[] = {
    {0,0,1,"C",   'C'}, {1,0,1,"<-",  8}, {2,0,1,"+/-", '~'}, {3,0,1,"/", '/'},
    {0,1,1,"7",   '7'}, {1,1,1,"8", '8'}, {2,1,1,"9",   '9'}, {3,1,1,"*", '*'},
    {0,2,1,"4",   '4'}, {1,2,1,"5", '5'}, {2,2,1,"6",   '6'}, {3,2,1,"-", '-'},
    {0,3,1,"1",   '1'}, {1,3,1,"2", '2'}, {2,3,1,"3",   '3'}, {3,3,1,"+", '+'},
    {0,4,2,"0",   '0'}, {2,4,2,"=", '='},
};
#define BTN_COUNT (sizeof(buttons)/sizeof(buttons[0]))

#define CALC_MARGIN  12
#define CALC_GAP     8
#define CALC_CELL_W  58
#define CALC_CELL_H  54
#define CALC_GRID_TOP 86

static void btn_rect(const calc_btn_t* b, i32* bx, i32* by, i32* bw, i32* bh) {
    *bx = CALC_MARGIN + b->col * (CALC_CELL_W + CALC_GAP);
    *by = CALC_GRID_TOP + b->row * (CALC_CELL_H + CALC_GAP);
    *bw = CALC_CELL_W * b->colspan + CALC_GAP * (b->colspan - 1);
    *bh = CALC_CELL_H;
}

void app_calc_draw(i32 x, i32 y, i32 w, i32 h) {
    (void)w; (void)h;
    color_t field_bg = RGB(14, 15, 20);
    gfx_rounded_rect(x + CALC_MARGIN, y + CALC_MARGIN, 256, 46, THEME_RADIUS_CTRL, field_bg);
    gfx_rounded_rect_outline(x + CALC_MARGIN, y + CALC_MARGIN, 256, 46, THEME_RADIUS_CTRL, THEME_BORDER);

    int dw = gfx_string_width(display);
    color_t dc = error_state ? THEME_DANGER : THEME_TEXT;
    gfx_string(x + CALC_MARGIN + 256 - 12 - dw, y + CALC_MARGIN + (46 - 16) / 2, display, dc, field_bg, 0);

    if (pending_op && !error_state) {
        char ctx[8] = { pending_op, 0 };
        gfx_string(x + CALC_MARGIN + 6, y + CALC_MARGIN + (46 - 16) / 2, ctx, THEME_TEXT_FAINT, field_bg, 0);
    }

    for (u32 i = 0; i < BTN_COUNT; i++) {
        i32 bx, by, bw, bh;
        btn_rect(&buttons[i], &bx, &by, &bw, &bh);
        int hl = (buttons[i].token == '=');
        ui_button(x + bx, y + by, bw, bh, buttons[i].label, hl);
    }
}

void app_calc_click(i32 rx, i32 ry) {
    for (u32 i = 0; i < BTN_COUNT; i++) {
        i32 bx, by, bw, bh;
        btn_rect(&buttons[i], &bx, &by, &bw, &bh);
        if (ui_point_in(rx, ry, bx, by, bw, bh)) {
            calc_input(buttons[i].token);
            return;
        }
    }
}

void app_calc_key(int key) {
    if ((key >= '0' && key <= '9') || key == '+' || key == '-' || key == '*' || key == '/') {
        calc_input((char)key);
    } else if (key == KEY_ENTER) {
        calc_input('=');
    } else if (key == KEY_BACKSPACE) {
        calc_input(8);
    } else if (key == 'c' || key == 'C') {
        calc_input('C');
    }
}
