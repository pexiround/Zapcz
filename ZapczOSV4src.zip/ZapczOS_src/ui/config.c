#include "config.h"
#include "fat32.h"
#include "theme.h"
#include "mouse.h"
#include "util.h"
#include "desktop.h"
#include "rtc.h"

#define CFG_FILENAME "ZAPCZCFG.DAT"
#define CFG_MAGIC0 'Z'
#define CFG_MAGIC1 'C'
#define CFG_MAGIC2 'F'
#define CFG_MAGIC3 'G'

typedef struct {
    u8 theme_mode;
    u8 mouse_sens_pct;
    u8 installed_mask;
    u8 taskbar_top;
    i32 tz_offset;
} live_cfg_t;

static live_cfg_t g = { THEME_MODE_LIGHT, 100, 0, TASKBAR_BOTTOM, 0 };
static int disk_was_available = 0;

static void save_to_disk(void) {
    if (!fat32_available()) return;
    u8 buf[9];
    buf[0] = CFG_MAGIC0; buf[1] = CFG_MAGIC1; buf[2] = CFG_MAGIC2; buf[3] = CFG_MAGIC3;
    buf[4] = g.theme_mode;
    buf[5] = g.mouse_sens_pct;
    buf[6] = g.installed_mask;
    buf[7] = g.taskbar_top;
    buf[8] = (u8)(g.tz_offset + 12);
    fat32_write_file(CFG_FILENAME, buf, sizeof(buf));
}

void config_init(void) {
    disk_was_available = fat32_available();

    if (disk_was_available) {
        fat_dirent_t ents[32];
        int n = fat32_list_root(ents, 32);
        for (int i = 0; i < n; i++) {
            if (str_eq_ci(ents[i].display_name, CFG_FILENAME)) {
                u8 buf[16];
                int len = fat32_read_file(&ents[i], buf, sizeof(buf));
                if (len >= 7 && buf[0] == CFG_MAGIC0 && buf[1] == CFG_MAGIC1 &&
                    buf[2] == CFG_MAGIC2 && buf[3] == CFG_MAGIC3) {
                    g.theme_mode = buf[4] ? THEME_MODE_LIGHT : THEME_MODE_DARK;
                    g.mouse_sens_pct = buf[5];
                    if (g.mouse_sens_pct < 25 || g.mouse_sens_pct > 200) g.mouse_sens_pct = 100;
                    g.installed_mask = buf[6];
                    if (len >= 8) g.taskbar_top = buf[7] ? TASKBAR_TOP : TASKBAR_BOTTOM;
                    if (len >= 9) {
                        g.tz_offset = (i32)buf[8] - 12;
                        if (g.tz_offset < -12 || g.tz_offset > 14) g.tz_offset = 0;
                    }
                }
                break;
            }
        }
    }

    theme_set_mode(g.theme_mode);
    mouse_set_sensitivity(g.mouse_sens_pct);
    desktop_set_taskbar_position(g.taskbar_top);
}

int config_disk_available(void) { return fat32_persistent(); }

u8 config_get_installed_mask(void) { return g.installed_mask; }
void config_set_installed(u8 bit, int installed) {
    if (installed) g.installed_mask |= bit;
    else g.installed_mask &= (u8)~bit;
    save_to_disk();
}

u8 config_get_theme_mode(void) { return g.theme_mode; }
void config_set_theme_mode(u8 mode) {
    g.theme_mode = (mode == THEME_MODE_LIGHT) ? THEME_MODE_LIGHT : THEME_MODE_DARK;
    theme_set_mode(g.theme_mode);
    desktop_invalidate_bg();
    save_to_disk();
}

u8 config_get_mouse_sens(void) { return g.mouse_sens_pct; }
void config_set_mouse_sens(u8 pct) {
    if (pct < 25) pct = 25;
    if (pct > 200) pct = 200;
    g.mouse_sens_pct = pct;
    mouse_set_sensitivity(pct);
    save_to_disk();
}

u8 config_get_taskbar_top(void) { return g.taskbar_top; }
void config_set_taskbar_top(u8 top) {
    g.taskbar_top = top ? TASKBAR_TOP : TASKBAR_BOTTOM;
    desktop_set_taskbar_position(g.taskbar_top);
    save_to_disk();
}

i32 config_get_tz_offset(void) { return g.tz_offset; }
void config_set_tz_offset(i32 off) {
    if (off < -12) off = -12;
    if (off > 14) off = 14;
    g.tz_offset = off;
    save_to_disk();
}

void config_local_time(rtc_time_t* t) {
    static const int mdays[12] = { 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };
    int h = (int)t->hour + g.tz_offset;
    int day = t->day, mon = t->month, yr = t->year;
    while (h < 0) { h += 24; day--; }
    while (h >= 24) { h -= 24; day++; }
    while (day < 1) {
        mon--; if (mon < 1) { mon = 12; yr--; }
        int md = mdays[mon - 1];
        if (mon == 2 && ((yr % 4 == 0 && yr % 100 != 0) || yr % 400 == 0)) md = 29;
        day += md;
    }
    for (;;) {
        int md = mdays[mon - 1];
        if (mon == 2 && ((yr % 4 == 0 && yr % 100 != 0) || yr % 400 == 0)) md = 29;
        if (day <= md) break;
        day -= md; mon++;
        if (mon > 12) { mon = 1; yr++; }
    }
    t->hour = (u8)h; t->day = (u8)day; t->month = (u8)mon; t->year = (u16)yr;
}
