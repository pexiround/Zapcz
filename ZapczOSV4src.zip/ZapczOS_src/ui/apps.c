#include "battery.h"
#include "apps.h"
#include "graphics.h"
#include "desktop.h"
#include "mouse.h"
#include "fat32.h"
#include "zip.h"
#include "ata.h"
#include "rtc.h"
#include "pit.h"
#include "util.h"
#include "keyboard.h"
#include "logo.h"
#include "theme.h"
#include "config.h"
#include "browser.h"
#include "appstore.h"
#include "settings.h"
#include "calculator.h"
#include "paint.h"
#include "ttt.h"
#include "png.h"
#include "photos.h"
#include "scroll.h"
#include "cube3d.h"
#include "installer.h"
#include "zapcc.h"
#include "accounts.h"
#include "net.h"
#include "icons.h"
#include "wallpaper_bitmaps.h"
#include "http.h"
#include "pkgmgr.h"
#include "wifi.h"

static const int clock_dx[60] = {0,105,208,309,407,500,588,669,743,809,866,914,951,978,995,1000,995,978,951,914,866,809,743,669,588,500,407,309,208,105,0,-105,-208,-309,-407,-500,-588,-669,-743,-809,-866,-914,-951,-978,-995,-1000,-995,-978,-951,-914,-866,-809,-743,-669,-588,-500,-407,-309,-208,-105};
static const int clock_dy[60] = {-1000,-995,-978,-951,-914,-866,-809,-743,-669,-588,-500,-407,-309,-208,-105,0,105,208,309,407,500,588,669,743,809,866,914,951,978,995,1000,995,978,951,914,866,809,743,669,588,500,407,309,208,105,0,-105,-208,-309,-407,-500,-588,-669,-743,-809,-866,-914,-951,-978,-995};

static u32 disk_free_cache = 0;
static int disk_free_known = 0;
static int disk_present = 0;

static void refresh_disk_free(void) {
    disk_present = fat32_available();
    if (disk_present) disk_free_cache = fat32_free_bytes();
    disk_free_known = 1;
}

#define LOGO_PNG_SCALE 6
#define LOGO_PNG_W (LOGO_W * LOGO_PNG_SCALE)
#define LOGO_PNG_H (LOGO_H_ * LOGO_PNG_SCALE)
static u8 logo_png_buf[LOGO_PNG_H][LOGO_PNG_W][3];
static char about_status[64] = "";

static void about_save_logo_png(void) {
    for (int j = 0; j < LOGO_H_; j++) {
        for (int i = 0; i < LOGO_W; i++) {
            u8 v = logo_bitmap[j][i];
            color_t c;
            if (v == 0) c = RGB(255,255,255);
            else if (v == 2) c = RGB(255,255,255);
            else {
                int adj = 0;
                for (int dj = -1; dj <= 1 && !adj; dj++)
                    for (int di = -1; di <= 1; di++) {
                        int nj = j + dj, ni = i + di;
                        if (nj < 0 || nj >= LOGO_H_ || ni < 0 || ni >= LOGO_W) continue;
                        if (logo_bitmap[nj][ni] == 2) { adj = 1; break; }
                    }
                c = adj ? RGB(0,0,0) : RGB(60,140,255);
            }
            for (int py = 0; py < LOGO_PNG_SCALE; py++) {
                for (int px = 0; px < LOGO_PNG_SCALE; px++) {
                    u8* d = logo_png_buf[j * LOGO_PNG_SCALE + py][i * LOGO_PNG_SCALE + px];
                    d[0] = c.r; d[1] = c.g; d[2] = c.b;
                }
            }
        }
    }
    int rc = png_encode_rgb_to_file("LOGO.PNG", &logo_png_buf[0][0][0], LOGO_PNG_W, LOGO_PNG_H);
    if (rc == PNG_OK) str_copy(about_status, "Saved as LOGO.PNG -- open it from Files.", 64);
    else str_copy(about_status, png_error_string(rc), 64);
}



static void app_clock_draw(i32 x, i32 y, i32 w, i32 h) {
    (void)h;
    rtc_time_t t;
    rtc_read(&t); config_local_time(&t);

    i32 cx = x + w / 2, cy = y + 95, r = 65;
    gfx_circle_fill(cx, cy, r + 4, RGB(14,16,22));
    gfx_circle(cx, cy, r, THEME_ACCENT);
    for (int i = 0; i < 12; i++) {
        int idx = i * 5;
        i32 ox = cx + clock_dx[idx] * (r - 8) / 1000;
        i32 oy = cy + clock_dy[idx] * (r - 8) / 1000;
        gfx_circle_fill(ox, oy, 2, THEME_ACCENT);
    }
    int hidx = ((t.hour % 12) * 5 + t.minute / 12) % 60;
    int midx = t.minute % 60;
    int sidx = t.second % 60;
    gfx_line(cx, cy, cx + clock_dx[hidx]*(r-35)/1000, cy + clock_dy[hidx]*(r-35)/1000, RGB(235,238,245));
    gfx_line(cx, cy, cx + clock_dx[midx]*(r-18)/1000, cy + clock_dy[midx]*(r-18)/1000, THEME_TEXT_DIM);
    gfx_line(cx, cy, cx + clock_dx[sidx]*(r-12)/1000, cy + clock_dy[sidx]*(r-12)/1000, THEME_DANGER);
    gfx_circle_fill(cx, cy, 3, THEME_ACCENT);

    char buf[16];
    const char* d = "0123456789";
    int p = 0;
    buf[p++] = d[t.hour/10]; buf[p++] = d[t.hour%10]; buf[p++] = ':';
    buf[p++] = d[t.minute/10]; buf[p++] = d[t.minute%10]; buf[p++] = ':';
    buf[p++] = d[t.second/10]; buf[p++] = d[t.second%10];
    buf[p] = 0;
    gfx_string(x + (w - gfx_string_width(buf))/2, y + h - 56, buf,
               THEME_TEXT, THEME_PANEL, 0);

    char dbuf[16]; int q = 0;
    dbuf[q++] = d[t.day/10]; dbuf[q++] = d[t.day%10]; dbuf[q++] = '/';
    dbuf[q++] = d[t.month/10]; dbuf[q++] = d[t.month%10]; dbuf[q++] = '/';
    u32 yr = t.year;
    dbuf[q++] = d[(yr/1000)%10]; dbuf[q++] = d[(yr/100)%10];
    dbuf[q++] = d[(yr/10)%10]; dbuf[q++] = d[yr%10];
    dbuf[q] = 0;
    gfx_string(x + (w - gfx_string_width(dbuf))/2, y + h - 32, dbuf,
               THEME_TEXT_DIM, THEME_PANEL, 0);
}

#define FILES_MAX 64
static fat_dirent_t files_list[FILES_MAX];
static int files_count = 0;
static int files_selected = -1;
static char files_status[64] = "Press Refresh to load the disk.";
static int new_file_counter = 1;
static int files_sort_mode = 0;

#define FILES_FOCUS_NONE   0
#define FILES_FOCUS_SEARCH 1
#define FILES_FOCUS_RENAME 2
static int files_focus = FILES_FOCUS_NONE;
static char files_filter[13] = "";
static u32 files_filter_len = 0;
static char files_rename_buf[13] = "";
static u32 files_rename_len = 0;

static int matched_idx[FILES_MAX];
static int matched_count = 0;
static i32 files_scroll = 0;

static u32 files_cur_dir = FAT32_ROOT_ID;
static u32 files_stack[16];
static char files_seg[16][13];
static int files_depth = 0;
static int new_dir_counter = 1;
static u32 files_dblclk_tick = 0;
static int files_dblclk_idx = -1;

typedef struct { const char* label; i32 w; } files_btn_t;
static const files_btn_t files_btns[6] = {
    {"New File", 82}, {"New Folder", 98}, {"Rename", 74}, {"Delete", 70}, {"Refresh", 78}, {".znap", 62}
};
static i32 files_btn_x(int i) { i32 bx = 8; for (int k = 0; k < i; k++) bx += files_btns[k].w + 6; return bx; }

static void files_build_path(char* out, int cap) {
    str_copy(out, "/", cap);
    for (int d = 0; d < files_depth; d++) {
        str_cat(out, files_seg[d], cap);
        if (d < files_depth - 1) str_cat(out, "/", cap);
    }
}
static void files_go_up(void) {
    if (files_depth > 0) { files_depth--; files_cur_dir = files_stack[files_depth]; files_selected = -1; files_scroll = 0; }
}
static void files_enter_dir(u32 fid, const char* name) {
    if (files_depth < 16) {
        files_stack[files_depth] = files_cur_dir;
        str_copy(files_seg[files_depth], name, 13);
        files_depth++;
        files_cur_dir = fid; files_selected = -1; files_scroll = 0;
    }
}
static void files_fmt_size(u32 fsz, char* out) {
    if (fsz >= 1024*1024) { u32_to_str(fsz/(1024*1024), out); str_cat(out, " MB", 12); }
    else if (fsz >= 1024) { u32_to_str(fsz/1024, out); str_cat(out, " KB", 12); }
    else { u32_to_str(fsz, out); str_cat(out, " B", 12); }
}
static const char* files_type_label(const char* name) {
    static char t[6];
    u32 n = str_len(name); int dot = -1;
    for (u32 i = 0; i < n; i++) if (name[i] == '.') dot = (int)i;
    if (dot < 0 || (u32)dot == n - 1) return "File";
    int p = 0;
    for (u32 i = (u32)dot + 1; i < n && p < 5; i++) {
        char c = name[i]; if (c >= 'a' && c <= 'z') c = (char)(c - 'a' + 'A'); t[p++] = c;
    }
    t[p] = 0;
    return t;
}
static void files_draw_lock(i32 x, i32 y, color_t c) {
    gfx_rounded_rect_outline(x + 1, y - 3, 6, 5, 2, c);
    gfx_rounded_rect(x, y, 8, 6, 2, c);
}

extern void editor_load_content(const char* name, const u8* data, u32 len);

static int name_has_ext(const char* name, const char* ext) {
    u32 nlen = str_len(name), elen = str_len(ext);
    if (nlen < elen + 1) return 0;
    if (name[nlen - elen - 1] != '.') return 0;
    return str_eq_ci(name + (nlen - elen), ext);
}

static char lower_ascii(char c) { return (c >= 'A' && c <= 'Z') ? (char)(c - 'A' + 'a') : c; }

static int name_contains_ci(const char* name, const char* needle) {
    if (!needle[0]) return 1;
    u32 nlen = str_len(name), klen = str_len(needle);
    if (klen > nlen) return 0;
    for (u32 i = 0; i + klen <= nlen; i++) {
        u32 j = 0;
        for (; j < klen; j++) if (lower_ascii(name[i+j]) != lower_ascii(needle[j])) break;
        if (j == klen) return 1;
    }
    return 0;
}

static void files_refresh(void);
static void files_enter_dir(u32 dir_id, const char* name);

static void znap_make_plain_name(const char* src, char* out) {
    int dot = -1;
    for (int i = 0; src[i]; i++) if (src[i] == '.') dot = i;
    int j = 0;
    for (int i = 0; src[i] && j < 8; i++) {
        if (dot >= 0 && i >= dot) break;
        char c = src[i];
        if (c >= 'a' && c <= 'z') c = (char)(c - 'a' + 'A');
        if ((c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9')) out[j++] = c;
    }
    if (j == 0) { out[j++] = 'F'; out[j++] = 'I'; out[j++] = 'L'; out[j++] = 'E'; }
    int k = 0;
    if (dot >= 0) {
        out[j++] = '.';
        for (int i = dot + 1; src[i] && k < 3; i++) {
            char c = src[i];
            if (c >= 'a' && c <= 'z') c = (char)(c - 'a' + 'A');
            if ((c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9')) { out[j++] = c; k++; }
        }
    }
    out[j] = 0;
}

static u8 zip_read_buf[4 * 1024 * 1024];
static u8 zip_out_buf[256 * 1024];

int files_extract_zip(const fat_dirent_t* ent) {
    int n = fat32_read_file(ent, zip_read_buf, sizeof(zip_read_buf));
    if (n <= 0) { str_copy(files_status, "Zip too big or unreadable.", 64); return 0; }

    static zip_entry_t entries[64];
    int cnt = zip_list(zip_read_buf, (u32)n, entries, 64);
    if (cnt <= 0) { str_copy(files_status, "Not a readable zip archive.", 64); return 0; }

    char folder[13];
    znap_make_plain_name(ent->display_name, folder);
    int fid = fat32_mkdir_id(files_cur_dir, folder, 0);
    if (fid < 0) { str_copy(files_status, "Could not create folder for zip.", 64); return 0; }

    int written = 0;
    for (int i = 0; i < cnt; i++) {
        if (entries[i].is_dir || entries[i].size == 0) continue;
        if (entries[i].size > sizeof(zip_out_buf)) continue;
        u32 olen = 0;
        if (!zip_extract_entry(zip_read_buf, (u32)n, entries[i].name,
                               zip_out_buf, sizeof(zip_out_buf), &olen)) continue;
        const char* base = entries[i].name;
        for (const char* q = entries[i].name; *q; q++) if (*q == '/') base = q + 1;
        char fname[13];
        znap_make_plain_name(base, fname);
        if (fat32_write_file_in((u32)fid, fname, zip_out_buf, olen)) written++;
    }

    char nb[12]; u32_to_str((u32)written, nb);
    str_copy(files_status, "Extracted ", 64); str_cat(files_status, nb, 64);
    str_cat(files_status, " files", 64);
    files_enter_dir((u32)fid, folder);
    files_refresh();
    return 1;
}

void files_open_entry(const fat_dirent_t* ent) {
    if (name_has_ext(ent->display_name, "ZIP")) {
        files_extract_zip(ent);
    } else if (name_has_ext(ent->display_name, "PNG")) {
        photos_open_file(ent->display_name);
    } else {
        static u8 tmp[8192];
        int n = fat32_read_file(ent, tmp, sizeof(tmp) - 1);
        if (n < 0) n = 0;
        tmp[n] = 0;
        editor_load_content(ent->display_name, tmp, (u32)n);
        desktop_open_app(APP_EDITOR);
    }
}

static int name_cmp_ci(const char* a, const char* b) {
    while (*a && *b) {
        char ca = lower_ascii(*a), cb = lower_ascii(*b);
        if (ca != cb) return (ca < cb) ? -1 : 1;
        a++; b++;
    }
    if (*a == *b) return 0;
    return *a ? 1 : -1;
}

static void files_sort(void) {
    for (int i = 1; i < files_count; i++) {
        fat_dirent_t key = files_list[i];
        int j = i - 1;
        while (j >= 0) {
            int swap;
            if (files_list[j].is_dir != key.is_dir) swap = key.is_dir ? 1 : 0;
            else if (files_sort_mode == 1) swap = files_list[j].size < key.size;
            else swap = name_cmp_ci(files_list[j].display_name, key.display_name) > 0;
            if (!swap) break;
            files_list[j+1] = files_list[j];
            j--;
        }
        files_list[j+1] = key;
    }
}

static void files_recompute_filter(void) {
    matched_count = 0;
    for (int i = 0; i < files_count && matched_count < FILES_MAX; i++) {
        if (name_contains_ci(files_list[i].display_name, files_filter)) {
            matched_idx[matched_count++] = i;
        }
    }
}

static void files_refresh(void) {
    files_count = fat32_list_dir(files_cur_dir, files_list, FILES_MAX);
    files_sort();
    str_copy(files_status, fat32_persistent() ? "Loaded." : "Session storage.", 64);
    if (files_selected >= files_count) files_selected = -1;
    files_recompute_filter();
}

#define FILES_SEARCH_Y 50
#define FILES_LIST_Y 82
#define FILES_ROW_H 20
#define FILES_BTN_Y_OFF(h) ((h) - 36)
#define FILES_ICON_SZ 14

static void file_row_icon(i32 x, i32 y, const char* name) {
    filetype_icon_draw(x, y, FILES_ICON_SZ, name);
}

#define ZNAP_MODAL_NONE   0
#define ZNAP_MODAL_CREATE 1
#define ZNAP_MODAL_UNLOCK 2

static int  znap_modal = ZNAP_MODAL_NONE;
static char znap_name[13] = "";
static u32  znap_name_len = 0;
static char znap_pw[24] = "";
static u32  znap_pw_len = 0;
static int  znap_want_pw = 1;
static int  znap_self_destruct = 0;
static int  znap_max_fails = 3;
static int  znap_field = 0;
static char znap_msg[52] = "";
static u32  znap_unlock_dir = 0;
static char znap_unlock_name[13] = "";
static u32 znap_hash(const char* s) {
    u32 h = 2166136261u;
    for (u32 i = 0; s[i]; i++) { h ^= (u8)s[i]; h *= 16777619u; }
    return h ? h : 1u;
}
static int znap_is_znap_dirent(const fat_dirent_t* e) {
    return e->is_dir && name_has_ext(e->display_name, "ZNP");
}

#define ZNAP_CFG_LEN 14
static const u8 znap_xor[8] = { 0x5A, 0x4E, 0x41, 0x50, 0xC3, 0x9E, 0x71, 0x2D };

static void znap_pack_cfg(u8* buf, int has_pw, u32 pwh, int sd, int mf, int fc) {
    buf[0] = 'Z'; buf[1] = 'N'; buf[2] = 'A'; buf[3] = 'P'; buf[4] = 1;
    buf[5] = (u8)has_pw;
    buf[6] = (u8)pwh; buf[7] = (u8)(pwh >> 8); buf[8] = (u8)(pwh >> 16); buf[9] = (u8)(pwh >> 24);
    buf[10] = (u8)sd; buf[11] = (u8)mf; buf[12] = (u8)fc; buf[13] = 0;
    for (int i = 0; i < ZNAP_CFG_LEN; i++) buf[i] ^= znap_xor[i & 7];
}
static int znap_unpack_cfg(const u8* raw, u32 len, int* has_pw, u32* pwh, int* sd, int* mf, int* fc) {
    if (len < ZNAP_CFG_LEN) return 0;
    u8 b[ZNAP_CFG_LEN];
    for (int i = 0; i < ZNAP_CFG_LEN; i++) b[i] = raw[i] ^ znap_xor[i & 7];
    if (b[0] != 'Z' || b[1] != 'N' || b[2] != 'A' || b[3] != 'P') return 0;
    *has_pw = b[5];
    *pwh = (u32)b[6] | ((u32)b[7] << 8) | ((u32)b[8] << 16) | ((u32)b[9] << 24);
    *sd = b[10]; *mf = b[11]; *fc = b[12];
    return 1;
}
static int znap_read_cfg(u32 folder_dir, int* has_pw, u32* pwh, int* sd, int* mf, int* fc) {
    fat_dirent_t ents[48];
    int n = fat32_list_dir(folder_dir, ents, 48);
    for (int i = 0; i < n; i++) {
        if (!ents[i].is_dir && str_eq_ci(ents[i].display_name, "ZNAP.CFG")) {
            u8 raw[64];
            int r = fat32_read_file(&ents[i], raw, sizeof(raw));
            if (r > 0) return znap_unpack_cfg(raw, (u32)r, has_pw, pwh, sd, mf, fc);
        }
    }
    return 0;
}
static int znap_write_cfg(u32 folder_dir, int has_pw, u32 pwh, int sd, int mf, int fc) {
    u8 buf[ZNAP_CFG_LEN];
    znap_pack_cfg(buf, has_pw, pwh, sd, mf, fc);
    return fat32_write_file_in(folder_dir, "ZNAP.CFG", buf, ZNAP_CFG_LEN);
}
static void znap_make_fatname(const char* src, char* out) {
    int j = 0;
    for (int i = 0; src[i] && src[i] != '.' && j < 8; i++) {
        char c = src[i];
        if (c >= 'a' && c <= 'z') c = (char)(c - 'a' + 'A');
        if (c == ' ') continue;
        out[j++] = c;
    }
    if (j == 0) { out[j++] = 'Z'; out[j++] = 'N'; out[j++] = 'A'; out[j++] = 'P'; }
    out[j++] = '.'; out[j++] = 'Z'; out[j++] = 'N'; out[j++] = 'P'; out[j] = 0;
}

extern void desktop_refresh_files(void);

static void znap_open_create(void) {
    znap_modal = ZNAP_MODAL_CREATE;
    znap_name[0] = 0; znap_name_len = 0;
    znap_pw[0] = 0; znap_pw_len = 0;
    znap_want_pw = 1; znap_self_destruct = 0; znap_max_fails = 3;
    znap_field = 0; znap_msg[0] = 0;
}
static void znap_do_create(void) {
    if (znap_name_len == 0) { str_copy(znap_msg, "Enter a folder name.", 52); return; }
    if (znap_want_pw && znap_pw_len == 0) { str_copy(znap_msg, "Set a password or turn it off.", 52); return; }
    char fname[13];
    znap_make_fatname(znap_name, fname);
    int fid = fat32_mkdir_id(files_cur_dir, fname, 0);
    if (fid < 0) { str_copy(znap_msg, "Could not create folder.", 52); return; }
    u32 pwh = (znap_want_pw && znap_pw_len > 0) ? znap_hash(znap_pw) : 0;
    int has_pw = (pwh != 0);
    int mf = znap_max_fails; if (mf < 1) mf = 1; if (mf > 99) mf = 99;
    znap_write_cfg((u32)fid, has_pw, pwh, znap_self_destruct ? 1 : 0, mf, 0);
    znap_modal = ZNAP_MODAL_NONE;
    str_copy(files_status, "Created .znap folder.", 64);
    files_refresh(); desktop_refresh_files();
}
static void znap_do_unlock(void) {
    int has_pw = 0, sd = 0, mf = 3, fc = 0; u32 pwh = 0;
    int have = znap_read_cfg(znap_unlock_dir, &has_pw, &pwh, &sd, &mf, &fc);
    if (!have || !has_pw || znap_hash(znap_pw) == pwh) {
        if (have && fc != 0) znap_write_cfg(znap_unlock_dir, has_pw, pwh, sd, mf, 0);
        znap_modal = ZNAP_MODAL_NONE;
        files_enter_dir(znap_unlock_dir, znap_unlock_name);
        files_refresh();
        return;
    }
    fc++;
    if (sd && fc >= mf) {
        fat32_delete_in(files_cur_dir, znap_unlock_name);
        znap_modal = ZNAP_MODAL_NONE;
        znap_pw[0] = 0; znap_pw_len = 0;
        str_copy(files_status, "Wrong password - folder self-destructed.", 64);
        files_selected = -1;
        files_refresh(); desktop_refresh_files();
        return;
    }
    znap_write_cfg(znap_unlock_dir, has_pw, pwh, sd, mf, fc);
    znap_pw[0] = 0; znap_pw_len = 0;
    if (sd) {
        int left = mf - fc;
        char nb[8]; u32_to_str((u32)left, nb);
        str_copy(znap_msg, "Wrong. ", 52); str_cat(znap_msg, nb, 52);
        str_cat(znap_msg, " tr left before wipe", 52);
    } else {
        str_copy(znap_msg, "Wrong password.", 52);
    }
}
static int znap_gate_enter(fat_dirent_t* e) {
    if (!znap_is_znap_dirent(e)) return 0;
    int has_pw = 0, sd = 0, mf = 3, fc = 0; u32 pwh = 0;
    if (!znap_read_cfg(e->first_cluster, &has_pw, &pwh, &sd, &mf, &fc) || !has_pw)
        return 0;
    znap_modal = ZNAP_MODAL_UNLOCK;
    znap_unlock_dir = e->first_cluster;
    str_copy(znap_unlock_name, e->display_name, 13);
    znap_pw[0] = 0; znap_pw_len = 0; znap_field = 0; znap_msg[0] = 0;
    return 1;
}

static void znap_toggle_draw(i32 x, i32 y, int on, const char* label) {
    gfx_rounded_rect(x, y, 18, 18, 3, on ? THEME_ACCENT : THEME_INPUT);
    gfx_rounded_rect_outline(x, y, 18, 18, 3, on ? THEME_ACCENT : THEME_BORDER);
    if (on) {
        gfx_line(x + 4, y + 9, x + 8, y + 13, THEME_ACCENT_TEXT);
        gfx_line(x + 8, y + 13, x + 14, y + 4, THEME_ACCENT_TEXT);
    }
    gfx_string(x + 26, y + 2, label, THEME_TEXT, THEME_WINDOW, 0);
}
static void znap_field_draw(i32 x, i32 y, i32 fw, const char* text, int active, int mask) {
    gfx_rounded_rect(x, y, fw, 24, THEME_RADIUS_CTRL, THEME_INPUT);
    gfx_rounded_rect_outline(x, y, fw, 24, THEME_RADIUS_CTRL, active ? THEME_ACCENT : THEME_BORDER);
    char shown[28]; int k = 0;
    for (int i = 0; text[i] && k < 24; i++) shown[k++] = mask ? '*' : text[i];
    shown[k] = 0;
    if (active && (ticks_get() / 30) % 2 == 0 && k < 23) { shown[k++] = '_'; shown[k] = 0; }
    gfx_string(x + 8, y + 4, shown, THEME_TEXT, THEME_INPUT, 0);
}

static void znap_modal_geom(i32 wx, i32 wy, i32 ww, i32 wh, i32* px, i32* py, i32* pw, i32* ph) {
    *pw = 330;
    *ph = (znap_modal == ZNAP_MODAL_CREATE) ? 250 : 172;
    *px = wx + (ww - *pw) / 2;
    *py = wy + (wh - *ph) / 2;
}
static void znap_modal_draw(i32 wx, i32 wy, i32 ww, i32 wh) {
    if (znap_modal == ZNAP_MODAL_NONE) return;
    i32 px, py, pw, ph; znap_modal_geom(wx, wy, ww, wh, &px, &py, &pw, &ph);
    gfx_rect(px + 4, py + 5, pw, ph, RGB(0, 0, 0));
    gfx_rounded_rect(px, py, pw, ph, 6, THEME_PANEL);
    gfx_rounded_rect_outline(px, py, pw, ph, 6, THEME_ACCENT);
    gfx_rect(px, py, pw, 30, THEME_PANEL_ALT);
    znap_folder_icon_draw(px + 8, py + 4, 22);
    if (znap_modal == ZNAP_MODAL_CREATE) {
        gfx_string(px + 36, py + 9, "New .znap encrypted folder", THEME_TEXT, THEME_PANEL_ALT, 0);
        i32 cx = px + 16, cy = py + 44;
        gfx_string(cx, cy + 4, "Name", THEME_TEXT_DIM, THEME_PANEL, 0);
        znap_field_draw(cx + 60, cy, pw - 92, znap_name, znap_field == 0, 0);
        cy += 34;
        znap_toggle_draw(cx, cy, znap_want_pw, "Require a password to open");
        cy += 28;
        if (znap_want_pw) {
            gfx_string(cx, cy + 4, "Pass", THEME_TEXT_DIM, THEME_PANEL, 0);
            znap_field_draw(cx + 60, cy, pw - 92, znap_pw, znap_field == 1, 1);
        }
        cy += 34;
        znap_toggle_draw(cx, cy, znap_self_destruct, "Self-destruct after failed tries");
        cy += 28;
        if (znap_self_destruct) {
            gfx_string(cx, cy + 4, "Attempts allowed:", THEME_TEXT_DIM, THEME_PANEL, 0);
            i32 stx = cx + 150;
            ui_button(stx, cy - 2, 24, 24, "-", 0);
            char nb[8]; u32_to_str((u32)znap_max_fails, nb);
            gfx_string(stx + 34, cy + 4, nb, THEME_TEXT, THEME_PANEL, 0);
            ui_button(stx + 60, cy - 2, 24, 24, "+", 0);
        }
        if (znap_msg[0]) gfx_string(cx, py + ph - 62, znap_msg, THEME_WARNING, THEME_PANEL, 0);
        ui_button(px + 16, py + ph - 34, 120, 26, "Create", 0);
        ui_button(px + pw - 116, py + ph - 34, 100, 26, "Cancel", 0);
    } else {
        gfx_string(px + 36, py + 9, "Locked .znap folder", THEME_TEXT, THEME_PANEL_ALT, 0);
        i32 cx = px + 16, cy = py + 42;
        char ln[40]; str_copy(ln, znap_unlock_name, 40);
        gfx_string(cx, cy, ln, THEME_TEXT_DIM, THEME_PANEL, 0);
        cy += 22;
        gfx_string(cx, cy + 4, "Pass", THEME_TEXT_DIM, THEME_PANEL, 0);
        znap_field_draw(cx + 60, cy, pw - 92, znap_pw, 1, 1);
        if (znap_msg[0]) gfx_string(cx, cy + 32, znap_msg, THEME_WARNING, THEME_PANEL, 0);
        ui_button(px + 16, py + ph - 34, 120, 26, "Unlock", 0);
        ui_button(px + pw - 116, py + ph - 34, 100, 26, "Cancel", 0);
    }
}
static int znap_modal_click(i32 wx, i32 wy, i32 ww, i32 wh, i32 mx, i32 my) {
    if (znap_modal == ZNAP_MODAL_NONE) return 0;
    i32 px, py, pw, ph; znap_modal_geom(wx, wy, ww, wh, &px, &py, &pw, &ph);
    if (znap_modal == ZNAP_MODAL_CREATE) {
        i32 cx = px + 16, cy = py + 44;
        if (ui_point_in(mx, my, cx + 60, cy, pw - 92, 24)) { znap_field = 0; return 1; }
        cy += 34;
        if (ui_point_in(mx, my, cx, cy, 240, 18)) { znap_want_pw = !znap_want_pw; return 1; }
        cy += 28;
        if (znap_want_pw && ui_point_in(mx, my, cx + 60, cy, pw - 92, 24)) { znap_field = 1; return 1; }
        cy += 34;
        if (ui_point_in(mx, my, cx, cy, 260, 18)) { znap_self_destruct = !znap_self_destruct; return 1; }
        cy += 28;
        if (znap_self_destruct) {
            i32 stx = cx + 150;
            if (ui_point_in(mx, my, stx, cy - 2, 24, 24)) { if (znap_max_fails > 1) znap_max_fails--; return 1; }
            if (ui_point_in(mx, my, stx + 60, cy - 2, 24, 24)) { if (znap_max_fails < 99) znap_max_fails++; return 1; }
        }
        if (ui_point_in(mx, my, px + 16, py + ph - 34, 120, 26)) { znap_do_create(); return 1; }
        if (ui_point_in(mx, my, px + pw - 116, py + ph - 34, 100, 26)) { znap_modal = ZNAP_MODAL_NONE; return 1; }
        return 1;
    } else {
        if (ui_point_in(mx, my, px + 16, py + ph - 34, 120, 26)) { znap_do_unlock(); return 1; }
        if (ui_point_in(mx, my, px + pw - 116, py + ph - 34, 100, 26)) { znap_modal = ZNAP_MODAL_NONE; return 1; }
        return 1;
    }
}
static int znap_modal_key(int key) {
    if (znap_modal == ZNAP_MODAL_NONE) return 0;
    char* buf; u32* len; u32 cap;
    if (znap_modal == ZNAP_MODAL_CREATE && znap_field == 0) { buf = znap_name; len = &znap_name_len; cap = sizeof(znap_name); }
    else { buf = znap_pw; len = &znap_pw_len; cap = sizeof(znap_pw); }
    if (key == KEY_ESC) { znap_modal = ZNAP_MODAL_NONE; return 1; }
    if (key == KEY_ENTER) {
        if (znap_modal == ZNAP_MODAL_CREATE) znap_do_create(); else znap_do_unlock();
        return 1;
    }
    if (key == KEY_TAB && znap_modal == ZNAP_MODAL_CREATE) { znap_field = (znap_field == 0 && znap_want_pw) ? 1 : 0; return 1; }
    if (key == KEY_BACKSPACE) { if (*len > 0) buf[--(*len)] = 0; return 1; }
    if (kbd_is_printable(key)) {
        if (*len < cap - 1) { buf[(*len)++] = (char)key; buf[*len] = 0; }
        return 1;
    }
    return 1;
}

static int files_drag_idx = -1;
static int files_drag_active = 0;
static char files_drag_name[16] = "";
static u8 files_move_buf[512 * 1024];

static int files_move_into(fat_dirent_t* src, u32 dst_dir) {
    if (!src || src->is_dir) return 0;
    if (src->size > sizeof(files_move_buf)) return 0;
    int n = fat32_read_file(src, files_move_buf, sizeof(files_move_buf));
    if (n < 0) return 0;
    char nm[16];
    str_copy(nm, src->display_name, 16);
    if (!fat32_write_file_in(dst_dir, nm, files_move_buf, (u32)n)) return 0;
    fat32_delete_in(files_cur_dir, nm);
    return 1;
}

static int files_row_index_at(i32 w, i32 h, i32 rx, i32 ry) {
    i32 status_h = 22;
    i32 list_top = 74;
    i32 list_h = h - 74 - status_h;
    i32 row_h = 22;
    (void)w;
    if (ry < list_top || ry > list_top + list_h) return -1;
    i32 rel = ry - list_top + files_scroll;
    if (rel < 0) return -1;
    int idx = rel / row_h;
    if (idx < 0 || idx >= files_count) return -1;
    return idx;
}

static void app_files_draw(i32 x, i32 y, i32 w, i32 h) {
    i32 status_h = 22;
    i32 nav_y = y + 8, nav_h = 24;
    i32 tool_y = y + 40, tool_h = 26;
    i32 list_top = y + 74;
    i32 list_h = h - 74 - status_h;
    i32 row_h = 22;

    gfx_rect(x, y, w, h, THEME_WINDOW);

    ui_button(x + 8, nav_y, 38, nav_h, "Up", 0);
    i32 path_x = x + 52, path_w = w - 52 - 140;
    gfx_rounded_rect(path_x, nav_y, path_w, nav_h, THEME_RADIUS_CTRL, THEME_INPUT);
    gfx_rounded_rect_outline(path_x, nav_y, path_w, nav_h, THEME_RADIUS_CTRL, THEME_BORDER);
    char path[64]; files_build_path(path, sizeof(path));
    gfx_string(path_x + 8, nav_y + 4, path, THEME_TEXT, THEME_INPUT, 0);

    int searching = (files_focus == FILES_FOCUS_SEARCH);
    i32 srx = x + w - 132, srw = 124;
    gfx_rounded_rect(srx, nav_y, srw, nav_h, THEME_RADIUS_CTRL, THEME_INPUT);
    gfx_rounded_rect_outline(srx, nav_y, srw, nav_h, THEME_RADIUS_CTRL, searching ? THEME_ACCENT : THEME_BORDER);
    char sbuf[24]; str_copy(sbuf, files_filter[0] ? files_filter : "Search", 24);
    if (searching && (ticks_get()/30)%2==0 && str_len(sbuf) < 20) str_cat(sbuf, "_", 24);
    gfx_string(srx + 8, nav_y + 4, sbuf, (files_filter[0]||searching) ? THEME_TEXT : THEME_TEXT_FAINT, THEME_INPUT, 0);

    for (int i = 0; i < 6; i++)
        ui_button(x + files_btn_x(i), tool_y, files_btns[i].w, tool_h, files_btns[i].label, 0);
    ui_button(x + w - 78, tool_y, 70, tool_h, files_sort_mode ? "By Size" : "By Name", 0);

    gfx_string(x + 34, list_top - 16, "Name", THEME_TEXT_FAINT, THEME_WINDOW, 0);
    gfx_string(x + w - 150, list_top - 16, "Type", THEME_TEXT_FAINT, THEME_WINDOW, 0);
    gfx_string(x + w - 78, list_top - 16, "Size", THEME_TEXT_FAINT, THEME_WINDOW, 0);
    gfx_hline(x + 8, list_top - 3, w - 16, THEME_SEP);

    i32 content_h_all = matched_count * row_h;
    files_scroll = scroll_clamp(files_scroll, content_h_all, list_h);

    clip_t clip = { x, list_top, x + w, list_top + list_h };
    gfx_set_clip(clip);
    for (int i = 0; i < matched_count; i++) {
        i32 ry = list_top + i * row_h - files_scroll;
        if (ry + row_h < list_top || ry > list_top + list_h) continue;
        int fi = matched_idx[i];
        fat_dirent_t* e = &files_list[fi];
        int sel = (fi == files_selected);
        int hot = ui_point_in(mouse_x(), mouse_y(), x + 8, ry, w - 30, row_h);
        color_t rbg = sel ? THEME_ACCENT : (hot ? THEME_PANEL_ALT : THEME_WINDOW);
        if (sel || hot) gfx_rounded_rect(x + 8, ry, w - 30, row_h, 4, rbg);
        color_t tc = sel ? THEME_ACCENT_TEXT : THEME_TEXT;

        if (znap_is_znap_dirent(e)) znap_folder_icon_draw(x + 12, ry + 3, 16);
        else if (e->is_dir) folder_icon_draw(x + 12, ry + 3, 16);
        else filetype_icon_draw(x + 12, ry + 3, 16, e->display_name);

        if (sel && files_focus == FILES_FOCUS_RENAME) {
            char rb[20]; str_copy(rb, files_rename_buf, 20);
            if ((ticks_get()/30)%2==0 && str_len(rb) < 16) str_cat(rb, "_", 20);
            gfx_string(x + 34, ry + 3, rb, tc, rbg, 0);
        } else {
            gfx_string(x + 34, ry + 3, e->display_name, tc, rbg, 0);
        }

        if (e->read_only) files_draw_lock(x + w - 166, ry + 6, sel ? THEME_ACCENT_TEXT : THEME_TEXT_FAINT);
        const char* ty = e->is_dir ? "Folder" : files_type_label(e->display_name);
        gfx_string(x + w - 150, ry + 3, ty, sel ? THEME_ACCENT_TEXT : THEME_TEXT_DIM, rbg, 0);
        if (!e->is_dir) {
            char sz[12]; files_fmt_size(e->size, sz);
            gfx_string(x + w - 78, ry + 3, sz, sel ? THEME_ACCENT_TEXT : THEME_TEXT_DIM, rbg, 0);
        }
    }
    gfx_clear_clip();
    scroll_draw_bar(x + w - 14, list_top, list_h, files_scroll, content_h_all, list_h, THEME_PANEL_ALT, THEME_BORDER);

    if (matched_count == 0)
        gfx_string(x + 20, list_top + 16, files_count > 0 ? "No items match." : "Empty folder.",
                   THEME_TEXT_FAINT, THEME_WINDOW, 0);

    i32 sby = y + h - status_h;
    gfx_hline(x, sby, w, THEME_SEP);
    char stat[80];
    if (files_selected >= 0 && files_selected < files_count) {
        fat_dirent_t* e = &files_list[files_selected];
        str_copy(stat, e->display_name, 40);
        if (e->read_only) str_cat(stat, "  (read-only)", 80);
        else if (e->is_dir) str_cat(stat, "  (folder)", 80);
        else { str_cat(stat, "  ", 80); char sz[12]; files_fmt_size(e->size, sz); str_cat(stat, sz, 80); }
    } else {
        char cb[12]; u32_to_str((u32)matched_count, cb);
        str_copy(stat, cb, 80); str_cat(stat, " item(s)", 80);
    }
    gfx_string(x + 8, sby + 3, stat, THEME_TEXT_DIM, THEME_WINDOW, 0);
    if (fat32_dir_readonly(files_cur_dir))
        gfx_string(x + w - 168, sby + 3, "System - read-only", THEME_WARNING, THEME_WINDOW, 0);
    else
        gfx_string(x + w - 168, sby + 3, files_status, THEME_TEXT_FAINT, THEME_WINDOW, 0);

    if (files_drag_idx >= 0 && mouse_left()) {
        i32 mrx = mouse_x() - x, mry = mouse_y() - y;
        if (!files_drag_active) {
            files_drag_active = 1;
        }
        int over = files_row_index_at(w, h, mrx, mry);
        if (over >= 0 && over < files_count && files_list[over].is_dir && over != files_drag_idx) {
            i32 list_top = 74, row_h = 22;
            i32 hy = y + list_top + over * row_h - files_scroll;
            gfx_rounded_rect_outline(x + 8, hy, w - 30, row_h, 4, THEME_ACCENT);
        }
        i32 gw = gfx_string_width(files_drag_name) + 16;
        gfx_rounded_rect(mouse_x() + 12, mouse_y() + 8, gw, 20, 4, THEME_PANEL_ALT);
        gfx_rounded_rect_outline(mouse_x() + 12, mouse_y() + 8, gw, 20, 4, THEME_ACCENT);
        gfx_string(mouse_x() + 20, mouse_y() + 12, files_drag_name, THEME_TEXT, THEME_PANEL_ALT, 0);
    }

    if (files_drag_idx >= 0 && !mouse_left()) {
        if (files_drag_active) {
            i32 mrx = mouse_x() - x, mry = mouse_y() - y;
            int outside = (mrx < 0 || mry < -28 || mrx > w || mry > h);
            int over = files_row_index_at(w, h, mrx, mry);
            if (outside) {
                if (files_cur_dir == FAT32_ROOT_ID) {
                    str_copy(files_status, "Already on the desktop.", 64);
                } else if (files_move_into(&files_list[files_drag_idx], FAT32_ROOT_ID)) {
                    str_copy(files_status, "Moved to desktop.", 64);
                    files_selected = -1;
                    files_refresh();
                    desktop_refresh_files();
                } else {
                    str_copy(files_status, "Could not move to desktop.", 64);
                }
            } else if (over >= 0 && over < files_count && files_list[over].is_dir && over != files_drag_idx) {
                u32 dst = files_list[over].first_cluster;
                if (fat32_dir_readonly(dst) || fat32_dir_readonly(files_cur_dir)) {
                    str_copy(files_status, "Read-only - cannot move.", 64);
                } else if (files_move_into(&files_list[files_drag_idx], dst)) {
                    str_copy(files_status, "Moved into folder.", 64);
                    files_selected = -1;
                    files_refresh();
                    desktop_refresh_files();
                } else {
                    str_copy(files_status, "Move failed (folder or too big).", 64);
                }
            }
        }
        files_drag_idx = -1;
        files_drag_active = 0;
    }

    znap_modal_draw(x, y, w, h);
}

static void files_begin_rename(void) {
    if (files_selected < 0 || files_selected >= files_count) {
        str_copy(files_status, "Select an item first.", 64);
        return;
    }
    if (files_list[files_selected].read_only) {
        str_copy(files_status, "Read-only, cannot rename.", 64);
        return;
    }
    files_focus = FILES_FOCUS_RENAME;
    str_copy(files_rename_buf, files_list[files_selected].display_name, 13);
    files_rename_len = str_len(files_rename_buf);
}

static void files_commit_rename(void) {
    if (files_selected < 0 || files_selected >= files_count) { files_focus = FILES_FOCUS_NONE; return; }
    if (files_rename_len == 0 || str_eq_ci(files_rename_buf, files_list[files_selected].display_name)) {
        files_focus = FILES_FOCUS_NONE;
        return;
    }
    if (fat32_rename_in(files_cur_dir, files_list[files_selected].display_name, files_rename_buf)) {
        str_copy(files_status, "Renamed.", 64);
        files_focus = FILES_FOCUS_NONE;
        files_refresh();
        desktop_refresh_files();
    } else {
        str_copy(files_status, "Rename failed.", 64);
    }
}

static void app_files_click(i32 rx, i32 ry) {
    i32 w = windows[APP_FILES].w, h = windows[APP_FILES].h;
    if (znap_modal_click(0, 0, w, h, rx, ry)) return;
    i32 status_h = 22;
    i32 nav_y = 8, nav_h = 24;
    i32 tool_y = 40, tool_h = 26;
    i32 list_top = 74;
    i32 list_h = h - 74 - status_h;
    i32 row_h = 22;

    if (ui_point_in(rx, ry, 8, nav_y, 38, nav_h)) {
        if (files_focus == FILES_FOCUS_RENAME) files_commit_rename();
        files_focus = FILES_FOCUS_NONE;
        files_go_up(); files_refresh();
        return;
    }
    if (ui_point_in(rx, ry, w - 132, nav_y, 124, nav_h)) {
        if (files_focus == FILES_FOCUS_RENAME) files_commit_rename();
        files_focus = FILES_FOCUS_SEARCH;
        return;
    }
    if (ui_point_in(rx, ry, w - 78, tool_y, 70, tool_h)) {
        files_sort_mode = !files_sort_mode; files_sort(); files_recompute_filter();
        return;
    }
    for (int i = 0; i < 6; i++) {
        if (!ui_point_in(rx, ry, files_btn_x(i), tool_y, files_btns[i].w, tool_h)) continue;
        if (files_focus == FILES_FOCUS_RENAME && i != 2) files_commit_rename();
        files_focus = FILES_FOCUS_NONE;
        int ro = fat32_dir_readonly(files_cur_dir);
        if (i == 0) {
            if (ro) { str_copy(files_status, "Read-only folder.", 64); return; }
            char name[16] = "UNTITLED"; char num[8]; u32_to_str((u32)new_file_counter++, num);
            str_cat(name, num, 16); str_cat(name, ".TXT", 16);
            if (fat32_write_file_in(files_cur_dir, name, (const u8*)"", 0)) {
                str_copy(files_status, "Created file.", 64); files_refresh(); refresh_disk_free(); desktop_refresh_files();
            } else str_copy(files_status, "Could not create.", 64);
        } else if (i == 1) {
            if (ro) { str_copy(files_status, "Read-only folder.", 64); return; }
            char name[13] = "FOLDER"; char num[8]; u32_to_str((u32)new_dir_counter++, num);
            str_cat(name, num, 13);
            if (fat32_mkdir(files_cur_dir, name)) {
                str_copy(files_status, "Created folder.", 64); files_refresh(); desktop_refresh_files();
            } else str_copy(files_status, "Could not create folder.", 64);
        } else if (i == 2) {
            files_begin_rename();
        } else if (i == 3) {
            if (files_selected >= 0 && files_selected < files_count) {
                fat_dirent_t* e = &files_list[files_selected];
                if (e->read_only) { str_copy(files_status, "Read-only, cannot delete.", 64); return; }
                fat32_delete_in(files_cur_dir, e->display_name);
                str_copy(files_status, "Deleted.", 64); files_selected = -1;
                files_refresh(); refresh_disk_free(); desktop_refresh_files();
            } else str_copy(files_status, "Select an item first.", 64);
        } else if (i == 4) {
            files_refresh(); refresh_disk_free();
        } else if (i == 5) {
            if (ro) { str_copy(files_status, "Read-only folder.", 64); return; }
            znap_open_create();
        }
        return;
    }
    if (rx >= 8 && rx < w - 16 && ry >= list_top && ry < list_top + list_h) {
        int idx = (ry - list_top + files_scroll) / row_h;
        if (idx >= 0 && idx < matched_count) {
            if (files_focus == FILES_FOCUS_RENAME) files_commit_rename();
            files_focus = FILES_FOCUS_NONE;
            int fi = matched_idx[idx];
            u32 now = ticks_get();
            int dbl = (fi == files_selected && files_dblclk_idx == fi && (now - files_dblclk_tick) < ticks_per_sec() / 2);
            files_selected = fi;
            files_dblclk_idx = fi; files_dblclk_tick = now;
            if (!files_list[fi].is_dir) {
                files_drag_idx = fi;
                files_drag_active = 0;
                str_copy(files_drag_name, files_list[fi].display_name, 16);
            }
            if (dbl) {
                fat_dirent_t* e = &files_list[fi];
                if (e->is_dir) { if (!znap_gate_enter(e)) { files_enter_dir(e->first_cluster, e->display_name); files_refresh(); } }
                else files_open_entry(e);
            }
        } else {
            files_selected = -1;
        }
        return;
    }
    if (files_focus == FILES_FOCUS_SEARCH) files_focus = FILES_FOCUS_NONE;
}

void files_activate_at(i32 rx, i32 ry) {
    i32 w = windows[APP_FILES].w, h = windows[APP_FILES].h;
    i32 status_h = 22;
    i32 list_top = 74;
    i32 list_h = h - 74 - status_h;
    i32 row_h = 22;
    if (ui_point_in(rx, ry, 8, 8, 38, 24)) { files_go_up(); files_refresh(); return; }
    if (rx < 8 || rx >= w - 16 || ry < list_top || ry >= list_top + list_h) return;
    int idx = (ry - list_top + files_scroll) / row_h;
    if (idx < 0 || idx >= matched_count) return;
    int fi = matched_idx[idx];
    files_selected = fi;
    files_focus = FILES_FOCUS_NONE;
    fat_dirent_t* e = &files_list[fi];
    if (e->is_dir) { if (!znap_gate_enter(e)) { files_enter_dir(e->first_cluster, e->display_name); files_refresh(); } }
    else files_open_entry(e);
}

static void app_files_wheel(i32 delta) {
    i32 list_h = (windows[APP_FILES].h - 36) - FILES_LIST_Y - 4;
    files_scroll = scroll_clamp(files_scroll - delta * FILES_ROW_H * 3,
                                 matched_count * FILES_ROW_H, list_h);
}

static void app_files_drag(i32 rx, i32 ry) {
    i32 list_h = (windows[APP_FILES].h - 36) - FILES_LIST_Y - 4;
    if (scroll_bar_hit(rx, ry, windows[APP_FILES].w - 14, FILES_LIST_Y, list_h,
                        matched_count * FILES_ROW_H, list_h)) {
        files_scroll = scroll_bar_drag_to(ry, FILES_LIST_Y, list_h, matched_count * FILES_ROW_H, list_h);
    }
}

static void app_files_key(int key) {
    if (znap_modal_key(key)) return;
    if (files_focus == FILES_FOCUS_SEARCH) {
        if (key == KEY_BACKSPACE) {
            if (files_filter_len > 0) files_filter[--files_filter_len] = 0;
            files_recompute_filter();
        } else if (key == KEY_ENTER || key == KEY_ESC) {
            files_focus = FILES_FOCUS_NONE;
        } else if (kbd_is_printable(key)) {
            if (files_filter_len < sizeof(files_filter) - 1) {
                files_filter[files_filter_len++] = (char)key;
                files_filter[files_filter_len] = 0;
                files_recompute_filter();
            }
        }
    } else if (files_focus == FILES_FOCUS_RENAME) {
        if (key == KEY_BACKSPACE) {
            if (files_rename_len > 0) files_rename_buf[--files_rename_len] = 0;
        } else if (key == KEY_ENTER) {
            files_commit_rename();
        } else if (key == KEY_ESC) {
            files_focus = FILES_FOCUS_NONE;
        } else if (kbd_is_printable(key) && key != ' ') {
            if (files_rename_len < sizeof(files_rename_buf) - 1) {
                files_rename_buf[files_rename_len++] = (char)key;
                files_rename_buf[files_rename_len] = 0;
            }
        }
    }
}

#define EDITOR_MAXLEN 8000
static char editor_filename[13] = "UNTITLED.TXT";
static u32 editor_filename_len = 12;
static int editor_editing_filename = 0;
static char editor_text[EDITOR_MAXLEN + 1];
static u32 editor_len = 0;
static char editor_status[64] = "New file.";
static int editor_font = 0;

void editor_load_content(const char* name, const u8* data, u32 len) {
    str_copy(editor_filename, name, 13);
    editor_filename_len = str_len(editor_filename);
    if (len > EDITOR_MAXLEN) len = EDITOR_MAXLEN;
    for (u32 i = 0; i < len; i++) editor_text[i] = (char)data[i];
    editor_text[len] = 0;
    editor_len = len;
    str_copy(editor_status, "Loaded.", 64);
}

#define EDITOR_BTN_Y_OFF(h) ((h) - 36)
#define EDITOR_NAME_X 8
#define EDITOR_NAME_Y 6
#define EDITOR_NAME_W 200
#define EDITOR_NAME_H 24

static void app_editor_draw(i32 x, i32 y, i32 w, i32 h) {
    (void)w;
    color_t name_bg = editor_editing_filename ? THEME_PANEL_RAISED : THEME_INPUT;
    color_t name_border = editor_editing_filename ? THEME_ACCENT : THEME_BORDER;
    gfx_rounded_rect(x + EDITOR_NAME_X, y + EDITOR_NAME_Y, EDITOR_NAME_W, EDITOR_NAME_H, THEME_RADIUS_CTRL, name_bg);
    gfx_rounded_rect_outline(x + EDITOR_NAME_X, y + EDITOR_NAME_Y, EDITOR_NAME_W, EDITOR_NAME_H, THEME_RADIUS_CTRL, name_border);
    char shown[20];
    str_copy(shown, editor_filename, 20);
    if (editor_editing_filename && (ticks_get() / 30) % 2 == 0 && str_len(shown) < 18) str_cat(shown, "_", 20);
    gfx_string(x + EDITOR_NAME_X + 8, y + EDITOR_NAME_Y + 4, shown, THEME_TEXT, name_bg, 0);

    gfx_string(x + EDITOR_NAME_X + EDITOR_NAME_W + 12, y + EDITOR_NAME_Y + 4, editor_status,
               THEME_TEXT_FAINT, THEME_PANEL, 0);

    i32 ty = y + 48, tx = x + 12;
    i32 max_y = y + EDITOR_BTN_Y_OFF(h) - 4;
    color_t field_bg = THEME_INPUT;
    gfx_rounded_rect(x + 8, y + 44, w - 16, max_y - (y + 44), THEME_RADIUS_CTRL, field_bg);
    gfx_rounded_rect_outline(x + 8, y + 44, w - 16, max_y - (y + 44), THEME_RADIUS_CTRL, THEME_BORDER);

    int ed_saved_font = gfx_get_font();
    gfx_set_font(editor_font);
    i32 cx = tx + 4, cy = ty + 4;
    i32 right_edge = x + w - 16;
    for (u32 i = 0; i < editor_len; i++) {
        char c = editor_text[i];
        if (c == '\n' || cx + 8 > right_edge) {
            cx = tx + 4; cy += 16;
            if (c == '\n') continue;
        }
        if (cy + 16 > max_y) break;
        gfx_char(cx, cy, c, THEME_TEXT, field_bg, 0);
        cx += 8;
    }

    if (!editor_editing_filename && (ticks_get() / 30) % 2 == 0 && cy + 16 <= max_y) {
        gfx_vline(cx, cy, 16, THEME_ACCENT);
    }
    gfx_set_font(ed_saved_font);

    i32 by = y + EDITOR_BTN_Y_OFF(h);
    ui_button(x + 8,   by, 66, 28, "Save", 0);
    ui_button(x + 80,  by, 60, 28, "Clear", 0);
    char fbtn[28]; str_copy(fbtn, "Font: ", 28); str_cat(fbtn, gfx_font_name(editor_font), 28);
    ui_button(x + 146, by, 156, 28, fbtn, 0);
}

static void app_editor_click(i32 rx, i32 ry) {
    if (ui_point_in(rx, ry, EDITOR_NAME_X, EDITOR_NAME_Y, EDITOR_NAME_W, EDITOR_NAME_H)) {
        editor_editing_filename = 1;
        return;
    }
    editor_editing_filename = 0;

    i32 by_off = windows[APP_EDITOR].h - 36;
    if (ry < by_off || ry > by_off + 28) return;
    if (rx >= 8 && rx < 74) {
        if (fat32_write_file(editor_filename, (const u8*)editor_text, editor_len)) {
            str_copy(editor_status, fat32_persistent() ? "Saved to disk." : "Saved -- check your desktop.", 64);
            refresh_disk_free();
            desktop_refresh_files();
        } else {
            str_copy(editor_status, "Save failed (storage full?).", 64);
        }
    } else if (rx >= 80 && rx < 140) {
        editor_len = 0;
        editor_text[0] = 0;
        str_copy(editor_status, "Cleared.", 64);
    } else if (rx >= 146 && rx < 302) {
        editor_font = (editor_font + 1) % FONT_STYLE_COUNT;
        str_copy(editor_status, "Font: ", 64);
        str_cat(editor_status, gfx_font_name(editor_font), 64);
    }
}

static void app_editor_key(int key) {
    if (editor_editing_filename) {
        if (key == KEY_BACKSPACE) {
            if (editor_filename_len > 0) editor_filename[--editor_filename_len] = 0;
        } else if (key == KEY_ENTER) {
            editor_editing_filename = 0;
        } else if (kbd_is_printable(key) && key != ' ') {
            if (editor_filename_len < sizeof(editor_filename) - 1) {
                editor_filename[editor_filename_len++] = (char)key;
                editor_filename[editor_filename_len] = 0;
            }
        }
        return;
    }
    if (key == KEY_BACKSPACE) {
        if (editor_len > 0) editor_text[--editor_len] = 0;
    } else if (key == KEY_ENTER) {
        if (editor_len < EDITOR_MAXLEN) editor_text[editor_len++] = '\n';
        editor_text[editor_len] = 0;
    } else if (kbd_is_printable(key)) {
        if (editor_len < EDITOR_MAXLEN) editor_text[editor_len++] = (char)key;
        editor_text[editor_len] = 0;
    }
}

#define TERM_HIST_SIZE 4096
static char term_hist[TERM_HIST_SIZE];
static u32 term_hist_len = 0;
static char term_cmd[100];
static u32 term_cmd_len = 0;
static i32 term_scroll = 0;

void term_print(const char* s) {
    u32 n = str_len(s);
    if (term_hist_len + n + 1 >= TERM_HIST_SIZE) {
        u32 drop = TERM_HIST_SIZE / 3;
        for (u32 i = drop; i < term_hist_len; i++) term_hist[i - drop] = term_hist[i];
        term_hist_len -= drop;
    }
    for (u32 i = 0; i < n; i++) term_hist[term_hist_len++] = s[i];
    term_hist[term_hist_len++] = '\n';
    term_hist[term_hist_len] = 0;
    term_scroll = 0;
}

static int term_parse_int(const char** s) {
    while (**s == ' ') (*s)++;
    int neg = 0;
    if (**s == '-') { neg = 1; (*s)++; }
    int v = 0;
    while (**s >= '0' && **s <= '9') { v = v * 10 + (**s - '0'); (*s)++; }
    return neg ? -v : v;
}

static void term_calc(const char* expr) {
    const char* p = expr;
    int a = term_parse_int(&p);
    while (*p == ' ') p++;
    char op = *p;
    if (op) p++;
    int b = term_parse_int(&p);
    int result = 0;
    int valid = 1;
    switch (op) {
        case '+': result = a + b; break;
        case '-': result = a - b; break;
        case '*': result = a * b; break;
        case '/':
            if (b == 0) { term_print("error: division by zero"); return; }
            result = a / b;
            break;
        default: valid = 0; break;
    }
    if (!valid) { term_print("usage: calc <number> <+|-|*|/> <number>"); return; }
    char buf[24];
    if (result < 0) { buf[0] = '-'; u32_to_str((u32)(-result), buf + 1); }
    else u32_to_str((u32)result, buf);
    term_print(buf);
}

#define TC_LOGO  "\x01"
#define TC_LABEL "\x02"
#define TC_RESET "\x03"

#define SYSFETCH_LOGO_ROWS 17
#define SYSFETCH_LOGO_W 34

static const char* const SYSFETCH_LOGO[SYSFETCH_LOGO_ROWS] = {
    "                *#                ",
    "               ####*              ",
    "            **#######*.           ",
    "           #############          ",
    "         ################*        ",
    "      **#####@@@@@@@@@#####*.     ",
    "     #######@        #@#######    ",
    "   ########@@         @########*  ",
    "**##########@@@@.  .@@###########*",
    "  ##########@@  @@@@@@###########*",
    "   ########@@         @########*  ",
    "     *######@@@@@@@@@@@######*    ",
    "        ####################      ",
    "         ################*        ",
    "           *###########*          ",
    "              #######             ",
    "               *##*.              ",
};

static void term_sysfetch_row(const char* logo_row, const char* info, char* out, u32 outlen) {
    str_copy(out, TC_LOGO, outlen);
    u32 raw_len = 0;
    if (logo_row) { str_cat(out, logo_row, outlen); raw_len = str_len(logo_row); }
    for (u32 i = raw_len; i < SYSFETCH_LOGO_W; i++) str_cat(out, " ", outlen);
    str_cat(out, TC_RESET "  ", outlen);
    if (info) str_cat(out, info, outlen);
}

static void term_sysfetch(void) {
    int cur_acc = accounts_current_index();
    const char* uname = (cur_acc >= 0) ? accounts_name_at(cur_acc) : "user";

    char header[48];
    str_copy(header, TC_LABEL, 48); str_cat(header, uname, 48);
    str_cat(header, TC_RESET "@zapczos", 48);

    char dashes[48] = "";
    { u32 n = str_len(uname) + 8; if (n > 40) n = 40; for (u32 i = 0; i < n; i++) str_cat(dashes, "-", 48); }

    char nbuf[12];
    u32 secs = ticks_get() / ticks_per_sec();
    char uptime_line[48];
    str_copy(uptime_line, TC_LABEL "Uptime: " TC_RESET, 48);
    u32_to_str(secs / 3600, nbuf); str_cat(uptime_line, nbuf, 48); str_cat(uptime_line, "h ", 48);
    u32_to_str((secs / 60) % 60, nbuf); str_cat(uptime_line, nbuf, 48); str_cat(uptime_line, "m ", 48);
    u32_to_str(secs % 60, nbuf); str_cat(uptime_line, nbuf, 48); str_cat(uptime_line, "s", 48);

    char res_line[48];
    str_copy(res_line, TC_LABEL "Resolution: " TC_RESET, 48);
    { char wbuf[12], hbuf[12]; u32_to_str((u32)gfx.width, wbuf); u32_to_str((u32)gfx.height, hbuf);
      str_cat(res_line, wbuf, 48); str_cat(res_line, "x", 48); str_cat(res_line, hbuf, 48); }

    perf_stats_t st; desktop_get_perf_stats(&st);
    extern u32 kernel_total_ram_kb(void);
    char mem_line[56];
    str_copy(mem_line, TC_LABEL "Memory: " TC_RESET, 56);
    u32_to_str(st.heap_used_kb, nbuf); str_cat(mem_line, nbuf, 56); str_cat(mem_line, " KB used / ", 56);
    { char rbuf[12]; u32_to_str(kernel_total_ram_kb() / 1024, rbuf); str_cat(mem_line, rbuf, 56); }
    str_cat(mem_line, " MB RAM", 56);

    refresh_disk_free();
    char storage_line[64];
    str_copy(storage_line, TC_LABEL "Storage: " TC_RESET, 64);
    { char kbs[32]; u32_to_kb_str(disk_free_cache, kbs); str_cat(storage_line, kbs, 64); }
    str_cat(storage_line, fat32_persistent() ? " free (disk)" : " free (session)", 64);

    char theme_line[40];
    str_copy(theme_line, TC_LABEL "Theme: " TC_RESET, 40);
    str_cat(theme_line, theme_get_mode() == THEME_MODE_LIGHT ? "Light" : "Dark", 40);

    const char* info[13];
    info[0]  = header;
    info[1]  = dashes;
    info[2]  = TC_LABEL "OS: " TC_RESET "ZapczOS V4";
    info[3]  = TC_LABEL "Kernel: " TC_RESET "i686, custom (C + NASM)";
    info[4]  = uptime_line;
    info[5]  = TC_LABEL "Shell: " TC_RESET "ZapczOS Terminal";
    info[6]  = res_line;
    info[7]  = TC_LABEL "DE: " TC_RESET "ZapczOS Desktop";
    info[8]  = TC_LABEL "WM: " TC_RESET "Zapcz WM";
    info[9]  = theme_line;
    info[10] = TC_LABEL "CPU: " TC_RESET "x86 (i386, no FPU/SSE)";
    info[11] = mem_line;
    info[12] = storage_line;

    int total_rows = SYSFETCH_LOGO_ROWS > 13 ? SYSFETCH_LOGO_ROWS : 13;
    char rowbuf[200];
    for (int i = 0; i < total_rows; i++) {
        const char* logo_row = (i < SYSFETCH_LOGO_ROWS) ? SYSFETCH_LOGO[i] : 0;
        const char* infoline = (i < 13) ? info[i] : 0;
        term_sysfetch_row(logo_row, infoline, rowbuf, sizeof(rowbuf));
        term_print(rowbuf);
    }
    term_print("");
}

static void term_ifconfig(void) {
    char line[80];
    u8 mac[6];
    net_get_mac(mac);
    const char* hx = "0123456789ABCDEF";
    char macbuf[18];
    int p = 0;
    for (int i = 0; i < 6; i++) {
        macbuf[p++] = hx[mac[i] >> 4];
        macbuf[p++] = hx[mac[i] & 0xF];
        if (i < 5) macbuf[p++] = ':';
    }
    macbuf[p] = 0;

    str_copy(line, TC_LABEL "Status: " TC_RESET, 80);
    str_cat(line, net_state_str(), 80);
    term_print(line);

    str_copy(line, TC_LABEL "MAC: " TC_RESET, 80);
    str_cat(line, macbuf, 80);
    term_print(line);

    if (net_ready()) {
        char ipbuf[16];
        str_copy(line, TC_LABEL "IP: " TC_RESET, 80);
        net_ip_to_str(net_get_ip(), ipbuf); str_cat(line, ipbuf, 80);
        term_print(line);

        str_copy(line, TC_LABEL "Netmask: " TC_RESET, 80);
        net_ip_to_str(net_get_netmask(), ipbuf); str_cat(line, ipbuf, 80);
        term_print(line);

        str_copy(line, TC_LABEL "Gateway: " TC_RESET, 80);
        net_ip_to_str(net_get_gateway(), ipbuf); str_cat(line, ipbuf, 80);
        term_print(line);

        str_copy(line, TC_LABEL "DNS: " TC_RESET, 80);
        net_ip_to_str(net_get_dns(), ipbuf); str_cat(line, ipbuf, 80);
        term_print(line);
    }
}

static void term_ping(const char* host) {
    u32 ip;
    if (!net_str_to_ip(host, &ip)) {
        if (!net_dns_resolve(host, &ip, 3000)) {
            term_print("ping: could not resolve host");
            return;
        }
    }
    char ipbuf[16]; net_ip_to_str(ip, ipbuf);
    char line[64];
    str_copy(line, "pinging ", 64); str_cat(line, ipbuf, 64); str_cat(line, " ...", 64);
    term_print(line);

    int ok_count = 0;
    for (int i = 0; i < 4; i++) {
        u32 ms = 0;
        if (net_ping(ip, 1500, &ms)) {
            char nbuf[12];
            str_copy(line, "reply from ", 64); str_cat(line, ipbuf, 64);
            str_cat(line, ": time=", 64); u32_to_str(ms, nbuf); str_cat(line, nbuf, 64); str_cat(line, "ms", 64);
            term_print(line);
            ok_count++;
        } else {
            term_print("request timed out");
        }
    }
    char summary[48] = "";
    char nbuf[12];
    u32_to_str((u32)ok_count, nbuf);
    str_cat(summary, nbuf, 48); str_cat(summary, "/4 replies received", 48);
    term_print(summary);
}


static u8 curl_buf[128 * 1024];

static int starts_with_ci(const char* s, const char* pre) {
    for (u32 i = 0; pre[i]; i++) {
        char a = s[i], b = pre[i];
        if (a >= 'A' && a <= 'Z') a = (char)(a - 'A' + 'a');
        if (b >= 'A' && b <= 'Z') b = (char)(b - 'A' + 'a');
        if (a != b) return 0;
    }
    return 1;
}

static int term_parse_url(const char* url, char* host, u32 hsz, char* path, u32 psz,
                          int* tls, u16* port) {
    while (*url == ' ') url++;
    if (!*url) return 0;
    *tls = 1; *port = 443;
    if (starts_with_ci(url, "https://")) { url += 8; *tls = 1; *port = 443; }
    else if (starts_with_ci(url, "http://")) { url += 7; *tls = 0; *port = 80; }
    u32 hi = 0;
    while (*url && *url != '/' && *url != ':' && hi + 1 < hsz) host[hi++] = *url++;
    host[hi] = 0;
    if (hi == 0) return 0;
    if (*url == ':') {
        url++;
        u32 pv = 0;
        while (*url >= '0' && *url <= '9') { pv = pv * 10 + (u32)(*url - '0'); url++; }
        if (pv > 0 && pv < 65536) *port = (u16)pv;
    }
    u32 pi = 0;
    if (*url != '/') path[pi++] = '/';
    while (*url && pi + 1 < psz) path[pi++] = *url++;
    path[pi] = 0;
    return 1;
}

static void term_curl(const char* url) {
    char host[80], path[160];
    int tls; u16 port;
    if (!term_parse_url(url, host, sizeof(host), path, sizeof(path), &tls, &port)) {
        term_print("usage: curl <url>   e.g. curl ascii.live/donut");
        return;
    }
    char msg[160];
    str_copy(msg, "curl: fetching ", 160); str_cat(msg, host, 160); str_cat(msg, path, 160);
    term_print(msg);

    http_response_t r;
    if (http_get(host, port, path, tls, curl_buf, sizeof(curl_buf) - 1, &r) <= 0) {
        term_print("curl: request failed (no route, DNS, or TLS error)");
        return;
    }
    if (r.body_len == 0) { term_print("curl: empty response"); return; }
    u32 n = r.body_len;
    if (n >= sizeof(curl_buf)) n = sizeof(curl_buf) - 1;
    curl_buf[n] = 0;

    u32 fstart = 0, fprev = 0;
    int frames = 0;
    int have_any = 0;
    for (u32 i = 0; i + 2 < n; i++) {
        if (curl_buf[i] == 0x1B && curl_buf[i + 1] == '[' &&
            (curl_buf[i + 2] == 'H' || curl_buf[i + 2] == '2')) {
            if (have_any && i < fstart + 12) continue;
            fprev = fstart; fstart = i; frames++; have_any = 1;
        }
    }
    u32 begin = 0, end = n;
    if (frames >= 2) { begin = fprev; end = fstart; }

    char line[200];
    u32 li = 0;
    int printed = 0;
    for (u32 i = begin; i < end && printed < 60; i++) {
        u8 c = curl_buf[i];
        if (c == 0x1B) {
            i++;
            if (i < end && curl_buf[i] == '[') {
                i++;
                while (i < end && !((curl_buf[i] >= 'A' && curl_buf[i] <= 'Z') ||
                                    (curl_buf[i] >= 'a' && curl_buf[i] <= 'z'))) i++;
            }
            continue;
        }
        if (c == '\r') continue;
        if (c == '\n' || li + 1 >= sizeof(line)) {
            line[li] = 0;
            term_print(line);
            printed++;
            li = 0;
            if (c != '\n') { if (li < sizeof(line) - 1) line[li++] = (char)c; }
            continue;
        }
        if (c == '\t') { for (int t = 0; t < 4 && li + 1 < sizeof(line); t++) line[li++] = ' '; continue; }
        if (c < 32 || c > 126) continue;
        line[li++] = (char)c;
    }
    if (li > 0 && printed < 60) { line[li] = 0; term_print(line); }
    if (frames >= 2) term_print("(live stream - showing one frame)");
}


static u8 term_cc_src[49152];
static u8 term_cc_img[ZAP_IMAGE_MAX];

static int term_find_file(const char* name, fat_dirent_t* out) {
    static fat_dirent_t list[128];
    int n = fat32_list_dir(FAT32_ROOT_ID, list, 128);
    for (int i = 0; i < n; i++) {
        if (list[i].is_dir) continue;
        if (str_eq_ci(list[i].display_name, name)) { *out = list[i]; return 1; }
    }
    return 0;
}

static void term_zap_outname(const char* in, char* out, u32 outlen) {
    u32 i = 0;
    while (in[i] && in[i] != '.' && i < 8 && i + 1 < outlen) {
        char c = in[i];
        if (c >= 'a' && c <= 'z') c = (char)(c - 32);
        out[i] = c; i++;
    }
    out[i] = 0;
    str_cat(out, ".ZAP", outlen);
}

static void term_print_zap_output(void) {
    int n = zrt_line_count();
    for (int i = 0; i < n; i++) term_print(zrt_line(i));
}

static void term_cmd_zapcc(const char* name) {
    fat_dirent_t f;
    if (!term_find_file(name, &f)) { term_print("zapcc: file not found"); return; }
    int n = fat32_read_file(&f, term_cc_src, sizeof(term_cc_src) - 1);
    if (n <= 0) { term_print("zapcc: cannot read source"); return; }
    term_cc_src[n] = 0;

    u32 sz = 0;
    if (!zapcc_compile((const char*)term_cc_src, (u32)n, term_cc_img, ZAP_IMAGE_MAX, &sz)) {
        char line[120];
        str_copy(line, "zapcc: error", sizeof(line));
        if (zapcc_error_line() > 0) {
            char nb[12]; u32_to_str((u32)zapcc_error_line(), nb);
            str_cat(line, " on line ", sizeof(line));
            str_cat(line, nb, sizeof(line));
        }
        str_cat(line, ": ", sizeof(line));
        str_cat(line, zapcc_error(), sizeof(line));
        term_print(line);
        return;
    }
    char outname[16];
    term_zap_outname(f.display_name, outname, sizeof(outname));
    char msg[100];
    char nb[12];
    str_copy(msg, "compiled ", sizeof(msg));
    str_cat(msg, f.display_name, sizeof(msg));
    str_cat(msg, " -> ", sizeof(msg));
    str_cat(msg, outname, sizeof(msg));
    str_cat(msg, "  (", sizeof(msg));
    u32_to_str(zapcc_stat_code(), nb);
    str_cat(msg, nb, sizeof(msg));
    str_cat(msg, " bytes of machine code, ", sizeof(msg));
    u32_to_str((u32)zapcc_stat_funcs(), nb);
    str_cat(msg, nb, sizeof(msg));
    str_cat(msg, " functions)", sizeof(msg));
    term_print(msg);
    if (fat32_write_file(outname, term_cc_img, sz) <= 0)
        term_print("zapcc: compiled but could not write the .ZAP file");
}

static void term_cmd_zaprun(const char* name) {
    fat_dirent_t f;
    if (!term_find_file(name, &f)) { term_print("zaprun: file not found"); return; }
    int n = fat32_read_file(&f, term_cc_img, ZAP_IMAGE_MAX);
    if (n <= 0) { term_print("zaprun: cannot read file"); return; }
    zrt_reset();
    int rc = 0;
    if (!zap_run(term_cc_img, (u32)n, &rc)) {
        char line[100];
        str_copy(line, "zaprun: ", sizeof(line));
        str_cat(line, zap_run_error(), sizeof(line));
        term_print(line);
        return;
    }
    term_print_zap_output();
    char msg[64]; char nb[12];
    str_copy(msg, "[exit code ", sizeof(msg));
    i32_to_str(rc, nb);
    str_cat(msg, nb, sizeof(msg));
    str_cat(msg, "]", sizeof(msg));
    term_print(msg);
}

static void term_exec(const char* cmd) {
    char echoed[140] = "> ";
    str_cat(echoed, cmd, 140);
    term_print(echoed);

    if (str_eq(cmd, "")) return;
    if (str_eq(cmd, "help")) {
        term_print("commands: help ls cat <f> rm <f> write <f> <text>");
        term_print("          clear time date free about echo <text>");
        term_print("          ver uptime mem sysfetch calc <a op b> open <app> zap list");
        term_print("          zap apps/list  zap install/remove/info <name>  curl <url>");
        term_print("          wifi diag           dump WiFi hardware registers");
        term_print("          wifi scan  wifi connect <ssid> <pass>  wifi status");
        term_print("          ifconfig  ping <host>");
        term_print("          disklist  install-os /dev/sdX <isofile>  (X=a..d)");
        term_print("          zapcc <file.c>      compile C to a .ZAP executable");
        term_print("          zaprun <file.zap>   run a compiled .ZAP program");
        term_print("          F12 anywhere        save a screenshot as SHOTnnn.PNG");
    } else if (str_eq(cmd, "ifconfig") || str_eq(cmd, "ipconfig")) {
        term_ifconfig();
    } else if (starts_with(cmd, "ping ")) {
        term_ping(cmd + 5);
    } else if (str_eq(cmd, "sysfetch")) {
        term_sysfetch();
    } else if (str_eq(cmd, "disklist")) {
        installer_cmd_disklist();
    } else if (starts_with(cmd, "install-os ")) {
        installer_cmd_install(cmd + 11);
    } else if (starts_with(cmd, "zapcc ")) {
        term_cmd_zapcc(cmd + 6);
    } else if (starts_with(cmd, "zaprun ")) {
        term_cmd_zaprun(cmd + 7);
    } else if (str_eq(cmd, "clear")) {
        term_hist_len = 0; term_hist[0] = 0;
    } else if (str_eq(cmd, "ls")) {
        if (!fat32_available()) { term_print("no disk detected"); return; }
        fat_dirent_t ents[FILES_MAX];
        int n = fat32_list_root(ents, FILES_MAX);
        for (int i = 0; i < n; i++) {
            char line[40]; str_copy(line, ents[i].display_name, 40);
            str_cat(line, "  ", 40);
            char sz[16]; u32_to_str(ents[i].size, sz);
            str_cat(line, sz, 40);
            term_print(line);
        }
        if (n == 0) term_print("(empty)");
    } else if (starts_with(cmd, "cat ")) {
        if (!fat32_available()) { term_print("no disk detected"); return; }
        fat_dirent_t ents[FILES_MAX];
        int n = fat32_list_root(ents, FILES_MAX);
        int found = 0;
        for (int i = 0; i < n; i++) {
            if (str_eq_ci(ents[i].display_name, cmd + 4)) {
                static u8 tmp[8192];
                int len = fat32_read_file(&ents[i], tmp, sizeof(tmp) - 1);
                if (len < 0) len = 0;
                tmp[len] = 0;
                term_print((const char*)tmp);
                found = 1;
                break;
            }
        }
        if (!found) term_print("file not found");
    } else if (starts_with(cmd, "rm ")) {
        if (fat32_delete_file(cmd + 3)) {
            extern int trash_add(const char*, u32);
            trash_add(cmd + 3, 0);
            term_print("deleted (moved to Trash)");
            desktop_refresh_files();
        }
        else term_print("not found");
    } else if (starts_with(cmd, "write ")) {
        const char* rest = cmd + 6;
        char fname[16]; int p = 0;
        while (rest[p] && rest[p] != ' ' && p < 15) { fname[p] = rest[p]; p++; }
        fname[p] = 0;
        const char* text = rest + p;
        while (*text == ' ') text++;
        if (fat32_write_file(fname, (const u8*)text, str_len(text))) {
            term_print("written");
            refresh_disk_free();
            desktop_refresh_files();
        } else term_print("write failed (storage full?)");
    } else if (str_eq(cmd, "time") || str_eq(cmd, "date")) {
        rtc_time_t t; rtc_read(&t); config_local_time(&t);
        char buf[32]; const char* d = "0123456789"; int p = 0;
        buf[p++]=d[t.hour/10];buf[p++]=d[t.hour%10];buf[p++]=':';
        buf[p++]=d[t.minute/10];buf[p++]=d[t.minute%10];buf[p++]=':';
        buf[p++]=d[t.second/10];buf[p++]=d[t.second%10];buf[p++]=' ';buf[p++]='-';buf[p++]=' ';
        buf[p++]=d[t.day/10];buf[p++]=d[t.day%10];buf[p++]='/';
        buf[p++]=d[t.month/10];buf[p++]=d[t.month%10];
        buf[p]=0;
        term_print(buf);
    } else if (str_eq(cmd, "free")) {
        refresh_disk_free();
        char kbs[32]; u32_to_kb_str(disk_free_cache, kbs);
        char line[56];
        str_copy(line, fat32_persistent() ? "disk free: " : "session storage free: ", 56);
        str_cat(line, kbs, 56);
        term_print(line);
    } else if (str_eq(cmd, "about")) {
        term_print("ZapczOS V4 -- a hobby OS in C and NASM.");
    } else if (str_eq(cmd, "ver") || str_eq(cmd, "uname")) {
        term_print("ZapczOS V4 (i686, BIOS/VBE + GRUB/Multiboot2 boot paths)");
    } else if (str_eq(cmd, "uptime")) {
        u32 secs = ticks_get() / ticks_per_sec();
        char buf[40] = "up "; char n[12];
        u32_to_str(secs / 3600, n); str_cat(buf, n, 40); str_cat(buf, "h ", 40);
        u32_to_str((secs / 60) % 60, n); str_cat(buf, n, 40); str_cat(buf, "m ", 40);
        u32_to_str(secs % 60, n); str_cat(buf, n, 40); str_cat(buf, "s", 40);
        term_print(buf);
    } else if (str_eq(cmd, "mem")) {
        perf_stats_t st; desktop_get_perf_stats(&st);
        char buf[64] = "heap: "; char n[12];
        u32_to_str(st.heap_used_kb, n); str_cat(buf, n, 64); str_cat(buf, " KB used / ", 64);
        u32_to_str(st.heap_used_kb + st.heap_free_kb, n); str_cat(buf, n, 64); str_cat(buf, " KB total", 64);
        term_print(buf);
        extern u32 kernel_total_ram_kb(void);
        char buf2[48] = "system RAM: "; char mb[32];
        u32_to_kb_str(kernel_total_ram_kb() * 1024, mb);
        str_cat(buf2, mb, 48);
        term_print(buf2);
    } else if (starts_with(cmd, "open ")) {
        const char* name = cmd + 5;
        const char* names[APP_COUNT] = {
            "about", "clock", "files", "editor", "terminal", "performance", "wallpaper", "snake",
            "browser", "store", "settings", "photos", "accounts", "installos",
            "calculator", "paint", "tictactoe", "cube", "desktopsettings",
            "minesweeper", "life", "", "calendar", "trash",
            "writer", "sheet", "media", "code"
        };
        int found = -1;
        for (int i = 0; i < APP_COUNT; i++) if (str_eq_ci(name, names[i])) { found = i; break; }
        if (found < 0) {
            term_print("no such app (about/clock/files/editor/terminal/performance/wallpaper/snake/");
            term_print("            browser/store/settings/photos/accounts/installos/");
            term_print("            calculator/paint/tictactoe/cube/desktopsettings)");
        } else if (!app_is_installed(found)) {
            term_print("not installed yet -- visit the App Store");
        } else {
            desktop_open_app(found);
            term_print("opening...");
        }
    } else if (starts_with(cmd, "calc ")) {
        term_calc(cmd + 5);
    } else if (starts_with_ci(cmd, "curl ")) {
        term_curl(cmd + 5);
    } else if (str_eq_ci(cmd, "curl")) {
        term_print("usage: curl <url>   e.g. curl ascii.live/donut");
    } else if (str_eq_ci(cmd, "wifi diag")) {
        extern void iwl_dump_diag(void (*)(const char*));
        term_print("--- Intel WiFi register dump ---");
        iwl_dump_diag(term_print);
        term_print("--- end ---");
    } else if (str_eq_ci(cmd, "zap apps")) {
        pkgmgr_cmd_apps();
    } else if (str_eq_ci(cmd, "zap list")) {
        pkgmgr_cmd_list();
    } else if (starts_with(cmd, "zap install ")) {
        pkgmgr_cmd_install(cmd + 12);
    } else if (starts_with(cmd, "zap remove ")) {
        pkgmgr_cmd_remove(cmd + 11);
    } else if (starts_with(cmd, "zap info ")) {
        pkgmgr_cmd_info(cmd + 9);
    } else if (starts_with(cmd, "curl ")) {
        const char* url = cmd + 5;
        int use_tls = starts_with(url, "https://");
        int start = use_tls ? 8 : 7;
        char host[128]; char path[256];
        u32 hi = 0;
        const char* p = url + start;
        while (*p && *p != '/' && hi < 127) { host[hi++] = *p++; }
        host[hi] = 0;
        if (*p == '/') str_copy(path, p, sizeof(path));
        else str_copy(path, "/", sizeof(path));
        term_print("connecting...");
        static u8 curl_body[32768];
        http_response_t resp;
        int ok = http_get(host, (u16)(use_tls ? 443 : 80), path, use_tls,
                          curl_body, sizeof(curl_body)-1, &resp);
        if (!ok) {
            term_print(resp.error_msg[0] ? resp.error_msg : "connection failed");
        } else {
            curl_body[resp.body_len < sizeof(curl_body)-1 ? resp.body_len : sizeof(curl_body)-2] = 0;
            term_print((const char*)curl_body);
        }
    } else if (str_eq_ci(cmd, "wifi scan")) {
        if (!wifi_available()) { term_print("no wifi hardware detected"); }
        else {
            term_print("scanning...");
            static wifi_bss_t scan_results[16];
            u32 count = 0;
            wifi_scan(scan_results, 16, &count);
            if (count == 0) { term_print("no networks found"); }
            else {
                char line[80];
                for (u32 i = 0; i < count; i++) {
                    char rssi_str[12]; i32_to_str(scan_results[i].rssi, rssi_str);
                    str_copy(line, scan_results[i].ssid, 80);
                    str_cat(line, " (ch", 80);
                    char ch_str[8]; u32_to_str(scan_results[i].channel, ch_str);
                    str_cat(line, ch_str, 80);
                    str_cat(line, ", ", 80);
                    str_cat(line, rssi_str, 80);
                    str_cat(line, " dBm)", 80);
                    if (scan_results[i].has_wpa2) str_cat(line, " [WPA2]", 80);
                    term_print(line);
                }
            }
        }
    } else if (starts_with(cmd, "wifi connect ")) {
        if (!wifi_available()) { term_print("no wifi hardware detected"); }
        else {
            const char* args = cmd + 13;
            char ssid[64]; char pass[64];
            u32 si = 0;
            while (*args && *args != ' ' && si < 63) { ssid[si++] = *args++; }
            ssid[si] = 0;
            if (*args == ' ') args++;
            str_copy(pass, args, sizeof(pass));
            term_print("connecting...");
            int ok = wifi_connect(ssid, pass);
            term_print(ok ? "connected!" : "failed to connect");
        }
    } else if (str_eq_ci(cmd, "wifi status")) {
        wifi_status_t ws;
        wifi_get_status(&ws);
        if (!ws.available) { term_print("no wifi hardware detected"); }
        else if (!ws.connected) { term_print("wifi: not connected"); }
        else {
            char line[80];
            str_copy(line, "connected to: ", 80);
            str_cat(line, ws.ssid, 80);
            term_print(line);
            char ch_line[80];
            str_copy(ch_line, "channel: ", 80);
            char ch_s[8]; u32_to_str(ws.channel, ch_s);
            str_cat(ch_line, ch_s, 80);
            term_print(ch_line);
        }
    } else if (starts_with(cmd, "echo ")) {
        term_print(cmd + 5);
    } else {
        term_print("unknown command (try 'help')");
    }
}

static void app_terminal_draw(i32 x, i32 y, i32 w, i32 h) {
    gfx_rect(x + 8, y + 8, w - 16, h - 16, RGB(10,12,16));
    i32 line_h = 16;
    i32 max_lines = (h - 16 - 24) / line_h;

    int line_count = 0;
    for (u32 i = 0; i < term_hist_len; i++) if (term_hist[i] == '\n') line_count++;
    i32 max_scroll_lines = line_count - max_lines;
    if (max_scroll_lines < 0) max_scroll_lines = 0;
    if (term_scroll < 0) term_scroll = 0;
    if (term_scroll > max_scroll_lines) term_scroll = max_scroll_lines;
    int skip = line_count - max_lines - term_scroll;
    if (skip < 0) skip = 0;

    i32 ty = y + 12;
    int cur_line = 0;
    char linebuf[120]; int lp = 0;
    for (u32 i = 0; i <= term_hist_len; i++) {
        char c = (i < term_hist_len) ? term_hist[i] : '\n';
        if (c == '\n') {
            if (cur_line >= skip) {
                linebuf[lp] = 0;
                i32 cx = x + 12;
                color_t cur_fg = RGB(120,230,140);
                for (int k = 0; k < lp; k++) {
                    char ch = linebuf[k];
                    if (ch == 0x01) { cur_fg = RGB(110,210,255); continue; }
                    if (ch == 0x02) { cur_fg = RGB(235,238,245); continue; }
                    if (ch == 0x03) { cur_fg = RGB(120,230,140); continue; }
                    gfx_char(cx, ty, ch, cur_fg, RGB(10,12,16), 0);
                    cx += 8;
                }
                ty += line_h;
            }
            lp = 0;
            cur_line++;
        } else if (lp < 118) {
            linebuf[lp++] = c;
        }
    }

    char prompt[128] = "> ";
    str_cat(prompt, term_cmd, 128);
    if ((ticks_get() / 30) % 2 == 0) str_cat(prompt, "_", 128);
    gfx_string(x + 12, y + h - 24, prompt, RGB(230,230,120), RGB(10,12,16), 0);
}

static void app_terminal_key(int key) {
    if (key == KEY_ENTER) {
        term_exec(term_cmd);
        term_cmd_len = 0;
        term_cmd[0] = 0;
    } else if (key == KEY_BACKSPACE) {
        if (term_cmd_len > 0) term_cmd[--term_cmd_len] = 0;
    } else if (kbd_is_printable(key)) {
        if (term_cmd_len < sizeof(term_cmd) - 1) {
            term_cmd[term_cmd_len++] = (char)key;
            term_cmd[term_cmd_len] = 0;
        }
    }
}

static void app_terminal_wheel(i32 delta) {
    term_scroll += delta * 3;
    if (term_scroll < 0) term_scroll = 0;
}

static void perf_bar(i32 x, i32 y, i32 w, i32 h, u32 pct, color_t fg) {
    if (pct > 100) pct = 100;
    gfx_rounded_rect(x, y, w, h, h / 2, THEME_PANEL_ALT);
    i32 fillw = (i32)((u32)(w - 2) * pct / 100);
    if (fillw > 2) gfx_rounded_rect(x + 1, y + 1, fillw, h - 2, (h-2)/2, fg);
}

#define PERF_HISTORY_LEN 80
static u8 perf_history[PERF_HISTORY_LEN];
static int perf_history_pos = 0;
static u32 perf_last_sample_tick = 0;

static void perf_graph(i32 x, i32 y, i32 w, i32 h) {
    gfx_rounded_rect(x, y, w, h, 6, RGB(15,16,21));
    gfx_rounded_rect_outline(x, y, w, h, 6, THEME_BORDER);

    gfx_hline(x + 4, y + h / 2, w - 8, RGB(34,36,44));

    i32 bw = w / PERF_HISTORY_LEN;
    if (bw < 1) bw = 1;
    for (int i = 0; i < PERF_HISTORY_LEN; i++) {
        int idx = (perf_history_pos + i) % PERF_HISTORY_LEN;
        u32 pct = perf_history[idx];
        i32 bar_h = (i32)((u32)(h - 4) * pct / 100);
        if (bar_h < 1 && pct > 0) bar_h = 1;
        color_t c = pct > 70 ? THEME_DANGER : (pct > 35 ? THEME_WARNING : THEME_SUCCESS);
        if (bar_h > 0) gfx_rect(x + 2 + i * bw, y + h - 2 - bar_h, bw > 1 ? bw - 1 : 1, bar_h, c);
    }
}

static int perf_active_tab = 0;

static color_t app_darken(color_t c, int amt) {
    int r = c.r - amt; int g = c.g - amt; int b = c.b - amt;
    if (r < 0) r = 0; if (g < 0) g = 0; if (b < 0) b = 0;
    return RGB(r, g, b);
}
static color_t app_lighten(color_t c, int amt) {
    int r = c.r + amt; int g = c.g + amt; int b = c.b + amt;
    if (r > 255) r = 255; if (g > 255) g = 255; if (b > 255) b = 255;
    return RGB(r, g, b);
}

static void draw_tab_bar(i32 x, i32 y, i32 w, int active, const char* t0, const char* t1) {
    i32 tab_w = (w - 4) / 2;
    i32 ty = y + 4;
    i32 th = 26;
    for (int t = 0; t < 2; t++) {
        const char* label = t == 0 ? t0 : t1;
        i32 tx = x + 2 + t * tab_w;
        color_t bg = (t == active) ? THEME_PANEL : app_darken(THEME_PANEL, 20);
        color_t fg = (t == active) ? THEME_TEXT : THEME_TEXT_DIM;
        gfx_rounded_rect(tx, ty, tab_w - 2, th, 4, bg);
        if (t == active) gfx_rounded_rect_outline(tx, ty, tab_w - 2, th, 4, THEME_BORDER);
        i32 tw = gfx_string_width(label);
        gfx_string(tx + (tab_w - 2 - tw) / 2, ty + (th - 16) / 2, label, fg, bg, 0);
    }
    gfx_hline(x, y + 4 + th, w, THEME_BORDER);
}

static void app_perf_draw(i32 x, i32 y, i32 w, i32 h) {
    perf_stats_t st;
    desktop_get_perf_stats(&st);

    u32 now = ticks_get();
    if (now - perf_last_sample_tick >= 10) {
        perf_history[perf_history_pos] = (u8)st.cpu_busy_pct;
        perf_history_pos = (perf_history_pos + 1) % PERF_HISTORY_LEN;
        perf_last_sample_tick = now;
    }

    draw_tab_bar(x, y + 4, w, perf_active_tab, "Performance", "Processes");
    i32 content_y = y + 44;
    char buf[80];

    if (perf_active_tab == 0) {
        i32 ty = content_y + 4;

        str_copy(buf, "FPS: ", 64); char n1[12]; u32_to_str(st.fps, n1); str_cat(buf, n1, 64);
        gfx_string(x + 12, ty, buf, THEME_TEXT_DIM, THEME_PANEL, 0); ty += 22;

        str_copy(buf, "CPU busy: ", 64);
        char n2[12]; u32_to_str(st.cpu_busy_pct, n2); str_cat(buf, n2, 64); str_cat(buf, "%", 64);
        gfx_string(x + 12, ty, buf, THEME_TEXT_DIM, THEME_PANEL, 0); ty += 18;
        perf_bar(x + 12, ty, w - 24, 14,
                 st.cpu_busy_pct, st.cpu_busy_pct > 70 ? THEME_DANGER : THEME_SUCCESS);
        ty += 22;

        perf_graph(x + 12, ty, w - 24, 56); ty += 66;
        gfx_string(x + 12, ty, "last ~8 seconds, 10 samples/sec", THEME_TEXT_FAINT, THEME_PANEL, 0);
        ty += 22;

        u32 heap_total = st.heap_used_kb + st.heap_free_kb;
        u32 heap_pct = heap_total ? (st.heap_used_kb * 100) / heap_total : 0;
        str_copy(buf, "Memory: ", 64);
        char n3[12]; u32_to_str(st.heap_used_kb, n3); str_cat(buf, n3, 64);
        str_cat(buf, " KB / ", 64);
        char n4[12]; u32_to_str(heap_total, n4); str_cat(buf, n4, 64); str_cat(buf, " KB", 64);
        gfx_string(x + 12, ty, buf, THEME_TEXT_DIM, THEME_PANEL, 0); ty += 18;
        perf_bar(x + 12, ty, w - 24, 14, heap_pct, THEME_ACCENT); ty += 26;

        if (!disk_free_known) refresh_disk_free();
        str_copy(buf, fat32_persistent() ? "Disk free: " : "Session free: ", 64);
        char kbs[32]; u32_to_kb_str(disk_free_cache, kbs); str_cat(buf, kbs, 64);
        gfx_string(x + 12, ty, buf, THEME_TEXT_DIM, THEME_PANEL, 0); ty += 22;

        extern u32 kernel_total_ram_kb(void);
        u32 ram_kb = kernel_total_ram_kb();
        str_copy(buf, "Total RAM: ", 64);
        if (ram_kb > 0) {
            char mbbuf[32]; u32_to_kb_str(ram_kb * 1024, mbbuf); str_cat(buf, mbbuf, 64);
        } else { str_cat(buf, "unknown", 64); }
        gfx_string(x + 12, ty, buf, THEME_TEXT_DIM, THEME_PANEL, 0); ty += 22;

        u32 secs = ticks_get() / ticks_per_sec();
        str_copy(buf, "Uptime: ", 64);
        char n5[12]; u32_to_str(secs / 60, n5); str_cat(buf, n5, 64); str_cat(buf, "m ", 64);
        char n6[12]; u32_to_str(secs % 60, n6); str_cat(buf, n6, 64); str_cat(buf, "s", 64);
        gfx_string(x + 12, ty, buf, THEME_TEXT_DIM, THEME_PANEL, 0); ty += 22;

        int ns = net_state();
        str_copy(buf, "Network: ", 64);
        str_cat(buf, ns == 2 ? "connected (DHCP OK)" : ns == 1 ? "link up, no IP" : "no link", 64);
        gfx_string(x + 12, ty, buf, THEME_TEXT_DIM, THEME_PANEL, 0); ty += 22;

        if (wifi_available()) {
            wifi_status_t ws; wifi_get_status(&ws);
            str_copy(buf, "WiFi: ", 64);
            str_cat(buf, ws.connected ? "connected to " : "available, not connected", 64);
            if (ws.connected) str_cat(buf, ws.ssid, 64);
            gfx_string(x + 12, ty, buf, THEME_TEXT_DIM, THEME_PANEL, 0);
        } else {
            gfx_string(x + 12, ty, "WiFi: no hardware detected", THEME_TEXT_FAINT, THEME_PANEL, 0);
        }

    } else {
        i32 ty = content_y + 2;
        i32 row_h = 22;
        i32 mem_col = x + w - 90;

        gfx_rect(x, ty, w, row_h - 2, app_darken(THEME_PANEL, 10));
        gfx_string(x + 8, ty + 3, "Process", THEME_TEXT_FAINT, app_darken(THEME_PANEL, 10), 0);
        gfx_string(mem_col, ty + 3, "Status", THEME_TEXT_FAINT, app_darken(THEME_PANEL, 10), 0);
        ty += row_h;

        static const char* APP_NAMES[] = {
            "2048", "Clock", "Files", "Editor", "Terminal",
            "Performance", "Wallpaper", "Snake", "Browser", "App Store",
            "Settings", "Photos", "Accounts", "Installer", "Calculator",
            "Paint", "Tic-Tac-Toe", "3D Grapher", "Desktop Settings", "Minesweeper", "Game of Life",
            "", "Calendar", "Trash", "Writer", "Sheet", "Media", "Code", "Compiler"
        };

        int visible_rows = (h - (ty - y) - 4) / row_h;
        int app_shown = 0;

        for (int i = 0; i < APP_COUNT && app_shown < visible_rows; i++) {
            if (!windows[i].visible) continue;
            color_t row_bg = (app_shown % 2 == 0) ? THEME_PANEL : app_lighten(THEME_PANEL, 6);
            gfx_rect(x, ty, w, row_h - 1, row_bg);

            const char* nm = (i < APP_COUNT) ? APP_NAMES[i] : "?";
            gfx_string(x + 8, ty + 3, nm, THEME_TEXT, row_bg, 0);

            const char* status = windows[i].minimized ? "Minimized" :
                                 (i == desktop_focused_app()) ? "Active" : "Running";
            color_t sc = windows[i].minimized ? THEME_TEXT_FAINT :
                         (i == desktop_focused_app()) ? THEME_SUCCESS : THEME_TEXT_DIM;
            gfx_string(mem_col, ty + 3, status, sc, row_bg, 0);

            ty += row_h;
            app_shown++;
        }

        if (app_shown == 0) {
            gfx_string(x + 8, ty + 4, "No apps running", THEME_TEXT_FAINT, THEME_PANEL, 0);
            ty += row_h;
        }

        ty += 8;
        gfx_hline(x + 4, ty, w - 8, THEME_BORDER);
        ty += 8;

        str_copy(buf, "System: kernel, net stack, UI loop", 80);
        gfx_string(x + 8, ty, buf, THEME_TEXT_FAINT, THEME_PANEL, 0); ty += row_h;

        str_copy(buf, "Heap: ", 80);
        char hk[12]; u32_to_str(st.heap_used_kb, hk); str_cat(buf, hk, 80);
        str_cat(buf, " KB used, ", 80);
        char fk[12]; u32_to_str(st.heap_free_kb, fk); str_cat(buf, fk, 80);
        str_cat(buf, " KB free", 80);
        gfx_string(x + 8, ty, buf, THEME_TEXT_DIM, THEME_PANEL, 0);
    }
    (void)h;
}

static void app_perf_click(i32 rx, i32 ry) {
    i32 tab_w = (windows[APP_PERF].w - 4) / 2;
    i32 tab_y = 4 + 4;
    i32 tab_h = 26;
    if (ry >= tab_y && ry < tab_y + tab_h) {
        if (rx >= 2 && rx < 2 + tab_w) { perf_active_tab = 0; return; }
        if (rx >= 2 + tab_w && rx < 2 + 2 * tab_w) { perf_active_tab = 1; return; }
    }
}

typedef struct { const char* name; int mode; color_t a, b, c, d; const u8* bitmap; } wallpaper_preset_t;

static const wallpaper_preset_t wallpapers[] = {
    { "Alpine Mirror",  BG_MODE_BITMAP, {0,0,0}, {0,0,0}, {0,0,0}, {0,0,0}, WP_BMP_ALPINE_MIRROR },
    { "Winter Sunset",  BG_MODE_BITMAP, {0,0,0}, {0,0,0}, {0,0,0}, {0,0,0}, WP_BMP_WINTER_SUNSET },
    { "Blue Streaks",   BG_MODE_BITMAP, {0,0,0}, {0,0,0}, {0,0,0}, {0,0,0}, WP_BMP_BLUE_STREAKS },
    { "Summer Field",   BG_MODE_BITMAP, {0,0,0}, {0,0,0}, {0,0,0}, {0,0,0}, WP_BMP_SUMMER_FIELD },
};
#define WALLPAPER_COUNT (sizeof(wallpapers)/sizeof(wallpapers[0]))
static int wallpaper_selected = 0;
static i32 wallpaper_scroll = 0;

static void app_wallpaper_draw(i32 x, i32 y, i32 w, i32 h) {
    gfx_string(x + 12, y + 10, "Choose a wallpaper", THEME_TEXT, THEME_PANEL, 0);

    i32 swatch_w = 130, swatch_h = 80, gap = 14;
    i32 cols = (w - 24) / (swatch_w + gap);
    if (cols < 1) cols = 1;
    i32 rows = ((i32)WALLPAPER_COUNT + cols - 1) / cols;
    i32 content_h = rows * (swatch_h + 30);
    i32 view_h = h - 36;
    wallpaper_scroll = scroll_clamp(wallpaper_scroll, content_h, view_h);

    clip_t grid_clip = { x, y + 36, x + w, y + h };
    gfx_set_clip(grid_clip);

    for (u32 i = 0; i < WALLPAPER_COUNT; i++) {
        i32 col = (i32)i % cols, row = (i32)i / cols;
        i32 sx = x + 12 + col * (swatch_w + gap);
        i32 sy = y + 36 + row * (swatch_h + 30) - wallpaper_scroll;

        if (wallpapers[i].mode == BG_MODE_SOLID) {
            gfx_rounded_rect(sx, sy, swatch_w, swatch_h, 8, wallpapers[i].a);
        } else if (wallpapers[i].mode == BG_MODE_BITMAP) {
            clip_t swclip = { sx, sy, sx + swatch_w, sy + swatch_h };
            gfx_set_clip(swclip);
            gfx_blit_rgb_scaled(wallpapers[i].bitmap, WALLPAPER_BMP_W, WALLPAPER_BMP_H,
                                sx, sy, swatch_w, swatch_h);
            gfx_clear_clip();
        } else {
            gfx_rounded_gradient_v(sx, sy, swatch_w, swatch_h, 8, wallpapers[i].a, wallpapers[i].b);
        }

        color_t border = ((int)i == wallpaper_selected) ? THEME_ACCENT : THEME_BORDER;
        gfx_rounded_rect_outline(sx, sy, swatch_w, swatch_h, 8, border);
        if ((int)i == wallpaper_selected)
            gfx_rounded_rect_outline(sx-1, sy-1, swatch_w+2, swatch_h+2, 9, THEME_ACCENT);

        gfx_string(sx, sy + swatch_h + 4, wallpapers[i].name, THEME_TEXT_DIM, THEME_PANEL, 0);
    }
    gfx_clear_clip();
    scroll_draw_bar(x + w - 14, y + 36, view_h, wallpaper_scroll, content_h, view_h,
                    THEME_PANEL_ALT, THEME_BORDER);
}

static void app_wallpaper_click(i32 rx, i32 ry) {
    i32 swatch_w = 130, swatch_h = 80, gap = 14;
    i32 w = windows[APP_WALLPAPER].w;
    i32 cols = (w - 24) / (swatch_w + gap);
    if (cols < 1) cols = 1;

    for (u32 i = 0; i < WALLPAPER_COUNT; i++) {
        i32 col = (i32)i % cols, row = (i32)i / cols;
        i32 sx = 12 + col * (swatch_w + gap);
        i32 sy = 36 + row * (swatch_h + 30) - wallpaper_scroll;
        if (ui_point_in(rx, ry, sx, sy, swatch_w, swatch_h)) {
            wallpaper_selected = (int)i;
            desktop_set_wallpaper(wallpapers[i].mode, wallpapers[i].a, wallpapers[i].b,
                                   wallpapers[i].c, wallpapers[i].d, wallpapers[i].bitmap);
            return;
        }
    }
}

static void app_wallpaper_wheel(i32 delta) {
    i32 h = windows[APP_WALLPAPER].h;
    i32 swatch_w = 130, swatch_h = 80, gap = 14;
    i32 w = windows[APP_WALLPAPER].w;
    i32 cols = (w - 24) / (swatch_w + gap);
    if (cols < 1) cols = 1;
    i32 rows = ((i32)WALLPAPER_COUNT + cols - 1) / cols;
    i32 content_h = rows * (swatch_h + 30);
    i32 view_h = h - 36;
    wallpaper_scroll = scroll_clamp(wallpaper_scroll - delta * 40, content_h, view_h);
}

#define SNAKE_GRID_W 28
#define SNAKE_GRID_H 18
#define SNAKE_CELL   16
#define SNAKE_MAXLEN (SNAKE_GRID_W * SNAKE_GRID_H)

typedef struct { i8 x, y; } snake_pt_t;
static snake_pt_t snake_body[SNAKE_MAXLEN];
static int snake_len;
static int snake_dir;
static int snake_pending_dir;
static snake_pt_t snake_food;
static int snake_score;
static int snake_over;
static u32 snake_last_move_tick;
static u32 snake_seed = 12345;
static int snake_started = 0;

static u32 snake_rand(void) {
    snake_seed = snake_seed * 1103515245u + 12345u;
    return (snake_seed >> 8) & 0x7FFFFFFFu;
}

static int snake_occupied(i32 gx, i32 gy) {
    for (int i = 0; i < snake_len; i++)
        if (snake_body[i].x == gx && snake_body[i].y == gy) return 1;
    return 0;
}

static void snake_spawn_food(void) {
    for (int tries = 0; tries < 200; tries++) {
        i32 gx = (i32)(snake_rand() % SNAKE_GRID_W);
        i32 gy = (i32)(snake_rand() % SNAKE_GRID_H);
        if (!snake_occupied(gx, gy)) {
            snake_food.x = (i8)gx; snake_food.y = (i8)gy;
            return;
        }
    }
    snake_food.x = 0; snake_food.y = 0;
}

static void snake_reset(void) {
    snake_len = 3;
    snake_body[0].x = SNAKE_GRID_W / 2;     snake_body[0].y = SNAKE_GRID_H / 2;
    snake_body[1].x = SNAKE_GRID_W / 2 - 1; snake_body[1].y = SNAKE_GRID_H / 2;
    snake_body[2].x = SNAKE_GRID_W / 2 - 2; snake_body[2].y = SNAKE_GRID_H / 2;
    snake_dir = 3; snake_pending_dir = 3;
    snake_score = 0;
    snake_over = 0;
    snake_last_move_tick = ticks_get();
    snake_spawn_food();
    snake_started = 1;
}

static void snake_step(void) {
    snake_dir = snake_pending_dir;
    i32 dx = 0, dy = 0;
    switch (snake_dir) {
        case 0: dy = -1; break;
        case 1: dy = 1; break;
        case 2: dx = -1; break;
        case 3: dx = 1; break;
    }
    i32 nx = snake_body[0].x + dx;
    i32 ny = snake_body[0].y + dy;

    if (nx < 0 || ny < 0 || nx >= SNAKE_GRID_W || ny >= SNAKE_GRID_H ||
        snake_occupied(nx, ny)) {
        snake_over = 1;
        return;
    }

    int grew = (nx == snake_food.x && ny == snake_food.y);
    for (int i = (grew ? snake_len : snake_len - 1); i > 0; i--) snake_body[i] = snake_body[i-1];
    snake_body[0].x = (i8)nx; snake_body[0].y = (i8)ny;
    if (grew) {
        snake_len++;
        snake_score += 10;
        if (snake_len < SNAKE_MAXLEN) snake_spawn_food();
    }
}

static void app_snake_draw(i32 x, i32 y, i32 w, i32 h) {
    (void)w; (void)h;
    if (!snake_started) snake_reset();

    if (!snake_over) {
        u32 now = ticks_get();
        if (now - snake_last_move_tick >= 12) {
            snake_step();
            snake_last_move_tick = now;
        }
    }

    i32 gx0 = x + 12, gy0 = y + 36;
    gfx_rect(gx0 - 2, gy0 - 2, SNAKE_GRID_W * SNAKE_CELL + 4, SNAKE_GRID_H * SNAKE_CELL + 4, RGB(20,24,18));

    gfx_rect(gx0 + snake_food.x * SNAKE_CELL, gy0 + snake_food.y * SNAKE_CELL,
              SNAKE_CELL - 1, SNAKE_CELL - 1, RGB(220,70,60));

    for (int i = 0; i < snake_len; i++) {
        color_t c = (i == 0) ? RGB(140,230,120) : RGB(90,190,90);
        gfx_rect(gx0 + snake_body[i].x * SNAKE_CELL, gy0 + snake_body[i].y * SNAKE_CELL,
                  SNAKE_CELL - 1, SNAKE_CELL - 1, c);
    }

    char buf[32] = "Score: ";
    char n[12]; u32_to_str((u32)snake_score, n); str_cat(buf, n, 32);
    gfx_string(x + 12, y + 10, buf, THEME_TEXT, THEME_PANEL, 0);

    if (snake_over) {
        gfx_string(x + 200, y + 10, "GAME OVER -- press R to restart",
                   THEME_DANGER, THEME_PANEL, 0);
    } else {
        gfx_string(x + 200, y + 10, "arrow keys to move",
                   THEME_TEXT_FAINT, THEME_PANEL, 0);
    }
}

static void app_snake_key(int key) {
    if (snake_over) {
        if (key == 'r' || key == 'R') snake_reset();
        return;
    }
    int want = snake_dir;
    if (key == KEY_UP) want = 0;
    else if (key == KEY_DOWN) want = 1;
    else if (key == KEY_LEFT) want = 2;
    else if (key == KEY_RIGHT) want = 3;
    else return;

    static const int opposite[4] = {1,0,3,2};
    if (snake_len > 1 && want == opposite[snake_dir]) return;
    snake_pending_dir = want;
}



static const color_t G2048_COLS[12] = {
    {214,205,196},{236,228,218},{234,222,200},{240,180,120},{242,150,100},
    {240,124,94},{240,96,72},{236,206,116},{236,202,96},{236,198,80},
    {236,194,64},{100,190,140}
};
static int g2048[4][4];
static u32 g2048_score = 0;
static int g2048_state = -1;

static void g2048_spawn(void) {
    int empty[16], n = 0;
    for (int i = 0; i < 16; i++) if (((int*)g2048)[i] == 0) empty[n++] = i;
    if (!n) return;
    int idx = empty[snake_rand() % n];
    ((int*)g2048)[idx] = (snake_rand() % 10 == 0) ? 4 : 2;
}
static void g2048_reset(void) {
    for (int i = 0; i < 16; i++) ((int*)g2048)[i] = 0;
    g2048_score = 0; g2048_state = 0;
    g2048_spawn(); g2048_spawn();
}
static int g2048_move(int dir) {
    int moved = 0;
    for (int line = 0; line < 4; line++) {
        int v[4];
        for (int i = 0; i < 4; i++) {
            int r, c;
            if (dir == 0) { r = line; c = i; } else if (dir == 1) { r = line; c = 3 - i; }
            else if (dir == 2) { r = i; c = line; } else { r = 3 - i; c = line; }
            v[i] = g2048[r][c];
        }
        int out[4] = {0,0,0,0}, oi = 0, merged = -1;
        for (int i = 0; i < 4; i++) {
            if (!v[i]) continue;
            if (oi > 0 && out[oi-1] == v[i] && merged != oi-1) {
                out[oi-1] *= 2; g2048_score += (u32)out[oi-1]; merged = oi-1;
                if (out[oi-1] == 2048 && g2048_state == 0) g2048_state = 2;
            } else out[oi++] = v[i];
        }
        for (int i = 0; i < 4; i++) {
            int r, c;
            if (dir == 0) { r = line; c = i; } else if (dir == 1) { r = line; c = 3 - i; }
            else if (dir == 2) { r = i; c = line; } else { r = 3 - i; c = line; }
            if (g2048[r][c] != out[i]) moved = 1;
            g2048[r][c] = out[i];
        }
    }
    return moved;
}
static int g2048_can_move(void) {
    for (int i = 0; i < 16; i++) if (((int*)g2048)[i] == 0) return 1;
    for (int r = 0; r < 4; r++) for (int c = 0; c < 4; c++) {
        if (c < 3 && g2048[r][c] == g2048[r][c+1]) return 1;
        if (r < 3 && g2048[r][c] == g2048[r+1][c]) return 1;
    }
    return 0;
}
static void app_2048_draw(i32 x, i32 y, i32 w, i32 h) {
    if (g2048_state < 0) g2048_reset();
    gfx_rect(x, y, w, h, THEME_WINDOW);
    gfx_string(x + 16, y + 14, "2048", THEME_TEXT, THEME_WINDOW, 1);
    char sb[24]; str_copy(sb, "Score: ", 24); char nb[12]; u32_to_str(g2048_score, nb); str_cat(sb, nb, 24);
    gfx_string(x + w - 150, y + 16, sb, THEME_TEXT_DIM, THEME_WINDOW, 0);
    gfx_string(x + 16, y + 40, "Arrow keys to move. Click to restart.", THEME_TEXT_FAINT, THEME_WINDOW, 0);

    i32 pad = 10, top = y + 62;
    i32 avail = (w < (h - 72) ? w : (h - 72)) - 24;
    i32 cell = (avail - pad * 5) / 4;
    i32 bx = x + (w - (cell * 4 + pad * 5)) / 2;
    gfx_rounded_rect(bx, top, cell * 4 + pad * 5, cell * 4 + pad * 5, 10, THEME_PANEL_ALT);
    for (int r = 0; r < 4; r++) for (int c = 0; c < 4; c++) {
        i32 cx = bx + pad + c * (cell + pad);
        i32 cy = top + pad + r * (cell + pad);
        int val = g2048[r][c];
        int lg = 0, t = val; while (t > 1) { t >>= 1; lg++; }
        color_t tc = val == 0 ? THEME_PANEL : G2048_COLS[lg < 12 ? lg : 11];
        gfx_rounded_rect(cx, cy, cell, cell, 6, tc);
        if (val) {
            char vb[8]; u32_to_str((u32)val, vb);
            int tw = gfx_string_width(vb);
            color_t txt = val <= 4 ? RGB(90,84,78) : RGB(255,255,255);
            gfx_string(cx + (cell - tw)/2, cy + (cell - 16)/2, vb, txt, tc, 0);
        }
    }
    if (g2048_state == 1 || g2048_state == 2) {
        const char* m = g2048_state == 2 ? "You reached 2048!" : "Game over";
        int tw = gfx_string_width(m);
        gfx_string(x + (w - tw)/2, top + cell*2, m, g2048_state==2?THEME_SUCCESS:THEME_DANGER, THEME_PANEL_ALT, 1);
    }
}
static void app_2048_key(int key) {
    if (g2048_state != 0) { if (key) g2048_reset(); return; }
    int dir = -1;
    if (key == KEY_LEFT) dir = 0; else if (key == KEY_RIGHT) dir = 1;
    else if (key == KEY_UP) dir = 2; else if (key == KEY_DOWN) dir = 3;
    if (dir < 0) return;
    if (g2048_move(dir)) { g2048_spawn(); if (!g2048_can_move()) g2048_state = 1; }
}
static void app_2048_click(i32 rx, i32 ry) { (void)rx; (void)ry; g2048_reset(); }

#define MS_N 9
#define MS_MINES 10
static u8 ms_mine[MS_N][MS_N], ms_open[MS_N][MS_N], ms_flag[MS_N][MS_N];
static int ms_state = -1, ms_started = 0, ms_left = 0;
static void ms_reset(void) {
    for (int r = 0; r < MS_N; r++) for (int c = 0; c < MS_N; c++) { ms_mine[r][c]=0; ms_open[r][c]=0; ms_flag[r][c]=0; }
    ms_state = 0; ms_started = 0; ms_left = MS_N*MS_N - MS_MINES;
}
static int ms_adj(int r, int c) {
    int n = 0;
    for (int dr=-1;dr<=1;dr++) for (int dc=-1;dc<=1;dc++) {
        int nr=r+dr,nc=c+dc; if(nr<0||nr>=MS_N||nc<0||nc>=MS_N||(dr==0&&dc==0)) continue;
        if (ms_mine[nr][nc]) n++;
    }
    return n;
}
static void ms_place(int ar, int ac) {
    int placed = 0;
    while (placed < MS_MINES) {
        int r = snake_rand()%MS_N, c = snake_rand()%MS_N;
        if (ms_mine[r][c] || (r==ar&&c==ac)) continue;
        ms_mine[r][c] = 1; placed++;
    }
    ms_started = 1;
}
static void ms_reveal(int r, int c) {
    if (r<0||r>=MS_N||c<0||c>=MS_N||ms_open[r][c]||ms_flag[r][c]) return;
    ms_open[r][c] = 1;
    if (ms_mine[r][c]) { ms_state = 1; return; }
    ms_left--;
    if (ms_left <= 0) ms_state = 2;
    if (ms_adj(r,c) == 0)
        for (int dr=-1;dr<=1;dr++) for (int dc=-1;dc<=1;dc++) ms_reveal(r+dr,c+dc);
}
static const color_t MS_NUMCOL[8] = {
    {53,132,228},{46,140,80},{224,74,74},{120,60,200},{200,120,40},{40,160,180},{80,80,90},{160,60,60}
};
static void ms_geom(i32 x, i32 y, i32 w, i32 h, i32* ox, i32* oy, i32* ocell) {
    i32 top = y + 56;
    i32 avail = (w < (h-66) ? w : (h-66)) - 24;
    i32 cell = avail / MS_N;
    *ocell = cell; *ox = x + (w - cell*MS_N)/2; *oy = top;
}
static void app_mines_draw(i32 x, i32 y, i32 w, i32 h) {
    if (ms_state < 0) ms_reset();
    gfx_rect(x, y, w, h, THEME_WINDOW);
    gfx_string(x + 16, y + 14, "Minesweeper", THEME_TEXT, THEME_WINDOW, 1);
    const char* st = ms_state==1 ? "Boom! Click to restart." : ms_state==2 ? "Cleared! Click to restart." : "Left-click reveal, right-click flag.";
    gfx_string(x + 16, y + 36, st, ms_state==1?THEME_DANGER:ms_state==2?THEME_SUCCESS:THEME_TEXT_FAINT, THEME_WINDOW, 0);
    i32 bx, by, cell; ms_geom(x,y,w,h,&bx,&by,&cell);
    for (int r=0;r<MS_N;r++) for (int c=0;c<MS_N;c++) {
        i32 cx = bx + c*cell, cy = by + r*cell;
        int op = ms_open[r][c];
        color_t bg = op ? THEME_PANEL : THEME_PANEL_ALT;
        if (op && ms_mine[r][c]) bg = THEME_DANGER;
        gfx_rounded_rect(cx+1, cy+1, cell-2, cell-2, 3, bg);
        if (!op) gfx_rounded_rect_outline(cx+1, cy+1, cell-2, cell-2, 3, THEME_BORDER);
        if (op && !ms_mine[r][c]) {
            int a = ms_adj(r,c);
            if (a > 0) { char nb[2]={(char)('0'+a),0}; gfx_string(cx+(cell-8)/2, cy+(cell-16)/2, nb, MS_NUMCOL[a-1], bg, 0); }
        } else if (op && ms_mine[r][c]) {
            gfx_circle_fill(cx+cell/2, cy+cell/2, cell/5, RGB(20,20,24));
        } else if (ms_flag[r][c]) {
            gfx_rect(cx+cell/2, cy+cell/4, 2, cell/2, RGB(60,60,70));
            gfx_rounded_rect(cx+cell/2, cy+cell/4, cell/4, cell/6, 1, THEME_DANGER);
        }
    }
}
static void app_mines_click(i32 rx, i32 ry) {
    if (ms_state != 0) { ms_reset(); return; }
    i32 w = windows[APP_MINES].w, h = windows[APP_MINES].h;
    i32 bx, by, cell; ms_geom(0,0,w,h,&bx,&by,&cell);
    int c = (rx - bx)/cell, r = (ry - by)/cell;
    if (r<0||r>=MS_N||c<0||c>=MS_N||rx<bx||ry<by) return;
    if (ms_flag[r][c]) return;
    if (!ms_started) ms_place(r,c);
    ms_reveal(r,c);
}
static void app_mines_rclick(i32 rx, i32 ry) {
    if (ms_state != 0) return;
    i32 w = windows[APP_MINES].w, h = windows[APP_MINES].h;
    i32 bx, by, cell; ms_geom(0,0,w,h,&bx,&by,&cell);
    int c = (rx - bx)/cell, r = (ry - by)/cell;
    if (r<0||r>=MS_N||c<0||c>=MS_N||rx<bx||ry<by||ms_open[r][c]) return;
    ms_flag[r][c] = !ms_flag[r][c];
}

#define LF_W 44
#define LF_H 30
static u8 lf[LF_H][LF_W], lf_tmp[LF_H][LF_W];
static int lf_running = 0, lf_init = 0;
static u32 lf_last = 0;
int life_is_running(void) { return lf_running; }
static void lf_clear(void) { for (int r=0;r<LF_H;r++) for (int c=0;c<LF_W;c++) lf[r][c]=0; }
static void lf_random(void) { for (int r=0;r<LF_H;r++) for (int c=0;c<LF_W;c++) lf[r][c] = (snake_rand()%100 < 28) ? 1 : 0; }
static void lf_step(void) {
    for (int r=0;r<LF_H;r++) for (int c=0;c<LF_W;c++) {
        int n = 0;
        for (int dr=-1;dr<=1;dr++) for (int dc=-1;dc<=1;dc++) {
            if (dr==0&&dc==0) continue;
            int nr=(r+dr+LF_H)%LF_H, nc=(c+dc+LF_W)%LF_W;
            n += lf[nr][nc];
        }
        lf_tmp[r][c] = (lf[r][c] ? (n==2||n==3) : (n==3)) ? 1 : 0;
    }
    for (int r=0;r<LF_H;r++) for (int c=0;c<LF_W;c++) lf[r][c]=lf_tmp[r][c];
}
static void lf_geom(i32 x, i32 y, i32 w, i32 h, i32* ox, i32* oy, i32* ocell) {
    i32 top = y + 66;
    i32 cw = (w - 24) / LF_W, ch = (h - 76) / LF_H;
    i32 cell = cw < ch ? cw : ch;
    *ocell = cell; *ox = x + (w - cell*LF_W)/2; *oy = top;
}
static void app_life_draw(i32 x, i32 y, i32 w, i32 h) {
    if (!lf_init) { lf_random(); lf_init = 1; }
    if (lf_running && ticks_get() - lf_last >= ticks_per_sec()/12) { lf_step(); lf_last = ticks_get(); }
    gfx_rect(x, y, w, h, THEME_WINDOW);
    gfx_string(x + 16, y + 14, "Game of Life", THEME_TEXT, THEME_WINDOW, 1);
    ui_button(x + 16, y + 34, 70, 24, lf_running ? "Pause" : "Run", 0);
    ui_button(x + 92, y + 34, 60, 24, "Step", 0);
    ui_button(x + 158, y + 34, 70, 24, "Random", 0);
    ui_button(x + 234, y + 34, 60, 24, "Clear", 0);
    gfx_string(x + 306, y + 40, "Click cells to toggle", THEME_TEXT_FAINT, THEME_WINDOW, 0);
    i32 bx, by, cell; lf_geom(x,y,w,h,&bx,&by,&cell);
    gfx_rect(bx-1, by-1, cell*LF_W+2, cell*LF_H+2, THEME_PANEL_ALT);
    for (int r=0;r<LF_H;r++) for (int c=0;c<LF_W;c++) {
        if (lf[r][c]) gfx_rect(bx + c*cell, by + r*cell, cell-1, cell-1, THEME_ACCENT);
    }
}
static void app_life_click(i32 rx, i32 ry) {
    i32 w = windows[APP_LIFE].w, h = windows[APP_LIFE].h;
    if (ui_point_in(rx, ry, 16, 34, 70, 24)) { lf_running = !lf_running; return; }
    if (ui_point_in(rx, ry, 92, 34, 60, 24)) { lf_step(); return; }
    if (ui_point_in(rx, ry, 158, 34, 70, 24)) { lf_random(); return; }
    if (ui_point_in(rx, ry, 234, 34, 60, 24)) { lf_clear(); lf_running = 0; return; }
    i32 bx, by, cell; lf_geom(0,0,w,h,&bx,&by,&cell);
    int c = (rx - bx)/cell, r = (ry - by)/cell;
    if (r>=0&&r<LF_H&&c>=0&&c<LF_W&&rx>=bx&&ry>=by) lf[r][c] = !lf[r][c];
}
static void app_life_key(int key) {
    if (key == ' ') lf_running = !lf_running;
    else if (key == 's' || key == 'S') lf_step();
    else if (key == 'c' || key == 'C') { lf_clear(); lf_running = 0; }
    else if (key == 'r' || key == 'R') lf_random();
}

static void app_files_rclick(i32 rx, i32 ry) { files_activate_at(rx, ry); }

static const color_t DS_SWATCH[6] = {
    {53, 132, 228}, {120, 80, 255}, {46, 170, 110}, {240, 150, 40}, {230, 80, 140}, {225, 70, 70}
};

static void ds_int_str(int v, char* out) {
    char rev[8]; int n = v, len = 0;
    if (n == 0) { out[0] = '0'; out[1] = 0; return; }
    while (n > 0 && len < 7) { rev[len++] = (char)('0' + n % 10); n /= 10; }
    int k = 0; for (; k < len; k++) out[k] = rev[len - 1 - k]; out[k] = 0;
}

static int ds_tab = 0;   /* 0 = Look, 1 = Power */

static void app_desksettings_draw(i32 x, i32 y, i32 w, i32 h) {
    (void)h;
    i32 pad = 18;
    i32 cx = x + pad;
    i32 cw = w - pad * 2;
    i32 ry = y + 12;

    /* tab bar */
    {
        static const char* TABS[2] = { "Look", "Power" };
        i32 tw = cw / 2, th = 26;
        for (int i = 0; i < 2; i++) {
            if (ui_button(cx + i * tw, ry, tw - 4, th, TABS[i], ds_tab == i)) ds_tab = i;
        }
    }
    ry += 40;

    if (ds_tab == 0) {
        /* Theme */
        gfx_string(cx, ry, "Theme", THEME_TEXT_DIM, THEME_WINDOW, 0);
        ry += 20;
        {
            i32 bw = (cw - 10) / 2, bh = 28;
            int light = (theme_get_mode() == THEME_MODE_LIGHT);
            if (ui_button(cx, ry, bw, bh, "Light", light)) { theme_set_mode(THEME_MODE_LIGHT); desktop_set_accent(desktop_get_accent()); }
            if (ui_button(cx + bw + 10, ry, bw, bh, "Dark", !light)) { theme_set_mode(THEME_MODE_DARK); desktop_set_accent(desktop_get_accent()); }
        }
        ry += 40;

        /* Accent */
        gfx_string(cx, ry, "Accent color", THEME_TEXT_DIM, THEME_WINDOW, 0);
        ry += 20;
        {
            i32 sw = 32, gap = (cw - sw * 6) / 5;
            int sel = desktop_get_accent();
            for (int i = 0; i < 6; i++) {
                i32 sx = cx + i * (sw + gap);
                gfx_rounded_rect(sx, ry, sw, sw, 8, DS_SWATCH[i]);
                if (i == sel) gfx_rounded_rect_outline(sx - 2, ry - 2, sw + 4, sw + 4, 9, THEME_TEXT);
                if (ui_point_in(mouse_x(), mouse_y(), sx, ry, sw, sw) && mouse_left_pressed())
                    desktop_set_accent(i);
            }
        }
        ry += 46;

        /* Wallpaper picker */
        gfx_string(cx, ry, "Wallpaper", THEME_TEXT_DIM, THEME_WINDOW, 0);
        ry += 20;
        {
            if (ui_button(cx, ry, 190, 30, "Open Wallpapers", 0)) desktop_open_app(APP_WALLPAPER);
            gfx_string(cx + 200, ry + 8, "Choose a photo background", THEME_TEXT_FAINT, THEME_WINDOW, 0);
            ry += 40;
        }

        /* Taskbar */
        gfx_string(cx, ry, "Taskbar", THEME_TEXT_DIM, THEME_WINDOW, 0);
        ry += 20;
        {
            i32 bw = 38, bh = 26;
            if (ui_button(cx, ry, bw, bh, "-", 0)) desktop_set_taskbar_opacity(desktop_get_taskbar_opacity() - 5);
            char val[10]; ds_int_str(desktop_get_taskbar_opacity(), val);
            int vl = (int)str_len(val); val[vl] = '%'; val[vl + 1] = 0;
            gfx_string(cx + bw + 12, ry + 6, val, THEME_TEXT, THEME_WINDOW, 0);
            if (ui_button(cx + bw + 60, ry, bw, bh, "+", 0)) desktop_set_taskbar_opacity(desktop_get_taskbar_opacity() + 5);
            int top = desktop_get_taskbar_position();
            if (ui_button(cx + cw - 120, ry, 58, bh, "Bottom", !top)) desktop_set_taskbar_position(0);
            if (ui_button(cx + cw - 58, ry, 58, bh, "Top", top)) desktop_set_taskbar_position(1);
        }
        return;
    }

    if (ds_tab == 1) {
        battery_status_t b;
        battery_read(&b);

        gfx_string(cx, ry, "Battery", THEME_TEXT_DIM, THEME_WINDOW, 0);
        ry += 22;
        if (b.present) {
            char line[64];
            ds_int_str(b.percent, line);
            int l = (int)str_len(line); line[l] = '%'; line[l + 1] = 0;
            str_cat(line, b.charging ? "  (charging)" : (b.ac_online ? "  (on AC)" : "  (on battery)"),
                    sizeof(line));
            gfx_string(cx, ry, line, THEME_TEXT, THEME_WINDOW, 0);
            /* gauge */
            i32 gw = cw, gh = 16;
            gfx_rounded_rect(cx, ry + 20, gw, gh, 5, THEME_PANEL_ALT);
            i32 fill = (gw * (b.percent < 0 ? 0 : b.percent > 100 ? 100 : b.percent)) / 100;
            color_t bc = (b.percent < 20) ? THEME_DANGER : (b.percent < 50 ? THEME_WARNING : THEME_SUCCESS);
            if (fill > 0) gfx_rounded_rect(cx, ry + 20, fill, gh, 5, bc);
            ry += 48;
        } else {
            gfx_string(cx, ry, "No battery detected (desktop or VM).", THEME_TEXT_DIM, THEME_WINDOW, 0);
            ry += 30;
        }

        gfx_string(cx, ry, "Power mode", THEME_TEXT_DIM, THEME_WINDOW, 0);
        ry += 20;
        {
            i32 bw = (cw - 10) / 2, bh = 28;
            int ps = desktop_get_power_saver();
            if (ui_button(cx, ry, bw, bh, "Balanced", !ps)) desktop_set_power_saver(0);
            if (ui_button(cx + bw + 10, ry, bw, bh, "Power saver", ps)) desktop_set_power_saver(1);
        }
        ry += 42;

        gfx_string(cx, ry, "Display sleep", THEME_TEXT_DIM, THEME_WINDOW, 0);
        ry += 20;
        {
            static const int MINS[4] = { 0, 5, 15, 30 };
            static const char* LBL[4] = { "Never", "5 min", "15 min", "30 min" };
            i32 bw = (cw - 18) / 4, bh = 28;
            int cur = desktop_get_sleep_minutes();
            for (int i = 0; i < 4; i++)
                if (ui_button(cx + i * (bw + 6), ry, bw, bh, LBL[i], cur == MINS[i]))
                    desktop_set_sleep_minutes(MINS[i]);
        }
        ry += 42;

        {
            int lk = desktop_get_lock_on_resume();
            if (ui_button(cx, ry, cw, 28,
                          lk ? "Lock on resume: on" : "Lock on resume: off", lk))
                desktop_set_lock_on_resume(!lk);
        }
        return;
    }

}

static void app_desksettings_click(i32 rx, i32 ry) { (void)rx; (void)ry; }

extern void app_calendar_draw(i32,i32,i32,i32); extern void app_calendar_click(i32,i32); extern void app_calendar_key(char);
extern void app_trash_draw(i32,i32,i32,i32);    extern void app_trash_click(i32,i32);
extern void app_writer_draw(i32,i32,i32,i32);   extern void app_writer_click(i32,i32);   extern void app_writer_key(char);
extern void app_sheet_draw(i32,i32,i32,i32);    extern void app_sheet_click(i32,i32);    extern void app_sheet_key(char);
extern void app_media_draw(i32,i32,i32,i32);    extern void app_media_click(i32,i32);
extern void app_ide_draw(i32,i32,i32,i32);      extern void app_ide_click(i32,i32);      extern void app_ide_key(char);
extern void app_compiler_draw(i32,i32,i32,i32); extern void app_compiler_wheel(i32);
extern void compiler_init(void);

app_draw_fn app_draw_table[APP_COUNT] = {
    app_2048_draw, app_clock_draw, app_files_draw, app_editor_draw, app_terminal_draw,
    app_perf_draw, app_wallpaper_draw, app_snake_draw,
    app_browser_draw, app_store_draw, app_settings_draw, app_photos_draw,
    app_accounts_draw, app_installer_draw,
    app_calc_draw, app_paint_draw, app_ttt_draw, app_cube3d_draw,
    app_desksettings_draw, app_mines_draw, app_life_draw,
    0, app_calendar_draw, app_trash_draw, app_writer_draw,
    app_sheet_draw, app_media_draw, app_ide_draw, app_compiler_draw
};
app_click_fn app_click_table[APP_COUNT] = {
    app_2048_click, 0, app_files_click, app_editor_click, 0,
    app_perf_click, app_wallpaper_click, 0,
    app_browser_click, app_store_click, app_settings_click, 0,
    app_accounts_click, app_installer_click,
    app_calc_click, app_paint_click, app_ttt_click, app_cube3d_click,
    0, app_mines_click, app_life_click,
    0, app_calendar_click, app_trash_click, app_writer_click,
    app_sheet_click, app_media_click, app_ide_click, 0
};
app_key_fn app_key_table[APP_COUNT] = {
    app_2048_key, 0, app_files_key, app_editor_key, app_terminal_key,
    0, 0, app_snake_key,
    app_browser_key, app_store_key, 0, 0,
    app_accounts_key, app_installer_key,
    app_calc_key, 0, app_ttt_key, app_cube3d_key,
    0, 0, app_life_key,
    0, app_calendar_key, 0, app_writer_key,
    app_sheet_key, 0, app_ide_key, 0
};
app_drag_fn app_drag_table[APP_COUNT] = {
    0, 0, app_files_drag, 0, 0,
    0, 0, 0,
    app_browser_drag, app_store_drag, app_settings_drag, 0,
    0, 0,
    0, app_paint_drag, 0, 0,
    0
};
app_wheel_fn app_wheel_table[APP_COUNT] = {
    0, 0, app_files_wheel, 0, app_terminal_wheel,
    0, app_wallpaper_wheel, 0,
    app_browser_wheel, app_store_wheel, app_settings_wheel, 0,
    0, 0,
    0, 0, 0, 0,
    0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, app_compiler_wheel
};

app_click_fn app_rclick_table[APP_COUNT] = {
    0, 0, app_files_rclick, 0, 0,
    0, 0, 0,
    app_browser_rclick, 0, 0, 0,
    0, 0,
    0, 0, 0, 0,
    0, app_mines_rclick, 0
};

void apps_init(void) {

    config_init();

    browser_init();
    store_init();
    settings_init();
    photos_init();
    calc_init();
    paint_init();
    ttt_init();
    cube3d_init();
    installer_init();
    compiler_init();

    refresh_disk_free();
    files_refresh();
    term_print("ZapczOS V4 terminal -- type 'help' for commands.");
}
