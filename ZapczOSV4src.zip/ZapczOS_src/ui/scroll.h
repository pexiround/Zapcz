#ifndef SCROLL_H
#define SCROLL_H
#include "io.h"
#include "graphics.h"

i32 scroll_clamp(i32 offset, i32 content_h, i32 view_h);
void scroll_draw_bar(i32 x, i32 y, i32 h, i32 offset, i32 content_h, i32 view_h, color_t track, color_t thumb);
int scroll_bar_hit(i32 rx, i32 ry, i32 x, i32 y, i32 h, i32 content_h, i32 view_h);
i32 scroll_bar_drag_to(i32 ry, i32 y, i32 h, i32 content_h, i32 view_h);

#endif
