#ifndef THEME_H
#define THEME_H
#include "graphics.h"

extern color_t THEME_BG_TOP;
extern color_t THEME_BG_BOTTOM;
extern color_t THEME_PANEL;
extern color_t THEME_PANEL_ALT;
extern color_t THEME_PANEL_RAISED;
extern color_t THEME_BORDER;
extern color_t THEME_ACCENT;
extern color_t THEME_ACCENT_DIM;
extern color_t THEME_ACCENT_TEXT;
extern color_t THEME_TEXT;
extern color_t THEME_TEXT_DIM;
extern color_t THEME_TEXT_FAINT;
extern color_t THEME_SUCCESS;
extern color_t THEME_DANGER;
extern color_t THEME_WARNING;

extern color_t THEME_TASKBAR;
extern color_t THEME_WINDOW;
extern color_t THEME_SEP;
extern color_t THEME_INPUT;

extern color_t GLASS_WIN_TINT;   extern int GLASS_WIN_OPA;
extern color_t GLASS_TASK_TINT;  extern int GLASS_TASK_OPA;
extern color_t GLASS_POPUP_TINT; extern int GLASS_POPUP_OPA;

extern color_t THEME_TITLEBAR_TOP;
extern color_t THEME_TITLEBAR_BOT;
extern color_t THEME_TITLEBAR_FOCUS;
extern color_t THEME_GLOW_BORDER;
extern color_t THEME_GLOW_DIM;

#define THEME_MODE_DARK  0
#define THEME_MODE_LIGHT 1

#define THEME_RADIUS_WIN  14
#define THEME_RADIUS_CTRL 7

void theme_set_mode(int mode);
int  theme_get_mode(void);

#endif
