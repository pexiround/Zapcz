#include "zapcc.h"
#include "apps.h"
#include "desktop.h"
#include "graphics.h"
#include "theme.h"
#include "keyboard.h"
#include "fat32.h"
#include "util.h"
#include "libc_shim.h"
#include "pit.h"

#define CC_FILES_MAX 64
#define CC_SRC_MAX   49152
#define CC_LOG_MAX   26

#define TAB_BUILD 0
#define TAB_SUPPORTED 1

static fat_dirent_t cc_files[CC_FILES_MAX];
static int  cc_count;
static int  cc_sel = -1;
static int  cc_scroll;
static int  cc_tab = TAB_BUILD;
static int  cc_out_scroll;
static int  cc_ref_scroll;

static char cc_log[CC_LOG_MAX][80];
static int  cc_log_n;

static u8   cc_src[CC_SRC_MAX];
static u8   cc_img[ZAP_IMAGE_MAX];
static u32  cc_img_size;
static int  cc_have_img;
static char cc_img_name[16];
static int  cc_show_canvas;

static void cc_logline(const char* s) {
    if (cc_log_n >= CC_LOG_MAX) {
        for (int i = 1; i < CC_LOG_MAX; i++) str_copy(cc_log[i - 1], cc_log[i], 80);
        cc_log_n = CC_LOG_MAX - 1;
    }
    str_copy(cc_log[cc_log_n++], s, 80);
}

static void cc_log2(const char* a, const char* b) {
    char line[80];
    str_copy(line, a, sizeof(line));
    str_cat(line, b, sizeof(line));
    cc_logline(line);
}

static void cc_log_num(const char* a, u32 v, const char* b) {
    char line[80];
    char n[16];
    str_copy(line, a, sizeof(line));
    u32_to_str(v, n);
    str_cat(line, n, sizeof(line));
    if (b) str_cat(line, b, sizeof(line));
    cc_logline(line);
}

static int name_ends(const char* name, const char* ext) {
    u32 n = str_len(name), e = str_len(ext);
    if (n < e + 1) return 0;
    if (name[n - e - 1] != '.') return 0;
    for (u32 i = 0; i < e; i++) {
        char a = name[n - e + i];
        char b = ext[i];
        if (a >= 'a' && a <= 'z') a = (char)(a - 32);
        if (b >= 'a' && b <= 'z') b = (char)(b - 32);
        if (a != b) return 0;
    }
    return 1;
}

static void cc_rescan(void) {
    static fat_dirent_t all[128];
    int n = fat32_list_dir(FAT32_ROOT_ID, all, 128);
    cc_count = 0;
    for (int i = 0; i < n && cc_count < CC_FILES_MAX; i++) {
        if (all[i].is_dir) continue;
        if (name_ends(all[i].display_name, "C") || name_ends(all[i].display_name, "ZAP"))
            cc_files[cc_count++] = all[i];
    }
    if (cc_sel >= cc_count) cc_sel = -1;
}

void compiler_init(void) {
    cc_log_n = 0;
    cc_have_img = 0;
    cc_img_size = 0;
    cc_show_canvas = 0;
    cc_img_name[0] = 0;
    zrt_reset();
    cc_rescan();
    cc_logline("ZapCC - the ZapczOS C compiler.");
    cc_logline("Pick a .c file, press Compile, then Run.");
    cc_logline("Compiling writes a .ZAP executable to disk.");
}

static void zap_out_name(const char* src_name, char* out, u32 outlen) {
    u32 i = 0;
    while (src_name[i] && src_name[i] != '.' && i < 8 && i + 1 < outlen) {
        char c = src_name[i];
        if (c >= 'a' && c <= 'z') c = (char)(c - 32);
        out[i] = c;
        i++;
    }
    out[i] = 0;
    str_cat(out, ".ZAP", outlen);
}

static void cc_do_compile(void) {
    if (cc_sel < 0 || cc_sel >= cc_count) { cc_logline("Select a .c file first."); return; }
    fat_dirent_t* f = &cc_files[cc_sel];
    if (!name_ends(f->display_name, "C")) { cc_logline("That is not a .c source file."); return; }

    cc_log_n = 0;
    cc_have_img = 0;
    cc_show_canvas = 0;
    cc_log2("Compiling ", f->display_name);

    int n = fat32_read_file(f, cc_src, CC_SRC_MAX - 1);
    if (n <= 0) { cc_logline("Could not read the source file."); return; }
    cc_src[n] = 0;
    cc_log_num("Source: ", (u32)n, " bytes");

    u32 sz = 0;
    if (!zapcc_compile((const char*)cc_src, (u32)n, cc_img, ZAP_IMAGE_MAX, &sz)) {
        char line[80];
        str_copy(line, "ERROR", sizeof(line));
        if (zapcc_error_line() > 0) {
            char nb[12];
            u32_to_str((u32)zapcc_error_line(), nb);
            str_cat(line, " on line ", sizeof(line));
            str_cat(line, nb, sizeof(line));
        }
        str_cat(line, ": ", sizeof(line));
        str_cat(line, zapcc_error(), sizeof(line));
        cc_logline(line);
        cc_logline("See the 'Supported C' tab for what ZapCC accepts.");
        return;
    }

    cc_img_size = sz;
    cc_have_img = 1;
    cc_log_num("Machine code: ", zapcc_stat_code(), " bytes");
    cc_log_num("Functions: ", (u32)zapcc_stat_funcs(), 0);
    cc_log_num("Globals: ", (u32)zapcc_stat_globals(), 0);

    zap_out_name(f->display_name, cc_img_name, sizeof(cc_img_name));
    if (fat32_write_file(cc_img_name, cc_img, sz) > 0) {
        cc_log2("Wrote ", cc_img_name);
    } else {
        cc_logline("Compiled OK but could not write the .ZAP file.");
    }
    cc_logline("Compile succeeded. Press Run.");
    cc_rescan();
}

static void cc_do_run(void) {
    if (!cc_have_img) {
        if (cc_sel >= 0 && cc_sel < cc_count && name_ends(cc_files[cc_sel].display_name, "ZAP")) {
            int n = fat32_read_file(&cc_files[cc_sel], cc_img, ZAP_IMAGE_MAX);
            if (n <= 0) { cc_logline("Could not read that .ZAP file."); return; }
            cc_img_size = (u32)n;
            cc_have_img = 1;
            str_copy(cc_img_name, cc_files[cc_sel].display_name, sizeof(cc_img_name));
        } else {
            cc_logline("Nothing to run - compile a .c file first.");
            return;
        }
    }
    zrt_reset();
    cc_out_scroll = 0;
    int rc = 0;
    if (!zap_run(cc_img, cc_img_size, &rc)) {
        cc_log2("Run failed: ", zap_run_error());
        return;
    }
    cc_show_canvas = zrt_canvas_used();
    cc_log_num("Program finished, exit code ", (u32)rc, 0);
}

static void cc_new_sample(void) {
    static const char sample[] =
        "int square(int n) { return n * n; }\n"
        "\n"
        "int main() {\n"
        "    print(\"squares: \");\n"
        "    for (int i = 1; i <= 8; i++) {\n"
        "        print_int(square(i));\n"
        "        put_char(32);\n"
        "    }\n"
        "    print(\"\\n\");\n"
        "    return 0;\n"
        "}\n";
    if (fat32_write_file("HELLO.C", (const u8*)sample, sizeof(sample) - 1) > 0) {
        cc_logline("Created HELLO.C - select it and press Compile.");
        cc_rescan();
        for (int i = 0; i < cc_count; i++)
            if (str_eq_ci(cc_files[i].display_name, "HELLO.C")) { cc_sel = i; break; }
    } else {
        cc_logline("Could not create HELLO.C.");
    }
}

#define CC_TAB_Y   8
#define CC_TAB_H   24
#define CC_LIST_Y  42
#define CC_ROW_H   18
#define CC_ROWS    7
#define CC_BTN_Y   (CC_LIST_Y + CC_ROWS * CC_ROW_H + 8)
#define CC_BTN_H   26
#define CC_OUT_Y   (CC_BTN_Y + CC_BTN_H + 10)

static const char* REF_TEXT[] = {
    "ZapCC - supported C",
    "",
    "ZapCC compiles a C subset straight to 32-bit x86 machine",
    "code and writes a .ZAP executable that ZapczOS can run.",
    "",
    "TYPES",
    "  int, char, void, long/short (treated as int)",
    "  pointers of any depth:  int *p;  char **q;",
    "  one-dimensional arrays: int a[10];  char buf[64];",
    "  sizeof(type) and sizeof(variable)",
    "  casts: (int)x, (char*)p",
    "  NOT supported: float, double, struct, union, enum,",
    "  typedef, 2D arrays. There is no FPU in the kernel, so",
    "  all arithmetic is 32-bit integer. 5/3 is 1.",
    "",
    "STATEMENTS",
    "  if / else, while, do..while, for, break, continue",
    "  return, blocks, local and global declarations",
    "  local init: int x = 5;  int a[3] = {1,2,3};",
    "  global init: constants and string literals only",
    "",
    "OPERATORS",
    "  + - * / %   and the compound forms += -= *= /= %=",
    "  &= |= ^= <<= >>=",
    "  == != < <= > >=   && || !   & | ^ ~ << >>",
    "  ++ -- (prefix and postfix), ?: ternary",
    "  * dereference, & address-of, [] indexing",
    "  pointer arithmetic scales by the element size",
    "",
    "FUNCTIONS",
    "  up to 8 arguments, recursion works, forward calls work",
    "  main() is the entry point and its return value is the",
    "  exit code",
    "",
    "PREPROCESSOR",
    "  // and /* */ comments",
    "  #define NAME value   (object-like macros)",
    "  #include lines are ignored - the library below is",
    "  always available, no header needed",
    "",
    "BUILT-IN LIBRARY",
    "  print(str)          print_int(n)      put_char(c)",
    "  print_line(str)     clear()",
    "  strlen(s)  strcmp(a,b)  strcpy(d,s)  strcat(d,s)",
    "  memset(p,v,n)       memcpy(d,s,n)",
    "  rand()  srand(n)    ticks()   sleep(ms)",
    "  abs(n)  min(a,b)  max(a,b)  sqrt(n)  pow(b,e)",
    "  plot(x,y,r,g,b)     canvas_clear(r,g,b)",
    "  canvas_rect(x,y,w,h,r,g,b)   canvas_on()",
    "  The canvas is 200x120 and appears under the output",
    "  once a program draws to it.",
    "",
    "LIMITS",
    "  source 48 KB, code 64 KB, static data 16 KB,",
    "  192 globals, 96 locals per function, 96 functions.",
    "",
    "EXAMPLE",
    "  int square(int n) { return n * n; }",
    "  int main() {",
    "      for (int i = 1; i <= 5; i++) {",
    "          print_int(square(i));",
    "          put_char(' ');",
    "      }",
    "      print(\"\\n\");",
    "      return 0;",
    "  }",
    0
};

static int ref_line_count(void) {
    int n = 0;
    while (REF_TEXT[n]) n++;
    return n;
}

void app_compiler_draw(i32 x, i32 y, i32 w, i32 h) {
    gfx_rect(x, y, w, h, THEME_WINDOW);

    i32 tw = ui_scale(96);
    int on_build = (cc_tab == TAB_BUILD);
    if (ui_button(x + ui_scale(10), y + CC_TAB_Y, tw, CC_TAB_H, "Build", on_build))
        cc_tab = TAB_BUILD;
    if (ui_button(x + ui_scale(10) + tw + ui_scale(6), y + CC_TAB_Y, ui_scale(130), CC_TAB_H,
                  "Supported C", !on_build))
        cc_tab = TAB_SUPPORTED;

    if (cc_tab == TAB_SUPPORTED) {
        i32 ty = y + CC_LIST_Y;
        i32 avail = h - CC_LIST_Y - ui_scale(10);
        int rows = avail / 14;
        int total = ref_line_count();
        if (cc_ref_scroll > total - rows) cc_ref_scroll = total - rows;
        if (cc_ref_scroll < 0) cc_ref_scroll = 0;
        clip_t cl = { x, ty, x + w, y + h };
        gfx_set_clip(cl);
        for (int i = 0; i < rows && cc_ref_scroll + i < total; i++) {
            const char* s = REF_TEXT[cc_ref_scroll + i];
            color_t c = THEME_TEXT_DIM;
            if (s[0] && s[0] >= 'A' && s[0] <= 'Z' && s[1] >= 'A' && s[1] <= 'Z') c = THEME_ACCENT;
            else if (s[0] == ' ' && s[1] == ' ') c = THEME_TEXT;
            gfx_string(x + ui_scale(12), ty + i * 14, s, c, THEME_WINDOW, 0);
        }
        gfx_clear_clip();
        if (total > rows) {
            char sb[40] = "scroll with the mouse wheel";
            gfx_string(x + w - ui_scale(220), y + CC_TAB_Y + 6, sb, THEME_TEXT_FAINT, THEME_WINDOW, 0);
        }
        return;
    }

    gfx_string(x + ui_scale(12), y + CC_LIST_Y - ui_scale(14),
               "Source files in the root directory:", THEME_TEXT_DIM, THEME_WINDOW, 0);
    if (ui_button(x + w - ui_scale(80), y + CC_TAB_Y, ui_scale(70), CC_TAB_H, "Rescan", 0))
        cc_rescan();

    i32 ly = y + CC_LIST_Y;
    i32 lw = w - ui_scale(24);
    gfx_rect(x + ui_scale(12), ly, lw, CC_ROWS * CC_ROW_H, THEME_PANEL_ALT);

    if (cc_count == 0) {
        gfx_string(x + ui_scale(18), ly + 4, "(no .c or .zap files found)", THEME_TEXT_FAINT, THEME_PANEL_ALT, 0);
    }
    for (int i = 0; i < CC_ROWS && cc_scroll + i < cc_count; i++) {
        int idx = cc_scroll + i;
        i32 ry = ly + i * CC_ROW_H;
        if (ui_point_in(mouse_x(), mouse_y(), x + ui_scale(12), ry, lw, CC_ROW_H) &&
            mouse_left_pressed()) {
            cc_sel = idx;
            cc_have_img = 0;
            cc_show_canvas = 0;
        }
        int sel = (idx == cc_sel);
        color_t rb = sel ? THEME_ACCENT : THEME_PANEL_ALT;
        if (sel) gfx_rect(x + ui_scale(12), ry, lw, CC_ROW_H, rb);
        color_t tc = sel ? THEME_ACCENT_TEXT : THEME_TEXT;
        gfx_string(x + ui_scale(18), ry + 2, cc_files[idx].display_name, tc, rb, 0);
        char sz[20];
        u32_to_kb_str(cc_files[idx].size, sz);
        gfx_string(x + ui_scale(12) + lw - ui_scale(80), ry + 2, sz,
                   sel ? THEME_ACCENT_TEXT : THEME_TEXT_FAINT, rb, 0);
    }

    i32 by = y + CC_BTN_Y;
    int can_compile = (cc_sel >= 0 && cc_sel < cc_count && name_ends(cc_files[cc_sel].display_name, "C"));
    int can_run = cc_have_img ||
                  (cc_sel >= 0 && cc_sel < cc_count && name_ends(cc_files[cc_sel].display_name, "ZAP"));
    if (ui_button(x + ui_scale(12), by, ui_scale(90), CC_BTN_H, "Compile", can_compile))
        cc_do_compile();
    if (ui_button(x + ui_scale(110), by, ui_scale(70), CC_BTN_H, "Run", can_run))
        cc_do_run();
    if (ui_button(x + ui_scale(188), by, ui_scale(80), CC_BTN_H, "New file", 0))
        cc_new_sample();
    if (cc_have_img) {
        char info[40] = "-> ";
        str_cat(info, cc_img_name, sizeof(info));
        gfx_string(x + ui_scale(278), by + 6, info, THEME_SUCCESS, THEME_WINDOW, 0);
    }

    i32 oy = y + CC_OUT_Y;
    i32 oh = h - CC_OUT_Y - ui_scale(8);
    if (oh < 40) return;

    i32 canvas_h = 0;
    if (cc_show_canvas) {
        i32 cw = zrt_canvas_w();
        i32 ch = zrt_canvas_h();
        canvas_h = ch + 8;
        if (canvas_h > oh - 40) { canvas_h = 0; }
        else {
            i32 cx = x + w - cw - ui_scale(14);
            gfx_rect(cx - 2, oy - 2, cw + 4, ch + 4, THEME_BORDER);
            gfx_blit_rgb_scaled(zrt_canvas(), cw, ch, cx, oy, cw, ch);
        }
    }

    i32 text_w = w - ui_scale(24) - (canvas_h > 0 ? zrt_canvas_w() + ui_scale(10) : 0);
    gfx_rect(x + ui_scale(12), oy, text_w, oh, RGB(18, 19, 26));

    clip_t cl = { x + ui_scale(12), oy, x + ui_scale(12) + text_w, oy + oh };
    gfx_set_clip(cl);

    int rows = (oh - 4) / 14;
    int prog_lines = zrt_line_count();
    int total = cc_log_n + prog_lines;
    if (cc_out_scroll > total - rows) cc_out_scroll = total - rows;
    if (cc_out_scroll < 0) cc_out_scroll = 0;

    for (int i = 0; i < rows; i++) {
        int idx = cc_out_scroll + i;
        if (idx >= total) break;
        const char* s;
        color_t c;
        if (idx < cc_log_n) {
            s = cc_log[idx];
            c = (s[0] == 'E' && s[1] == 'R' && s[2] == 'R') ? THEME_DANGER : THEME_TEXT_DIM;
        } else {
            s = zrt_line(idx - cc_log_n);
            c = RGB(150, 230, 160);
        }
        gfx_string(x + ui_scale(16), oy + 2 + i * 14, s, c, RGB(18, 19, 26), 0);
    }
    gfx_clear_clip();
}

void app_compiler_wheel(i32 delta) {
    if (cc_tab == TAB_SUPPORTED) {
        cc_ref_scroll -= delta * 3;
        if (cc_ref_scroll < 0) cc_ref_scroll = 0;
        return;
    }
    cc_out_scroll -= delta * 3;
    if (cc_out_scroll < 0) cc_out_scroll = 0;
}

/* Exercises exactly what the Compile button calls, so the app's own path is
   covered by the zapcctest boot flag without needing to drive the mouse. */
void compiler_selftest(void) {
    cc_rescan();
    serial_puts("  files listed: ");
    char nb[16]; u32_to_str((u32)cc_count, nb); serial_puts(nb); serial_puts("\r\n");
    cc_sel = -1;
    for (int i = 0; i < cc_count; i++)
        if (str_eq_ci(cc_files[i].display_name, "DEMO.C")) { cc_sel = i; break; }
    if (cc_sel < 0) { serial_puts("  FAIL: DEMO.C not in list\r\n"); return; }
    serial_puts("  selected DEMO.C, pressing Compile\r\n");
    cc_do_compile();
    for (int i = 0; i < cc_log_n; i++) { serial_puts("    "); serial_puts(cc_log[i]); serial_puts("\r\n"); }
    if (!cc_have_img) { serial_puts("  FAIL: no image after Compile\r\n"); return; }
    serial_puts("  pressing Run\r\n");
    cc_do_run();
    for (int i = 0; i < zrt_line_count(); i++) { serial_puts("    "); serial_puts(zrt_line(i)); serial_puts("\r\n"); }
}
