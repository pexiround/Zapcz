#include "ttt.h"
#include "graphics.h"
#include "desktop.h"
#include "theme.h"
#include "util.h"

static char board[9];
static char turn = 'X';
static char winner = 0;

void ttt_init(void) {
    for (int i = 0; i < 9; i++) board[i] = 0;
    turn = 'X';
    winner = 0;
}

static const int WIN_LINES[8][3] = {
    {0,1,2}, {3,4,5}, {6,7,8},
    {0,3,6}, {1,4,7}, {2,5,8},
    {0,4,8}, {2,4,6},
};

static void ttt_check_winner(void) {
    for (int i = 0; i < 8; i++) {
        const int* l = WIN_LINES[i];
        if (board[l[0]] && board[l[0]] == board[l[1]] && board[l[1]] == board[l[2]]) {
            winner = board[l[0]];
            return;
        }
    }
    int full = 1;
    for (int i = 0; i < 9; i++) if (!board[i]) { full = 0; break; }
    if (full) winner = 'D';
}

#define CELL 88
#define GRID_W (CELL*3)
#define GRID_TOP 56
#define RESET_BTN_W 100
#define RESET_BTN_H 30

static i32 grid_x0(i32 w) { return (w - GRID_W) / 2; }

void app_ttt_draw(i32 x, i32 y, i32 w, i32 h) {
    char status[40];
    if (winner == 'D') str_copy(status, "Draw! Press Reset or R.", 40);
    else if (winner) { str_copy(status, "Player ", 40); char p[2] = {winner,0}; str_cat(status, p, 40); str_cat(status, " wins!", 40); }
    else { str_copy(status, "Turn: ", 40); char p[2] = {turn,0}; str_cat(status, p, 40); }
    gfx_string(x + (w - gfx_string_width(status)) / 2, y + 16, status,
               winner && winner != 'D' ? THEME_SUCCESS : THEME_TEXT, THEME_PANEL, 0);

    i32 gx = x + grid_x0(w), gy = y + GRID_TOP;
    gfx_rounded_rect(gx - 4, gy - 4, GRID_W + 8, GRID_W + 8, 8, THEME_PANEL_ALT);
    for (int r = 0; r < 3; r++) {
        for (int c = 0; c < 3; c++) {
            i32 cx = gx + c * CELL, cy = gy + r * CELL;
            gfx_rounded_rect(cx + 3, cy + 3, CELL - 6, CELL - 6, 8, THEME_PANEL);
            gfx_rounded_rect_outline(cx + 3, cy + 3, CELL - 6, CELL - 6, 8, THEME_BORDER);
            char v = board[r * 3 + c];
            if (v == 'X') {
                color_t cl = THEME_ACCENT;
                for (i32 off = -1; off <= 1; off++) {
                    gfx_line(cx + 18 + off, cy + 18, cx + CELL - 18 + off, cy + CELL - 18, cl);
                    gfx_line(cx + CELL - 18 + off, cy + 18, cx + 18 + off, cy + CELL - 18, cl);
                }
            } else if (v == 'O') {
                gfx_circle(cx + CELL/2, cy + CELL/2, CELL/2 - 16, THEME_WARNING);
                gfx_circle(cx + CELL/2, cy + CELL/2, CELL/2 - 17, THEME_WARNING);
            }
        }
    }

    i32 bx = x + (w - RESET_BTN_W) / 2, by = gy + GRID_W + 16;
    ui_button(bx, by, RESET_BTN_W, RESET_BTN_H, "Reset", 0);
    (void)h;
}

void app_ttt_click(i32 rx, i32 ry) {
    i32 w = windows[APP_TTT].w;
    i32 gx = grid_x0(w), gy = GRID_TOP;
    i32 by = gy + GRID_W + 16;

    if (ui_point_in(rx, ry, (w - RESET_BTN_W) / 2, by, RESET_BTN_W, RESET_BTN_H)) {
        ttt_init();
        return;
    }

    if (winner) return;
    if (rx < gx || rx >= gx + GRID_W || ry < gy || ry >= gy + GRID_W) return;
    int c = (rx - gx) / CELL, r = (ry - gy) / CELL;
    int idx = r * 3 + c;
    if (idx < 0 || idx >= 9 || board[idx]) return;
    board[idx] = turn;
    ttt_check_winner();
    if (!winner) turn = (turn == 'X') ? 'O' : 'X';
}

void app_ttt_key(int key) {
    if (key == 'r' || key == 'R') ttt_init();
}
