#ifndef APPS_H
#define APPS_H
#include "io.h"
#include "fat32.h"

typedef void (*app_draw_fn)(i32 x, i32 y, i32 w, i32 h);
typedef void (*app_click_fn)(i32 rel_x, i32 rel_y);
typedef void (*app_key_fn)(int key);

typedef void (*app_drag_fn)(i32 rel_x, i32 rel_y);
typedef void (*app_wheel_fn)(i32 delta);

void apps_init(void);
void files_open_entry(const fat_dirent_t* ent);
void files_activate_at(i32 rx, i32 ry);
void term_print(const char* s);

extern app_draw_fn  app_draw_table[];
extern app_click_fn app_click_table[];
extern app_click_fn app_rclick_table[];
extern app_key_fn   app_key_table[];
extern app_drag_fn  app_drag_table[];
extern app_wheel_fn app_wheel_table[];

int life_is_running(void);
#endif
