#ifndef DESKTOP_H
#define DESKTOP_H
#include "io.h"
#include "graphics.h"

#define APP_2048      0
#define APP_CLOCK      1
#define APP_FILES      2
#define APP_EDITOR     3
#define APP_TERMINAL   4
#define APP_PERF       5
#define APP_WALLPAPER  6
#define APP_SNAKE      7
#define APP_BROWSER    8
#define APP_STORE      9
#define APP_SETTINGS   10
#define APP_PHOTOS     11
#define APP_ACCOUNTS   12
#define APP_INSTALLER  13
#define APP_CALC       14
#define APP_PAINT      15
#define APP_TTT        16
#define APP_CUBE3D     17
#define APP_DESKSETTINGS 18
#define APP_MINES      19
#define APP_LIFE       20
#define APP_NOTIFY     21
#define APP_CALENDAR   22
#define APP_TRASH      23
#define APP_WRITER     24
#define APP_SHEET      25
#define APP_MEDIA      26
#define APP_IDE        27
#define APP_COMPILER   28
#define APP_COUNT      29

#define APP_FIRST_STORE_APP APP_CALC

#define BG_MODE_GRADIENT 0
#define BG_MODE_SOLID    1
#define BG_MODE_BITMAP   2
#define BG_MODE_MOUNTAINS 3
#define BG_MODE_AURORA 4
#define BG_MODE_NEBULA 5
#define BG_MODE_SUNSET 6
#define BG_MODE_SILK 7

#define TASKBAR_BOTTOM 0
#define TASKBAR_TOP    1

typedef struct {
    char title[32];
    i32 x, y, w, h;
    int visible;
    int app_id;
    int maximized;
    int minimized;
    i32 rx, ry, rw, rh;
} window_t;

void desktop_invalidate_bg(void);
void desktop_cycle_wallpaper(void);
void desktop_set_wallpaper_variant(int v);
int  desktop_wallpaper_count(void);
int  desktop_get_ui_size(void);
void desktop_set_ui_size(int s);
int  desktop_get_sleep_minutes(void);
void desktop_set_sleep_minutes(int m);
int  desktop_get_lock_on_resume(void);
void desktop_set_lock_on_resume(int v);
int  desktop_get_power_saver(void);
void desktop_set_power_saver(int v);
int  desktop_get_workspace(void);
void desktop_set_workspace(int ws);
int  desktop_ws_count(void);
extern window_t windows[APP_COUNT];

void desktop_init(void);
void desktop_run_frame(void);
void desktop_open_app(int app_id);
void desktop_close_app(int app);
void desktop_demo_enable(void);
int  desktop_demo_active(void);
i32 ui_scale(i32 base);
void desktop_reset_session(void);
int  desktop_focused_app(void);
void desktop_set_wallpaper(int mode, color_t a, color_t b, color_t c, color_t d, const u8* bitmap);
void desktop_set_taskbar_position(int top);
int  desktop_get_taskbar_position(void);
void desktop_set_taskbar_opacity(int pct);
int  desktop_get_taskbar_opacity(void);
void desktop_set_accent(int idx);
int  desktop_get_accent(void);
void desktop_cycle_wallpaper(void);
void desktop_set_wallpaper_variant(int v);
int  desktop_wallpaper_count(void);
int  desktop_get_ui_size(void);
void desktop_set_ui_size(int s);
int  desktop_get_sleep_minutes(void);
void desktop_set_sleep_minutes(int m);
int  desktop_get_lock_on_resume(void);
void desktop_set_lock_on_resume(int v);
int  desktop_get_power_saver(void);
void desktop_set_power_saver(int v);
int  desktop_get_workspace(void);
void desktop_set_workspace(int ws);
int  desktop_ws_count(void);
int  desktop_get_wallpaper_variant(void);
void desktop_refresh_files(void);

typedef struct {
    u32 fps;
    u32 cpu_busy_pct;
    u32 heap_used_kb;
    u32 heap_free_kb;
} perf_stats_t;
void desktop_get_perf_stats(perf_stats_t* out);

void desktop_set_system_font(int f);
int desktop_get_system_font(void);
int  ui_button(i32 x, i32 y, i32 w, i32 h, const char* label, int highlighted);
int  ui_point_in(i32 px, i32 py, i32 x, i32 y, i32 w, i32 h);
void desktop_draw_cursor(void);

#endif
