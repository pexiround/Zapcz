#include "screenshot.h"
#include "graphics.h"
#include "png.h"
#include "fat32.h"
#include "util.h"
#include "mm.h"
#include "libc_shim.h"
#include "pit.h"

static char last_name[16];
static char last_msg[64];
static u32  msg_until;

const char* screenshot_message(void) {
    if (!last_msg[0]) return 0;
    if (ticks_get() > msg_until) { last_msg[0] = 0; return 0; }
    return last_msg;
}

const char* screenshot_last_name(void) { return last_name; }

static void build_name(int n, char* out) {
    out[0] = 'S'; out[1] = 'H'; out[2] = 'O'; out[3] = 'T';
    out[4] = (char)('0' + (n / 100) % 10);
    out[5] = (char)('0' + (n / 10) % 10);
    out[6] = (char)('0' + n % 10);
    out[7] = '.'; out[8] = 'P'; out[9] = 'N'; out[10] = 'G';
    out[11] = 0;
}

static int name_taken(const fat_dirent_t* list, int n, const char* want) {
    for (int i = 0; i < n; i++) if (str_eq_ci(list[i].display_name, want)) return 1;
    return 0;
}

int screenshot_take(void) {
    last_msg[0] = 0;
    if (!gfx.back || gfx.width == 0 || gfx.height == 0) return 0;
    if (!fat32_available()) {
        str_copy(last_msg, "Screenshot failed: no writable filesystem", sizeof(last_msg));
        msg_until = ticks_get() + 300;
        return 0;
    }

    u32 sw = gfx.width, sh = gfx.height;
    u32 shrink = 1;
    while (((u32)(1 + (sw / shrink) * 3)) * (sh / shrink) > (3u * 1024u * 1024u)) shrink++;
    u32 ow = sw / shrink, oh = sh / shrink;
    if (ow == 0 || oh == 0) return 0;

    u8* rgb = (u8*)kmalloc(ow * oh * 3);
    if (!rgb) {
        str_copy(last_msg, "Screenshot failed: out of memory", sizeof(last_msg));
        msg_until = ticks_get() + 300;
        return 0;
    }

    u32 bypp = gfx.bypp;
    u32 row_bytes = gfx.width * bypp;
    for (u32 y = 0; y < oh; y++) {
        const u8* src = gfx.back + (u32)(y * shrink) * row_bytes;
        u8* dst = rgb + (u32)y * ow * 3;
        for (u32 x = 0; x < ow; x++) {
            const u8* p = src + (u32)(x * shrink) * bypp;
            dst[x * 3 + 0] = p[2];
            dst[x * 3 + 1] = p[1];
            dst[x * 3 + 2] = p[0];
        }
        if ((y & 63) == 0) watchdog_heartbeat("screenshot");
    }

    static fat_dirent_t list[128];
    int n = fat32_list_dir(FAT32_ROOT_ID, list, 128);
    char name[16];
    int idx = 1;
    for (; idx < 1000; idx++) {
        build_name(idx, name);
        if (!name_taken(list, n, name)) break;
    }
    if (idx >= 1000) {
        kfree(rgb);
        str_copy(last_msg, "Screenshot failed: too many screenshots", sizeof(last_msg));
        msg_until = ticks_get() + 300;
        return 0;
    }

    int rc = png_encode_rgb_to_file(name, rgb, ow, oh);
    kfree(rgb);

    if (rc == PNG_OK) {
        str_copy(last_name, name, sizeof(last_name));
        str_copy(last_msg, "Saved ", sizeof(last_msg));
        str_cat(last_msg, name, sizeof(last_msg));
        if (shrink > 1) str_cat(last_msg, " (scaled)", sizeof(last_msg));
        msg_until = ticks_get() + 300;
        return 1;
    }

    str_copy(last_msg, "Screenshot failed: ", sizeof(last_msg));
    str_cat(last_msg, png_error_string(rc), sizeof(last_msg));
    msg_until = ticks_get() + 300;
    return 0;
}
