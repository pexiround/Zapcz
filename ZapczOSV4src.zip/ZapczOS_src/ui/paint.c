#include "paint.h"
#include "graphics.h"
#include "desktop.h"
#include "theme.h"
#include "util.h"
#include "fat32.h"
#include "libc_shim.h"
#include "png.h"

#define PAINT_COLS 60
#define PAINT_ROWS 34
#define PAINT_CELL 8
#define PAINT_FILENAME "PAINT.PNG"
#define PAINT_PX_W (PAINT_COLS * PAINT_CELL)
#define PAINT_PX_H (PAINT_ROWS * PAINT_CELL)

static u8 canvas[PAINT_ROWS][PAINT_COLS];
static int cur_color = 1;
static char paint_status[48] = "Click or drag to paint.";

static u8 px_buf[PAINT_PX_H][PAINT_PX_W][3];

static const color_t palette[8] = {
    {255,255,255},
    {20,20,24},
    {220,60,60},
    {235,150,40},
    {235,210,40},
    {70,190,90},
    {60,140,255},
    {170,90,220},
};
#define PALETTE_COUNT 8

#define PAINT_MARGIN 12
#define CANVAS_Y_OFF 40
#define TOOLBAR_Y_OFF(h) ((h) - 48)
#define SWATCH_SIZE 26
#define SWATCH_GAP 6

static int nearest_palette_index(u8 r, u8 g, u8 b) {
    int best = 0;
    i32 best_dist = 0x7FFFFFFF;
    for (int i = 0; i < PALETTE_COUNT; i++) {
        i32 dr = (i32)r - palette[i].r;
        i32 dg = (i32)g - palette[i].g;
        i32 db = (i32)b - palette[i].b;
        i32 dist = dr*dr + dg*dg + db*db;
        if (dist < best_dist) { best_dist = dist; best = i; }
    }
    return best;
}

void paint_init(void) {
    cur_color = 1;
    str_copy(paint_status, "Click or drag to paint.", 48);

    if (!fat32_available()) return;
    u32 w = 0, h = 0;
    int rc = png_decode_file(PAINT_FILENAME, &px_buf[0][0][0], PAINT_PX_W, PAINT_PX_H, &w, &h);
    if (rc == PNG_OK && w == PAINT_PX_W && h == PAINT_PX_H) {
        for (int r = 0; r < PAINT_ROWS; r++) {
            for (int c = 0; c < PAINT_COLS; c++) {
                u8* px = px_buf[r * PAINT_CELL][c * PAINT_CELL];
                canvas[r][c] = (u8)nearest_palette_index(px[0], px[1], px[2]);
            }
        }
        str_copy(paint_status, "Loaded your last painting.", 48);
    }
}

static void paint_save(void) {
    if (!fat32_available()) { str_copy(paint_status, "No disk -- can't save.", 48); return; }
    for (int r = 0; r < PAINT_ROWS; r++) {
        for (int c = 0; c < PAINT_COLS; c++) {
            color_t col = palette[canvas[r][c]];
            for (int py = 0; py < PAINT_CELL; py++) {
                for (int px = 0; px < PAINT_CELL; px++) {
                    u8* d = px_buf[r * PAINT_CELL + py][c * PAINT_CELL + px];
                    d[0] = col.r; d[1] = col.g; d[2] = col.b;
                }
            }
        }
    }
    int rc = png_encode_rgb_to_file(PAINT_FILENAME, &px_buf[0][0][0], PAINT_PX_W, PAINT_PX_H);
    if (rc == PNG_OK) {
        str_copy(paint_status, "Saved as a real PNG (PAINT.PNG).", 48);
    } else {
        str_copy(paint_status, png_error_string(rc), 48);
    }
}

static void paint_clear(void) {
    memset(canvas, 0, sizeof(canvas));
    str_copy(paint_status, "Cleared.", 48);
}

static i32 swatch_x(int i) { return PAINT_MARGIN + i * (SWATCH_SIZE + SWATCH_GAP); }

void app_paint_draw(i32 x, i32 y, i32 w, i32 h) {
    gfx_string(x + PAINT_MARGIN, y + 12, "Paint", THEME_TEXT, THEME_PANEL, 0);
    gfx_string(x + 80, y + 12, paint_status, THEME_TEXT_FAINT, THEME_PANEL, 0);

    i32 cv_x = x + PAINT_MARGIN, cv_y = y + CANVAS_Y_OFF;
    gfx_rect(cv_x - 2, cv_y - 2, PAINT_COLS * PAINT_CELL + 4, PAINT_ROWS * PAINT_CELL + 4, THEME_BORDER);
    for (int r = 0; r < PAINT_ROWS; r++) {
        for (int c = 0; c < PAINT_COLS; c++) {
            u8 v = canvas[r][c];
            gfx_rect(cv_x + c * PAINT_CELL, cv_y + r * PAINT_CELL, PAINT_CELL, PAINT_CELL, palette[v]);
        }
    }

    i32 ty = y + TOOLBAR_Y_OFF(h);
    gfx_hline(x + PAINT_MARGIN, ty - 8, w - PAINT_MARGIN * 2, THEME_BORDER);

    for (int i = 0; i < PALETTE_COUNT; i++) {
        i32 sx = x + swatch_x(i);
        gfx_rounded_rect(sx, ty, SWATCH_SIZE, SWATCH_SIZE, 6, palette[i]);
        color_t border = (i == cur_color) ? THEME_ACCENT : THEME_BORDER;
        gfx_rounded_rect_outline(sx, ty, SWATCH_SIZE, SWATCH_SIZE, 6, border);
        if (i == cur_color) gfx_rounded_rect_outline(sx - 1, ty - 1, SWATCH_SIZE + 2, SWATCH_SIZE + 2, 7, THEME_ACCENT);
    }

    i32 btn_x = x + swatch_x(PALETTE_COUNT) + 12;
    ui_button(btn_x, ty - 1, 80, SWATCH_SIZE + 2, "Save", 0);
    ui_button(btn_x + 88, ty - 1, 80, SWATCH_SIZE + 2, "Clear", 0);
}

void app_paint_click(i32 rx, i32 ry) {
    i32 h = windows[APP_PAINT].h;
    i32 ty = TOOLBAR_Y_OFF(h);

    if (ry >= ty - 1 && ry < ty - 1 + SWATCH_SIZE + 2) {
        for (int i = 0; i < PALETTE_COUNT; i++) {
            i32 sx = swatch_x(i);
            if (rx >= sx && rx < sx + SWATCH_SIZE) { cur_color = i; return; }
        }
        i32 btn_x = swatch_x(PALETTE_COUNT) + 12;
        if (ui_point_in(rx, ry, btn_x, ty - 1, 80, SWATCH_SIZE + 2)) { paint_save(); return; }
        if (ui_point_in(rx, ry, btn_x + 88, ty - 1, 80, SWATCH_SIZE + 2)) { paint_clear(); return; }
        return;
    }

    app_paint_drag(rx, ry);
}

void app_paint_drag(i32 rx, i32 ry) {
    i32 cv_x = PAINT_MARGIN, cv_y = CANVAS_Y_OFF;
    i32 h = windows[APP_PAINT].h;
    if (ry >= TOOLBAR_Y_OFF(h) - 8) return;

    i32 col = (rx - cv_x) / PAINT_CELL;
    i32 row = (ry - cv_y) / PAINT_CELL;
    if (col < 0 || col >= PAINT_COLS || row < 0 || row >= PAINT_ROWS) return;
    canvas[row][col] = (u8)cur_color;
}
