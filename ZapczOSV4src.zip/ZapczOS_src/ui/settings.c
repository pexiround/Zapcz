#include "settings.h"
#include "desktop.h"
#include "graphics.h"
#include "theme.h"
#include "util.h"
#include "config.h"
#include "appstore.h"
#include "keyboard.h"
#include "accounts.h"
#include "scroll.h"

void settings_init(void) {

}

#define SEC_COUNT 7
static const i32 SEC_OFFSETS[SEC_COUNT] = {56, 182, 268, 434, 574, 664, 734};
#define HEADER_H 50
#define CONTENT_BOTTOM 804
#define SCROLL_STEP 60

static i32 settings_scroll = 0;

static i32 max_scroll(i32 win_h) {
    i32 visible = win_h - HEADER_H;
    i32 ms = (CONTENT_BOTTOM - HEADER_H) - visible;
    if (ms < 0) ms = 0;
    return ms;
}

static void clamp_scroll(i32 win_h) {
    i32 ms = max_scroll(win_h);
    if (settings_scroll < 0) settings_scroll = 0;
    if (settings_scroll > ms) settings_scroll = ms;
}

static i32 section_y(i32 y, int idx) { return y + HEADER_H + SEC_OFFSETS[idx] - HEADER_H - settings_scroll; }

void app_settings_draw(i32 x, i32 y, i32 w, i32 h) {
    clamp_scroll(h);

    gfx_string(x + 16, y + 14, "Settings", THEME_TEXT, THEME_PANEL, 0);
    if (config_disk_available()) {
        gfx_string(x + 16, y + 34, "Changes are saved to disk automatically.",
                   THEME_TEXT_FAINT, THEME_PANEL, 0);
    } else {
        gfx_string(x + 16, y + 34, "No disk detected -- changes apply for this session only.",
                   THEME_WARNING, THEME_PANEL, 0);
    }

    i32 sc_y = y + HEADER_H - 6;
    i32 sc_h = h - HEADER_H + 6;
    clip_t c = { x, sc_y, x + w, y + h };
    gfx_set_clip(c);

    i32 s0 = section_y(y, 0);
    gfx_hline(x + 12, s0 - 8, w - 24, THEME_BORDER);
    gfx_string(x + 16, s0, "Appearance", THEME_TEXT, THEME_PANEL, 0);
    int dark = (config_get_theme_mode() == THEME_MODE_DARK);
    ui_button(x + 16, s0 + 22, 110, 30, "Dark", dark);
    ui_button(x + 134, s0 + 22, 110, 30, "Light", !dark);
    char sysfont[32];
    str_copy(sysfont, "System Font: ", 32);
    str_cat(sysfont, gfx_font_name(desktop_get_system_font()), 32);
    ui_button(x + 16, s0 + 58, 260, 30, sysfont, 0);

    i32 s1 = section_y(y, 1);
    gfx_hline(x + 12, s1 - 8, w - 24, THEME_BORDER);
    gfx_string(x + 16, s1, "Mouse sensitivity", THEME_TEXT, THEME_PANEL, 0);
    int sens = config_get_mouse_sens();
    char sbuf[16]; u32_to_str((u32)sens, sbuf); str_cat(sbuf, "%", 16);
    ui_button(x + 16, s1 + 22, 36, 30, "-", 0);
    gfx_rounded_rect(x + 60, s1 + 22, w - 76 - 60, 30, THEME_RADIUS_CTRL, THEME_PANEL_ALT);
    {
        i32 barw = w - 76 - 60 - 8;
        i32 fillw = (i32)((u32)barw * (u32)(sens - 25) / (200 - 25));
        if (fillw < 0) fillw = 0;
        gfx_rounded_rect(x + 64, s1 + 26, fillw, 22, 4, THEME_ACCENT);
    }
    gfx_string(x + 60 + (w - 76 - 60) / 2 - gfx_string_width(sbuf) / 2, s1 + 31, sbuf,
               THEME_TEXT, THEME_PANEL, 0);
    ui_button(x + w - 16 - 36, s1 + 22, 36, 30, "+", 0);

    i32 s2 = section_y(y, 2);
    gfx_hline(x + 12, s2 - 8, w - 24, THEME_BORDER);
    gfx_string(x + 16, s2, "Display", THEME_TEXT, THEME_PANEL, 0);
    ui_button(x + 16, s2 + 22, 160, 30, "Open Wallpaper", 0);
    gfx_string(x + 16, s2 + 64, "Time zone", THEME_TEXT, THEME_PANEL, 0);
    {
        i32 tz = config_get_tz_offset();
        char tzb[16]; int q = 0;
        tzb[q++] = 'U'; tzb[q++] = 'T'; tzb[q++] = 'C';
        tzb[q++] = (tz < 0) ? '-' : '+';
        int a = tz < 0 ? -tz : tz;
        if (a >= 10) tzb[q++] = (char)('0' + a / 10);
        tzb[q++] = (char)('0' + a % 10); tzb[q] = 0;
        ui_button(x + 16, s2 + 86, 36, 30, "-", 0);
        gfx_rounded_rect(x + 60, s2 + 86, 96, 30, THEME_RADIUS_CTRL, THEME_PANEL_ALT);
        gfx_string(x + 60 + 48 - gfx_string_width(tzb) / 2, s2 + 95, tzb, THEME_TEXT, THEME_PANEL_ALT, 0);
        ui_button(x + 164, s2 + 86, 36, 30, "+", 0);
    }

    i32 s3 = section_y(y, 3);
    gfx_hline(x + 12, s3 - 8, w - 24, THEME_BORDER);
    gfx_string(x + 16, s3, "Keyboard language", THEME_TEXT, THEME_PANEL, 0);
    {
        int cur = accounts_get_keyboard_layout();
        i32 bw = 110, bh = 30, gap = 8;
        i32 cols = 3;
        for (int i = 0; i < KBD_LAYOUT_COUNT; i++) {
            i32 col = i % cols, row = i / cols;
            i32 bx = x + 16 + col * (bw + gap);
            i32 by = s3 + 22 + row * (bh + gap);
            ui_button(bx, by, bw, bh, kbd_layout_name(i), i == cur);
        }
        i32 rows = (KBD_LAYOUT_COUNT + cols - 1) / cols;
        gfx_string(x + 16, s3 + 22 + rows * (bh + gap) + 2, kbd_layout_label(cur),
                   THEME_TEXT_FAINT, THEME_PANEL, 0);
    }

    i32 s4 = section_y(y, 4);
    gfx_hline(x + 12, s4 - 8, w - 24, THEME_BORDER);
    gfx_string(x + 16, s4, "Account", THEME_TEXT, THEME_PANEL, 0);
    {
        char who[48] = "Signed in as: ";
        str_cat(who, accounts_name_at(accounts_current_index()), 48);
        gfx_string(x + 16, s4 + 20, who, THEME_TEXT_DIM, THEME_PANEL, 0);
    }
    ui_button(x + 16,  s4 + 40, 150, 30, "Manage Accounts", 0);
    ui_button(x + 174, s4 + 40, 100, 30, "Log Out", 0);

    i32 s5 = section_y(y, 5);
    gfx_hline(x + 12, s5 - 8, w - 24, THEME_BORDER);
    gfx_string(x + 16, s5, "System", THEME_TEXT, THEME_PANEL, 0);
    ui_button(x + 16, s5 + 22, 180, 30, "Install to Hard Drive", 0);

    i32 s6 = section_y(y, 6);
    gfx_hline(x + 12, s6 - 8, w - 24, THEME_BORDER);
    gfx_string(x + 16, s6, "App Store", THEME_TEXT, THEME_PANEL, 0);
    ui_button(x + 16, s6 + 22, 160, 30, "Open App Store", 0);
    ui_button(x + 184, s6 + 22, 170, 30, "Uninstall store apps", 0);

    gfx_clear_clip();

    int ms = max_scroll(h);
    if (ms > 0) {
        ui_button(x + w - 76, y + 12, 30, 26, "^", settings_scroll <= 0);
        ui_button(x + w - 40, y + 12, 30, 26, "v", settings_scroll >= ms);
        scroll_draw_bar(x + w - 14, sc_y, sc_h, settings_scroll,
                        CONTENT_BOTTOM - HEADER_H, h - HEADER_H, THEME_PANEL_ALT, THEME_BORDER);
    }
    (void)sc_y; (void)sc_h;
}

void app_settings_wheel(i32 delta) {
    i32 h = windows[APP_SETTINGS].h;
    settings_scroll -= delta * SCROLL_STEP;
    clamp_scroll(h);
}

void app_settings_drag(i32 rx, i32 ry) {
    i32 h = windows[APP_SETTINGS].h;
    i32 w = windows[APP_SETTINGS].w;
    i32 sc_y = HEADER_H - 6;
    i32 sc_h = h - HEADER_H + 6;
    if (scroll_bar_hit(rx, ry, w - 14, sc_y, sc_h, CONTENT_BOTTOM - HEADER_H, h - HEADER_H)) {
        settings_scroll = scroll_bar_drag_to(ry, sc_y, sc_h, CONTENT_BOTTOM - HEADER_H, h - HEADER_H);
        clamp_scroll(h);
    }
}

void app_settings_click(i32 rx, i32 ry) {
    i32 w = windows[APP_SETTINGS].w;
    i32 h = windows[APP_SETTINGS].h;
    clamp_scroll(h);

    int ms = max_scroll(h);
    if (ms > 0) {
        if (ui_point_in(rx, ry, w - 76, 12, 30, 26)) { settings_scroll -= SCROLL_STEP; clamp_scroll(h); return; }
        if (ui_point_in(rx, ry, w - 40, 12, 30, 26)) { settings_scroll += SCROLL_STEP; clamp_scroll(h); return; }
    }

    if (ry < HEADER_H - 6) return;

    i32 s0 = HEADER_H + SEC_OFFSETS[0] - HEADER_H - settings_scroll;
    if (ui_point_in(rx, ry, 16, s0 + 22, 110, 30)) { config_set_theme_mode(THEME_MODE_DARK); return; }
    if (ui_point_in(rx, ry, 134, s0 + 22, 110, 30)) { config_set_theme_mode(THEME_MODE_LIGHT); return; }
    if (ui_point_in(rx, ry, 16, s0 + 58, 260, 30)) {
        desktop_set_system_font((desktop_get_system_font() + 1) % FONT_STYLE_COUNT);
        return;
    }

    i32 s1 = HEADER_H + SEC_OFFSETS[1] - HEADER_H - settings_scroll;
    if (ui_point_in(rx, ry, 16, s1 + 22, 36, 30)) {
        config_set_mouse_sens((u8)(config_get_mouse_sens() - 25));
        return;
    }
    if (ui_point_in(rx, ry, w - 16 - 36, s1 + 22, 36, 30)) {
        config_set_mouse_sens((u8)(config_get_mouse_sens() + 25));
        return;
    }

    i32 s2 = HEADER_H + SEC_OFFSETS[2] - HEADER_H - settings_scroll;
    if (ui_point_in(rx, ry, 16, s2 + 22, 160, 30)) { desktop_open_app(APP_WALLPAPER); return; }
    if (ui_point_in(rx, ry, 16, s2 + 86, 36, 30)) { config_set_tz_offset(config_get_tz_offset() - 1); return; }
    if (ui_point_in(rx, ry, 164, s2 + 86, 36, 30)) { config_set_tz_offset(config_get_tz_offset() + 1); return; }

    i32 s3 = HEADER_H + SEC_OFFSETS[3] - HEADER_H - settings_scroll;
    {
        i32 bw = 110, bh = 30, gap = 8;
        i32 cols = 3;
        for (int i = 0; i < KBD_LAYOUT_COUNT; i++) {
            i32 col = i % cols, row = i / cols;
            i32 bx = 16 + col * (bw + gap);
            i32 by = s3 + 22 + row * (bh + gap);
            if (ui_point_in(rx, ry, bx, by, bw, bh)) { accounts_set_keyboard_layout(i); return; }
        }
    }

    i32 s4 = HEADER_H + SEC_OFFSETS[4] - HEADER_H - settings_scroll;
    if (ui_point_in(rx, ry, 16, s4 + 40, 150, 30)) { desktop_open_app(APP_ACCOUNTS); return; }
    if (ui_point_in(rx, ry, 174, s4 + 40, 100, 30)) { accounts_logout(); return; }

    i32 s5 = HEADER_H + SEC_OFFSETS[5] - HEADER_H - settings_scroll;
    if (ui_point_in(rx, ry, 16, s5 + 22, 180, 30)) { desktop_open_app(APP_INSTALLER); return; }

    i32 s6 = HEADER_H + SEC_OFFSETS[6] - HEADER_H - settings_scroll;
    if (ui_point_in(rx, ry, 16, s6 + 22, 160, 30)) { desktop_open_app(APP_STORE); return; }
    if (ui_point_in(rx, ry, 184, s6 + 22, 170, 30)) {
        config_set_installed(CFG_INSTALLED_CALC, 0);
        config_set_installed(CFG_INSTALLED_PAINT, 0);
        config_set_installed(CFG_INSTALLED_TTT, 0);
        config_set_installed(CFG_INSTALLED_CUBE3D, 0);
        return;
    }
}
