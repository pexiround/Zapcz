#ifndef ICONS_H
#define ICONS_H
#include "io.h"
#include "graphics.h"

void icon_draw(int app_id, i32 x, i32 y, i32 size, color_t fg);
int  icon_has_bitmap(int app_id);
void filetype_icon_draw(i32 x, i32 y, i32 size, const char* name83);
void logo_draw(i32 x, i32 y, i32 bw, i32 bh, color_t bg);
void logo_draw_ex(i32 x, i32 y, i32 bw, i32 bh, color_t bg, int transparent);
void folder_icon_draw(i32 x, i32 y, i32 size);
void znap_folder_icon_draw(i32 x, i32 y, i32 size);

#endif
