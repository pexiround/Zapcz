#include "boot_screen.h"
#include "icons.h"
#include "logo.h"
#include "pit.h"
#include "util.h"
#include "io.h"

#define BOOT_LOGO_SCALE 3
#define BOOT_MARGIN_X 20
#define BOOT_LINE_H 15

static color_t COL_BLACK   = {0, 0, 0};
static color_t COL_CYAN    = {90, 200, 250};
static color_t COL_WHITE   = {220, 222, 228};
static color_t COL_GRAY    = {140, 144, 156};
static color_t COL_GREEN   = {90, 220, 110};
static color_t COL_MAGENTA = {210, 130, 235};
static color_t COL_YELLOW  = {235, 205, 110};
static color_t COL_RED     = {235, 95, 85};
static color_t COL_BARBG   = {28, 30, 38};

static i32 line_y = 0;
static i32 cur_line_y = 0;
static i32 log_top = 0;
static i32 bar_x, bar_y, bar_w, bar_h;
static i32 step_count = 0;
static i32 step_total = 64;
static i32 mode_shutdown = 0;

static void draw_progress(void) {
    i32 pct = step_total > 0 ? (step_count * 100 / step_total) : 0;
    if (pct > 100) pct = 100;
    gfx_rect(bar_x, bar_y, bar_w, bar_h, COL_BARBG);
    color_t fill = mode_shutdown ? COL_RED : COL_GREEN;
    gfx_rect(bar_x + 1, bar_y + 1, (bar_w - 2) * pct / 100, bar_h - 2, fill);
    gfx_rect(bar_x, bar_y, bar_w, 1, RGB(60, 62, 72));
    gfx_rect(bar_x, bar_y + bar_h - 1, bar_w, 1, RGB(60, 62, 72));
    char pb[8]; u32_to_str((u32)pct, pb); str_cat(pb, "%", 8);
    gfx_rect(bar_x + bar_w + 8, bar_y, 44, bar_h, COL_BLACK);
    gfx_string(bar_x + bar_w + 8, bar_y - 1, pb, COL_GRAY, COL_BLACK, 1);
}

static void advance(void) {
    step_count++;
    if (step_count > step_total) step_total = step_count + 4;
    draw_progress();
}

static void page_if_needed(void) {
    if (line_y + BOOT_LINE_H > bar_y - 8) {
        gfx_rect(0, log_top, (i32)gfx.width, bar_y - 8 - log_top, COL_BLACK);
        line_y = log_top;
    }
}

static void header(const char* subtitle, int shutdown) {
    mode_shutdown = shutdown;
    step_count = 0;
    gfx_rect(0, 0, (i32)gfx.width, (i32)gfx.height, COL_BLACK);
    i32 lx = BOOT_MARGIN_X, ly = 16;
    logo_draw(lx, ly, LOGO_W * BOOT_LOGO_SCALE, LOGO_H_ * BOOT_LOGO_SCALE, COL_BLACK);
    i32 tx = lx + LOGO_W * BOOT_LOGO_SCALE + 24;
    gfx_string(tx, ly + 6, "ZapczOS V4", RGB(255, 255, 255), COL_BLACK, 1);
    gfx_string(tx, ly + 26, "live x86 operating system", COL_GRAY, COL_BLACK, 1);
    gfx_string(tx, ly + 46, subtitle, COL_CYAN, COL_BLACK, 1);

    log_top = ly + LOGO_H_ * BOOT_LOGO_SCALE + 18;
    line_y = log_top;

    bar_x = BOOT_MARGIN_X;
    bar_w = (i32)gfx.width - 2 * BOOT_MARGIN_X - 56;
    bar_h = 16;
    bar_y = (i32)gfx.height - 40;
    draw_progress();
    gfx_mark_all_dirty(); gfx_present();
}

void boot_screen_init(void) {
    step_total = 64;
    header("Welcome to ZapczOS V4!", 0);
}

void boot_screen_shutdown_init(void) {
    step_total = 20;
    header("Shutting down ...", 1);
}

void boot_screen_section(const char* msg) {
    page_if_needed();
    gfx_string(BOOT_MARGIN_X, line_y, msg, COL_CYAN, COL_BLACK, 1);
    cur_line_y = line_y;
    line_y += BOOT_LINE_H;
    advance();
    gfx_mark_all_dirty(); gfx_present();
    sleep_ms(14);
}

static void log_colored(const char* msg, color_t c, const char* prefix) {
    page_if_needed();
    char line[96];
    str_copy(line, prefix, 96);
    str_cat(line, msg, 96);
    gfx_string(BOOT_MARGIN_X, line_y, line, c, COL_BLACK, 1);
    cur_line_y = line_y;
    line_y += BOOT_LINE_H;
    advance();
    gfx_mark_all_dirty(); gfx_present();
    sleep_ms(9);
}

void boot_screen_log(const char* msg) { log_colored(msg, COL_WHITE, "  "); }
void boot_screen_note(const char* msg) { log_colored(msg, COL_MAGENTA, "  "); }
void boot_screen_good(const char* msg) { log_colored(msg, COL_GREEN, "  "); }
void boot_screen_warn(const char* msg) { log_colored(msg, COL_YELLOW, "  "); }

void boot_screen_status(int ok) {
    const char* txt = ok ? "[ OK ]" : "[ -- ]";
    color_t c = ok ? COL_GREEN : COL_YELLOW;
    i32 x = (i32)gfx.width - 130;
    gfx_rect(x, cur_line_y, 70, 14, COL_BLACK);
    gfx_string(x, cur_line_y, txt, c, COL_BLACK, 1);
    gfx_mark_all_dirty(); gfx_present();
    sleep_ms(6);
}

void boot_screen_finish(void) {
    step_count = step_total;
    draw_progress();
    gfx_mark_all_dirty(); gfx_present();
    sleep_ms(180);
}

void boot_screen_goodbye(void) {
    step_count = step_total;
    draw_progress();
    page_if_needed();
    line_y += BOOT_LINE_H;
    gfx_string(BOOT_MARGIN_X, line_y, "It is now safe to power off your computer.", COL_WHITE, COL_BLACK, 1);
    gfx_mark_all_dirty(); gfx_present();
    sleep_ms(400);
}
