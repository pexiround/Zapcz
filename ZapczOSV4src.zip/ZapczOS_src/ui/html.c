#include "html.h"
#include "js.h"
#include "pit.h"
#include "libc_shim.h"

static char lc(char c){return(c>='A'&&c<='Z')?(char)(c-'A'+'a'):c;}

static int tag_is(const char* n,u32 nl,const char* lit){
    u32 i=0;for(;i<nl&&lit[i];i++)if(lc(n[i])!=lit[i])return 0;
    return i==nl&&lit[i]==0;
}
static int find_attr(const char*t,u32 tl,const char*a,const char**o,u32*ol){
    u32 al=0;while(a[al])al++;
    for(u32 i=0;i+al<=tl;i++){
        u32 k=0;for(;k<al;k++)if(lc(t[i+k])!=a[k])break;
        if(k!=al)continue;
        u32 j=i+al;while(j<tl&&(t[j]==' '||t[j]=='\t'))j++;
        if(j>=tl||t[j]!='=')continue;j++;
        while(j<tl&&(t[j]==' '||t[j]=='\t'))j++;
        if(j>=tl)continue;char q=t[j];if(q!='"'&&q!='\'')continue;j++;
        u32 s=j;while(j<tl&&t[j]!=q)j++;*o=t+s;*ol=j-s;return 1;
    }return 0;
}
static u32 skip_after(const char*s,u32 l,u32 f,const char*nd){
    u32 nl=0;while(nd[nl])nl++;
    for(u32 i=f;i+nl<=l;i++){u32 k=0;for(;k<nl;k++)if(lc(s[i+k])!=nd[k])break;if(k==nl)return i+nl;}
    return l;
}
static u32 pool_add(html_doc_t*d,const char*s,u32 sl){
    if(d->pool_used+sl>HTML_POOL_SIZE)sl=d->pool_used<HTML_POOL_SIZE?HTML_POOL_SIZE-d->pool_used:0;
    u32 o=d->pool_used;if(sl)memcpy(d->pool+o,s,sl);d->pool_used+=sl;return o;
}
static int hd(char c){if(c>='0'&&c<='9')return c-'0';if(c>='a'&&c<='f')return c-'a'+10;if(c>='A'&&c<='F')return c-'A'+10;return 0;}
static int hex_color(const char*s,u32 l,u8*r,u8*g,u8*b){
    while(l&&*s==' '){s++;l--;}while(l&&s[l-1]==' ')l--;if(!l)return 0;
    u32 i=0;if(s[0]=='#')i=1;u32 rem=l-i;
    if(rem>=6){*r=(u8)(hd(s[i])*16+hd(s[i+1]));*g=(u8)(hd(s[i+2])*16+hd(s[i+3]));*b=(u8)(hd(s[i+4])*16+hd(s[i+5]));return 1;}
    if(rem>=3){*r=(u8)(hd(s[i])*17);*g=(u8)(hd(s[i+1])*17);*b=(u8)(hd(s[i+2])*17);return 1;}
    return 0;
}
static int named_color(const char*s,u32 l,u8*r,u8*g,u8*b){
    char nm[24]={0};u32 nl=l<23?l:23;for(u32 i=0;i<nl;i++)nm[i]=lc(s[i]);
    static const struct{const char*n;u8 r,g,b;}t[]={
        {"white",255,255,255},{"black",0,0,0},{"red",220,50,50},{"green",50,180,80},
        {"blue",60,100,220},{"yellow",220,200,50},{"orange",220,130,40},{"purple",140,60,200},
        {"pink",220,100,150},{"gray",120,120,120},{"grey",120,120,120},{"silver",180,180,180},
        {"navy",20,30,150},{"teal",30,150,150},{"cyan",50,200,220},{"lime",80,220,80},
        {"indigo",75,0,130},{"violet",140,80,200},{"maroon",150,30,30},
        {"gold",212,175,55},{"brown",140,90,50},{"tan",210,180,140},
        {"lightblue",130,180,230},{"darkblue",20,40,110},{"skyblue",120,190,230},
        {"lightgray",200,200,200},{"lightgrey",200,200,200},{"darkgray",80,80,80},
        {"darkgrey",80,80,80},{"beige",235,225,200},{"crimson",210,40,70},
        {"coral",230,120,90},{"salmon",230,140,120},{"khaki",200,190,130},
        {"olive",120,120,40},{"aqua",50,200,220},{"fuchsia",220,60,200},
        {"magenta",220,60,200},{"transparent",0,0,0},{0,0,0,0}};
    for(int i=0;t[i].n;i++){u32 cnl=0;while(t[i].n[cnl])cnl++;if(cnl!=nl)continue;
        int m=1;for(u32 j=0;j<nl;j++)if(nm[j]!=t[i].n[j]){m=0;break;}
        if(m){*r=t[i].r;*g=t[i].g;*b=t[i].b;return 1;}}
    return 0;
}
static int css_color(const char*s,u32 l,u8*r,u8*g,u8*b){
    while(l&&*s==' '){s++;l--;}while(l&&s[l-1]==' ')l--;if(!l)return 0;
    if(s[0]=='#')return hex_color(s,l,r,g,b);
    if(l>4&&lc(s[0])=='r'&&lc(s[1])=='g'&&lc(s[2])=='b'&&s[3]=='('){
        int rv=0,gv=0,bv=0;u32 i=4;
        while(i<l&&s[i]>='0'&&s[i]<='9')rv=rv*10+(s[i++]-'0');
        while(i<l&&(s[i]==' '||s[i]==','))i++;
        while(i<l&&s[i]>='0'&&s[i]<='9')gv=gv*10+(s[i++]-'0');
        while(i<l&&(s[i]==' '||s[i]==','))i++;
        while(i<l&&s[i]>='0'&&s[i]<='9')bv=bv*10+(s[i++]-'0');
        *r=(u8)(rv>255?255:rv);*g=(u8)(gv>255?255:gv);*b=(u8)(bv>255?255:bv);return 1;
    }
    return named_color(s,l,r,g,b);
}
static void parse_style_attr(const char*sv,u32 sl,u8*fr,u8*fg,u8*fb){
    for(u32 k=0;k<sl;k++){
        if(sl-k>=6&&lc(sv[k])=='c'&&lc(sv[k+1])=='o'&&lc(sv[k+2])=='l'&&lc(sv[k+3])=='o'&&lc(sv[k+4])=='r'&&sv[k+5]==':'){
            u32 v=k+6;while(v<sl&&sv[v]==' ')v++;u32 e=v;while(e<sl&&sv[e]!=';')e++;
            css_color(sv+v,e-v,fr,fg,fb);return;}}
}
static int ent_name_eq(const char*a,u32 al,const char*b){
    for(u32 k=0;k<al;k++){char c=a[k];if(c>='A'&&c<='Z')c=(char)(c-'A'+'a');if(c!=b[k])return 0;}
    return b[al]==0;
}
static void ent_emit(char*out,u32*o,u32 os,const char*s){
    for(u32 k=0;s[k];k++){if(*o+1>=os)return;out[(*o)++]=s[k];}
}
static char accent_base(u32 c){
    if(c>=0xC0&&c<=0xC5)return 'A';if(c>=0xE0&&c<=0xE5)return 'a';
    if(c>=0xC8&&c<=0xCB)return 'E';if(c>=0xE8&&c<=0xEB)return 'e';
    if(c>=0xCC&&c<=0xCF)return 'I';if(c>=0xEC&&c<=0xEF)return 'i';
    if(c>=0xD2&&c<=0xD6)return 'O';if(c>=0xF2&&c<=0xF6)return 'o';
    if(c>=0xD9&&c<=0xDC)return 'U';if(c>=0xF9&&c<=0xFC)return 'u';
    if(c==0xC7)return 'C';if(c==0xE7)return 'c';
    if(c==0xD1)return 'N';if(c==0xF1)return 'n';
    if(c==0xDD)return 'Y';if(c==0xFD||c==0xFF)return 'y';
    if(c==0xD8)return 'O';if(c==0xF8)return 'o';
    return 0;
}
static void cp_map(u32 code,char*out){
    if(code>=0x20&&code<0x7F){out[0]=(char)code;out[1]=0;return;}
    const char*s;
    switch(code){
        case 0xA0:s=" ";break;case 0xA9:s="(c)";break;case 0xAE:s="(R)";break;case 0x2122:s="(TM)";break;
        case 0xAB:s="<<";break;case 0xBB:s=">>";break;
        case 0x2018:case 0x2019:case 0x201A:case 0x2032:s="'";break;
        case 0x201C:case 0x201D:case 0x201E:case 0x2033:s="\"";break;
        case 0x2010:case 0x2011:case 0x2012:case 0x2013:case 0x2014:case 0x2015:case 0x2212:s="-";break;
        case 0x2026:s="...";break;
        case 0x2022:case 0xB7:case 0x2027:case 0x25CF:case 0x25AA:case 0x25E6:s="*";break;
        case 0xB0:s="deg";break;case 0xB1:s="+/-";break;case 0xD7:s="x";break;case 0xF7:s="/";break;
        case 0x20AC:s="EUR";break;case 0xA3:s="GBP";break;case 0xA5:s="JPY";break;case 0xA2:s="c";break;
        case 0xA7:s="S";break;case 0xB6:s="P";break;
        case 0xBD:s="1/2";break;case 0xBC:s="1/4";break;case 0xBE:s="3/4";break;
        case 0xA1:s="!";break;case 0xBF:s="?";break;
        case 0x2192:s="->";break;case 0x2190:s="<-";break;case 0x2191:s="^";break;case 0x2193:s="v";break;
        case 0x2264:s="<=";break;case 0x2265:s=">=";break;case 0x2260:s="!=";break;
        case 0xC6:s="AE";break;case 0xE6:s="ae";break;case 0xDF:s="ss";break;case 0x152:s="OE";break;case 0x153:s="oe";break;
        default:{char b=accent_base(code);if(b){out[0]=b;out[1]=0;return;}s="?";}break;
    }
    u32 k=0;while(s[k]){out[k]=s[k];k++;}out[k]=0;
}
static void decode_ent(const char*in,u32 il,char*out,u32 os,u32*ol){
    u32 i=0,o=0;
    while(i<il&&o+1<os){
        if((u8)in[i]>=0x80){
            u8 c0=(u8)in[i];u32 code;u32 sl2;
            if((c0&0xE0)==0xC0&&i+1<il){code=((u32)(c0&0x1F)<<6)|((u8)in[i+1]&0x3F);sl2=2;}
            else if((c0&0xF0)==0xE0&&i+2<il){code=((u32)(c0&0x0F)<<12)|(((u32)((u8)in[i+1]&0x3F))<<6)|((u8)in[i+2]&0x3F);sl2=3;}
            else if((c0&0xF8)==0xF0&&i+3<il){code=((u32)(c0&0x07)<<18)|(((u32)((u8)in[i+1]&0x3F))<<12)|(((u32)((u8)in[i+2]&0x3F))<<6)|((u8)in[i+3]&0x3F);sl2=4;}
            else{code=c0;sl2=1;}
            char r8[6];cp_map(code,r8);ent_emit(out,&o,os,r8);i+=sl2;continue;
        }
        if(in[i]!='&'){out[o++]=in[i++];continue;}
        u32 semi=0,maxj=i+11<il?i+11:il;
        for(u32 j=i+1;j<maxj;j++){if(in[j]==';'){semi=j;break;}if(in[j]=='&'||in[j]==' ')break;}
        if(semi==0){out[o++]='&';i++;continue;}
        u32 nl=semi-(i+1);const char*nm=in+i+1;
        if(nl>=2&&nm[0]=='#'){
            u32 code=0;int ok=1;
            if(nm[1]=='x'||nm[1]=='X'){
                for(u32 j=2;j<nl;j++){char c=nm[j];int v;if(c>='0'&&c<='9')v=c-'0';else if(c>='a'&&c<='f')v=c-'a'+10;else if(c>='A'&&c<='F')v=c-'A'+10;else{ok=0;break;}code=code*16+(u32)v;}
            }else{
                for(u32 j=1;j<nl;j++){char c=nm[j];if(c<'0'||c>'9'){ok=0;break;}code=code*10+(u32)(c-'0');}
            }
            if(ok){
                char rep[6];cp_map(code,rep);ent_emit(out,&o,os,rep);i=semi+1;continue;
            }
            out[o++]='&';i++;continue;
        }
        const char*rep=0;
        if(ent_name_eq(nm,nl,"amp"))rep="&";
        else if(ent_name_eq(nm,nl,"lt"))rep="<";
        else if(ent_name_eq(nm,nl,"gt"))rep=">";
        else if(ent_name_eq(nm,nl,"nbsp"))rep=" ";
        else if(ent_name_eq(nm,nl,"quot"))rep="\"";
        else if(ent_name_eq(nm,nl,"apos"))rep="'";
        else if(ent_name_eq(nm,nl,"copy"))rep="(c)";
        else if(ent_name_eq(nm,nl,"reg"))rep="(R)";
        else if(ent_name_eq(nm,nl,"trade"))rep="(TM)";
        else if(ent_name_eq(nm,nl,"mdash"))rep="--";
        else if(ent_name_eq(nm,nl,"ndash"))rep="-";
        else if(ent_name_eq(nm,nl,"hellip"))rep="...";
        else if(ent_name_eq(nm,nl,"rsquo")||ent_name_eq(nm,nl,"lsquo"))rep="'";
        else if(ent_name_eq(nm,nl,"rdquo")||ent_name_eq(nm,nl,"ldquo"))rep="\"";
        else if(ent_name_eq(nm,nl,"times"))rep="x";
        else if(ent_name_eq(nm,nl,"middot"))rep="\xB7";
        else if(ent_name_eq(nm,nl,"laquo"))rep="<<";
        else if(ent_name_eq(nm,nl,"raquo"))rep=">>";
        else if(ent_name_eq(nm,nl,"bull"))rep="*";
        else if(ent_name_eq(nm,nl,"deg"))rep="deg";
        else if(ent_name_eq(nm,nl,"euro"))rep="EUR";
        else if(ent_name_eq(nm,nl,"pound"))rep="GBP";
        else if(ent_name_eq(nm,nl,"yen"))rep="JPY";
        else if(ent_name_eq(nm,nl,"cent"))rep="c";
        else if(ent_name_eq(nm,nl,"sect"))rep="S";
        else if(ent_name_eq(nm,nl,"para"))rep="P";
        else if(ent_name_eq(nm,nl,"plusmn"))rep="+/-";
        else if(ent_name_eq(nm,nl,"divide"))rep="/";
        else if(ent_name_eq(nm,nl,"frac12"))rep="1/2";
        else if(ent_name_eq(nm,nl,"frac14"))rep="1/4";
        else if(ent_name_eq(nm,nl,"frac34"))rep="3/4";
        else if(ent_name_eq(nm,nl,"rarr"))rep="->";
        else if(ent_name_eq(nm,nl,"larr"))rep="<-";
        else if(ent_name_eq(nm,nl,"le"))rep="<=";
        else if(ent_name_eq(nm,nl,"ge"))rep=">=";
        else if(ent_name_eq(nm,nl,"ne"))rep="!=";
        else if(ent_name_eq(nm,nl,"aacute")||ent_name_eq(nm,nl,"agrave")||ent_name_eq(nm,nl,"acirc")||ent_name_eq(nm,nl,"auml")||ent_name_eq(nm,nl,"aring")||ent_name_eq(nm,nl,"atilde"))rep="a";
        else if(ent_name_eq(nm,nl,"eacute")||ent_name_eq(nm,nl,"egrave")||ent_name_eq(nm,nl,"ecirc")||ent_name_eq(nm,nl,"euml"))rep="e";
        else if(ent_name_eq(nm,nl,"iacute")||ent_name_eq(nm,nl,"igrave")||ent_name_eq(nm,nl,"icirc")||ent_name_eq(nm,nl,"iuml"))rep="i";
        else if(ent_name_eq(nm,nl,"oacute")||ent_name_eq(nm,nl,"ograve")||ent_name_eq(nm,nl,"ocirc")||ent_name_eq(nm,nl,"ouml")||ent_name_eq(nm,nl,"otilde")||ent_name_eq(nm,nl,"oslash"))rep="o";
        else if(ent_name_eq(nm,nl,"uacute")||ent_name_eq(nm,nl,"ugrave")||ent_name_eq(nm,nl,"ucirc")||ent_name_eq(nm,nl,"uuml"))rep="u";
        else if(ent_name_eq(nm,nl,"ntilde"))rep="n";
        else if(ent_name_eq(nm,nl,"ccedil"))rep="c";
        else if(ent_name_eq(nm,nl,"szlig"))rep="ss";
        else if(ent_name_eq(nm,nl,"aelig"))rep="ae";
        else if(ent_name_eq(nm,nl,"oelig"))rep="oe";
        if(rep){ent_emit(out,&o,os,rep);i=semi+1;continue;}
        out[o++]='&';i++;
    }
    out[o]=0;*ol=o;
}

#define CSS_MAX_RULES 160
typedef struct{u8 kind;char name[28];char cls[24];char idn[24];
    u8 has_fg,fr,fg,fb; u8 has_bg,br,bg,bb; u8 has_bold,bold; u8 has_ital,ital;
    u8 has_grad,g1r,g1g,g1b,g2r,g2g,g2b;
    u8 has_align,align; u8 has_fsize,fsize; u8 has_dec,dec_u,dec_s; u8 has_hidden,hidden;}css_rule_t;
static css_rule_t g_css[CSS_MAX_RULES];static int g_css_n=0;
static void css_reset(void){g_css_n=0;}
static u32 slen(const char*s){u32 n=0;while(s[n])n++;return n;}
static int tok_eq(const char*a,u32 al,const char*b,u32 bl){if(al!=bl)return 0;for(u32 i=0;i<al;i++)if(lc(a[i])!=lc(b[i]))return 0;return 1;}
static int css_gradient(const char*v,u32 l,u8*r1,u8*g1,u8*b1,u8*r2,u8*g2,u8*b2){
    while(l&&*v==' '){v++;l--;}
    const char*g="linear-gradient(";u32 gl=16;
    if(l<gl)return 0;for(u32 i=0;i<gl;i++)if(lc(v[i])!=g[i])return 0;
    u32 p=gl;u8 cols[2][3];int nc=0;u32 s=p;int depth=0;
    for(u32 i=p;i<l;i++){
        char c=v[i];
        if(c=='(')depth++;
        else if(c==')'){ if(depth==0){u8 cr,cg,cb;if(nc<2&&css_color(v+s,i-s,&cr,&cg,&cb)){cols[nc][0]=cr;cols[nc][1]=cg;cols[nc][2]=cb;nc++;}break;} depth--; }
        else if(c==','&&depth==0){u8 cr,cg,cb;if(nc<2&&css_color(v+s,i-s,&cr,&cg,&cb)){cols[nc][0]=cr;cols[nc][1]=cg;cols[nc][2]=cb;nc++;}s=i+1;}
    }
    if(nc==0)return 0;
    *r1=cols[0][0];*g1=cols[0][1];*b1=cols[0][2];
    if(nc>=2){*r2=cols[1][0];*g2=cols[1][1];*b2=cols[1][2];}else{*r2=*r1;*g2=*g1;*b2=*b1;}
    return 1;
}
static int val_has(const char*v,u32 l,const char*w){
    u32 wl=0;while(w[wl])wl++;
    if(l<wl)return 0;
    for(u32 i=0;i+wl<=l;i++){u32 k=0;while(k<wl&&lc(v[i+k])==w[k])k++;if(k==wl)return 1;}
    return 0;
}
static u32 val_num(const char*v,u32 l){
    u32 i=0,n=0;while(i<l&&!(v[i]>='0'&&v[i]<='9'))i++;
    while(i<l&&v[i]>='0'&&v[i]<='9'){n=n*10+(u32)(v[i]-'0');i++;}
    return n;
}
static void css_decls(css_rule_t*r,const char*d,u32 dl){
    u32 i=0;
    while(i<dl){
        while(i<dl&&(d[i]==' '||d[i]=='\t'||d[i]=='\n'||d[i]=='\r'||d[i]==';'))i++;
        u32 ps=i;while(i<dl&&d[i]!=':'&&d[i]!=';'&&d[i]!='}')i++;
        if(i>=dl||d[i]!=':'){while(i<dl&&d[i]!=';')i++;continue;}
        u32 pe=i;i++;
        u32 vs=i;while(i<dl&&d[i]!=';'&&d[i]!='}')i++;u32 ve=i;
        const char*pn=d+ps;u32 pnl=pe-ps;while(pnl&&(pn[pnl-1]==' '||pn[pnl-1]=='\t'))pnl--;
        const char*pv=d+vs;u32 pvl=ve-vs;while(pvl&&(pv[0]==' '||pv[0]=='\t')){pv++;pvl--;}while(pvl&&(pv[pvl-1]==' '||pv[pvl-1]=='\t'))pvl--;
        u8 cr,cg,cb;
        if(tok_eq(pn,pnl,"color",5)){if(css_color(pv,pvl,&cr,&cg,&cb)){r->has_fg=1;r->fr=cr;r->fg=cg;r->fb=cb;}}
        else if(tok_eq(pn,pnl,"background",10)||tok_eq(pn,pnl,"background-color",16)||tok_eq(pn,pnl,"background-image",16)){
            u8 a,b,c,e,f,g;
            if(css_gradient(pv,pvl,&a,&b,&c,&e,&f,&g)){r->has_grad=1;r->g1r=a;r->g1g=b;r->g1b=c;r->g2r=e;r->g2g=f;r->g2b=g;r->has_bg=1;r->br=a;r->bg=b;r->bb=c;}
            else if(css_color(pv,pvl,&cr,&cg,&cb)){r->has_bg=1;r->br=cr;r->bg=cg;r->bb=cb;}}
        else if(tok_eq(pn,pnl,"font-weight",11)){if(pvl&&((lc(pv[0])=='b')||(pv[0]>='6'&&pv[0]<='9'))){r->has_bold=1;r->bold=1;}else if(pvl){r->has_bold=1;r->bold=0;}}
        else if(tok_eq(pn,pnl,"font-style",10)){if(pvl&&lc(pv[0])=='i'){r->has_ital=1;r->ital=1;}}
        else if(tok_eq(pn,pnl,"text-align",10)){
            r->has_align=1;
            if(val_has(pv,pvl,"center"))r->align=HAL_CENTER;
            else if(val_has(pv,pvl,"right"))r->align=HAL_RIGHT;
            else r->align=HAL_LEFT;}
        else if(tok_eq(pn,pnl,"font-size",9)){
            u32 n=val_num(pv,pvl);
            r->has_fsize=1;
            if(val_has(pv,pvl,"xx-large")||val_has(pv,pvl,"x-large"))r->fsize=HFS_XLARGE;
            else if(val_has(pv,pvl,"larger")||val_has(pv,pvl,"large"))r->fsize=HFS_LARGE;
            else if(val_has(pv,pvl,"smaller")||val_has(pv,pvl,"small"))r->fsize=HFS_SMALL;
            else if(n>=30)r->fsize=HFS_XLARGE;
            else if(n>=20)r->fsize=HFS_LARGE;
            else if(n>0&&n<=12)r->fsize=HFS_SMALL;
            else r->fsize=HFS_NORMAL;}
        else if(tok_eq(pn,pnl,"text-decoration",15)||tok_eq(pn,pnl,"text-decoration-line",20)){
            r->has_dec=1;r->dec_u=0;r->dec_s=0;
            if(val_has(pv,pvl,"underline"))r->dec_u=1;
            if(val_has(pv,pvl,"line-through"))r->dec_s=1;}
        else if(tok_eq(pn,pnl,"display",7)){
            if(val_has(pv,pvl,"none")){r->has_hidden=1;r->hidden=1;}}
        else if(tok_eq(pn,pnl,"visibility",10)){
            if(val_has(pv,pvl,"hidden")){r->has_hidden=1;r->hidden=1;}}
    }
}
static void css_add_one(const char*sel,u32 sl,const char*dec,u32 dl){
    while(sl&&(sel[0]==' '||sel[0]=='\t'||sel[0]=='\n'||sel[0]=='\r')){sel++;sl--;}
    while(sl&&(sel[sl-1]==' '||sel[sl-1]=='\t'||sel[sl-1]=='\n'||sel[sl-1]=='\r'))sl--;
    if(!sl||g_css_n>=CSS_MAX_RULES)return;
    u32 st=0;for(u32 i=0;i<sl;i++)if(sel[i]==' '||sel[i]=='>')st=i+1;
    const char*s=sel+st;u32 l=sl-st;if(!l)return;
    css_rule_t*r=&g_css[g_css_n];
    for(u32 i=0;i<sizeof(r->name);i++)r->name[i]=0;
    r->has_fg=r->has_bg=r->has_bold=r->has_ital=r->has_grad=0;
    r->has_align=r->has_fsize=r->has_dec=r->has_hidden=0;
    r->cls[0]=0;r->idn[0]=0;
    for(u32 i=0;i<l;i++)if(s[i]==':'){l=i;break;}
    if(!l)return;
    u32 pi=0;
    u32 ts2=0;
    while(pi<l&&s[pi]!='.'&&s[pi]!='#'&&s[pi]!='[')pi++;
    u32 tlen=pi-ts2;
    u8 kind=3;
    if(tlen==1&&s[0]=='*'){kind=3;tlen=0;}
    else if(tlen>0){kind=0;}
    if(tlen>27)tlen=27;
    for(u32 i=0;i<tlen;i++)r->name[i]=lc(s[i]);
    r->name[tlen]=0;
    while(pi<l){
        char mk=s[pi];
        if(mk!='.'&&mk!='#'){pi++;continue;}
        pi++;
        u32 vs2=pi;
        while(pi<l&&s[pi]!='.'&&s[pi]!='#'&&s[pi]!='[')pi++;
        u32 vl2=pi-vs2;
        if(vl2>23)vl2=23;
        if(mk=='.'){for(u32 i=0;i<vl2;i++)r->cls[i]=s[vs2+i];r->cls[vl2]=0;if(kind==3&&!tlen)kind=1;}
        else{for(u32 i=0;i<vl2;i++)r->idn[i]=s[vs2+i];r->idn[vl2]=0;if(kind==3&&!tlen)kind=2;}
    }
    if(tlen>0)kind=0;
    r->kind=kind;
    css_decls(r,dec,dl);
    if(r->has_fg||r->has_bg||r->has_bold||r->has_ital||r->has_grad||
       r->has_align||r->has_fsize||r->has_dec||r->has_hidden)g_css_n++;
}
static void css_parse_block(const char*c,u32 cl){
    u32 i=0;
    while(i<cl&&g_css_n<CSS_MAX_RULES){
        while(i<cl&&(c[i]==' '||c[i]=='\n'||c[i]=='\r'||c[i]=='\t'))i++;
        if(i+1<cl&&c[i]=='/'&&c[i+1]=='*'){i+=2;while(i+1<cl&&!(c[i]=='*'&&c[i+1]=='/'))i++;i+=2;continue;}
        u32 ss=i;while(i<cl&&c[i]!='{'&&c[i]!='}')i++;
        if(i>=cl||c[i]!='{'){break;}
        u32 se=i;i++;
        u32 ds=i;while(i<cl&&c[i]!='}')i++;u32 de=i;if(i<cl)i++;
        if(c[ss]=='@'){continue;}
        u32 a=ss;
        for(u32 k=ss;k<=se;k++)
            if(k==se||c[k]==','){css_add_one(c+a,k-a,c+ds,de-ds);a=k+1;}
    }
}
static u8 s_align=HAL_LEFT,s_fsize=HFS_NORMAL,s_under=0,s_strike=0,s_indent=0,s_hidden=0,s_has_bg=0;
static u8 s_bullet=0;
static char s_pend_id[40];static u32 s_pend_id_len=0;

typedef struct{
    char tag[12];
    u8 fr,fg,fb,br,bg,bb;
    int bold,italic,code,heading,pre,is_link;
    u8 align,fsize,under,strike,indent,hidden,has_bg;
}sty_frame_t;
#define STY_STACK_MAX 40
static sty_frame_t g_sty[STY_STACK_MAX];
static int g_sty_n=0;

static int class_list_has(const char*cls,u32 cll,const char*want){
    u32 rl=slen(want);
    if(!rl)return 1;
    u32 j=0;
    while(j<cll){
        while(j<cll&&(cls[j]==' '||cls[j]=='\t'))j++;
        u32 st2=j;while(j<cll&&cls[j]!=' '&&cls[j]!='\t')j++;
        if(st2<j&&tok_eq(cls+st2,j-st2,want,rl))return 1;
    }
    return 0;
}
static int css_rule_matches(css_rule_t*r,const char*tn,u32 tnl,const char*cls,u32 cll,const char*id,u32 idl){
    if(r->name[0]&&!tag_is(tn,tnl,r->name))return 0;
    if(r->cls[0]&&!(cls&&class_list_has(cls,cll,r->cls)))return 0;
    if(r->idn[0]&&!(id&&tok_eq(id,idl,r->idn,slen(r->idn))))return 0;
    if(!r->name[0]&&!r->cls[0]&&!r->idn[0])return r->kind==3;
    return 1;
}

static void css_rule_use(css_rule_t*r,u8*fr,u8*fg,u8*fb,u8*br,u8*bg,u8*bb,int*bold,int*italic){
    if(r->has_fg){*fr=r->fr;*fg=r->fg;*fb=r->fb;}
    if(r->has_bg){*br=r->br;*bg=r->bg;*bb=r->bb;s_has_bg=1;}
    if(r->has_bold)*bold=r->bold;
    if(r->has_ital&&italic)*italic=r->ital;
    if(r->has_align)s_align=r->align;
    if(r->has_fsize)s_fsize=r->fsize;
    if(r->has_dec){s_under=r->dec_u;s_strike=r->dec_s;}
    if(r->has_hidden)s_hidden=r->hidden;
}

static void css_apply(const char*tn,u32 tnl,const char*cls,u32 cll,const char*id,u32 idl,
    u8*fr,u8*fg,u8*fb,u8*br,u8*bg,u8*bb,int*bold,int*italic){
    for(int pass=0;pass<3;pass++){
        for(int i=0;i<g_css_n;i++){
            css_rule_t*r=&g_css[i];
            int spec=0;
            if(r->cls[0])spec=1;
            if(r->idn[0])spec=2;
            if(spec!=pass)continue;
            if(!css_rule_matches(r,tn,tnl,cls,cll,id,idl))continue;
            css_rule_use(r,fr,fg,fb,br,bg,bb,bold,italic);
        }
    }
}

static void apply_inline_style(const char*sv,u32 sl,u8*fr,u8*fg,u8*fb,u8*br,u8*bg,u8*bb,int*bold,int*italic){
    css_rule_t r;
    for(u32 i=0;i<sizeof(r.name);i++)r.name[i]=0;
    r.kind=0;
    r.has_fg=r.has_bg=r.has_bold=r.has_ital=r.has_grad=0;
    r.has_align=r.has_fsize=r.has_dec=r.has_hidden=0;
    css_decls(&r,sv,sl);
    css_rule_use(&r,fr,fg,fb,br,bg,bb,bold,italic);
}

static u8 g_page_r=250,g_page_g=250,g_page_b=252;
static int g_page_grad=0; static u8 g_pg1r=250,g_pg1g=250,g_pg1b=252,g_pg2r=230,g_pg2g=232,g_pg2b=240;
static int pg_name_is(const char*n,const char*s){u32 i=0;while(n[i]&&s[i]){if(n[i]!=s[i])return 0;i++;}return n[i]==0&&s[i]==0;}
static void resolve_page_bg(const char*cls,u32 cll,const char*id,u32 idl,const char*style,u32 stl){
    g_page_r=250;g_page_g=250;g_page_b=252;g_page_grad=0;
    for(int i=0;i<g_css_n;i++){
        css_rule_t*r=&g_css[i];int match=0;
        if(!r->name[0]&&!r->cls[0]&&!r->idn[0])match=(r->kind==3);
        else{
            match=1;
            if(r->name[0]&&!(pg_name_is(r->name,"body")||pg_name_is(r->name,"html")))match=0;
            if(match&&r->cls[0]&&!(cls&&class_list_has(cls,cll,r->cls)))match=0;
            if(match&&r->idn[0]&&!(id&&tok_eq(id,idl,r->idn,slen(r->idn))))match=0;
        }
        if(!match)continue;
        if(r->has_grad){g_page_grad=1;g_pg1r=r->g1r;g_pg1g=r->g1g;g_pg1b=r->g1b;g_pg2r=r->g2r;g_pg2g=r->g2g;g_pg2b=r->g2b;}
        else if(r->has_bg){g_page_grad=0;g_page_r=r->br;g_page_g=r->bg;g_page_b=r->bb;}
    }
    if(style&&stl){u8 a,b,c,e,f,g;
        for(u32 k=0;k+5<=stl;k++){
            if(lc(style[k])=='b'&&lc(style[k+1])=='a'&&lc(style[k+2])=='c'&&lc(style[k+3])=='k'&&lc(style[k+4])=='g'){
                u32 v=k;while(v<stl&&style[v]!=':')v++;if(v<stl)v++;while(v<stl&&style[v]==' ')v++;u32 en=v;while(en<stl&&style[en]!=';')en++;
                if(css_gradient(style+v,en-v,&a,&b,&c,&e,&f,&g)){g_page_grad=1;g_pg1r=a;g_pg1g=b;g_pg1b=c;g_pg2r=e;g_pg2g=f;g_pg2b=g;}
                else if(css_color(style+v,en-v,&a,&b,&c)){g_page_grad=0;g_page_r=a;g_page_g=b;g_page_b=c;}
                break;}}}
}
void html_page_bg(u8*r,u8*g,u8*b,int*grad,u8*g1r,u8*g1g,u8*g1b,u8*g2r,u8*g2g,u8*g2b){
    *r=g_page_r;*g=g_page_g;*b=g_page_b;*grad=g_page_grad;
    *g1r=g_pg1r;*g1g=g_pg1g;*g1b=g_pg1b;*g2r=g_pg2r;*g2g=g_pg2g;*g2b=g_pg2b;
}
static void flush_pending(html_doc_t*doc,char*pt,u32*ptl,
    int is_link,const char*hb,u32 hl,
    u8 fr,u8 fg,u8 fb,u8 br,u8 bg,u8 bb,
    int bold,int italic,int code,int heading,int pre){
    if(*ptl==0)return;
    if(doc->count>=HTML_MAX_ELEMENTS){*ptl=0;return;}
    static char dec[HTML_POOL_SIZE];u32 dl=0;
    decode_ent(pt,*ptl,dec,sizeof(dec),&dl);
    u32 before=doc->pool_used;
    u32 off=pool_add(doc,dec,dl);
    u32 stored=doc->pool_used-before;
    html_el_t*el=&doc->els[doc->count++];
    el->type=is_link?HEL_LINK:HEL_TEXT;
    el->text_off=off;el->text_len=stored;
    el->fg_r=fr;el->fg_g=fg;el->fg_b=fb;
    el->bg_r=br;el->bg_g=bg;el->bg_b=bb;
    el->bold=bold;el->italic=italic;el->code=code;el->heading=heading;el->is_pre=pre;
    el->align=s_align;el->fsize=s_fsize;el->underline=s_under;el->strike=s_strike;
    el->indent=s_indent;el->hidden=s_hidden;el->bullet=s_bullet;
    el->dom_id_off=0;el->dom_id_len=0;
    if(s_pend_id_len){u32 i0=doc->pool_used;el->dom_id_off=pool_add(doc,s_pend_id,s_pend_id_len);
        el->dom_id_len=doc->pool_used-i0;s_pend_id_len=0;}
    s_bullet=0;
    if(is_link){u32 hb0=doc->pool_used;el->href_off=pool_add(doc,hb,hl);el->href_len=doc->pool_used-hb0;}
    else{el->href_off=0;el->href_len=0;}
    *ptl=0;
}
static void add_gap_el(html_doc_t*doc,int n){
    if(doc->count>=HTML_MAX_ELEMENTS)return;
    html_el_t*el=&doc->els[doc->count++];
    el->type=HEL_GAP;el->text_off=0;el->text_len=(u32)n;
    el->fg_r=el->fg_g=el->fg_b=el->bg_r=el->bg_g=el->bg_b=0;
    el->bold=el->italic=el->code=el->heading=el->is_pre=0;
    el->href_off=el->href_len=0;
    el->align=HAL_LEFT;el->fsize=HFS_NORMAL;el->underline=0;el->strike=0;
    el->indent=0;el->hidden=s_hidden;el->bullet=0;el->dom_id_off=0;el->dom_id_len=0;
}
static void add_hr_el(html_doc_t*doc){
    if(doc->count>=HTML_MAX_ELEMENTS)return;
    html_el_t*el=&doc->els[doc->count++];
    el->type=HEL_HR;el->text_off=0;el->text_len=0;
    el->fg_r=80;el->fg_g=80;el->fg_b=120;el->bg_r=el->bg_g=el->bg_b=0;
    el->bold=el->italic=el->code=el->heading=el->is_pre=0;
    el->href_off=el->href_len=0;
}
static void add_img_el(html_doc_t*doc,const char*src,u32 srclen,const char*alt,u32 altlen){
    if(doc->count>=HTML_MAX_ELEMENTS)return;
    html_el_t*el=&doc->els[doc->count++];
    el->type=HEL_IMG;
    u32 b0=doc->pool_used;
    if(alt&&altlen)el->text_off=pool_add(doc,alt,altlen);else el->text_off=pool_add(doc,"image",5);
    el->text_len=doc->pool_used-b0;
    u32 h0=doc->pool_used;el->href_off=pool_add(doc,src,srclen);el->href_len=doc->pool_used-h0;
    el->fg_r=150;el->fg_g=170;el->fg_b=210;el->bg_r=el->bg_g=el->bg_b=0;
    el->bold=el->italic=el->code=el->heading=el->is_pre=0;
}

static int in_pre=0,heading=0;
static u8 fr=38,fg=40,fb=48,br=0,bg=0,bb=0;
static int bold=0,italic=0,code=0,is_link=0;
static char hb[128];static u32 hl=0;
static html_doc_t* g_doc=0;
static char pt[HTML_POOL_SIZE];static u32 ptl=0;

static void push_style(const char*tn,u32 tnl){
    if(g_sty_n>=STY_STACK_MAX)return;
    sty_frame_t*f=&g_sty[g_sty_n++];
    u32 n=tnl<sizeof(f->tag)-1?tnl:sizeof(f->tag)-1;
    for(u32 i=0;i<n;i++)f->tag[i]=lc(tn[i]);
    f->tag[n]=0;
    f->fr=fr;f->fg=fg;f->fb=fb;f->br=br;f->bg=bg;f->bb=bb;
    f->bold=bold;f->italic=italic;f->code=code;f->heading=heading;f->pre=in_pre;f->is_link=is_link;
    f->align=s_align;f->fsize=s_fsize;f->under=s_under;f->strike=s_strike;
    f->indent=s_indent;f->hidden=s_hidden;f->has_bg=s_has_bg;
}
static void pop_style(const char*tn,u32 tnl){
    char want[12];
    u32 n=tnl<sizeof(want)-1?tnl:sizeof(want)-1;
    for(u32 i=0;i<n;i++)want[i]=lc(tn[i]);
    want[n]=0;
    for(int i=g_sty_n-1;i>=0;i--){
        u32 k=0;while(g_sty[i].tag[k]&&want[k]&&g_sty[i].tag[k]==want[k])k++;
        if(g_sty[i].tag[k]==0&&want[k]==0){
            sty_frame_t*f=&g_sty[i];
            fr=f->fr;fg=f->fg;fb=f->fb;br=f->br;bg=f->bg;bb=f->bb;
            bold=f->bold;italic=f->italic;code=f->code;heading=f->heading;in_pre=f->pre;is_link=f->is_link;
            s_align=f->align;s_fsize=f->fsize;s_under=f->under;s_strike=f->strike;
            s_indent=f->indent;s_hidden=f->hidden;s_has_bg=f->has_bg;
            g_sty_n=i;
            return;
        }
    }
}
static int is_void_tag(const char*t,u32 l){
    return tag_is(t,l,"br")||tag_is(t,l,"hr")||tag_is(t,l,"img")||tag_is(t,l,"input")||
           tag_is(t,l,"meta")||tag_is(t,l,"link")||tag_is(t,l,"col")||tag_is(t,l,"source")||
           tag_is(t,l,"area")||tag_is(t,l,"base")||tag_is(t,l,"embed")||tag_is(t,l,"wbr");
}

void html_emit_text(html_doc_t*doc,const char*str,u32 len){
    if(!doc)return;
    for(u32 i=0;i<len;i++){
        char c=str[i];
        if(c=='\n'){
            flush_pending(doc,pt,&ptl,is_link,hb,hl,fr,fg,fb,br,bg,bb,bold,italic,code,heading,in_pre);
            add_gap_el(doc,1);
            continue;
        }
        if(ptl+2<HTML_POOL_SIZE)pt[ptl++]=c;
    }
    flush_pending(doc,pt,&ptl,is_link,hb,hl,fr,fg,fb,br,bg,bb,bold,italic,code,heading,in_pre);
}

int html_set_by_id(html_doc_t*doc,const char*id,const char*text,u32 len){
    if(!doc)return 0;
    u32 il=0;while(id[il])il++;
    if(!il)return 0;
    int found=0;
    for(int i=0;i<doc->count;i++){
        html_el_t*e=&doc->els[i];
        if(e->dom_id_len!=il)continue;
        u32 k=0;while(k<il&&doc->pool[e->dom_id_off+k]==id[k])k++;
        if(k!=il)continue;
        u32 before=doc->pool_used;
        e->text_off=pool_add(doc,text,len);
        e->text_len=doc->pool_used-before;
        e->hidden=0;
        if(e->type==HEL_GAP)e->type=HEL_TEXT;
        found=1;
    }
    return found;
}

void html_parse(const char*src,u32 len,u32 cpl,html_doc_t*doc){
    watchdog_heartbeat("web: parsing");
    doc->count=0;doc->pool_used=0;doc->anchor_count=0;
    doc->css_rules=0;doc->scripts_run=0;doc->js_errors=0;doc->js_error[0]=0;g_page_r=250;g_page_g=250;g_page_b=252;g_page_grad=0;(void)cpl;
    css_reset();
    if(!src||!len)return;
    in_pre=0;heading=0;
    int in_script=0;
    fr=38;fg=40;fb=48;br=0;bg=0;bb=0;
    bold=0;italic=0;code=0;is_link=0;
    hl=0;hb[0]=0;
    s_align=HAL_LEFT;s_fsize=HFS_NORMAL;s_under=0;s_strike=0;s_indent=0;s_hidden=0;
    s_has_bg=0;s_bullet=0;s_pend_id_len=0;g_sty_n=0;g_doc=doc;
    int list_depth=0;int ol_flag[8];int ol_idx[8];
    for(int q=0;q<8;q++){ol_flag[q]=0;ol_idx[q]=1;}
    ptl=0;
    u32 i=0;
    while(i<len){
        if(src[i]=='<'){
            u32 ts=i+1;while(i<len&&src[i]!='>') i++;
            u32 te=i;if(i<len)i++;
            const char*tag=src+ts;u32 tl=te-ts;if(!tl)continue;
            int cl=(tag[0]=='/');
            const char*tn=cl?tag+1:tag;u32 tnl=0;
            while(tnl<tl-(u32)(cl?1:0)&&tn[tnl]!=' '&&tn[tnl]!='/'&&tn[tnl]!='\t')tnl++;
            if(in_script){if(tag_is(tn,tnl,"script")&&cl)in_script=0;continue;}
            if(tag_is(tn,tnl,"script")&&!cl){
                flush_pending(doc,pt,&ptl,is_link,hb,hl,fr,fg,fb,br,bg,bb,bold,italic,code,heading,in_pre);
                u32 body=i;
                u32 after=skip_after(src,len,i,"</script>");
                u32 end=after;
                if(end>=body+9)end-=9;else end=body;
                const char*srcattr;u32 srcattrl;
                int external=find_attr(tag,tl,"src",&srcattr,&srcattrl);
                if(!external&&end>body){
                    doc->scripts_run++;
                    js_run(src+body,end-body,doc);
                }
                i=after;in_script=0;continue;
            }
            if(tag_is(tn,tnl,"style")&&!cl){
                flush_pending(doc,pt,&ptl,is_link,hb,hl,fr,fg,fb,br,bg,bb,bold,italic,code,heading,in_pre);
                u32 cs=i;u32 ce=skip_after(src,len,i,"</style>");
                u32 clen=ce-cs;if(clen>=8)clen-=8;
                css_parse_block(src+cs,clen);
                i=ce;continue;
            }
            if(tag_is(tn,tnl,"svg")&&!cl&&tag[tl-1]!='/'){
                flush_pending(doc,pt,&ptl,is_link,hb,hl,fr,fg,fb,br,bg,bb,bold,italic,code,heading,in_pre);
                i=skip_after(src,len,i,"</svg>");continue;
            }
            if(tag_is(tn,tnl,"title")&&!cl){i=skip_after(src,len,i,"</title>");continue;}
            if(tag_is(tn,tnl,"head")){continue;}
            if(!cl&&!is_void_tag(tn,tnl)&&!(tl>0&&tag[tl-1]=='/'))push_style(tn,tnl);
            if(tag_is(tn,tnl,"pre")||tag_is(tn,tnl,"code")){
                flush_pending(doc,pt,&ptl,is_link,hb,hl,fr,fg,fb,br,bg,bb,bold,italic,code,heading,in_pre);
                if(!cl){in_pre=1;code=1;fr=160;fg=220;fb=150;}
                else{in_pre=0;code=0;fr=38;fg=40;fb=48;}
            }else if(tag_is(tn,tnl,"br")){
                flush_pending(doc,pt,&ptl,is_link,hb,hl,fr,fg,fb,br,bg,bb,bold,italic,code,heading,in_pre);
                add_gap_el(doc,1);
            }else if(tag_is(tn,tnl,"hr")){
                flush_pending(doc,pt,&ptl,is_link,hb,hl,fr,fg,fb,br,bg,bb,bold,italic,code,heading,in_pre);
                add_gap_el(doc,1);add_hr_el(doc);add_gap_el(doc,1);
            }else if(tag_is(tn,tnl,"p")||tag_is(tn,tnl,"div")||tag_is(tn,tnl,"section")||
                     tag_is(tn,tnl,"article")||tag_is(tn,tnl,"main")||tag_is(tn,tnl,"nav")||
                     tag_is(tn,tnl,"header")||tag_is(tn,tnl,"footer")||tag_is(tn,tnl,"figure")||
                     tag_is(tn,tnl,"figcaption")||tag_is(tn,tnl,"aside")||
                     tag_is(tn,tnl,"button")){
                flush_pending(doc,pt,&ptl,is_link,hb,hl,fr,fg,fb,br,bg,bb,bold,italic,code,heading,in_pre);
                add_gap_el(doc,1);
            }else if(tag_is(tn,tnl,"blockquote")){
                flush_pending(doc,pt,&ptl,is_link,hb,hl,fr,fg,fb,br,bg,bb,bold,italic,code,heading,in_pre);
                add_gap_el(doc,1);
                if(!cl){s_indent=(u8)(s_indent+1);italic=1;}
            }else if(tnl>0&&tn[0]=='h'&&tnl==2&&tn[1]>='1'&&tn[1]<='6'){
                flush_pending(doc,pt,&ptl,is_link,hb,hl,fr,fg,fb,br,bg,bb,bold,italic,code,heading,in_pre);
                if(!cl){add_gap_el(doc,1);heading=tn[1]-'0';bold=1;
                    s_fsize=(heading<=1)?HFS_XLARGE:(heading==2)?HFS_LARGE:HFS_NORMAL;
                    fr=22;fg=32;fb=78;
                }else{heading=0;bold=0;fr=38;fg=40;fb=48;add_gap_el(doc,1);}
            }else if(tag_is(tn,tnl,"strong")||tag_is(tn,tnl,"b")){
                flush_pending(doc,pt,&ptl,is_link,hb,hl,fr,fg,fb,br,bg,bb,bold,italic,code,heading,in_pre);
                bold=cl?0:1;if(!cl){fr=15;fg=18;fb=28;}else{fr=38;fg=40;fb=48;}
            }else if(tag_is(tn,tnl,"em")||tag_is(tn,tnl,"i")){
                flush_pending(doc,pt,&ptl,is_link,hb,hl,fr,fg,fb,br,bg,bb,bold,italic,code,heading,in_pre);
                italic=cl?0:1;
            }else if(tag_is(tn,tnl,"a")){
                flush_pending(doc,pt,&ptl,is_link,hb,hl,fr,fg,fb,br,bg,bb,bold,italic,code,heading,in_pre);
                if(!cl){is_link=1;const char*hv;u32 hvl;
                    if(find_attr(tag,tl,"href",&hv,&hvl)){hl=hvl<127?hvl:127;memcpy(hb,hv,hl);hb[hl]=0;}
                    else{hl=0;hb[0]=0;}
                }else{is_link=0;hl=0;}
            }else if(tag_is(tn,tnl,"li")){
                flush_pending(doc,pt,&ptl,is_link,hb,hl,fr,fg,fb,br,bg,bb,bold,italic,code,heading,in_pre);
                if(!cl){
                    add_gap_el(doc,1);
                    s_indent=(u8)(list_depth?list_depth:1);
                    if(ol_flag[list_depth]){
                        int num=ol_idx[list_depth]++;
                        ptl=0;
                        if(num>=10)pt[ptl++]=(char)('0'+(num/10)%10);
                        pt[ptl++]=(char)('0'+num%10);
                        pt[ptl++]='.';pt[ptl++]=' ';
                    }else{
                        s_bullet=1;ptl=0;
                    }
                }
            }else if(tag_is(tn,tnl,"img")){
                flush_pending(doc,pt,&ptl,is_link,hb,hl,fr,fg,fb,br,bg,bb,bold,italic,code,heading,in_pre);
                if(!cl){const char*sv;u32 svl;const char*av;u32 avl;
                    if(find_attr(tag,tl,"src",&sv,&svl)&&svl>0){
                        if(!(find_attr(tag,tl,"alt",&av,&avl)&&avl>0)){av=0;avl=0;}
                        add_img_el(doc,sv,svl,av,avl);
                    }
                }
            }else if(tag_is(tn,tnl,"ul")||tag_is(tn,tnl,"ol")){
                flush_pending(doc,pt,&ptl,is_link,hb,hl,fr,fg,fb,br,bg,bb,bold,italic,code,heading,in_pre);
                if(!cl){
                    if(list_depth<7)list_depth++;
                    ol_flag[list_depth]=tag_is(tn,tnl,"ol");
                    ol_idx[list_depth]=1;
                    s_indent=(u8)list_depth;
                }else{
                    if(list_depth>0)list_depth--;
                    s_indent=(u8)list_depth;
                }
                add_gap_el(doc,1);
            }else if(tag_is(tn,tnl,"tr")||tag_is(tn,tnl,"table")){
                flush_pending(doc,pt,&ptl,is_link,hb,hl,fr,fg,fb,br,bg,bb,bold,italic,code,heading,in_pre);
                if(cl)add_gap_el(doc,1);
            }else if(tag_is(tn,tnl,"td")||tag_is(tn,tnl,"th")){
                if(!cl){if(tag_is(tn,tnl,"th"))bold=1;}
                else if(ptl+1<HTML_POOL_SIZE)pt[ptl++]='\t';
            }else if(tag_is(tn,tnl,"u")||tag_is(tn,tnl,"ins")){
                flush_pending(doc,pt,&ptl,is_link,hb,hl,fr,fg,fb,br,bg,bb,bold,italic,code,heading,in_pre);
                if(!cl)s_under=1;
            }else if(tag_is(tn,tnl,"s")||tag_is(tn,tnl,"del")||tag_is(tn,tnl,"strike")){
                flush_pending(doc,pt,&ptl,is_link,hb,hl,fr,fg,fb,br,bg,bb,bold,italic,code,heading,in_pre);
                if(!cl)s_strike=1;
            }else if(tag_is(tn,tnl,"small")||tag_is(tn,tnl,"sub")||tag_is(tn,tnl,"sup")){
                flush_pending(doc,pt,&ptl,is_link,hb,hl,fr,fg,fb,br,bg,bb,bold,italic,code,heading,in_pre);
                if(!cl)s_fsize=HFS_SMALL;
            }else if(tag_is(tn,tnl,"big")){
                flush_pending(doc,pt,&ptl,is_link,hb,hl,fr,fg,fb,br,bg,bb,bold,italic,code,heading,in_pre);
                if(!cl)s_fsize=HFS_LARGE;
            }else if(tag_is(tn,tnl,"mark")){
                flush_pending(doc,pt,&ptl,is_link,hb,hl,fr,fg,fb,br,bg,bb,bold,italic,code,heading,in_pre);
                if(!cl){br=250;bg=232;bb=140;s_has_bg=1;fr=30;fg=28;fb=20;}
            }else if(tag_is(tn,tnl,"center")){
                flush_pending(doc,pt,&ptl,is_link,hb,hl,fr,fg,fb,br,bg,bb,bold,italic,code,heading,in_pre);
                add_gap_el(doc,1);
                if(!cl)s_align=HAL_CENTER;
            }else if(tag_is(tn,tnl,"span")){
                flush_pending(doc,pt,&ptl,is_link,hb,hl,fr,fg,fb,br,bg,bb,bold,italic,code,heading,in_pre);
            }
            if(cl&&!is_void_tag(tn,tnl))pop_style(tn,tnl);
            if(!cl){const char*cv=0,*iv=0;u32 cvl=0,ivl=0;
                find_attr(tag,tl,"class",&cv,&cvl);find_attr(tag,tl,"id",&iv,&ivl);
                css_apply(tn,tnl,cv,cvl,iv,ivl,&fr,&fg,&fb,&br,&bg,&bb,&bold,&italic);
                {const char*sv3=0;u32 svl3=0;
                 if(find_attr(tag,tl,"style",&sv3,&svl3))
                     apply_inline_style(sv3,svl3,&fr,&fg,&fb,&br,&bg,&bb,&bold,&italic);}
                {const char*av3=0;u32 avl3=0;
                 if(find_attr(tag,tl,"align",&av3,&avl3)){
                     if(val_has(av3,avl3,"center"))s_align=HAL_CENTER;
                     else if(val_has(av3,avl3,"right"))s_align=HAL_RIGHT;}}
                if(ivl>0&&ivl<sizeof(s_pend_id)){
                    for(u32 q=0;q<ivl;q++)s_pend_id[q]=iv[q];
                    s_pend_id[ivl]=0;s_pend_id_len=ivl;}
                if(tag_is(tn,tnl,"body")||tag_is(tn,tnl,"html")){const char*sv2=0;u32 svl2=0;find_attr(tag,tl,"style",&sv2,&svl2);resolve_page_bg(cv,cvl,iv,ivl,sv2,svl2);}
                if(ivl==0&&tag_is(tn,tnl,"a"))find_attr(tag,tl,"name",&iv,&ivl);
                if(ivl>0&&doc->anchor_count<HTML_MAX_ANCHORS){u32 nl=ivl<39?ivl:39;
                    memcpy(doc->anchors[doc->anchor_count].name,iv,nl);doc->anchors[doc->anchor_count].name[nl]=0;
                    doc->anchors[doc->anchor_count].el=doc->count;doc->anchor_count++;}}
            continue;
        }
        char c=src[i++];
        if(c=='\r')continue;
        if(c=='\n'){
            if(in_pre){flush_pending(doc,pt,&ptl,is_link,hb,hl,fr,fg,fb,br,bg,bb,bold,italic,code,heading,in_pre);add_gap_el(doc,1);}
            else if(ptl>0&&pt[ptl-1]!=' ')pt[ptl++]=' ';
            continue;
        }
        if((c==' '||c=='\t')&&!in_pre){if(ptl>0&&pt[ptl-1]!=' ')pt[ptl++]=' ';continue;}
        if(ptl+1>=HTML_POOL_SIZE){flush_pending(doc,pt,&ptl,is_link,hb,hl,fr,fg,fb,br,bg,bb,bold,italic,code,heading,in_pre);}
        pt[ptl++]=c;
    }
    flush_pending(doc,pt,&ptl,is_link,hb,hl,fr,fg,fb,br,bg,bb,bold,italic,code,heading,in_pre);
    doc->css_rules=g_css_n;
}

void html_text(const html_doc_t*doc,u32 off,u32 len,char*out,u32 os){
    if(off>HTML_POOL_SIZE)off=HTML_POOL_SIZE;
    u32 avail=HTML_POOL_SIZE-off;if(len>avail)len=avail;
    u32 n=len<os-1?len:os-1;if(n)memcpy(out,doc->pool+off,n);out[n]=0;
}
int html_anchor_el(const html_doc_t*doc,const char*name){
    for(int i=0;i<doc->anchor_count;i++){
        const char*a=doc->anchors[i].name;const char*b=name;int eq=1;
        while(*a&&*b){char ca=*a,cb=*b;if(ca>='A'&&ca<='Z')ca+=32;if(cb>='A'&&cb<='Z')cb+=32;
            if(ca!=cb){eq=0;break;}a++;b++;}
        if(eq&&*a==0&&*b==0)return doc->anchors[i].el;
    }
    return -1;
}

void md_parse(const char*src,u32 len,u32 cpl,html_doc_t*doc){
    doc->count=0;doc->pool_used=0;doc->anchor_count=0;
    doc->css_rules=0;doc->scripts_run=0;doc->js_errors=0;doc->js_error[0]=0;g_page_r=250;g_page_g=250;g_page_b=252;g_page_grad=0;(void)cpl;
    if(!src||!len)return;
    u32 i=0;
    while(i<len&&doc->count<HTML_MAX_ELEMENTS-2){
        u32 ls=i;while(i<len&&src[i]!='\n')i++;
        u32 le=i;if(i<len)i++;
        u32 ll=le-ls;while(ll>0&&(src[ls+ll-1]=='\r'||src[ls+ll-1]==' '))ll--;
        if(!ll){add_gap_el(doc,1);continue;}
        const char*line=src+ls;
        if(line[0]=='#'){
            u32 hc=0;while(hc<ll&&line[hc]=='#')hc++;
            const char*ht=line+hc;u32 htl=ll-hc;while(htl>0&&ht[0]==' '){ht++;htl--;}
            add_gap_el(doc,1);
            if(doc->count<HTML_MAX_ELEMENTS){
                html_el_t*el=&doc->els[doc->count++];
                el->type=HEL_HEADING;el->text_off=pool_add(doc,ht,htl);el->text_len=htl;
                el->fg_r=hc==1?240:hc==2?200:170;el->fg_g=hc==1?200:hc==2?180:165;el->fg_b=255;
                el->bg_r=el->bg_g=el->bg_b=0;el->bold=1;el->italic=0;el->code=0;
                el->heading=(int)hc;el->is_pre=0;el->href_off=0;el->href_len=0;
            }
            add_gap_el(doc,1);
        }else if(ll>2&&(line[0]=='-'||line[0]=='*')&&line[1]==' '){
            if(doc->count<HTML_MAX_ELEMENTS){
                char buf[128];buf[0]=0xB7;buf[1]=' ';u32 bl=ll-2<126?ll-2:126;memcpy(buf+2,line+2,bl);bl+=2;
                html_el_t*el=&doc->els[doc->count++];
                el->type=HEL_TEXT;el->text_off=pool_add(doc,buf,bl);el->text_len=bl;
                el->fg_r=200;el->fg_g=210;el->fg_b=240;
                el->bg_r=el->bg_g=el->bg_b=0;el->bold=0;el->italic=0;el->code=0;el->heading=0;el->is_pre=0;
                el->href_off=0;el->href_len=0;
            }
        }else{
            if(doc->count<HTML_MAX_ELEMENTS){
                html_el_t*el=&doc->els[doc->count++];
                el->type=HEL_TEXT;el->text_off=pool_add(doc,line,ll);el->text_len=ll;
                el->fg_r=220;el->fg_g=222;el->fg_b=255;
                el->bg_r=el->bg_g=el->bg_b=0;el->bold=0;el->italic=0;el->code=0;el->heading=0;el->is_pre=0;
                el->href_off=0;el->href_len=0;
            }
        }
    }
}

void txt_parse(const char*src,u32 len,u32 cpl,html_doc_t*doc){
    doc->count=0;doc->pool_used=0;doc->anchor_count=0;
    doc->css_rules=0;doc->scripts_run=0;doc->js_errors=0;doc->js_error[0]=0;g_page_r=250;g_page_g=250;g_page_b=252;g_page_grad=0;(void)cpl;
    if(!src||!len)return;
    u32 i=0;
    while(i<len&&doc->count<HTML_MAX_ELEMENTS){
        u32 ls=i;while(i<len&&src[i]!='\n')i++;
        u32 ll=(i<len?i:len)-ls;while(ll>0&&(src[ls+ll-1]=='\r'||src[ls+ll-1]==' '))ll--;
        if(i<len)i++;
        if(!ll){add_gap_el(doc,1);continue;}
        html_el_t*el=&doc->els[doc->count++];
        el->type=HEL_TEXT;el->text_off=pool_add(doc,src+ls,ll);el->text_len=ll;
        el->fg_r=220;el->fg_g=222;el->fg_b=255;
        el->bg_r=el->bg_g=el->bg_b=0;el->bold=0;el->italic=0;el->code=0;el->heading=0;el->is_pre=1;
        el->href_off=0;el->href_len=0;
    }
}
