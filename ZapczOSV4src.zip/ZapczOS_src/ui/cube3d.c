#include "cube3d.h"
#include "graphics.h"
#include "theme.h"
#include "desktop.h"
#include "keyboard.h"

#define FP_SHIFT 10
#define FP_ONE (1 << FP_SHIFT)

static const i16 sin_table[256] = {
0,25,50,75,100,125,150,175,200,224,249,273,297,321,345,369,392,415,438,460,483,505,526,548,569,590,610,630,650,669,688,706,724,742,759,775,792,807,822,837,851,865,878,891,903,915,926,936,946,955,964,972,980,987,993,999,1004,1008,1012,1015,1018,1020,1022,1023,1024,1023,1022,1020,1018,1015,1012,1008,1004,999,993,987,980,972,964,955,946,936,926,915,903,891,878,865,851,837,822,807,792,775,759,742,724,706,688,669,650,630,610,590,569,548,526,505,483,460,438,415,392,369,345,321,297,273,249,224,200,175,150,125,100,75,50,25,0,-25,-50,-75,-100,-125,-150,-175,-200,-224,-249,-273,-297,-321,-345,-369,-392,-415,-438,-460,-483,-505,-526,-548,-569,-590,-610,-630,-650,-669,-688,-706,-724,-742,-759,-775,-792,-807,-822,-837,-851,-865,-878,-891,-903,-915,-926,-936,-946,-955,-964,-972,-980,-987,-993,-999,-1004,-1008,-1012,-1015,-1018,-1020,-1022,-1023,-1024,-1023,-1022,-1020,-1018,-1015,-1012,-1008,-1004,-999,-993,-987,-980,-972,-964,-955,-946,-936,-926,-915,-903,-891,-878,-865,-851,-837,-822,-807,-792,-775,-759,-742,-724,-706,-688,-669,-650,-630,-610,-590,-569,-548,-526,-505,-483,-460,-438,-415,-392,-369,-345,-321,-297,-273,-249,-224,-200,-175,-150,-125,-100,-75,-50,-25
};
static i32 sin_l(i32 a) { return sin_table[a & 255]; }
static i32 cos_l(i32 a) { return sin_table[(a + 64) & 255]; }
static i32 fmul(i32 a, i32 b) { return (a * b) >> FP_SHIFT; }
static i32 isqrt32(i32 v) { if (v <= 0) return 0; i32 x = v, y = (x + 1) / 2; while (y < x) { x = y; y = (x + v / x) / 2; } return x; }

typedef struct { i32 x, y, z; } v3;

#define MAXV 620
#define MAXT 1240
static v3 vtx[MAXV];
static int nvtx;
static int tri[MAXT][3];
static color_t tri_col[MAXT];
static int ntri;

#define NSHAPES 13
static const char* shape_names[NSHAPES] = {
    "Cube", "Pyramid", "Octahedron", "Cone",
    "Saddle  z = x^2 - y^2", "Ripple  z = sin(r)", "Waves  z = sin x + cos y", "Sphere",
    "Torus", "Cylinder", "Icosahedron",
    "Bell  z = e^-r^2", "Monkey Saddle  z = x^3-3xy^2"
};
static int shape_idx = 0;
static int wire = 0;
static i32 ang_y = 0, ang_x = 34;

static void add_tri(int a, int b, int c, color_t col) {
    if (ntri >= MAXT) return;
    tri[ntri][0] = a; tri[ntri][1] = b; tri[ntri][2] = c; tri_col[ntri] = col; ntri++;
}
static void add_quad(int a, int b, int c, int d, color_t col) { add_tri(a, b, c, col); add_tri(a, c, d, col); }
static int add_v(i32 x, i32 y, i32 z) { vtx[nvtx] = (v3){x, y, z}; return nvtx++; }

static color_t height_color(i32 h) {
    i32 t = (h + 80) * 255 / 160;
    if (t < 0) t = 0; if (t > 255) t = 255;
    color_t c;
    if (t < 128) { c.r = 40; c.g = (u8)(80 + t); c.b = (u8)(230 - t); }
    else { c.r = (u8)(t); c.g = (u8)(220 - (t - 128)); c.b = 70; }
    return c;
}

static void build_cube(void) {
    i32 s = 62;
    int v[8];
    v[0]=add_v(-s,-s,-s); v[1]=add_v(s,-s,-s); v[2]=add_v(s,s,-s); v[3]=add_v(-s,s,-s);
    v[4]=add_v(-s,-s,s); v[5]=add_v(s,-s,s); v[6]=add_v(s,s,s); v[7]=add_v(-s,s,s);
    add_quad(v[0],v[1],v[2],v[3], RGB(70,150,235));
    add_quad(v[5],v[4],v[7],v[6], RGB(70,150,235));
    add_quad(v[4],v[0],v[3],v[7], RGB(90,175,120));
    add_quad(v[1],v[5],v[6],v[2], RGB(90,175,120));
    add_quad(v[4],v[5],v[1],v[0], RGB(230,175,80));
    add_quad(v[3],v[2],v[6],v[7], RGB(210,110,95));
}
static void build_pyramid(void) {
    i32 s = 64;
    int b0=add_v(-s,s,-s), b1=add_v(s,s,-s), b2=add_v(s,s,s), b3=add_v(-s,s,s);
    int ap=add_v(0,-84,0);
    add_tri(b0,b1,ap, RGB(80,160,230)); add_tri(b1,b2,ap, RGB(230,175,80));
    add_tri(b2,b3,ap, RGB(90,175,120)); add_tri(b3,b0,ap, RGB(210,110,95));
    add_quad(b3,b2,b1,b0, RGB(120,128,150));
}
static void build_octa(void) {
    i32 s = 88;
    int px=add_v(s,0,0), nx=add_v(-s,0,0), py=add_v(0,s,0), ny=add_v(0,-s,0), pz=add_v(0,0,s), nz=add_v(0,0,-s);
    color_t a=RGB(80,160,230), b=RGB(230,175,80);
    add_tri(ny,px,pz,a); add_tri(ny,pz,nx,b); add_tri(ny,nx,nz,a); add_tri(ny,nz,px,b);
    add_tri(py,pz,px,b); add_tri(py,nx,pz,a); add_tri(py,nz,nx,b); add_tri(py,px,nz,a);
}
static void build_cone(void) {
    int seg = 28; i32 r = 62;
    int base[32]; int ap=add_v(0,-84,0); int cen=add_v(0,62,0);
    for (int i=0;i<seg;i++) { i32 a=i*256/seg; base[i]=add_v(r*cos_l(a)/FP_ONE, 62, r*sin_l(a)/FP_ONE); }
    for (int i=0;i<seg;i++) {
        int n=(i+1)%seg;
        add_tri(base[i],base[n],ap, RGB(90,170,225));
        add_tri(base[n],base[i],cen, RGB(120,128,150));
    }
}
static void build_sphere(void) {
    int rings = 16, seg = 22; i32 r = 80;
    for (int j=0;j<=rings;j++) {
        i32 lat = -64 + 128*j/rings;
        for (int i=0;i<seg;i++) {
            i32 lon = i*256/seg;
            i32 y = r*sin_l(lat)/FP_ONE;
            i32 rr = r*cos_l(lat)/FP_ONE;
            add_v(rr*cos_l(lon)/FP_ONE, y, rr*sin_l(lon)/FP_ONE);
        }
    }
    for (int j=0;j<rings;j++) for (int i=0;i<seg;i++) {
        int a=j*seg+i, b=j*seg+(i+1)%seg, c=(j+1)*seg+(i+1)%seg, d=(j+1)*seg+i;
        add_quad(a,b,c,d, height_color(vtx[a].y));
    }
}
#define GS 17
static void build_surface(int fn) {
    i32 half = 72;
    for (int j=0;j<GS;j++) for (int i=0;i<GS;i++) {
        i32 x = -half + 2*half*i/(GS-1);
        i32 y = -half + 2*half*j/(GS-1);
        i32 z;
        if (fn==0) z = (x*x - y*y)/95;
        else if (fn==1) { i32 rr = isqrt32(x*x+y*y); z = sin_l(rr*5)/13; }
        else if (fn==2) z = (sin_l(x*4) + sin_l(y*4))/26;
        else if (fn==3) { i32 d2 = (x*x + y*y)/40; i32 e = 4096 - d2*d2/60; if (e<0) e=0; z = -(e*70/4096); }
        else { z = (x*x*x/1600 - 3*x*y*y/1600); }
        add_v(x, -z, y);
    }
    for (int j=0;j<GS-1;j++) for (int i=0;i<GS-1;i++) {
        int a=j*GS+i, b=j*GS+i+1, c=(j+1)*GS+i+1, d=(j+1)*GS+i;
        i32 h=(vtx[a].y+vtx[b].y+vtx[c].y+vtx[d].y)/4;
        add_quad(a,d,c,b, height_color(-h));
    }
}
static void build_torus(void) {
    int maj = 26, min = 14; i32 R = 62, rr = 26;
    for (int i=0;i<maj;i++) {
        i32 a = i*256/maj;
        i32 cxr = R + rr*cos_l(0)/FP_ONE;
        (void)cxr;
        for (int j=0;j<min;j++) {
            i32 b = j*256/min;
            i32 ringr = R + rr*cos_l(b)/FP_ONE;
            i32 x = ringr*cos_l(a)/FP_ONE;
            i32 z = ringr*sin_l(a)/FP_ONE;
            i32 y = rr*sin_l(b)/FP_ONE;
            add_v(x, y, z);
        }
    }
    for (int i=0;i<maj;i++) for (int j=0;j<min;j++) {
        int a=i*min+j, b=i*min+(j+1)%min, c=((i+1)%maj)*min+(j+1)%min, d=((i+1)%maj)*min+j;
        color_t col = (j%2) ? RGB(90,170,225) : RGB(225,150,90);
        add_quad(a,b,c,d, col);
    }
}
static void build_cylinder(void) {
    int seg = 26; i32 r = 54, hh = 66;
    int top[26], bot[26];
    int ct = add_v(0, -hh, 0), cb = add_v(0, hh, 0);
    for (int i=0;i<seg;i++) {
        i32 a = i*256/seg;
        i32 cx = r*cos_l(a)/FP_ONE, cz = r*sin_l(a)/FP_ONE;
        top[i] = add_v(cx, -hh, cz);
        bot[i] = add_v(cx,  hh, cz);
    }
    for (int i=0;i<seg;i++) {
        int n=(i+1)%seg;
        add_quad(top[i], top[n], bot[n], bot[i], (i%2)?RGB(90,170,225):RGB(70,150,205));
        add_tri(top[n], top[i], ct, RGB(120,190,235));
        add_tri(bot[i], bot[n], cb, RGB(120,190,235));
    }
}
static void build_icosa(void) {
    i32 P = 81, Q = 50;
    int v[12];
    v[0]=add_v(0,Q,P);  v[1]=add_v(0,Q,-P); v[2]=add_v(0,-Q,P); v[3]=add_v(0,-Q,-P);
    v[4]=add_v(Q,P,0);  v[5]=add_v(Q,-P,0); v[6]=add_v(-Q,P,0); v[7]=add_v(-Q,-P,0);
    v[8]=add_v(P,0,Q);  v[9]=add_v(P,0,-Q); v[10]=add_v(-P,0,Q); v[11]=add_v(-P,0,-Q);
    static const int f[20][3] = {
        {0,2,8},{0,8,4},{0,4,6},{0,6,10},{0,10,2},
        {3,1,9},{3,9,5},{3,5,7},{3,7,11},{3,11,1},
        {2,5,8},{8,5,9},{8,9,4},{4,9,1},{4,1,6},
        {6,1,11},{6,11,10},{10,11,7},{10,7,2},{2,7,5}
    };
    for (int i=0;i<20;i++) {
        color_t col = (i%3==0)?RGB(230,120,95):(i%3==1)?RGB(90,175,120):RGB(80,150,230);
        add_tri(v[f[i][0]], v[f[i][1]], v[f[i][2]], col);
    }
}
static void build_shape(void) {
    nvtx = 0; ntri = 0;
    if (shape_idx==0) build_cube();
    else if (shape_idx==1) build_pyramid();
    else if (shape_idx==2) build_octa();
    else if (shape_idx==3) build_cone();
    else if (shape_idx==4) build_surface(0);
    else if (shape_idx==5) build_surface(1);
    else if (shape_idx==6) build_surface(2);
    else if (shape_idx==7) build_sphere();
    else if (shape_idx==8) build_torus();
    else if (shape_idx==9) build_cylinder();
    else if (shape_idx==10) build_icosa();
    else if (shape_idx==11) build_surface(3);
    else build_surface(4);
}

void cube3d_init(void) { shape_idx = 0; ang_y = 0; ang_x = 34; wire = 0; build_shape(); }
void cube3d_toggle(void) { wire = !wire; }

static i32 cl_x0, cl_y0, cl_x1, cl_y1;
static void span(i32 xa, i32 xb, i32 yy, color_t c) {
    if (yy < cl_y0 || yy >= cl_y1) return;
    if (xa > xb) { i32 t = xa; xa = xb; xb = t; }
    if (xa < cl_x0) xa = cl_x0;
    if (xb >= cl_x1) xb = cl_x1 - 1;
    if (xb < xa) return;
    gfx_hline(xa, yy, xb - xa + 1, c);
}
static i32 ex(i32 x0, i32 y0, i32 x1, i32 y1, i32 yy) { if (y1==y0) return x0; return x0 + (x1-x0)*(yy-y0)/(y1-y0); }
static void fill_tri(i32 x0,i32 y0,i32 x1,i32 y1,i32 x2,i32 y2,color_t c) {
    if (y0>y1){i32 t;t=x0;x0=x1;x1=t;t=y0;y0=y1;y1=t;}
    if (y0>y2){i32 t;t=x0;x0=x2;x2=t;t=y0;y0=y2;y2=t;}
    if (y1>y2){i32 t;t=x1;x1=x2;x2=t;t=y1;y1=y2;y2=t;}
    for (i32 yy=y0; yy<=y2; yy++) {
        i32 xa = ex(x0,y0,x2,y2,yy);
        i32 xb = (yy<y1) ? ex(x0,y0,x1,y1,yy) : ex(x1,y1,x2,y2,yy);
        span(xa,xb,yy,c);
    }
}
static color_t shade(color_t base, i32 dot) {
    i32 b = (35*FP_ONE/100) + (65 * (dot>0?dot:0) / 100);
    if (b > FP_ONE) b = FP_ONE;
    color_t c; c.r=(u8)(base.r*b>>FP_SHIFT); c.g=(u8)(base.g*b>>FP_SHIFT); c.b=(u8)(base.b*b>>FP_SHIFT);
    return c;
}

void app_cube3d_draw(i32 x, i32 y, i32 w, i32 h) {
    if (nvtx == 0) build_shape();
    gfx_rect(x, y, w, h, THEME_WINDOW);
    gfx_string(x + 14, y + 12, "3D Grapher", THEME_TEXT, THEME_WINDOW, 1);
    gfx_string(x + 14, y + 34, shape_names[shape_idx], THEME_ACCENT, THEME_WINDOW, 0);
    ui_button(x + w - 150, y + 30, 44, 24, "Prev", 0);
    ui_button(x + w - 102, y + 30, 44, 24, "Next", 0);
    ui_button(x + w - 150, y + 58, 92, 24, wire ? "Solid" : "Wireframe", 0);

    cl_x0 = x + 2; cl_y0 = y + 88; cl_x1 = x + w - 2; cl_y1 = y + h - 2;
    i32 cx = x + w/2, cy = y + h/2 + 22, dist = 340;

    static i32 sx[MAXV], sy[MAXV], rz[MAXV];
    for (int i=0;i<nvtx;i++) {
        i32 p = vtx[i].x, q = vtx[i].y, r = vtx[i].z;
        i32 cz = cos_l(ang_y), sz = sin_l(ang_y);
        i32 x1 = fmul(p,cz) + fmul(r,sz);
        i32 z1 = fmul(r,cz) - fmul(p,sz);
        i32 cx2 = cos_l(ang_x), sx2 = sin_l(ang_x);
        i32 y2 = fmul(q,cx2) - fmul(z1,sx2);
        i32 z2 = fmul(q,sx2) + fmul(z1,cx2);
        i32 den = dist + z2; if (den < 60) den = 60;
        sx[i] = cx + x1*dist/den;
        sy[i] = cy + y2*dist/den;
        rz[i] = z2;
    }

    static int order[MAXT];
    static i32 fz[MAXT];
    for (int t=0;t<ntri;t++) { order[t]=t; fz[t]=(rz[tri[t][0]]+rz[tri[t][1]]+rz[tri[t][2]])/3; }
    for (int a=0;a<ntri;a++) { int m=a; for (int b=a+1;b<ntri;b++) if (fz[order[b]]>fz[order[m]]) m=b; int tmp=order[a];order[a]=order[m];order[m]=tmp; }

    i32 Lx=-380, Ly=-520, Lz=760;
    for (int oi=0; oi<ntri; oi++) {
        int t = order[oi];
        int a=tri[t][0], b=tri[t][1], c=tri[t][2];
        i32 abx=sx[b]-sx[a], aby=sy[b]-sy[a], acx=sx[c]-sx[a], acy=sy[c]-sy[a];
        i32 area = abx*acy - aby*acx;
        if (!wire && area <= 0) continue;
        if (wire) {
            gfx_line(sx[a],sy[a],sx[b],sy[b], THEME_ACCENT);
            gfx_line(sx[b],sy[b],sx[c],sy[c], THEME_ACCENT);
            gfx_line(sx[c],sy[c],sx[a],sy[a], THEME_ACCENT);
            continue;
        }
        i32 ux=vtx[b].x-vtx[a].x, uy=vtx[b].y-vtx[a].y, uz=vtx[b].z-vtx[a].z;
        i32 vx=vtx[c].x-vtx[a].x, vy=vtx[c].y-vtx[a].y, vz=vtx[c].z-vtx[a].z;
        i32 nx=uy*vz-uz*vy, ny=uz*vx-ux*vz, nz=ux*vy-uy*vx;
        i32 rnx = fmul(nx,cos_l(ang_y)) + fmul(nz,sin_l(ang_y));
        i32 rnz = fmul(nz,cos_l(ang_y)) - fmul(nx,sin_l(ang_y));
        i32 rny = fmul(ny,cos_l(ang_x)) - fmul(rnz,sin_l(ang_x));
        i32 rnz2 = fmul(ny,sin_l(ang_x)) + fmul(rnz,cos_l(ang_x));
        i32 mag = isqrt32(rnx*rnx + rny*rny + rnz2*rnz2); if (mag < 1) mag = 1;
        i32 dot = (rnx*Lx + rny*Ly + rnz2*Lz) / mag;
        if (dot < 0) dot = -dot;
        dot = dot * FP_ONE / 1024;
        color_t col = shade(tri_col[t], dot);
        fill_tri(sx[a],sy[a],sx[b],sy[b],sx[c],sy[c], col);
    }
    ang_y += 2; ang_x += 1;
}

void app_cube3d_click(i32 rx, i32 ry) {
    i32 w = windows[APP_CUBE3D].w;
    if (ui_point_in(rx, ry, w - 150, 30, 44, 24)) { shape_idx = (shape_idx + NSHAPES - 1) % NSHAPES; build_shape(); return; }
    if (ui_point_in(rx, ry, w - 102, 30, 44, 24)) { shape_idx = (shape_idx + 1) % NSHAPES; build_shape(); return; }
    if (ui_point_in(rx, ry, w - 150, 58, 92, 24)) { wire = !wire; return; }
}
void app_cube3d_key(int key) {
    if (key == KEY_LEFT) { shape_idx = (shape_idx + NSHAPES - 1) % NSHAPES; build_shape(); }
    else if (key == KEY_RIGHT || key == ' ') { shape_idx = (shape_idx + 1) % NSHAPES; build_shape(); }
    else if (key == 'w' || key == 'W') wire = !wire;
}
