/* apps2.c -- second-generation ZapczOS applications:
   Calendar, Trash, Writer, Sheet, Media viewer, Code IDE.
   The notification centre lives in notify.c and is dispatched from here. */

#include "desktop.h"
#include "config.h"
#include "graphics.h"
#include "theme.h"
#include "util.h"
#include "fat32.h"
#include "rtc.h"

/* ================= Calendar ================= */

static int cal_year = 0, cal_month = 0;   /* 0 = use RTC */
static int cal_sel_day = 0;

typedef struct { int day, month, year; char text[40]; int used; } cal_event_t;
#define CAL_MAX_EVENTS 32
static cal_event_t cal_events[CAL_MAX_EVENTS];

static const char* MONTH_NAMES[12] = { "January","February","March","April","May","June",
    "July","August","September","October","November","December" };

static int days_in_month(int m, int y) {
    static const int d[12] = { 31,28,31,30,31,30,31,31,30,31,30,31 };
    if (m == 1 && ((y % 4 == 0 && y % 100 != 0) || y % 400 == 0)) return 29;
    return d[m];
}

/* Zeller: 0 = Monday .. 6 = Sunday */
static int first_weekday(int m, int y) {
    int mm = m + 1, yy = y;
    if (mm < 3) { mm += 12; yy -= 1; }
    int k = yy % 100, j = yy / 100;
    int h = (1 + (13 * (mm + 1)) / 5 + k + k / 4 + j / 4 + 5 * j) % 7;
    return (h + 5) % 7;
}

static void cal_ensure_init(void) {
    if (cal_year) return;
    rtc_time_t t;
    rtc_read(&t); config_local_time(&t);
    cal_year = (int)t.year;
    cal_month = (int)t.month - 1;
    if (cal_month < 0 || cal_month > 11) cal_month = 0;
    if (cal_year < 1970) cal_year = 2026;
    cal_sel_day = (int)t.day;
}

static int cal_event_on(int d) {
    for (int i = 0; i < CAL_MAX_EVENTS; i++)
        if (cal_events[i].used && cal_events[i].day == d &&
            cal_events[i].month == cal_month && cal_events[i].year == cal_year) return i;
    return -1;
}

void app_calendar_draw(i32 x, i32 y, i32 w, i32 h) {
    cal_ensure_init();
    gfx_rect(x, y, w, h, THEME_WINDOW);

    char hdr[48];
    str_copy(hdr, MONTH_NAMES[cal_month], sizeof(hdr));
    str_cat(hdr, " ", sizeof(hdr));
    { char nb[12]; u32_to_str((u32)cal_year, nb); str_cat(hdr, nb, sizeof(hdr)); }
    gfx_string(x + ui_scale(16), y + ui_scale(12), hdr, THEME_TEXT, THEME_WINDOW, 0);

    ui_button(x + w - ui_scale(70), y + ui_scale(8), ui_scale(26), ui_scale(22), "<", 0);
    ui_button(x + w - ui_scale(40), y + ui_scale(8), ui_scale(26), ui_scale(22), ">", 0);

    static const char* DOW[7] = { "Mo","Tu","We","Th","Fr","Sa","Su" };
    i32 gx = x + ui_scale(16), gy = y + ui_scale(44);
    i32 cw = (w - ui_scale(32)) / 7, ch = ui_scale(30);
    for (int i = 0; i < 7; i++)
        gfx_string(gx + i * cw + ui_scale(6), gy, DOW[i], THEME_TEXT_DIM, THEME_WINDOW, 0);

    int fw = first_weekday(cal_month, cal_year);
    int dim = days_in_month(cal_month, cal_year);
    i32 top = gy + ui_scale(20);
    for (int d = 1; d <= dim; d++) {
        int cell = fw + d - 1;
        i32 cx = gx + (cell % 7) * cw;
        i32 cy = top + (cell / 7) * ch;
        int sel = (d == cal_sel_day);
        if (sel) gfx_rounded_rect(cx + 2, cy, cw - 4, ch - 3, THEME_RADIUS_CTRL, THEME_ACCENT);
        char db[8]; u32_to_str((u32)d, db);
        gfx_string(cx + ui_scale(8), cy + ui_scale(6), db,
                   sel ? THEME_ACCENT_TEXT : THEME_TEXT, THEME_WINDOW, 0);
        if (cal_event_on(d) >= 0)
            gfx_rect(cx + cw / 2 - 2, cy + ch - ui_scale(8), 4, 4,
                     sel ? THEME_ACCENT_TEXT : THEME_ACCENT);
    }

    i32 iy = top + 6 * ch + ui_scale(8);
    int ev = cal_event_on(cal_sel_day);
    if (ev >= 0) {
        gfx_string(x + ui_scale(16), iy, "Event:", THEME_TEXT_DIM, THEME_WINDOW, 0);
        gfx_string(x + ui_scale(70), iy, cal_events[ev].text, THEME_TEXT, THEME_WINDOW, 0);
    } else {
        gfx_string(x + ui_scale(16), iy, "No event. Press A to add one for this day.",
                   THEME_TEXT_FAINT, THEME_WINDOW, 0);
    }
}

void app_calendar_click(i32 rx, i32 ry) {
    cal_ensure_init();
    extern window_t windows[];
    i32 w = windows[APP_CALENDAR].w;
    if (ry >= ui_scale(8) && ry <= ui_scale(30)) {
        if (rx >= w - ui_scale(70) && rx < w - ui_scale(44)) {
            if (--cal_month < 0) { cal_month = 11; cal_year--; }
            return;
        }
        if (rx >= w - ui_scale(40) && rx < w - ui_scale(14)) {
            if (++cal_month > 11) { cal_month = 0; cal_year++; }
            return;
        }
    }
    i32 gx = ui_scale(16), top = ui_scale(64) + ui_scale(20);
    i32 cw = (w - ui_scale(32)) / 7, ch = ui_scale(30);
    if (ry >= top && rx >= gx) {
        int col = (rx - gx) / cw, row = (ry - top) / ch;
        if (col >= 0 && col < 7 && row >= 0 && row < 6) {
            int cell = row * 7 + col;
            int d = cell - first_weekday(cal_month, cal_year) + 1;
            if (d >= 1 && d <= days_in_month(cal_month, cal_year)) cal_sel_day = d;
        }
    }
}

void app_calendar_key(char c) {
    cal_ensure_init();
    if (c == 'a' || c == 'A') {
        if (cal_event_on(cal_sel_day) >= 0) return;
        for (int i = 0; i < CAL_MAX_EVENTS; i++) {
            if (!cal_events[i].used) {
                cal_events[i].used = 1;
                cal_events[i].day = cal_sel_day;
                cal_events[i].month = cal_month;
                cal_events[i].year = cal_year;
                str_copy(cal_events[i].text, "New event", sizeof(cal_events[i].text));
                return;
            }
        }
    } else if (c == 'd' || c == 'D') {
        int ev = cal_event_on(cal_sel_day);
        if (ev >= 0) { cal_events[ev].used = 0; }
    }
}

/* ================= Trash ================= */

typedef struct { char name[64]; u32 size; int used; } trash_item_t;
#define TRASH_MAX 32
static trash_item_t trash[TRASH_MAX];
static int trash_sel = -1;

int trash_count(void) {
    int c = 0;
    for (int i = 0; i < TRASH_MAX; i++) if (trash[i].used) c++;
    return c;
}

/* Called by Files when a file is deleted. */
int trash_add(const char* name, u32 size) {
    for (int i = 0; i < TRASH_MAX; i++) {
        if (!trash[i].used) {
            trash[i].used = 1;
            trash[i].size = size;
            str_copy(trash[i].name, name, sizeof(trash[i].name));
            return 1;
        }
    }
    return 0;
}

void app_trash_draw(i32 x, i32 y, i32 w, i32 h) {
    gfx_rect(x, y, w, h, THEME_WINDOW);
    gfx_string(x + ui_scale(16), y + ui_scale(12), "Trash", THEME_TEXT, THEME_WINDOW, 0);

    char sub[48];
    { char nb[12]; u32_to_str((u32)trash_count(), nb);
      str_copy(sub, nb, sizeof(sub)); str_cat(sub, " item(s)", sizeof(sub)); }
    gfx_string(x + ui_scale(16), y + ui_scale(30), sub, THEME_TEXT_DIM, THEME_WINDOW, 0);

    ui_button(x + w - ui_scale(90), y + ui_scale(10), ui_scale(76), ui_scale(22), "Empty", 0);
    ui_button(x + w - ui_scale(178), y + ui_scale(10), ui_scale(80), ui_scale(22), "Restore", trash_sel >= 0);

    i32 ly = y + ui_scale(58);
    int row = 0;
    for (int i = 0; i < TRASH_MAX; i++) {
        if (!trash[i].used) continue;
        i32 ry = ly + row * ui_scale(24);
        if (ry > y + h - ui_scale(16)) break;
        if (i == trash_sel)
            gfx_rounded_rect(x + ui_scale(12), ry - 2, w - ui_scale(24), ui_scale(22),
                             THEME_RADIUS_CTRL, THEME_ACCENT_DIM);
        gfx_string(x + ui_scale(20), ry, trash[i].name, THEME_TEXT, THEME_WINDOW, 0);
        row++;
    }
    if (!row)
        gfx_string(x + ui_scale(20), ly, "Trash is empty.", THEME_TEXT_FAINT, THEME_WINDOW, 0);
}

void app_trash_click(i32 rx, i32 ry) {
    extern window_t windows[];
    i32 w = windows[APP_TRASH].w;
    if (ry >= ui_scale(10) && ry <= ui_scale(32)) {
        if (rx >= w - ui_scale(90)) {
            int n = trash_count();
            for (int i = 0; i < TRASH_MAX; i++) trash[i].used = 0;
            trash_sel = -1;
            if (n)
            return;
        }
        if (rx >= w - ui_scale(178) && rx < w - ui_scale(98)) {
            if (trash_sel >= 0 && trash[trash_sel].used) {
                trash[trash_sel].used = 0;
                trash_sel = -1;
            }
            return;
        }
    }
    i32 ly = ui_scale(58);
    if (ry >= ly) {
        int want = (ry - ly) / ui_scale(24), row = 0;
        for (int i = 0; i < TRASH_MAX; i++) {
            if (!trash[i].used) continue;
            if (row == want) { trash_sel = i; return; }
            row++;
        }
    }
}

/* ================= Writer (word processor) ================= */

#define WR_MAX 4096
static char wr_buf[WR_MAX];
static u32  wr_len = 0;
static int  wr_bold = 0, wr_align_center = 0;
static i32  wr_scroll = 0;

void app_writer_draw(i32 x, i32 y, i32 w, i32 h) {
    gfx_rect(x, y, w, h, THEME_WINDOW);

    /* toolbar */
    i32 ty = y + ui_scale(8);
    ui_button(x + ui_scale(12), ty, ui_scale(34), ui_scale(22), "B", wr_bold);
    ui_button(x + ui_scale(50), ty, ui_scale(52), ui_scale(22), "Center", wr_align_center);
    ui_button(x + ui_scale(106), ty, ui_scale(52), ui_scale(22), "Save", 0);
    ui_button(x + ui_scale(162), ty, ui_scale(52), ui_scale(22), "Clear", 0);

    char info[40];
    { char nb[12]; u32_to_str(wr_len, nb);
      str_copy(info, nb, sizeof(info)); str_cat(info, " chars", sizeof(info)); }
    gfx_string(x + w - ui_scale(90), ty + ui_scale(4), info, THEME_TEXT_DIM, THEME_WINDOW, 0);

    /* page */
    i32 py = y + ui_scale(40);
    i32 ph = h - ui_scale(48);
    gfx_rect(x + ui_scale(12), py, w - ui_scale(24), ph, THEME_INPUT);
    gfx_rect_outline(x + ui_scale(12), py, w - ui_scale(24), ph, THEME_BORDER);

    clip_t cl = { x + ui_scale(12), py, x + w - ui_scale(12), py + ph };
    gfx_set_clip(cl);

    i32 cpl = (w - ui_scale(48)) / 8;
    if (cpl < 8) cpl = 8;
    i32 line = 0, col = 0;
    char lb[256];
    u32 li = 0;
    for (u32 i = 0; i <= wr_len; i++) {
        char c = (i < wr_len) ? wr_buf[i] : '\n';
        if (c == '\n' || col >= cpl) {
            lb[li] = 0;
            i32 ly = py + ui_scale(8) + line * ui_scale(16) - wr_scroll;
            if (ly >= py - 16 && ly < py + ph) {
                i32 lx = x + ui_scale(20);
                if (wr_align_center) {
                    i32 tw = gfx_string_width(lb);
                    lx = x + (w - tw) / 2;
                }
                gfx_string(lx, ly, lb, THEME_TEXT, THEME_INPUT, 0);
                if (wr_bold) gfx_string(lx + 1, ly, lb, THEME_TEXT, THEME_INPUT, 0);
            }
            line++; col = 0; li = 0;
            if (c != '\n') { lb[li++] = c; col = 1; }
            continue;
        }
        if (li < sizeof(lb) - 1) { lb[li++] = c; col++; }
    }
    gfx_clear_clip();
}

void app_writer_click(i32 rx, i32 ry) {
    if (ry >= ui_scale(8) && ry <= ui_scale(30)) {
        if (rx >= ui_scale(12) && rx < ui_scale(46)) { wr_bold = !wr_bold; return; }
        if (rx >= ui_scale(50) && rx < ui_scale(102)) { wr_align_center = !wr_align_center; return; }
        if (rx >= ui_scale(106) && rx < ui_scale(158)) {
            if (fat32_available() && wr_len)
                fat32_write_file("document.txt", (const u8*)wr_buf, wr_len);
            return;
        }
        if (rx >= ui_scale(162) && rx < ui_scale(214)) {
            wr_len = 0; wr_buf[0] = 0; wr_scroll = 0;
            return;
        }
    }
}

void app_writer_key(char c) {
    if (c == '\b') { if (wr_len) wr_len--; }
    else if (wr_len < WR_MAX - 1 && (c >= 32 || c == '\n')) wr_buf[wr_len++] = c;
    wr_buf[wr_len] = 0;
}

/* ================= Sheet (spreadsheet) ================= */

#define SH_COLS 6
#define SH_ROWS 14
typedef struct { char text[12]; } cell_t;
static cell_t sheet[SH_ROWS][SH_COLS];
static int sh_cr = 0, sh_cc = 0;
static char sh_edit[12];
static u32  sh_edit_len = 0;

static int cell_number(const char* s, int* out) {
    int v = 0, any = 0, neg = 0;
    u32 i = 0;
    if (s[0] == '-') { neg = 1; i = 1; }
    for (; s[i]; i++) {
        if (s[i] < '0' || s[i] > '9') return 0;
        v = v * 10 + (s[i] - '0'); any = 1;
    }
    if (!any) return 0;
    *out = neg ? -v : v;
    return 1;
}

/* Supports =SUM(col) style: "=S" sums the column above the cell. */
static int cell_value(int r, int c, int* out) {
    const char* s = sheet[r][c].text;
    if (s[0] == '=' && (s[1] == 's' || s[1] == 'S')) {
        int sum = 0;
        for (int k = 0; k < r; k++) {
            int v;
            if (cell_number(sheet[k][c].text, &v)) sum += v;
        }
        *out = sum;
        return 1;
    }
    return cell_number(s, out);
}

void app_sheet_draw(i32 x, i32 y, i32 w, i32 h) {
    gfx_rect(x, y, w, h, THEME_WINDOW);

    i32 hdr = ui_scale(28);
    gfx_string(x + ui_scale(12), y + ui_scale(8), "Cell:", THEME_TEXT_DIM, THEME_WINDOW, 0);
    char ref[8]; ref[0] = (char)('A' + sh_cc);
    { char nb[8]; u32_to_str((u32)(sh_cr + 1), nb); ref[1] = 0; str_cat(ref, nb, sizeof(ref)); }
    gfx_string(x + ui_scale(52), y + ui_scale(8), ref, THEME_ACCENT, THEME_WINDOW, 0);
    gfx_string(x + ui_scale(90), y + ui_scale(8), sh_edit, THEME_TEXT, THEME_WINDOW, 0);
    gfx_string(x + w - ui_scale(150), y + ui_scale(8), "=S sums column",
               THEME_TEXT_FAINT, THEME_WINDOW, 0);

    i32 gx = x + ui_scale(34), gy = y + hdr + ui_scale(6);
    i32 cw = (w - ui_scale(44)) / SH_COLS, chh = ui_scale(20);

    for (int c = 0; c < SH_COLS; c++) {
        char cb[4]; cb[0] = (char)('A' + c); cb[1] = 0;
        gfx_string(gx + c * cw + cw / 2 - 4, gy, cb, THEME_TEXT_DIM, THEME_WINDOW, 0);
    }
    for (int r = 0; r < SH_ROWS; r++) {
        i32 ry = gy + ui_scale(16) + r * chh;
        if (ry > y + h - ui_scale(10)) break;
        char rb[8]; u32_to_str((u32)(r + 1), rb);
        gfx_string(x + ui_scale(10), ry + ui_scale(4), rb, THEME_TEXT_DIM, THEME_WINDOW, 0);
        for (int c = 0; c < SH_COLS; c++) {
            i32 cx = gx + c * cw;
            int sel = (r == sh_cr && c == sh_cc);
            gfx_rect_outline(cx, ry, cw - 1, chh - 1, THEME_SEP);
            if (sel) gfx_rounded_rect_outline(cx, ry, cw - 1, chh - 1, 3, THEME_ACCENT);
            const char* txt = sheet[r][c].text;
            char shown[12];
            int v;
            if (txt[0] == '=' && cell_value(r, c, &v)) {
                u32_to_str((u32)(v < 0 ? -v : v), shown);
                if (v < 0) { char t[12]; str_copy(t, "-", sizeof(t)); str_cat(t, shown, sizeof(t)); str_copy(shown, t, sizeof(shown)); }
                txt = shown;
            }
            if (txt[0])
                gfx_string(cx + ui_scale(4), ry + ui_scale(4), txt, THEME_TEXT, THEME_WINDOW, 0);
        }
    }
}

void app_sheet_click(i32 rx, i32 ry) {
    extern window_t windows[];
    i32 w = windows[APP_SHEET].w;
    i32 gx = ui_scale(34), gy = ui_scale(28) + ui_scale(6) + ui_scale(16);
    i32 cw = (w - ui_scale(44)) / SH_COLS, chh = ui_scale(20);
    if (rx >= gx && ry >= gy) {
        int c = (rx - gx) / cw, r = (ry - gy) / chh;
        if (c >= 0 && c < SH_COLS && r >= 0 && r < SH_ROWS) {
            sh_cr = r; sh_cc = c;
            str_copy(sh_edit, sheet[r][c].text, sizeof(sh_edit));
            sh_edit_len = str_len(sh_edit);
        }
    }
}

void app_sheet_key(char c) {
    if (c == '\n') {
        str_copy(sheet[sh_cr][sh_cc].text, sh_edit, sizeof(sheet[0][0].text));
        if (sh_cr < SH_ROWS - 1) sh_cr++;
        str_copy(sh_edit, sheet[sh_cr][sh_cc].text, sizeof(sh_edit));
        sh_edit_len = str_len(sh_edit);
        return;
    }
    if (c == '\b') { if (sh_edit_len) sh_edit[--sh_edit_len] = 0; return; }
    if (c >= 32 && sh_edit_len < sizeof(sh_edit) - 1) {
        sh_edit[sh_edit_len++] = c;
        sh_edit[sh_edit_len] = 0;
    }
}

/* ================= Media viewer ================= */

static int media_idx = 0;

void app_media_draw(i32 x, i32 y, i32 w, i32 h) {
    gfx_rect(x, y, w, h, THEME_WINDOW);
    gfx_string(x + ui_scale(14), y + ui_scale(10), "Media", THEME_TEXT, THEME_WINDOW, 0);

    ui_button(x + ui_scale(70), y + ui_scale(8), ui_scale(30), ui_scale(22), "<", 0);
    ui_button(x + ui_scale(104), y + ui_scale(8), ui_scale(30), ui_scale(22), ">", 0);

    static fat_dirent_t ents[64];
    int n = fat32_available() ? fat32_list_root(ents, 64) : 0;
    int imgs[64], ni = 0;
    for (int i = 0; i < n && ni < 64; i++) {
        const char* nm = ents[i].display_name;
        u32 l = str_len(nm);
        if (l > 4) {
            const char* e = nm + l - 4;
            if (str_eq_ci(e, ".png") || str_eq_ci(e, ".bmp") || str_eq_ci(e, ".jpg"))
                imgs[ni++] = i;
        }
    }

    i32 vy = y + ui_scale(40);
    i32 vh = h - ui_scale(48);
    gfx_rect(x + ui_scale(12), vy, w - ui_scale(24), vh, RGB(20, 20, 24));

    if (!ni) {
        gfx_string(x + ui_scale(24), vy + ui_scale(16), "No image files on disk.",
                   THEME_TEXT_DIM, RGB(20, 20, 24), 0);
        gfx_string(x + ui_scale(24), vy + ui_scale(34),
                   "Audio and video playback are not supported:",
                   THEME_TEXT_FAINT, RGB(20, 20, 24), 0);
        gfx_string(x + ui_scale(24), vy + ui_scale(50),
                   "no sound driver or codecs are implemented yet.",
                   THEME_TEXT_FAINT, RGB(20, 20, 24), 0);
        return;
    }
    if (media_idx >= ni) media_idx = 0;
    if (media_idx < 0) media_idx = ni - 1;

    gfx_string(x + ui_scale(20), vy + ui_scale(10), ents[imgs[media_idx]].display_name,
               THEME_TEXT, RGB(20, 20, 24), 0);
    char pos[32];
    { char a[8], b[8]; u32_to_str((u32)(media_idx + 1), a); u32_to_str((u32)ni, b);
      str_copy(pos, a, sizeof(pos)); str_cat(pos, " / ", sizeof(pos)); str_cat(pos, b, sizeof(pos)); }
    gfx_string(x + ui_scale(20), vy + vh - ui_scale(20), pos, THEME_TEXT_DIM, RGB(20, 20, 24), 0);
    gfx_string(x + ui_scale(20), vy + ui_scale(34),
               "Open in Photos to view the decoded image.", THEME_TEXT_FAINT, RGB(20, 20, 24), 0);
}

void app_media_click(i32 rx, i32 ry) {
    if (ry >= ui_scale(8) && ry <= ui_scale(30)) {
        if (rx >= ui_scale(70) && rx < ui_scale(100)) { media_idx--; return; }
        if (rx >= ui_scale(104) && rx < ui_scale(134)) { media_idx++; return; }
    }
}

/* ================= IDE (code editor with highlighting) ================= */

#define IDE_MAX 6144
static char ide_buf[IDE_MAX];
static u32  ide_len = 0;
static i32  ide_scroll = 0;

static int ide_is_kw(const char* s, u32 l) {
    static const char* KW[] = { "int","char","void","if","else","while","for","return",
        "static","struct","const","u32","u8","i32","break","continue","sizeof","typedef",
        "unsigned","switch","case","default","do","enum","float","double","long","short", 0 };
    for (int i = 0; KW[i]; i++) {
        u32 kl = str_len(KW[i]);
        if (kl != l) continue;
        int m = 1;
        for (u32 j = 0; j < l; j++) if (s[j] != KW[i][j]) { m = 0; break; }
        if (m) return 1;
    }
    return 0;
}

void app_ide_draw(i32 x, i32 y, i32 w, i32 h) {
    color_t bg = RGB(28, 30, 38);
    gfx_rect(x, y, w, h, THEME_WINDOW);

    i32 ty = y + ui_scale(8);
    ui_button(x + ui_scale(12), ty, ui_scale(52), ui_scale(22), "Save", 0);
    ui_button(x + ui_scale(68), ty, ui_scale(52), ui_scale(22), "Load", 0);
    ui_button(x + ui_scale(124), ty, ui_scale(52), ui_scale(22), "Clear", 0);
    gfx_string(x + w - ui_scale(110), ty + ui_scale(4), "code.c", THEME_TEXT_DIM, THEME_WINDOW, 0);

    i32 ey = y + ui_scale(40), eh = h - ui_scale(48);
    gfx_rect(x + ui_scale(12), ey, w - ui_scale(24), eh, bg);

    clip_t cl = { x + ui_scale(12), ey, x + w - ui_scale(12), ey + eh };
    gfx_set_clip(cl);

    i32 line = 0, cx = x + ui_scale(44);
    i32 ly = ey + ui_scale(6);
    u32 i = 0;
    int in_comment = 0, in_str = 0;

    while (i <= ide_len) {
        /* line number */
        i32 dy = ly + line * ui_scale(14) - ide_scroll;
        if (dy > ey + eh) break;
        if (dy >= ey - 14) {
            char lnb[8]; u32_to_str((u32)(line + 1), lnb);
            gfx_string(x + ui_scale(16), dy, lnb, RGB(90, 95, 115), bg, 0);
        }
        cx = x + ui_scale(44);
        in_str = 0;
        /* tokens on this line */
        while (i < ide_len && ide_buf[i] != '\n') {
            char c = ide_buf[i];
            if (!in_comment && c == '/' && i + 1 < ide_len && ide_buf[i + 1] == '/') {
                u32 st = i;
                while (i < ide_len && ide_buf[i] != '\n') i++;
                if (dy >= ey - 14) {
                    char tb[128]; u32 tl = 0;
                    for (u32 k = st; k < i && tl < sizeof(tb) - 1; k++) tb[tl++] = ide_buf[k];
                    tb[tl] = 0;
                    gfx_string(cx, dy, tb, RGB(110, 160, 110), bg, 0);
                }
                break;
            }
            if (c == '"') {
                u32 st = i++;
                while (i < ide_len && ide_buf[i] != '"' && ide_buf[i] != '\n') i++;
                if (i < ide_len && ide_buf[i] == '"') i++;
                if (dy >= ey - 14) {
                    char tb[128]; u32 tl = 0;
                    for (u32 k = st; k < i && tl < sizeof(tb) - 1; k++) tb[tl++] = ide_buf[k];
                    tb[tl] = 0;
                    gfx_string(cx, dy, tb, RGB(220, 170, 120), bg, 0);
                    cx += gfx_string_width(tb);
                }
                continue;
            }
            if ((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || c == '_') {
                u32 st = i;
                while (i < ide_len && ((ide_buf[i] >= 'a' && ide_buf[i] <= 'z') ||
                       (ide_buf[i] >= 'A' && ide_buf[i] <= 'Z') ||
                       (ide_buf[i] >= '0' && ide_buf[i] <= '9') || ide_buf[i] == '_')) i++;
                u32 tl = i - st;
                if (dy >= ey - 14) {
                    char tb[64]; u32 n = 0;
                    for (u32 k = st; k < i && n < sizeof(tb) - 1; k++) tb[n++] = ide_buf[k];
                    tb[n] = 0;
                    color_t col = ide_is_kw(tb, tl) ? RGB(130, 170, 255) : RGB(215, 218, 230);
                    gfx_string(cx, dy, tb, col, bg, 0);
                    cx += gfx_string_width(tb);
                }
                continue;
            }
            if (c >= '0' && c <= '9') {
                u32 st = i;
                while (i < ide_len && ide_buf[i] >= '0' && ide_buf[i] <= '9') i++;
                if (dy >= ey - 14) {
                    char tb[32]; u32 n = 0;
                    for (u32 k = st; k < i && n < sizeof(tb) - 1; k++) tb[n++] = ide_buf[k];
                    tb[n] = 0;
                    gfx_string(cx, dy, tb, RGB(240, 190, 130), bg, 0);
                    cx += gfx_string_width(tb);
                }
                continue;
            }
            if (dy >= ey - 14) {
                char tb[2] = { c, 0 };
                gfx_string(cx, dy, tb, RGB(190, 195, 210), bg, 0);
                cx += 8;
            }
            i++;
        }
        if (i < ide_len && ide_buf[i] == '\n') i++;
        else if (i >= ide_len) break;
        line++;
    }
    gfx_clear_clip();
    (void)in_comment;
}

void app_ide_click(i32 rx, i32 ry) {
    if (ry >= ui_scale(8) && ry <= ui_scale(30)) {
        if (rx >= ui_scale(12) && rx < ui_scale(64)) {
            if (fat32_available() && ide_len)
                fat32_write_file("code.c", (const u8*)ide_buf, ide_len);
            return;
        }
        if (rx >= ui_scale(68) && rx < ui_scale(120)) {
            static fat_dirent_t ents[64];
            int n = fat32_available() ? fat32_list_root(ents, 64) : 0;
            for (int i = 0; i < n; i++) {
                if (str_eq_ci(ents[i].display_name, "code.c")) {
                    int len = fat32_read_file(&ents[i], (u8*)ide_buf, IDE_MAX - 1);
                    if (len > 0) { ide_len = (u32)len; ide_buf[ide_len] = 0; }
                    return;
                }
            }
            return;
        }
        if (rx >= ui_scale(124) && rx < ui_scale(176)) { ide_len = 0; ide_buf[0] = 0; ide_scroll = 0; }
    }
}

void app_ide_key(char c) {
    if (c == '\b') { if (ide_len) ide_len--; }
    else if (ide_len < IDE_MAX - 1 && (c >= 32 || c == '\n' || c == '\t')) ide_buf[ide_len++] = c;
    ide_buf[ide_len] = 0;
}

