#ifndef GRAPHICS_H
#define GRAPHICS_H

#include "io.h"

typedef struct {
    u32 fb_addr;
    u32 width;
    u32 height;
    u32 pitch;
    u32 bpp;
    u32 bypp;
    u8* back;
} gfx_t;

extern gfx_t gfx;

typedef struct { u8 r, g, b; } color_t;

#define RGB(r,g,b) ((color_t){(u8)(r),(u8)(g),(u8)(b)})

int  gfx_mode_fits(u32 width, u32 height, u32 bpp);
void gfx_init(u32 fb_addr, u32 width, u32 height, u32 pitch, u32 bpp);
void gfx_present(void);
void gfx_fb_read(i32 x, i32 y, i32 w, i32 h, u8* dst);
void gfx_fb_write(i32 x, i32 y, i32 w, i32 h, const u8* src);
void gfx_back_save(i32 x, i32 y, i32 w, i32 h, u8* dst);
void gfx_back_restore(i32 x, i32 y, i32 w, i32 h, const u8* src);
void gfx_fb_pixel(i32 x, i32 y, color_t c);
void gfx_mark_dirty(i32 y0, i32 y1);
void gfx_mark_all_dirty(void);

color_t gfx_get_pixel(i32 x, i32 y);
color_t gfx_lerp(color_t a, color_t b, int t);
void gfx_glass_rect(i32 x, i32 y, i32 w, i32 h, color_t tint, int opacity_pct);
void gfx_glass_rounded_rect(i32 x, i32 y, i32 w, i32 h, i32 r, color_t tint, int opa);
void gfx_glow_border(i32 x, i32 y, i32 w, i32 h, i32 r, color_t col, int strength);
void gfx_gradient_titlebar(i32 x, i32 y, i32 w, i32 h, color_t top, color_t bot);
void gfx_specular_line(i32 x, i32 y, i32 w);

void gfx_pixel(i32 x, i32 y, color_t c);
void gfx_rect(i32 x, i32 y, i32 w, i32 h, color_t c);
void gfx_rounded_rect_top(i32 x, i32 y, i32 w, i32 h, i32 radius, color_t c);
void gfx_rounded_rect(i32 x, i32 y, i32 w, i32 h, i32 radius, color_t c);
void gfx_rounded_rect_outline(i32 x, i32 y, i32 w, i32 h, i32 radius, color_t c);

void gfx_rounded_rect4(i32 x, i32 y, i32 w, i32 h, i32 r_top, i32 r_bottom, color_t c);
void gfx_rect_outline(i32 x, i32 y, i32 w, i32 h, color_t c);
void gfx_hline(i32 x, i32 y, i32 w, color_t c);
void gfx_vline(i32 x, i32 y, i32 h, color_t c);
void gfx_line(i32 x0, i32 y0, i32 x1, i32 y1, color_t c);
void gfx_circle(i32 cx, i32 cy, i32 r, color_t c);
void gfx_circle_fill(i32 cx, i32 cy, i32 r, color_t c);
void gfx_gradient_v(i32 x, i32 y, i32 w, i32 h, color_t top, color_t bottom);
void gfx_rounded_gradient_v(i32 x, i32 y, i32 w, i32 h, i32 radius, color_t top, color_t bottom);
color_t gfx_lerp_color(color_t a, color_t b, i32 num, i32 den);

#define FONT_STYLE_COUNT 5
extern int g_font_style;
void gfx_set_font(int style);
int gfx_get_font(void);
const char* gfx_font_name(int style);
void gfx_char(i32 x, i32 y, char ch, color_t fg, color_t bg, int opaque);
void gfx_string(i32 x, i32 y, const char* s, color_t fg, color_t bg, int opaque);
int  gfx_string_width(const char* s);
void gfx_char_scaled(i32 x, i32 y, char ch, color_t fg, int scale);
void gfx_string_scaled(i32 x, i32 y, const char* s, color_t fg, int scale);
int  gfx_string_width_scaled(const char* s, int scale);

void gfx_blit_rgb_scaled(const u8* src, i32 src_w, i32 src_h,
                         i32 dst_x, i32 dst_y, i32 dst_w, i32 dst_h);

typedef struct { i32 x0, y0, x1, y1; } clip_t;
void gfx_set_clip(clip_t c);
void gfx_clear_clip(void);
int  gfx_clip_test(i32 x, i32 y);

#endif
