
%ifndef KERNEL_SECTORS
%define KERNEL_SECTORS 600
%endif

BITS 16
ORG 0x7C00

KERNEL_LOAD_SEG  equ 0x2000
BOOT_INFO_ADDR   equ 0x9E00
MMAP_ADDR        equ 0x9E20

STAGE2_LBA       equ 8

KERNEL_LBA       equ 24

db 0xeb,0x58,0x90,0x6d,0x6b,0x66,0x73,0x2e,0x66,0x61,0x74,0x00,0x02,0x01
db 0x00,0x10,0x02,0x00,0x00,0x00,0x00,0xf8,0x00,0x00,0x20,0x00,0x08,0x00
db 0x00,0x00,0x00,0x00,0x00,0x00,0x02,0x00,0xd1,0x03,0x00,0x00,0x00,0x00
db 0x00,0x00,0x02,0x00,0x00,0x00,0x01,0x00,0x06,0x00,0x00,0x00,0x00,0x00
db 0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x80,0x00,0x29,0x82,0x2f,0x63
db 0x13,0x5a,0x41,0x50,0x43,0x5a,0x4f,0x53,0x20,0x20,0x20,0x20,0x46,0x41
db 0x54,0x33,0x32,0x20,0x20,0x20

stage1_start:
    cli
    xor ax, ax
    mov ds, ax
    mov es, ax
    mov ss, ax
    mov sp, 0x7C00
    sti

    mov [boot_drive], dl

    call serial_init16
    mov al, 'A'
    call serial_putc16

    mov si, msg_stage1
    call print_string

    mov ah, 0x41
    mov bx, 0x55AA
    mov dl, [boot_drive]
    int 0x13
    jc .no_lba
    cmp bx, 0xAA55
    jne .no_lba

    mov si, dap
    mov word [dap_count], 16
    mov dword [dap_lba], STAGE2_LBA
    mov word [dap_off], 0x7E00
    mov word [dap_seg], 0x0000
    mov ah, 0x42
    mov dl, [boot_drive]
    int 0x13
    jc .disk_error

    mov si, msg_ok
    call print_string

    mov al, 'B'
    call serial_putc16
    jmp 0x0000:0x7E00

.no_lba:
    mov si, msg_no_lba
    call print_string
    jmp halt_forever

.disk_error:
    mov si, msg_disk_err
    call print_string
    jmp halt_forever

halt_forever:
    cli
.hang:
    hlt
    jmp .hang

print_string:
    push ax
    push bx
.loop:
    lodsb
    or al, al
    jz .done
    mov ah, 0x0E
    mov bx, 0
    int 0x10
    jmp .loop
.done:
    pop bx
    pop ax
    ret

serial_init16:
    push ax
    push dx
    mov dx, 0x3F9
    xor al, al
    out dx, al
    mov dx, 0x3FB
    mov al, 0x80
    out dx, al
    mov dx, 0x3F8
    mov al, 0x03
    out dx, al
    mov dx, 0x3F9
    xor al, al
    out dx, al
    mov dx, 0x3FB
    mov al, 0x03
    out dx, al
    mov dx, 0x3FC
    mov al, 0x0B
    out dx, al
    pop dx
    pop ax
    ret

serial_putc16:
    push dx
    push ax
    mov dx, 0x3FD
.wait:
    in al, dx
    test al, 0x20
    jz .wait
    pop ax
    mov dx, 0x3F8
    out dx, al
    pop dx
    ret

boot_drive:   db 0
msg_stage1:   db 'ZenithOS: stage1...', 13, 10, 0
msg_ok:       db 'ok, jumping to stage2', 13, 10, 0
msg_no_lba:   db 'FATAL: BIOS has no LBA disk extensions', 13, 10, 0
msg_disk_err: db 'FATAL: disk read error in stage1', 13, 10, 0

dap:
    dap_size:  db 0x10
               db 0
    dap_count: dw 0
    dap_off:   dw 0
    dap_seg:   dw 0
    dap_lba:   dd 0
               dd 0

times 510-($-$$) db 0
dw 0xAA55

stage2_start:
    mov al, 'C'
    call serial_putc16

    mov si, msg_stage2
    call print_string

    call do_e820
    mov al, 'D'
    call serial_putc16

    call enable_a20
    mov al, 'E'
    call serial_putc16

    call setup_vbe
    mov al, 'F'
    call serial_putc16

    call load_kernel
    mov al, 'G'
    call serial_putc16

    mov si, msg_pmode
    call print_string

    mov al, 'H'
    call serial_putc16
    cli
    lgdt [gdt_descriptor]
    mov eax, cr0
    or eax, 1
    mov cr0, eax

    jmp dword CODE_SEL:pm_entry

load_kernel:
    mov si, msg_loading_kernel
    call print_string

    mov word [k_remaining], KERNEL_SECTORS
    mov dword [k_lba], KERNEL_LBA
    mov word [k_seg], KERNEL_LOAD_SEG

.loop:
    cmp word [k_remaining], 0
    je .done

    mov ax, [k_remaining]
    cmp ax, 64
    jbe .small
    mov ax, 64
.small:
    mov [dap_count], ax

    mov word [dap_off], 0
    mov ax, [k_seg]
    mov [dap_seg], ax
    mov eax, [k_lba]
    mov [dap_lba], eax
    mov dword [dap_lba+4], 0

    mov ah, 0x42
    mov dl, [boot_drive]
    mov si, dap
    int 0x13
    jc .disk_error

    mov ax, [dap_count]
    sub [k_remaining], ax
    movzx eax, word [dap_count]

    add [k_lba], eax

    mov bx, ax
    shl bx, 5
    add [k_seg], bx

    jmp .loop

.done:
    mov si, msg_ok
    call print_string
    ret

.disk_error:
    mov si, msg_disk_err
    call print_string
    jmp halt_forever

k_remaining: dw 0
k_lba:       dd 0
k_seg:       dw 0

enable_a20:

    in al, 0x92
    or al, 2
    out 0x92, al

    call kbc_wait_input
    mov al, 0xAD
    out 0x64, al
    call kbc_wait_input
    mov al, 0xD1
    out 0x64, al
    call kbc_wait_input
    mov al, 0xDF
    out 0x60, al
    call kbc_wait_input
    mov al, 0xAE
    out 0x64, al
    call kbc_wait_input
    ret

kbc_wait_input:
    in al, 0x64
    test al, 2
    jnz kbc_wait_input
    ret

do_e820:
    mov di, MMAP_ADDR
    xor ebx, ebx
    xor bp, bp
.next:
    mov eax, 0xE820
    mov ecx, 24
    mov edx, 0x534D4150
    int 0x15
    jc .done
    cmp eax, 0x534D4150
    jne .done
    cmp ecx, 0
    je .skip
    inc bp
    add di, 24
.skip:
    test ebx, ebx
    je .done
    cmp bp, 64
    jae .done
    jmp .next
.done:
    mov [mmap_count], bp
    ret

mmap_count: dw 0

VBE_INFO_ADDR  equ 0xA420
VBE_MODE_ADDR  equ 0xA620

setup_vbe:
    mov si, msg_vbe
    call print_string

    mov di, VBE_INFO_ADDR
    mov dword [di], 0x32454256
    mov ax, 0x4F00
    int 0x10
    cmp ax, 0x004F
    jne .vbe_fail

    mov al, '1'
    call serial_putc16

    mov ax, [VBE_INFO_ADDR + 0x10]
    mov [modelist_seg], ax
    mov ax, [VBE_INFO_ADDR + 0x0E]
    mov [modelist_off], ax

    mov word [best_mode], 0
    mov byte [best_rank], 0
    mov word [scan_guard], 0

    mov al, '2'
    call serial_putc16

.scan_modes:
    mov al, '.'
    call serial_putc16
    inc word [scan_guard]
    cmp word [scan_guard], 512
    jae .scan_done
    mov ax, [modelist_seg]
    mov es, ax
    mov bx, [modelist_off]
    mov ax, [es:bx]
    cmp ax, 0xFFFF
    je .scan_done
    add word [modelist_off], 2

    push ax
    mov cx, ax
    mov di, VBE_MODE_ADDR
    mov ax, 0x4F01
    int 0x10
    pop cx
    cmp ax, 0x004F
    jne .scan_modes

    mov ax, [VBE_MODE_ADDR + 0]
    test ax, 0x0001
    jz .scan_modes
    test ax, 0x0010
    jz .scan_modes
    test ax, 0x0080
    jz .scan_modes

    mov bl, [VBE_MODE_ADDR + 0x19]
    cmp bl, 24
    jb .scan_modes

    cmp word [VBE_MODE_ADDR+0x12], 1024
    jb .scan_modes
    cmp word [VBE_MODE_ADDR+0x14], 768
    jb .scan_modes

    mov al, 0
    cmp bl, 32
    jne .not32bpp
    mov al, 2
    jmp .check_exact
.not32bpp:
    cmp bl, 24
    jne .scan_modes
    mov al, 1
.check_exact:
    cmp word [VBE_MODE_ADDR+0x12], 1024
    jne .have_rank
    cmp word [VBE_MODE_ADDR+0x14], 768
    jne .have_rank
    add al, 2

.have_rank:
    cmp al, [best_rank]
    jbe .scan_modes
    mov [best_rank], al
    mov [best_mode], cx
    jmp .scan_modes

.scan_done:
    xor ax, ax
    mov es, ax
    cmp word [best_mode], 0
    je .vbe_fail

    mov bx, [best_mode]
    or bx, 0x4000
    mov ax, 0x4F02
    int 0x10
    cmp ax, 0x004F
    jne .vbe_fail

    mov cx, [best_mode]
    mov di, VBE_MODE_ADDR
    mov ax, 0x4F01
    int 0x10
    cmp ax, 0x004F
    jne .vbe_fail

    mov eax, [VBE_MODE_ADDR + 0x28]
    mov [BOOT_INFO_ADDR + 0],  eax
    mov ax, [VBE_MODE_ADDR + 0x12]
    mov [BOOT_INFO_ADDR + 4],  ax
    mov ax, [VBE_MODE_ADDR + 0x14]
    mov [BOOT_INFO_ADDR + 6],  ax
    mov al, [VBE_MODE_ADDR + 0x19]
    mov [BOOT_INFO_ADDR + 8],  al
    mov ax, [VBE_MODE_ADDR + 0x10]
    mov [BOOT_INFO_ADDR + 10], ax
    mov byte [BOOT_INFO_ADDR + 12], 1
    mov byte [BOOT_INFO_ADDR + 13], 1

    mov si, msg_ok
    call print_string
    ret

.vbe_fail:
    mov byte [BOOT_INFO_ADDR + 12], 0
    mov si, msg_vbe_fail
    call print_string
    ret

modelist_seg: dw 0
modelist_off: dw 0
best_mode:    dw 0
best_rank:    db 0
scan_guard:   dw 0

msg_stage2:         db 'stage2 running, real mode', 13, 10, 0
msg_vbe:            db 'querying VBE for real framebuffer...', 13, 10, 0
msg_vbe_fail:       db 'WARNING: VBE graphics mode not available', 13, 10, 0
msg_loading_kernel: db 'loading kernel...', 13, 10, 0
msg_pmode:          db 'entering protected mode', 13, 10, 0

align 8
gdt_start:
    dq 0
gdt_code:
    dw 0xFFFF, 0x0000
    db 0x00, 0x9A, 0xCF, 0x00
gdt_data:
    dw 0xFFFF, 0x0000
    db 0x00, 0x92, 0xCF, 0x00
gdt_end:

gdt_descriptor:
    dw gdt_end - gdt_start - 1
    dd gdt_start

CODE_SEL equ gdt_code - gdt_start
DATA_SEL equ gdt_data - gdt_start

BITS 32
pm_entry:
    mov ax, DATA_SEL
    mov ds, ax
    mov es, ax
    mov fs, ax
    mov gs, ax
    mov ss, ax
    mov esp, 0x9F000

    mov al, 'I'
    mov dx, 0x3F8
    out dx, al

    mov dword [BOOT_INFO_ADDR + 16], MMAP_ADDR
    movzx eax, word [mmap_count]
    mov [BOOT_INFO_ADDR + 20], eax
    mov dword [BOOT_INFO_ADDR + 24], 0
    mov dword [BOOT_INFO_ADDR + 28], 0

    mov al, 'J'
    mov dx, 0x3F8
    out dx, al

    mov ebx, BOOT_INFO_ADDR
    jmp KERNEL_LOAD_SEG*16

times (17*512)-($-$$) db 0
